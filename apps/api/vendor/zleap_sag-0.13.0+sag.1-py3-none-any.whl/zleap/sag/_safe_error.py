"""Bound untrusted exception details at public, persistence, and log boundaries."""

from __future__ import annotations


def safe_error_summary(error: BaseException, *, label: str = "dependency failure") -> str:
    """Return a useful summary without copying provider text or response bodies."""

    return f"{label} ({type(error).__name__})"


def safe_error_type(error: BaseException) -> str:
    """Return only the exception class for structured logs and diagnostics."""

    return type(error).__name__


__all__ = ["safe_error_summary", "safe_error_type"]
