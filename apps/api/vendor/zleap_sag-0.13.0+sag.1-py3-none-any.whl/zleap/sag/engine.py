"""DataEngine: resource owner and explicit five-stage convenience facade."""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import uuid
from collections.abc import Awaitable, Callable, Iterable
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import UTC
from functools import wraps
from pathlib import Path
from time import perf_counter
from typing import TYPE_CHECKING, Any, Never, TypeVar, cast

from zleap.sag import _bootstrap
from zleap.sag.core import resources
from zleap.sag.core.adapters import Capability
from zleap.sag.exceptions import ConfigError, InvalidInputError, SagError, StateError
from zleap.sag.runtime import RuntimeGovernor, RuntimeResource
from zleap.sag.utils import get_logger

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from zleap.sag._operation_store import OperationStore
    from zleap.sag._record_store import KnowledgeRecordStore
    from zleap.sag.config import EngineConfig
    from zleap.sag.core.resources import ResourceContainer
    from zleap.sag.core.storage.repositories import RepositoryBundle
    from zleap.sag.maintenance import MaintenancePolicy, MaintenanceResult
    from zleap.sag.modules.search.profiles import SearchProfile
    from zleap.sag.modules.search.registry import SearchExecutorSpec
    from zleap.sag.observability import EngineObserver, OperationEventKind, SearchOutcome
    from zleap.sag.operations import (
        DeleteDataSourceRequest,
        DeleteSourceRequest,
        OperationResult,
        ProcessSourceRequest,
    )
    from zleap.sag.pipeline import (
        CancellationToken,
        ChunkOptions,
        ChunkSet,
        ChunkSetRef,
        EventDetail,
        EventSetRef,
        ExtractionOptions,
        ImageEnricher,
        IndexOptions,
        ParsedSource,
        ParseOptions,
        PersistedChunkSelector,
        PipelineComponents,
        PipelinePlan,
        PipelineRunResult,
        SearchRequest,
        SearchResult,
        SourceDescriptor,
        SourceInput,
        StageObserver,
    )
    from zleap.sag.queries import SearchPage, SearchPageRequest
    from zleap.sag.records import (
        ChunkRecord,
        EvidenceRecord,
        KnowledgeGraph,
        OutlinePage,
        SourceState,
    )
    from zleap.sag.runtime import LimiterSnapshot
    from zleap.sag.status import EngineCapabilities, EngineHealth, SchemaStatus

# 通用默认实体类型(type 小写,对齐抽取 prompt 约定)。全新库首次建表时幂等播种,
# 使 LLM 抽出的实体不被"无效类型"过滤,实体图开箱即用。生产可另配 source 级/自定义类型。
_DEFAULT_ENTITY_TYPES: list[tuple[str, str, str]] = [
    ("person", "Person", "人物 / 个人"),
    ("organization", "Organization", "组织 / 机构 / 公司"),
    ("location", "Location", "地点 / 地理位置"),
    ("product", "Product", "产品 / 服务 / 项目"),
    ("event", "Event", "事件 / 活动"),
    ("time", "Time", "时间 / 日期 / 时段"),
    ("concept", "Concept", "概念 / 术语 / 主题"),
    ("work", "Work", "作品 / 文档 / 成果"),
    ("technology", "Technology", "技术 / 方法 / 工具"),
    ("metric", "Metric", "指标 / 数值 / 度量"),
]

_HEALTH_PROBE_TIMEOUT_SECONDS = 5.0

_Fn = TypeVar("_Fn", bound=Callable[..., Awaitable[Any]])
_SyncFn = TypeVar("_SyncFn", bound=Callable[..., Any])

logger = get_logger("engine")


def _normalize_errors(operation: str) -> Callable[[_Fn], _Fn]:
    """将越过公开边界的非 SagError 异常统一包装为结构化 SagError。"""

    def decorator(fn: _Fn) -> _Fn:
        @wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return await fn(*args, **kwargs)
            except SagError as exc:
                if exc.operation is None:
                    exc.operation = operation
                raise
            except Exception as exc:
                raise SagError.wrap(exc, operation=operation) from exc

        return cast(_Fn, wrapper)

    return decorator


def _normalize_sync_errors(operation: str) -> Callable[[_SyncFn], _SyncFn]:
    """同步公开入口使用的结构化错误边界。"""

    def decorator(fn: _SyncFn) -> _SyncFn:
        @wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return fn(*args, **kwargs)
            except SagError as exc:
                if exc.operation is None:
                    exc.operation = operation
                raise
            except Exception as exc:
                raise SagError.wrap(exc, operation=operation) from exc

        return cast(_SyncFn, wrapper)

    return decorator


def _derive_search_capabilities(
    config: EngineConfig,
    container: ResourceContainer,
) -> frozenset[Capability]:
    """根据当前实例的后端和模型配置推导搜索能力。"""
    capabilities: set[Capability] = {
        Capability.GRAPH_RELATION_LOOKUP,
        Capability.LLM_STRUCTURED_OUTPUT,
        *container.vector.capabilities,
    }
    if config.rerank is not None:
        capabilities.add(Capability.RERANK)
    return frozenset(capabilities)


@dataclass(frozen=True, slots=True)
class _StorageHealthSnapshot:
    schema: Any
    pending_cleanup_sources: int
    pending_cleanup_operations: int
    expired_search_sessions: int
    stale_operations: int


@dataclass(frozen=True, slots=True)
class _ScopeValidatingSearchAdapter:
    """Treat every search adapter response as untrusted provider data."""

    engine: DataEngine
    inner: Any

    async def search(self, request: SearchRequest) -> SearchResult:
        result = await self.inner.search(request)
        return self.engine._validate_search_result_scope(request, result)


@dataclass(frozen=True, slots=True)
class _ManagedPipelineSearchAdapter:
    """Apply DataEngine visibility and concurrency guarantees to ``run()`` searches."""

    engine: DataEngine
    inner: Any

    async def search(self, request: SearchRequest) -> SearchResult:
        async with self.engine._governor.slot(RuntimeResource.SEARCH):
            if self.engine._components is not None:
                return await self.inner.search(request)

            from zleap.sag.core.storage.repositories.search_scope import (
                reset_active_generation_scope,
                set_active_generation_scope,
            )

            visibility = await self.engine._resolve_active_generations(
                request.scope.data_source_ids,
                request.scope.source_ids,
            )
            token = set_active_generation_scope(visibility)
            try:
                return await self.inner.search(request)
            finally:
                reset_active_generation_scope(token)


class DataEngine:
    """SAG 数据引擎。一个实例绑定一个数据源(data_source_id)。"""

    def __init__(
        self,
        config: EngineConfig,
        data_source_id: str | None = None,
        *,
        health_check: bool = True,
        observer: EngineObserver | None = None,
        _components: PipelineComponents | None = None,
    ) -> None:
        if config.storage_mode not in ("normal", "lite"):
            from zleap.sag.exceptions import ConfigError

            raise ConfigError("storage_mode 必须是 normal 或 lite")
        if data_source_id is not None:
            normalized_data_source_id = data_source_id.strip()
            if not normalized_data_source_id:
                from zleap.sag.exceptions import ConfigError

                raise ConfigError("data_source_id 不能为空")
            if len(normalized_data_source_id) > 36:
                from zleap.sag.exceptions import ConfigError

                raise ConfigError("data_source_id 不能超过 36 个字符")
            data_source_id = normalized_data_source_id
        self._config = config
        self._storage_mode = config.storage_mode
        self._data_source_id = data_source_id
        self._health_check = health_check
        self._observer = observer
        self._components = _components
        self._started = False
        self._governor = RuntimeGovernor(config.runtime_limits)

        # 运行时组件(start 后就绪)
        self._resources: ResourceContainer | None = None
        self._session_factory: Any = None
        self._repositories: RepositoryBundle | None = None
        self._extractor: Any = None
        self._source_readers: Any = None
        self._image_enricher: ImageEnricher | None = None
        self._index_adapter: Any = None
        self._extract_adapter: Any = None
        self._event_loader: Any = None
        self._search_adapter: Any = None
        self._record_store: KnowledgeRecordStore | None = None
        self._operation_store: OperationStore | None = None
        self._health_probe_task: asyncio.Task[_StorageHealthSnapshot] | None = None
        self._guard: Any = None
        self._pending_search_algorithms: list[
            tuple[SearchExecutorSpec, tuple[SearchProfile, ...], bool]
        ] = []

    @classmethod
    @_normalize_sync_errors("from_components")
    def from_components(
        cls,
        *,
        config: EngineConfig,
        components: PipelineComponents,
        observer: EngineObserver | None = None,
    ) -> DataEngine:
        """Build external-component mode with an explicit contract validator."""
        if components.validate_contract is None:
            from zleap.sag.exceptions import ConfigError

            raise ConfigError("外部组件模式必须提供 validate_contract")
        return cls(config, health_check=False, observer=observer, _components=components)

    # ── 生命周期 ──────────────────────────────────────────────
    @_normalize_errors("start")
    async def start(self) -> None:
        self._assert_storage_mode_unchanged()
        if self._started:
            return

        if self._components is not None:
            import inspect

            validator = self._components.validate_contract
            if validator is None:
                from zleap.sag.exceptions import ConfigError

                raise ConfigError("外部组件模式缺少 validate_contract")
            validation = validator()
            if inspect.isawaitable(validation):
                await validation
            self._source_readers = self._components.source_readers
            self._image_enricher = self._components.image_enricher
            self._index_adapter = self._components.index_adapter
            self._extract_adapter = self._components.extract_adapter
            self._event_loader = self._components.event_loader
            self._search_adapter = self._components.search_adapter
            self._started = True
            return

        _bootstrap.ensure_local_dirs(self._config)

        # 构建当前实例独占的资源容器(DI 单一事实来源)
        self._resources = resources.build_container(self._config, governor=self._governor)

        try:
            self._session_factory = self._resources.relational.session_factory()
            # fail-fast:启动即检查存储后端连通性,失败给明确错误,不进入半初始化
            if self._health_check:
                await self._resources.relational.ping()
                await self._resources.vector.ping()

            # create_all 不能发现旧表缺字段；独立扫描器必须先识别/校验，再按 provider
            # 规则只补当前模式缺失的完整表，并在创建后复检。
            await self._initialize_storage_schema(explicit_init=False)

            # 惰性导入和组件实例化必须位于 schema 复检之后。
            from zleap.sag import guard
            from zleap.sag._pipeline_adapters import (
                BuiltinEventLoader,
                BuiltinExtractAdapter,
                BuiltinIndexAdapter,
                BuiltinSearchAdapter,
            )
            from zleap.sag.core.storage.repositories import build_repository_bundle
            from zleap.sag.guard.adapter import GuardedSearchAdapter
            from zleap.sag.modules.extract.extractor import EventExtractor
            from zleap.sag.modules.search.catalog import builtin_executor_specs
            from zleap.sag.modules.search.orchestrator import SearchOrchestrator
            from zleap.sag.modules.search.registry import (
                SearchExecutorRegistry,
                SearchProfileRegistry,
            )
            from zleap.sag.modules.search.vector import VectorSearcher
            from zleap.sag.pipeline.parse import SourceReaderRegistry

            prompt_manager = self._resources.prompts
            if prompt_manager is None:
                raise StateError("ResourceContainer 缺少实例级 PromptManager")
            if self._config.vlm is not None:
                from zleap.sag.modules.load.images import BuiltinImageEnricher

                self._image_enricher = BuiltinImageEnricher(
                    vlm=self._resources.require_vlm(),
                    prompt_manager=prompt_manager,
                    options=self._config.image_processing,
                    max_image_bytes=self._config.vlm.max_image_bytes,
                    detail=self._config.vlm.detail,
                    model_name=self._config.vlm.model,
                )
            self._repositories = build_repository_bundle(
                self._resources.relational,
                self._resources.vector,
                storage_mode=self._storage_mode,
            )
            self._extractor = EventExtractor(
                prompt_manager=prompt_manager,
                session_factory=self._session_factory,
                repositories=self._repositories,
                embedding=self._resources.embedding,
                llm=self._resources.llm,
            )
            vector_searcher = VectorSearcher(
                session_factory=self._session_factory,
                repositories=self._repositories,
                embedding=self._resources.embedding,
            )
            self._source_readers = SourceReaderRegistry()
            self._index_adapter = BuiltinIndexAdapter(
                session_factory=self._session_factory,
                repositories=self._repositories,
                embedding=self._resources.embedding,
                storage_mode=self._storage_mode,
                embedding_concurrency=self._config.runtime_limits.embedding_concurrency,
                vector_write_concurrency=self._config.runtime_limits.vector_write_concurrency,
            )
            self._extract_adapter = BuiltinExtractAdapter(
                session_factory=self._session_factory,
                extractor=self._extractor,
                storage_mode=self._storage_mode,
                embedding_dimensions=self._config.embedding.schema_dimensions,
                llm_concurrency=self._config.runtime_limits.llm_concurrency,
                embedding_concurrency=self._config.runtime_limits.embedding_concurrency,
                vector_write_concurrency=self._config.runtime_limits.vector_write_concurrency,
            )
            self._event_loader = BuiltinEventLoader(session_factory=self._session_factory)
            search_capabilities = _derive_search_capabilities(self._config, self._resources)
            logger.info(
                "[搜索能力] rerank=%s, capabilities=%s",
                self._config.rerank is not None,
                sorted(capability.value for capability in search_capabilities),
            )
            profile_registry = SearchProfileRegistry.with_builtins()
            executor_registry = SearchExecutorRegistry(
                builtin_executor_specs(
                    session_factory=self._session_factory,
                    repositories=self._repositories,
                    vector_searcher=vector_searcher,
                    embedding=self._resources.embedding,
                    llm=self._resources.llm,
                    rerank=self._resources.rerank,
                    prompts=prompt_manager,
                    available_capabilities=search_capabilities,
                )
            )
            for spec, registered_profiles, replace in self._pending_search_algorithms:
                for profile in registered_profiles:
                    profile_registry.register(profile, replace=replace)
                executor_registry.register(spec, replace=replace)
            executor_registry.validate_profiles(profile_registry)
            profile_registry.freeze()
            executor_registry.freeze()
            search_orchestrator = SearchOrchestrator(
                profiles=profile_registry,
                executors=executor_registry,
                available_capabilities=search_capabilities,
                storage_mode=self._storage_mode,
            )
            self._search_adapter = BuiltinSearchAdapter(
                orchestrator=search_orchestrator,
            )
            guard_config = self._config.guard
            self._guard = guard.build(guard_config)
            if self._guard is not None and guard_config is not None:
                self._search_adapter = GuardedSearchAdapter(
                    self._search_adapter,
                    self._guard,
                    guard_config.policy,
                )
                await self._guard.warmup()
            self._started = True
        except Exception:
            # 启动失败:回滚上下文/资源,不留半初始化状态
            await self._rollback_start()
            raise

    async def _rollback_start(self) -> None:
        """start 失败时关闭当前实例资源并清空半初始化组件。"""
        await self._stop_health_probe()
        try:
            if self._image_enricher is not None:
                await self._image_enricher.aclose()
        except Exception:
            pass
        try:
            if self._resources is not None:
                await self._resources.aclose()
        except Exception:
            pass
        self._resources = None
        self._session_factory = self._repositories = None
        self._extractor = None
        self._source_readers = None
        self._image_enricher = None
        self._index_adapter = self._extract_adapter = self._event_loader = None
        self._search_adapter = None
        self._record_store = None
        self._operation_store = None
        self._guard = None

    @_normalize_errors("aclose")
    async def aclose(self) -> None:
        if not self._started:
            return
        try:
            await self._stop_health_probe()
            components = getattr(self, "_components", None)
            if components is not None and components.aclose is not None:
                import inspect

                result = components.aclose()
                if inspect.isawaitable(result):
                    await result
            else:
                try:
                    if self._image_enricher is not None:
                        await self._image_enricher.aclose()
                finally:
                    if self._resources is not None:
                        await self._resources.aclose()
        finally:
            self._resources = None
            self._session_factory = self._repositories = None
            self._extractor = None
            self._source_readers = None
            self._image_enricher = None
            self._index_adapter = self._extract_adapter = self._event_loader = None
            self._search_adapter = None
            self._record_store = None
            self._operation_store = None
            self._health_probe_task = None
            self._guard = None
            self._started = False

    async def _stop_health_probe(self) -> None:
        task = getattr(self, "_health_probe_task", None)
        self._health_probe_task = None
        if task is None:
            return
        if not task.done():
            task.cancel()
        try:
            await task
        except (Exception, asyncio.CancelledError):
            # Health is diagnostic. A failed/cancelled probe must not prevent
            # deterministic release of the instance-owned storage resources.
            pass

    @property
    @_normalize_sync_errors("resources")
    def resources(self) -> ResourceContainer:
        """当前引擎的资源容器(适配器集合);未启动时报错。"""
        if self._resources is None:
            raise StateError("DataEngine 未启动:请先 await engine.start() 或使用 async with")
        return self._resources

    async def __aenter__(self) -> DataEngine:
        await self.start()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    @property
    def data_source_id(self) -> str | None:
        """当前绑定的数据源 ID(首次写入/检索时确定)。"""
        return self._data_source_id

    @property
    def storage_mode(self) -> str:
        """构造引擎时冻结的物理存储模式。"""
        return self._storage_mode

    @property
    def runtime_snapshot(self) -> dict[RuntimeResource, LimiterSnapshot]:
        """Return current per-resource concurrency counters for metrics and tests."""
        return self._governor.snapshot()

    def capabilities(self) -> EngineCapabilities:
        """Describe public guarantees without requiring storage connectivity."""
        from zleap.sag.status import EngineCapabilities

        durable = self._components is None
        return EngineCapabilities(
            strict_processing=durable,
            caller_owned_ids=True,
            operation_replay=durable,
            durable_operation_status=durable,
            scoped_fencing=durable,
            multi_namespace_search=True,
            search_pagination=durable,
            document_delete=durable,
            namespace_delete=durable,
            outline_read=durable,
            evidence_read=durable,
            graph_read=durable,
            bounded_maintenance=durable,
        )

    async def schema_status(self) -> SchemaStatus:
        """Inspect the current schema without creating or altering any object."""
        self._require_started()
        if self._components is not None or self._resources is None:
            from zleap.sag.pipeline import UnsupportedStageOptionError

            raise UnsupportedStageOptionError(
                "external component mode does not expose SAG schema status",
                stage="schema_status",
                code="schema_status_unavailable",
            )

        from zleap.sag.core.storage.schema import prepare_vector_schema
        from zleap.sag.db.schema import (
            SchemaContractValidator,
            inspect_relation_schema,
        )
        from zleap.sag.db.version import CURRENT_SCHEMA_VERSION
        from zleap.sag.status import SchemaState, SchemaStatus

        relation = await inspect_relation_schema(self._resources.relational.engine())
        validation = SchemaContractValidator.validate(relation, self._storage_mode)
        vector = await prepare_vector_schema(
            self._resources.vector,
            storage_mode=self._storage_mode,
            dimensions=self._config.embedding.schema_dimensions,
            create_missing=False,
        )
        if validation.schema_diffs:
            state = SchemaState.MISMATCH
        elif validation.missing_tables:
            state = SchemaState.MISSING
        else:
            state = SchemaState.READY
        return SchemaStatus(
            state=state,
            storage_mode=self._storage_mode,
            expected_version=CURRENT_SCHEMA_VERSION,
            actual_version=relation.schema_version,
            missing_relation_tables=validation.missing_tables,
            relation_diffs=validation.schema_diffs,
            vector_objects=tuple(sorted(vector.object_names)),
            missing_vector_objects=vector.missing_objects,
        )

    async def _probe_storage_health(self, *, deep: bool) -> _StorageHealthSnapshot:
        from sqlalchemy import func, select

        from zleap.sag.db import (
            SAGOperation,
            SAGSearchSession,
            SAGSourceManifest,
        )

        schema = await self.schema_status()
        async with self._session_factory() as session:
            pending_cleanup_sources = int(
                await session.scalar(
                    select(func.count())
                    .select_from(SAGSourceManifest)
                    .where(SAGSourceManifest.cleanup_required.is_(True))
                )
                or 0
            )
            pending_cleanup = int(
                await session.scalar(
                    select(func.count(SAGOperation.operation_id)).where(
                        SAGOperation.operation_type == "process_source",
                        SAGOperation.status == "failed",
                        SAGOperation.retryable.is_(False),
                        SAGOperation.cleanup_completed_at.is_(None),
                    )
                )
                or 0
            )
            expired_search_sessions = int(
                await session.scalar(
                    select(func.count())
                    .select_from(SAGSearchSession)
                    .where(SAGSearchSession.expires_at <= func.now())
                )
                or 0
            )
            stale_operations = int(
                await session.scalar(
                    select(func.count())
                    .select_from(SAGOperation)
                    .where(
                        SAGOperation.status == "running",
                        SAGOperation.lease_expires_at.is_not(None),
                        SAGOperation.lease_expires_at <= func.now(),
                    )
                )
                or 0
            )
        if deep and self._resources is not None:
            await self._resources.relational.ping()
            await self._resources.vector.ping()
        return _StorageHealthSnapshot(
            schema=schema,
            pending_cleanup_sources=pending_cleanup_sources,
            pending_cleanup_operations=pending_cleanup,
            expired_search_sessions=expired_search_sessions,
            stale_operations=stale_operations,
        )

    def _health_probe_finished(
        self,
        task: asyncio.Task[_StorageHealthSnapshot],
    ) -> None:
        try:
            task.exception()
        except asyncio.CancelledError:
            pass
        if self._health_probe_task is task:
            self._health_probe_task = None

    async def health(self, *, deep: bool = False) -> EngineHealth:
        """Return bounded machine-readable readiness, including cleanup debt."""
        from zleap.sag.status import (
            EngineHealth,
            EngineHealthIssue,
            EngineHealthIssueCode,
            EngineHealthState,
        )

        runtime = {
            resource.value: {
                "limit": snapshot.limit,
                "active": snapshot.active,
                "waiting": snapshot.waiting,
                "peak_active": snapshot.peak_active,
            }
            for resource, snapshot in self._governor.snapshot().items()
        }
        if not self._started:
            return EngineHealth(
                state=EngineHealthState.UNAVAILABLE,
                issues=(
                    EngineHealthIssue(
                        code=EngineHealthIssueCode.NOT_STARTED,
                        message="DataEngine is not started",
                    ),
                ),
                runtime=runtime,
            )

        issues: list[EngineHealthIssue] = []
        schema = None
        pending_cleanup_sources = 0
        pending_cleanup = 0
        expired_search_sessions = 0
        stale_operations = 0
        if self._components is None:
            probe = self._health_probe_task
            if probe is None or probe.done():
                probe = asyncio.create_task(self._probe_storage_health(deep=deep))
                self._health_probe_task = probe
                probe.add_done_callback(self._health_probe_finished)
            probe_done = probe.done()
            if not probe_done and not probe.cancelling():
                completed, _pending = await asyncio.wait(
                    (probe,),
                    timeout=_HEALTH_PROBE_TIMEOUT_SECONDS,
                )
                probe_done = probe in completed
            if not probe_done:
                issues.append(
                    EngineHealthIssue(
                        code=EngineHealthIssueCode.DEPENDENCY_UNAVAILABLE,
                        message="SAG storage dependency probe exceeded its time limit",
                    )
                )
            else:
                try:
                    snapshot = probe.result()
                except (Exception, asyncio.CancelledError):
                    issues.append(
                        EngineHealthIssue(
                            code=EngineHealthIssueCode.DEPENDENCY_UNAVAILABLE,
                            message="SAG storage dependency probe failed",
                        )
                    )
                else:
                    schema = snapshot.schema
                    pending_cleanup_sources = snapshot.pending_cleanup_sources
                    pending_cleanup = snapshot.pending_cleanup_operations
                    expired_search_sessions = snapshot.expired_search_sessions
                    stale_operations = snapshot.stale_operations
                    if not schema.ready:
                        issues.append(
                            EngineHealthIssue(
                                code=EngineHealthIssueCode.SCHEMA_MISMATCH,
                                message="SAG storage schema is not at the current baseline",
                            )
                        )
                    if pending_cleanup_sources or pending_cleanup:
                        issues.append(
                            EngineHealthIssue(
                                code=EngineHealthIssueCode.CLEANUP_PENDING,
                                message=(
                                    f"{pending_cleanup_sources} source cleanup debt item(s) and "
                                    f"{pending_cleanup} failed generation cleanup operation(s) "
                                    "pending"
                                ),
                            )
                        )

        unavailable_codes = {
            EngineHealthIssueCode.NOT_STARTED,
            EngineHealthIssueCode.SCHEMA_MISMATCH,
            EngineHealthIssueCode.DEPENDENCY_UNAVAILABLE,
        }
        state = (
            EngineHealthState.UNAVAILABLE
            if any(issue.code in unavailable_codes for issue in issues)
            else EngineHealthState.DEGRADED
            if issues
            else EngineHealthState.AVAILABLE
        )
        return EngineHealth(
            state=state,
            issues=tuple(issues),
            storage_schema=schema,
            pending_cleanup_sources=pending_cleanup_sources,
            pending_cleanup_operations=pending_cleanup,
            expired_search_sessions=expired_search_sessions,
            stale_operations=stale_operations,
            runtime=runtime,
        )

    def _assert_storage_mode_unchanged(self) -> None:
        if self._config.storage_mode != self._storage_mode:
            from zleap.sag.exceptions import ConfigError

            raise ConfigError("DataEngine 生命周期内禁止热切换 storage_mode；请创建新引擎")

    @_normalize_errors("init_schema")
    async def init_schema(self) -> None:
        """显式创建当前模式缺失的完整表；可在 ``start()`` 之前调用。

        已有表会先经过逐字段/约束校验；本方法不会 ALTER、DROP 或迁移旧表。
        """
        self._assert_storage_mode_unchanged()
        if self._started:
            await self._initialize_storage_schema(explicit_init=True)
            return

        _bootstrap.ensure_local_dirs(self._config)
        self._resources = resources.build_container(self._config, governor=self._governor)
        try:
            if self._health_check:
                await self._resources.relational.ping()
            self._session_factory = self._resources.relational.session_factory()
            await self._initialize_storage_schema(explicit_init=True)
        finally:
            await self._rollback_start()

    async def _initialize_storage_schema(self, *, explicit_init: bool) -> None:
        """先扫向量与关系结构，再模式化建整表并复检。"""
        from zleap.sag.core.storage.schema import prepare_vector_schema
        from zleap.sag.db.schema import prepare_relation_schema

        rel = self._config.relational
        if rel is None:  # EngineConfig 已保证，此处仅为类型收窄
            raise ConfigError("relational 配置缺失")
        if self._resources is None:
            raise StateError("存储资源尚未构建")

        # 第一次向量扫描严格只读：错连/旧 Arrow schema 必须发生在任何关系 DDL 前。
        vector_scan = await prepare_vector_schema(
            self._resources.vector,
            storage_mode=self._storage_mode,
            dimensions=self._config.embedding.schema_dimensions,
            create_missing=False,
            enforce_mode=False,
        )
        vector_provider = getattr(self._resources.vector, "provider", None)
        may_create_vector = explicit_init or vector_provider == "lancedb"
        if vector_scan.missing_objects and not may_create_vector:
            from zleap.sag.exceptions import StorageInitializationRequiredError

            raise StorageInitializationRequiredError(
                "向量存储缺少当前模式对象，请先显式调用 init_schema()",
                missing_objects=list(vector_scan.missing_objects),
            )
        await prepare_relation_schema(
            self._resources.relational.engine(),
            provider=rel.provider,
            storage_mode=self._storage_mode,
            explicit_init=explicit_init,
            normal_vector_objects=vector_scan.object_names,
            vector_mode=vector_scan.state.value,
        )
        # 只预建维度可静态确定的对象；其余对象由首次真实向量写入推断模型维度。
        await prepare_vector_schema(
            self._resources.vector,
            storage_mode=self._storage_mode,
            dimensions=self._config.embedding.schema_dimensions,
            create_missing=may_create_vector,
        )
        # replace 模式:对 scope="global" 实体类型做幂等 upsert(按 type 更新已存在、
        # 插入缺失),保证与目标 entity_types 完全一致,且不破坏已有 entity 的外键引用。
        # 注意:不能用 DELETE 清空——Entity.entity_type_id 外键是 ondelete=RESTRICT。
        if self._config.entity_types_mode == "replace":
            if self._config.entity_types:
                specs = [
                    (e.type, e.name or e.type.capitalize(), e.description)
                    for e in self._config.entity_types
                ]
                await self._upsert_global_entity_types(specs)
            return
        # 内建默认类型:仅当库中完全没有全局实体类型时播种(不覆盖生产已有集,让实体图开箱即用)
        await self._seed_entity_types(_DEFAULT_ENTITY_TYPES, only_if_empty=True)
        # 用户自定义类型:逐个幂等追加(已存在按 type 名跳过,只加新的)
        if self._config.entity_types:
            specs = [
                (e.type, e.name or e.type.capitalize(), e.description)
                for e in self._config.entity_types
            ]
            await self._seed_entity_types(specs, only_if_empty=False)

    async def _upsert_global_entity_types(self, specs: list[tuple[str, str, str]]) -> None:
        """对 scope="global" 实体类型按 type 幂等 upsert(供 entity_types_mode="replace" 使用)。

        已存在的按 type 更新 name/description,缺失的插入;不删除任何记录,
        因此不会破坏 Entity.entity_type_id 的外键引用(ondelete=RESTRICT)。
        """
        import uuid

        from sqlalchemy import select

        from zleap.sag.db.models import EntityType

        if self._session_factory is None:
            raise StateError("关系 Store 尚未初始化")
        async with self._session_factory() as session:
            rows = (
                (await session.execute(select(EntityType).where(EntityType.scope == "global")))
                .scalars()
                .all()
            )
            by_type = {row.type: row for row in rows}
            wanted = {type_id for type_id, _, _ in specs}
            for type_id, name, description in specs:
                existing = by_type.get(type_id)
                if existing is not None:
                    existing.name = name
                    existing.description = description
                    existing.is_active = True
                    continue
                session.add(
                    EntityType(
                        id=str(uuid.uuid4()),
                        scope="global",
                        data_source_id=None,
                        type=type_id,
                        name=name,
                        description=description,
                        is_default=True,
                        is_active=True,
                    )
                )
            # 停用目标集合之外的全局类型(不删除,避免破坏已有 entity 外键),
            # 使 replace 语义与"目标 entity_types 完全一致"对齐。
            for row in rows:
                if row.type not in wanted:
                    row.is_active = False
            await session.commit()

    async def _seed_entity_types(
        self, specs: list[tuple[str, str, str]], only_if_empty: bool
    ) -> None:
        """幂等播种全局实体类型(is_default=True)。

        抽取阶段仅保留"已定义实体类型"内的实体;声明类型可让 LLM 抽出并保留这些实体。

        - ``only_if_empty=True``:仅当库中无任何全局类型时才播种(内建默认集,不与生产已有集冲突);
        - ``only_if_empty=False``:逐个按 ``type`` 名追加,已存在跳过(自定义类型,"只加新的")。
        """
        import uuid

        from sqlalchemy import select

        from zleap.sag.db.models import EntityType

        if self._session_factory is None:
            raise StateError("关系 Store 尚未初始化")
        factory = self._session_factory
        async with factory() as session:
            existing = {
                r[0]
                for r in (
                    await session.execute(
                        select(EntityType.type).where(EntityType.scope == "global")
                    )
                ).all()
            }
            if only_if_empty and existing:
                return  # 已有全局类型 → 不动内建默认集
            added = 0
            for type_id, name, description in specs:
                if type_id in existing:
                    continue  # 已存在 → 跳过
                session.add(
                    EntityType(
                        id=str(uuid.uuid4()),
                        scope="global",
                        data_source_id=None,
                        type=type_id,
                        name=name,
                        description=description,
                        is_default=True,
                        is_active=True,
                    )
                )
                existing.add(type_id)
                added += 1
            if added:
                await session.commit()

    # ── 显式五阶段入口 ────────────────────────────────────────
    @_normalize_errors("parse")
    async def parse(
        self,
        source: SourceInput,
        options: ParseOptions | None = None,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> ParsedSource:
        """Read and normalize a source without writing SAG storage."""
        return await self._parse(
            source,
            options,
            observer=observer,
            cancellation=cancellation,
        )

    async def _parse(
        self,
        source: SourceInput,
        options: ParseOptions | None = None,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> ParsedSource:
        from zleap.sag.pipeline import ParseStage

        external_image_enricher = (
            self._components.image_enricher if self._components is not None else None
        )
        if (
            self._config.vlm is not None or external_image_enricher is not None
        ) and not self._started:
            raise StateError(
                "图片处理需要已启动的 DataEngine；请先 await engine.start() 或使用 async with"
            )

        return await ParseStage().run(
            source,
            options,
            context=self._pipeline_context(observer=observer, cancellation=cancellation),
        )

    @_normalize_errors("chunk")
    async def chunk(
        self,
        parsed: ParsedSource,
        options: ChunkOptions | None = None,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> ChunkSet:
        """Deterministically chunk an explicit ParsedSource without storage I/O."""
        return await self._chunk(
            parsed,
            options,
            observer=observer,
            cancellation=cancellation,
        )

    async def _chunk(
        self,
        parsed: ParsedSource,
        options: ChunkOptions | None = None,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> ChunkSet:
        from zleap.sag.pipeline import ChunkStage

        return await ChunkStage().run(
            parsed,
            options,
            context=self._pipeline_context(observer=observer, cancellation=cancellation),
        )

    @_normalize_errors("chunk_text")
    async def chunk_text(
        self,
        text: str,
        descriptor: SourceDescriptor,
        options: ChunkOptions | None = None,
    ) -> ChunkSet:
        """Explicit Parse+Chunk convenience for already available text."""
        from zleap.sag.pipeline import TextSource

        parsed = await self._parse(TextSource(text=text, descriptor=descriptor))
        return await self._chunk(parsed, options)

    @_normalize_errors("index")
    async def index(
        self,
        chunks: ChunkSet,
        descriptor: SourceDescriptor,
        options: IndexOptions | None = None,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> ChunkSetRef:
        """Persist source/chunk relations, then independently upsert chunk vectors."""
        return await self._index(
            chunks,
            descriptor,
            options,
            observer=observer,
            cancellation=cancellation,
        )

    async def _index(
        self,
        chunks: ChunkSet,
        descriptor: SourceDescriptor,
        options: IndexOptions | None = None,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> ChunkSetRef:
        self._require_started()
        from zleap.sag.pipeline import IndexStage

        async with self._governor.slot(RuntimeResource.MUTATION):
            return await IndexStage().run(
                chunks,
                descriptor,
                options,
                context=self._pipeline_context(observer=observer, cancellation=cancellation),
            )

    @_normalize_errors("extract")
    async def extract(
        self,
        target: ChunkSetRef | PersistedChunkSelector,
        options: ExtractionOptions | None = None,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> EventSetRef:
        """Extract from an explicit persisted reference; no last-run state exists."""
        self._require_started()
        from zleap.sag.pipeline import ExtractStage

        async with self._governor.slot(RuntimeResource.MUTATION):
            return await ExtractStage().run(
                target,
                options,
                context=self._pipeline_context(observer=observer, cancellation=cancellation),
            )

    @_normalize_errors("load_events")
    async def load_events(self, event_ref: EventSetRef) -> tuple[EventDetail, ...]:
        """Reload an EventSetRef as portable event DTOs without exposing ORM state."""
        self._require_started()
        if self._event_loader is None:
            from zleap.sag.pipeline import UnsupportedStageOptionError

            raise UnsupportedStageOptionError(
                "当前 DataEngine 组件未提供 EventSetRef 重载能力",
                stage="load_events",
                code="event_loader_unavailable",
            )
        return await self._event_loader.load_events(event_ref)

    @_normalize_errors("search")
    async def search(
        self,
        request: SearchRequest,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> SearchResult:
        """Run a read-only search with an explicit data/source/time scope."""
        return await self._search(
            request,
            observer=observer,
            cancellation=cancellation,
        )

    async def _search(
        self,
        request: SearchRequest,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> SearchResult:
        self._require_started()
        from zleap.sag.core.storage.repositories.search_scope import (
            reset_active_generation_scope,
            set_active_generation_scope,
        )
        from zleap.sag.pipeline import SearchStage

        started_at = perf_counter()
        try:
            async with self._governor.slot(RuntimeResource.SEARCH):
                visibility = (
                    None
                    if self._components is not None
                    else await self._resolve_active_generations(
                        request.scope.data_source_ids,
                        request.scope.source_ids,
                    )
                )
                result = await self._search_with_visibility(
                    request,
                    visibility,
                    search_stage=SearchStage(),
                    observer=observer,
                    cancellation=cancellation,
                    set_scope=set_active_generation_scope,
                    reset_scope=reset_active_generation_scope,
                )
        except Exception as exc:
            await self._emit_search_event(
                request,
                outcome=self._search_failure_outcome(exc),
                duration_seconds=perf_counter() - started_at,
                paged=False,
                resumed=False,
            )
            raise
        await self._emit_search_event(
            request,
            outcome="succeeded",
            duration_seconds=perf_counter() - started_at,
            paged=False,
            resumed=False,
            result_count=len(result.events) if result.events else len(result.chunks),
        )
        return result

    async def search_page(self, query: SearchPageRequest) -> SearchPage:
        """Execute or resume a stable, multi-process cursor search snapshot."""
        self._require_started()
        if self._components is not None:
            from zleap.sag.pipeline import UnsupportedStageOptionError

            raise UnsupportedStageOptionError(
                "external component mode does not provide durable search pagination",
                stage="search",
                code="search_pagination_unavailable",
            )
        from zleap.sag._search_store import SearchSessionStore

        store = SearchSessionStore(self._session_factory)
        resumed = query.cursor is not None
        request = query.cursor_request if resumed else query.request
        assert request is not None
        from zleap.sag.core.storage.repositories.search_scope import (
            reset_active_generation_scope,
            set_active_generation_scope,
        )
        from zleap.sag.pipeline import SearchStage

        started_at = perf_counter()
        try:
            async with self._governor.slot(RuntimeResource.SEARCH):
                if resumed:
                    assert query.cursor is not None
                    page = await store.resume(query.cursor, request)
                    self._validate_search_result_scope(request, page.result)
                else:
                    visibility = await self._resolve_active_generations(
                        request.scope.data_source_ids,
                        request.scope.source_ids,
                    )
                    result = await self._search_with_visibility(
                        request,
                        visibility,
                        search_stage=SearchStage(),
                        set_scope=set_active_generation_scope,
                        reset_scope=reset_active_generation_scope,
                    )
                    page = await store.create(
                        request,
                        result,
                        page_size=query.page_size,
                        ttl_seconds=query.ttl_seconds,
                        visibility=visibility,
                    )
        except Exception as exc:
            await self._emit_search_event(
                request,
                outcome=self._search_failure_outcome(exc),
                duration_seconds=perf_counter() - started_at,
                paged=True,
                resumed=resumed,
            )
            raise
        await self._emit_search_event(
            request,
            outcome="succeeded",
            duration_seconds=perf_counter() - started_at,
            paged=True,
            resumed=resumed,
            result_count=(
                len(page.result.events) if page.result.events else len(page.result.chunks)
            ),
        )
        return page

    async def _emit_search_event(
        self,
        request: SearchRequest,
        *,
        outcome: SearchOutcome | str,
        duration_seconds: float,
        paged: bool,
        resumed: bool,
        result_count: int = 0,
    ) -> None:
        from zleap.sag.observability import (
            SearchEvent,
            SearchOutcome,
            SearchStrategyMetric,
            notify_engine_observer,
        )

        await notify_engine_observer(
            self._observer,
            SearchEvent(
                outcome=SearchOutcome(outcome),
                strategy=SearchStrategyMetric.from_strategy(request.options.strategy),
                return_type=request.options.return_type,
                paged=paged,
                resumed=resumed,
                duration_seconds=duration_seconds,
                result_count=result_count,
            ),
        )

    @staticmethod
    def _search_failure_outcome(exc: Exception) -> SearchOutcome:
        from zleap.sag.exceptions import (
            AIError,
            CursorExpiredError,
            CursorInvalidError,
            InvalidInputError,
            LLMError,
            RetryableError,
            SearchSessionTooLargeError,
            StorageError,
        )
        from zleap.sag.observability import SearchOutcome

        causes: list[BaseException] = []
        current: BaseException | None = exc
        seen: set[int] = set()
        while current is not None and id(current) not in seen:
            seen.add(id(current))
            causes.append(current)
            current = current.__cause__ or current.__context__
        if any(isinstance(error, CursorExpiredError) for error in causes):
            return SearchOutcome.CURSOR_EXPIRED
        if any(isinstance(error, CursorInvalidError) for error in causes):
            return SearchOutcome.CURSOR_INVALID
        if any(
            isinstance(error, (StorageError, LLMError, AIError, RetryableError, OSError))
            for error in causes
        ):
            return SearchOutcome.DEPENDENCY_UNAVAILABLE
        if any(
            isinstance(error, (SearchSessionTooLargeError, InvalidInputError, ValueError))
            for error in causes
        ):
            return SearchOutcome.REQUEST_REJECTED
        return SearchOutcome.EXECUTION_FAILED

    async def _search_with_visibility(
        self,
        request: SearchRequest,
        visibility: Any,
        *,
        search_stage: Any,
        set_scope: Any,
        reset_scope: Any,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> SearchResult:
        token = set_scope(visibility) if visibility is not None else None
        try:
            return await search_stage.run(
                request,
                context=self._pipeline_context(observer=observer, cancellation=cancellation),
            )
        finally:
            if token is not None:
                reset_scope(token)

    def _validate_search_result_scope(
        self,
        request: SearchRequest,
        result: SearchResult,
    ) -> SearchResult:
        """Fail closed if a backend returns a hit outside the authorized scope."""

        from zleap.sag.pipeline import SearchGraph, SearchStageError

        def reject_scope() -> Never:
            raise SearchStageError(
                "search backend returned a result outside the requested scope",
                stage="search",
                code="search_scope_violation",
            )

        def reject_contract() -> Never:
            raise SearchStageError(
                "search backend returned an invalid result contract",
                stage="search",
                code="search_result_contract_violation",
            )

        allowed_data_sources = frozenset(request.scope.data_source_ids)
        allowed_sources = frozenset(request.scope.source_ids)
        if result.original_query != request.query:
            reject_contract()
        if result.rewritten_query is None:
            if result.query != request.query:
                reject_contract()
        elif result.query != result.rewritten_query:
            reject_contract()
        if request.options.return_type == "chunk" and result.events:
            reject_contract()
        if request.options.return_type == "event" and result.chunks:
            reject_contract()

        hit_identities: set[tuple[str, str, str]] = set()
        for hit in (*result.events, *result.chunks):
            if (
                hit.data_source_id not in allowed_data_sources
                or not hit.source_id
                or (allowed_sources and hit.source_id not in allowed_sources)
            ):
                reject_scope()
            if (
                not hit.id.strip()
                or not hit.content.strip()
                or (hit.score is not None and not math.isfinite(hit.score))
            ):
                reject_contract()
            identity = (hit.data_source_id, hit.source_id, hit.id)
            if identity in hit_identities:
                reject_contract()
            hit_identities.add(identity)

        if result.graph is None:
            if result.paths is not None:
                reject_contract()
            return result
        try:
            graph = SearchGraph.model_validate(result.graph)
        except Exception:
            reject_contract()

        nodes_by_id = {node.id: node for node in graph.nodes}
        if len(nodes_by_id) != len(graph.nodes):
            reject_contract()
        query_texts = {
            value
            for value in (
                request.query,
                result.query,
                result.original_query,
                result.rewritten_query,
            )
            if value
        }
        for node in graph.nodes:
            if node.type == "query":
                if node.content not in query_texts:
                    reject_contract()
                continue
            data_source_id = node.metadata.get("data_source_id")
            source_id = node.metadata.get("source_id")
            if not isinstance(data_source_id, str) or data_source_id not in allowed_data_sources:
                reject_scope()
            if node.type in {"event", "chunk"} and not isinstance(source_id, str):
                reject_scope()
            if allowed_sources and isinstance(source_id, str) and source_id not in allowed_sources:
                reject_scope()

        hit_ids = {hit.id for hit in (*result.events, *result.chunks)}
        target_type = request.options.return_type
        if any(
            hit_id not in nodes_by_id or nodes_by_id[hit_id].type != target_type
            for hit_id in hit_ids
        ):
            reject_contract()

        clues_by_id = {clue.id: clue for clue in graph.clues}
        if len(clues_by_id) != len(graph.clues) or any(
            clue.from_id not in nodes_by_id or clue.to_id not in nodes_by_id for clue in graph.clues
        ):
            reject_contract()
        if result.paths is not None:
            path_targets = set(result.paths.candidate_paths)
            if (
                path_targets != set(result.paths.shortest_paths)
                or path_targets != set(result.paths.longest_paths)
                or not path_targets.issubset(hit_ids)
            ):
                reject_contract()

            def valid_path(target_id: str, path: tuple[Any, ...]) -> bool:
                if not path or path[-1].to_id != target_id:
                    return False
                if any(clues_by_id.get(clue.id) != clue for clue in path):
                    return False
                if any(
                    left.to_id != right.from_id for left, right in zip(path, path[1:], strict=False)
                ):
                    return False
                origin = nodes_by_id.get(path[0].from_id)
                return origin is not None and origin.type == "query" and origin.category == "origin"

            for target_id, candidates in result.paths.candidate_paths.items():
                if not candidates or any(not valid_path(target_id, path) for path in candidates):
                    reject_contract()
                if result.paths.shortest_paths[target_id] not in candidates:
                    reject_contract()
                if result.paths.longest_paths[target_id] not in candidates:
                    reject_contract()
            if any(
                nodes_by_id.get(node.id) != node
                for nodes in result.paths.nodes_by_depth.values()
                for node in nodes
            ):
                reject_contract()
        return result

    async def _resolve_active_generations(
        self,
        data_source_ids: tuple[str, ...],
        source_ids: tuple[str, ...] = (),
    ) -> Any:
        """Capture one manifest snapshot so a search never mixes two generations."""
        from sqlalchemy import select

        from zleap.sag.core.storage.repositories.search_scope import (
            ActiveGeneration,
            ActiveGenerationScope,
        )
        from zleap.sag.db import SAGDataSourceManifest, SAGSourceManifest

        statement = select(SAGSourceManifest).where(
            SAGSourceManifest.data_source_id.in_(list(data_source_ids))
        )
        if source_ids:
            statement = statement.where(SAGSourceManifest.source_id.in_(list(source_ids)))
        async with self._session_factory() as session:
            manifests = list((await session.scalars(statement)).all())
            data_manifests = list(
                (
                    await session.scalars(
                        select(SAGDataSourceManifest).where(
                            SAGDataSourceManifest.data_source_id.in_(list(data_source_ids))
                        )
                    )
                ).all()
            )
        return ActiveGenerationScope(
            data_source_ids=tuple(data_source_ids),
            generations=tuple(
                ActiveGeneration(
                    data_source_id=str(row.data_source_id),
                    source_id=str(row.source_id),
                    generation_id=str(row.active_generation_id),
                )
                for row in manifests
                if row.status == "ready" and row.active_generation_id is not None
            ),
            managed_sources=tuple(
                (str(row.data_source_id), str(row.source_id)) for row in manifests
            ),
            inactive_data_source_ids=tuple(
                str(row.data_source_id) for row in data_manifests if not row.active
            ),
            revisions=tuple(
                (
                    data_source_id,
                    next(
                        (
                            int(row.revision or 0)
                            for row in data_manifests
                            if str(row.data_source_id) == data_source_id
                        ),
                        0,
                    ),
                )
                for data_source_id in data_source_ids
            ),
        )

    async def source_state(self, source_id: str) -> SourceState | None:
        """Return persisted processing state for one source in this data source."""
        async with self._governor.slot(RuntimeResource.SEARCH):
            return await self._records().source_state(source_id)

    async def process_source(
        self,
        request: ProcessSourceRequest,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> OperationResult:
        """Execute or exactly replay one durable, fenced source-processing command.

        ``observer`` is request-local and best-effort.  It exposes stage progress
        without making a shared Engine instance carry mutable job state.
        Successful Chunk outcomes are checkpointed before the whole-batch commit.
        ``cancellation`` preserves durable progress and releases the execution
        lease; resume by replaying this request with a fresh cancellation token.
        """
        if cancellation is not None:
            return await cancellation.run(lambda: self.process_source(request, observer=observer))
        call_started_at = perf_counter()
        self._require_started()
        if self._components is not None:
            from zleap.sag.pipeline import UnsupportedStageOptionError

            raise UnsupportedStageOptionError(
                "external component mode does not provide durable operations",
                stage="process_source",
                code="operation_store_unavailable",
            )

        descriptor = request.source.descriptor
        assert descriptor is not None and descriptor.data_source_id and descriptor.source_id
        if self._data_source_id is not None and self._data_source_id != descriptor.data_source_id:
            from zleap.sag.exceptions import OperationConflictError

            raise OperationConflictError("request data_source_id does not match engine binding")
        self._data_source_id = descriptor.data_source_id
        await self._ensure_source()
        store = self._operations()
        state = await store.begin_process(request)
        if state.status == "succeeded" or (state.status == "failed" and not state.retryable):
            if state.status == "succeeded":
                await self._cleanup_retired_generations(descriptor.source_id)
                await self._cleanup_abandoned_generations(descriptor.source_id)
            else:
                await self._cleanup_abandoned_generations(descriptor.source_id)
                refreshed = await store.get(request.context.operation_id)
                state = refreshed or state
            await self._emit_operation_event(
                state,
                kind="replayed",
                duration_seconds=perf_counter() - call_started_at,
            )
            return state

        execution = await store.claim(request)
        if execution is None:
            current = await store.get(request.context.operation_id)
            if current is None:
                raise StateError("durable operation disappeared after begin")
            await self._emit_operation_event(
                current,
                kind="contended",
                duration_seconds=perf_counter() - call_started_at,
            )
            return current

        await self._emit_operation_event(
            execution.state,
            kind="started",
            duration_seconds=0,
        )
        state = execution.state
        try:
            async with self._operation_lease(request):
                async with self._governor.slot(RuntimeResource.MUTATION):
                    while True:
                        await self._raise_if_operation_deadline_elapsed(request)
                        prior_checkpoint = state.checkpoint
                        checkpoint_started_at = perf_counter()
                        state = await self._advance_process_operation(
                            request,
                            observer=observer,
                        )
                        if state.checkpoint != prior_checkpoint:
                            await self._emit_operation_event(
                                state,
                                kind="checkpoint",
                                duration_seconds=perf_counter() - checkpoint_started_at,
                            )
                        if state.terminal:
                            if state.status == "succeeded":
                                await self._cleanup_retired_generations(descriptor.source_id)
                                await self._cleanup_abandoned_generations(descriptor.source_id)
                            await self._emit_operation_event(
                                state,
                                kind="completed",
                                duration_seconds=perf_counter() - call_started_at,
                            )
                            return state
        except asyncio.CancelledError:
            # Generation checkpoints already committed remain reusable. Release
            # the lease so exact replay need not wait for its expiry.
            try:
                await store.fail(
                    request.context.operation_id,
                    code="cancelled",
                    message="operation cancelled",
                    retryable=True,
                    owner_id=request.context.owner_id,
                    execution_attempt=execution.state.attempts,
                )
            except Exception:
                # If storage is unavailable, lease expiry still permits recovery.
                # A stale worker must not turn cancellation into a second failure.
                logger.warning(
                    "Could not release cancelled operation lease; expiry will recover it"
                )
            raise
        except Exception as exc:
            retryable, code = self._operation_failure(exc)
            failed = await store.fail(
                request.context.operation_id,
                code=code,
                message=self._safe_operation_failure_message(code, exc),
                retryable=retryable,
                owner_id=request.context.owner_id,
            )
            if not retryable:
                await self._cleanup_abandoned_generations(descriptor.source_id)
                refreshed = await store.get(request.context.operation_id)
                failed = refreshed or failed
            await self._emit_operation_event(
                failed,
                kind="completed",
                duration_seconds=perf_counter() - call_started_at,
            )
            return failed

    async def _emit_operation_event(
        self,
        state: OperationResult,
        *,
        kind: OperationEventKind | str,
        duration_seconds: float,
    ) -> None:
        from zleap.sag.observability import (
            OperationEvent,
            OperationEventKind,
            notify_engine_observer,
        )

        await notify_engine_observer(
            self._observer,
            OperationEvent(
                kind=OperationEventKind(kind),
                operation_type=state.operation_type,
                checkpoint=state.checkpoint,
                status=state.status,
                duration_seconds=max(0, duration_seconds),
                attempts=state.attempts,
                failure_code=state.failure_code,
                retryable=state.retryable,
            ),
        )

    async def get_operation_status(self, operation_id: str) -> OperationResult | None:
        """Read durable status; an expired execution lease becomes retryable FAILED."""
        return await self._operations().get(operation_id)

    async def reconcile_source(self, source_id: str) -> tuple[str, ...]:
        """Retry durable cleanup and return generations still awaiting cleanup."""
        self._require_started()
        if self._data_source_id is None:
            raise StateError("DataEngine has not been bound to a data_source_id")
        async with self._governor.slot(RuntimeResource.MUTATION):
            return await self._reconcile_source(self._data_source_id, source_id)

    async def maintain(self, policy: MaintenancePolicy) -> MaintenanceResult:
        """Run one global, bounded, repeatable maintenance pass."""

        self._require_started()
        if self._components is not None:
            from zleap.sag.pipeline import UnsupportedStageOptionError

            raise UnsupportedStageOptionError(
                "external component mode has no SAG maintenance store",
                stage="maintenance",
                code="maintenance_unavailable",
            )
        from datetime import UTC, datetime

        from zleap.sag._maintenance_store import MaintenanceStore
        from zleap.sag.maintenance import MaintenanceResult

        store = MaintenanceStore(self._session_factory)
        async with self._governor.slot(RuntimeResource.MUTATION):
            stale_released, stale_has_more = await store.release_stale_operations(
                policy.stale_operation_limit
            )
            targets, cleanup_has_more = await store.cleanup_targets(policy.cleanup_source_limit)
            cleanup_completed = 0
            cleanup_pending = 0
            for target in targets:
                remaining = await self._reconcile_source(
                    target.data_source_id,
                    target.source_id,
                )
                if remaining:
                    cleanup_pending += 1
                else:
                    cleanup_completed += 1
            sessions_deleted, sessions_have_more = await store.purge_expired_search_sessions(
                policy.expired_search_session_limit
            )
            operations_deleted, operations_have_more = await store.purge_terminal_operations(
                retention_days=policy.terminal_operation_retention_days,
                limit=policy.terminal_operation_limit,
            )
        return MaintenanceResult(
            completed_at=datetime.now(UTC),
            cleanup_sources_selected=len(targets),
            cleanup_sources_completed=cleanup_completed,
            cleanup_sources_pending=cleanup_pending,
            expired_search_sessions_deleted=sessions_deleted,
            stale_operations_released=stale_released,
            terminal_operations_deleted=operations_deleted,
            has_more=(
                cleanup_has_more
                or cleanup_pending > 0
                or sessions_have_more
                or stale_has_more
                or operations_have_more
            ),
        )

    async def _reconcile_source(self, data_source_id: str, source_id: str) -> tuple[str, ...]:
        from zleap.sag.db import SAGSourceManifest

        await self._cleanup_retired_generations(source_id, data_source_id=data_source_id)
        await self._cleanup_abandoned_generations(source_id, data_source_id=data_source_id)
        abandoned = await self._abandoned_generation_ids(
            source_id,
            data_source_id=data_source_id,
        )
        async with self._session_factory() as session:
            manifest = await session.get(
                SAGSourceManifest,
                (data_source_id, source_id),
            )
            pending = (
                [str(item) for item in manifest.pending_cleanup_generations or ()]
                if manifest is not None
                else []
            )
            pending.extend(abandoned)
            remaining = tuple(dict.fromkeys(pending))
            if manifest is not None:
                manifest.cleanup_required = bool(remaining)
                if not remaining:
                    manifest.cleanup_error = None
                await session.commit()
        return remaining

    async def _cleanup_retired_generations(
        self,
        source_id: str,
        *,
        data_source_id: str | None = None,
    ) -> None:
        """Idempotently remove data made unreachable by an atomic manifest switch."""
        from zleap.sag.db import SAGSourceManifest

        target_data_source_id = data_source_id or self._data_source_id
        if target_data_source_id is None or self._repositories is None:
            return
        async with self._session_factory() as session:
            manifest = await session.get(
                SAGSourceManifest,
                (target_data_source_id, source_id),
            )
            if manifest is None:
                return
            active_generation = manifest.active_generation_id
            pending = tuple(
                str(item)
                for item in manifest.pending_cleanup_generations or ()
                if item and item != active_generation
            )
        for generation_id in pending:
            try:
                await self._cleanup_generation(
                    source_id,
                    generation_id,
                    data_source_id=target_data_source_id,
                    tracked_in_manifest=True,
                )
            except Exception as exc:  # cleanup never revokes an already-ready generation
                await self._record_cleanup_error(
                    source_id,
                    self._safe_cleanup_failure_message(exc),
                    data_source_id=target_data_source_id,
                )

    async def _cleanup_abandoned_generations(
        self,
        source_id: str,
        *,
        data_source_id: str | None = None,
    ) -> None:
        """Remove terminal failed generations that can never become visible."""
        target_data_source_id = data_source_id or self._data_source_id
        if target_data_source_id is None:
            return
        for generation_id in await self._abandoned_generation_ids(
            source_id,
            data_source_id=target_data_source_id,
        ):
            try:
                cleaned = await self._cleanup_generation(
                    source_id,
                    generation_id,
                    data_source_id=target_data_source_id,
                    tracked_in_manifest=False,
                )
                if cleaned:
                    await self._scrub_abandoned_operation_payloads(
                        source_id,
                        generation_id,
                        data_source_id=target_data_source_id,
                    )
            except Exception as exc:
                await self._record_cleanup_error(
                    source_id,
                    self._safe_cleanup_failure_message(exc),
                    data_source_id=target_data_source_id,
                )

    async def _abandoned_generation_ids(
        self,
        source_id: str,
        *,
        data_source_id: str | None = None,
    ) -> tuple[str, ...]:
        from sqlalchemy import select

        from zleap.sag.db import SAGOperation, SAGSourceManifest

        target_data_source_id = data_source_id or self._data_source_id
        if target_data_source_id is None:
            return ()
        async with self._session_factory() as session:
            manifest = await session.get(
                SAGSourceManifest,
                (target_data_source_id, source_id),
            )
            active_generation = manifest.active_generation_id if manifest is not None else None
            generations = tuple(
                str(item)
                for item in (
                    await session.scalars(
                        select(SAGOperation.generation_id).where(
                            SAGOperation.data_source_id == target_data_source_id,
                            SAGOperation.source_id == source_id,
                            SAGOperation.operation_type == "process_source",
                            SAGOperation.status == "failed",
                            SAGOperation.retryable.is_(False),
                            SAGOperation.generation_id.is_not(None),
                            SAGOperation.cleanup_completed_at.is_(None),
                        )
                    )
                ).all()
                if item is not None and str(item) != active_generation
            )
        return tuple(dict.fromkeys(generations))

    async def _cleanup_generation(
        self,
        source_id: str,
        generation_id: str,
        *,
        data_source_id: str | None = None,
        tracked_in_manifest: bool,
    ) -> bool:
        """Delete one invisible generation, vectors first and relations second."""
        from sqlalchemy import delete, exists, select

        from zleap.sag.db import (
            ArticleSection,
            ChatMessage,
            Entity,
            EventEntity,
            SAGSourceManifest,
            SourceChunk,
            SourceEvent,
        )
        from zleap.sag.db.clock import database_utcnow

        repositories = self._repositories
        target_data_source_id = data_source_id or self._data_source_id
        if target_data_source_id is None or repositories is None:
            return False
        async with self._session_factory() as session:
            manifest = await session.get(
                SAGSourceManifest,
                (target_data_source_id, source_id),
            )
            if manifest is not None and manifest.active_generation_id == generation_id:
                return False
            chunk_ids = tuple(
                (
                    await session.scalars(
                        select(SourceChunk.id).where(
                            SourceChunk.data_source_id == target_data_source_id,
                            SourceChunk.source_id == source_id,
                            SourceChunk.generation_id == generation_id,
                        )
                    )
                ).all()
            )
            event_ids = tuple(
                (
                    await session.scalars(
                        select(SourceEvent.id).where(
                            SourceEvent.data_source_id == target_data_source_id,
                            SourceEvent.source_id == source_id,
                            SourceEvent.generation_id == generation_id,
                        )
                    )
                ).all()
            )
            association_rows = (
                list(
                    (
                        await session.execute(
                            select(EventEntity.id, EventEntity.entity_id).where(
                                EventEntity.event_id.in_(event_ids)
                            )
                        )
                    ).all()
                )
                if event_ids
                else []
            )
            association_ids = tuple(row[0] for row in association_rows)
            candidate_entity_ids = tuple(dict.fromkeys(row[1] for row in association_rows))
            orphan_entity_ids = (
                tuple(
                    (
                        await session.scalars(
                            select(Entity.id).where(
                                Entity.data_source_id == target_data_source_id,
                                Entity.id.in_(candidate_entity_ids),
                                ~exists(
                                    select(EventEntity.id).where(
                                        EventEntity.entity_id == Entity.id,
                                        EventEntity.event_id.not_in(event_ids),
                                    )
                                ),
                            )
                        )
                    ).all()
                )
                if candidate_entity_ids
                else ()
            )

        await self._delete_vector_groups(
            (
                (repositories.source_chunks, chunk_ids),
                (repositories.events, event_ids),
                (repositories.event_entities, association_ids),
                (repositories.entities, orphan_entity_ids),
            )
        )

        async with self._session_factory() as session:
            locked = (
                await session.scalars(
                    select(SAGSourceManifest)
                    .where(
                        SAGSourceManifest.data_source_id == target_data_source_id,
                        SAGSourceManifest.source_id == source_id,
                    )
                    .with_for_update()
                )
            ).first()
            if locked is not None and locked.active_generation_id == generation_id:
                await session.rollback()
                return False
            if tracked_in_manifest:
                if locked is None:
                    await session.rollback()
                    return False
                current_pending = list(locked.pending_cleanup_generations or [])
                if generation_id not in current_pending:
                    locked.cleanup_required = bool(current_pending)
                    if not current_pending:
                        locked.cleanup_error = None
                    await session.commit()
                    return True
            if event_ids:
                await session.execute(
                    delete(EventEntity).where(EventEntity.event_id.in_(event_ids))
                )
                await session.execute(delete(SourceEvent).where(SourceEvent.id.in_(event_ids)))
            if chunk_ids:
                await session.execute(delete(SourceChunk).where(SourceChunk.id.in_(chunk_ids)))
            await session.execute(
                delete(ArticleSection).where(
                    ArticleSection.article_id == source_id,
                    ArticleSection.generation_id == generation_id,
                )
            )
            await session.execute(
                delete(ChatMessage).where(
                    ChatMessage.conversation_id == source_id,
                    ChatMessage.generation_id == generation_id,
                )
            )
            if orphan_entity_ids:
                await session.execute(delete(Entity).where(Entity.id.in_(orphan_entity_ids)))
            if tracked_in_manifest and locked is not None:
                now = await database_utcnow(session)
                current_pending = list(locked.pending_cleanup_generations or [])
                if generation_id in current_pending:
                    current_pending.remove(generation_id)
                locked.pending_cleanup_generations = current_pending
                locked.cleanup_required = bool(current_pending)
                locked.cleanup_error = None
                locked.cleanup_updated_at = now
            await session.commit()
        return True

    async def _scrub_abandoned_operation_payloads(
        self,
        source_id: str,
        generation_id: str,
        *,
        data_source_id: str | None = None,
    ) -> None:
        from sqlalchemy import update

        from zleap.sag.db import SAGOperation
        from zleap.sag.db.clock import database_utcnow

        target_data_source_id = data_source_id or self._data_source_id
        if target_data_source_id is None:
            return
        async with self._session_factory() as session:
            now = await database_utcnow(session)
            await session.execute(
                update(SAGOperation)
                .where(
                    SAGOperation.data_source_id == target_data_source_id,
                    SAGOperation.source_id == source_id,
                    SAGOperation.generation_id == generation_id,
                    SAGOperation.status == "failed",
                    SAGOperation.retryable.is_(False),
                )
                .values(
                    work_payload=None,
                    cleanup_completed_at=now,
                    cleanup_error=None,
                )
            )
            await session.commit()

    async def _record_cleanup_error(
        self,
        source_id: str,
        message: str,
        *,
        data_source_id: str | None = None,
    ) -> None:
        from sqlalchemy import update

        from zleap.sag.db import SAGOperation, SAGSourceManifest
        from zleap.sag.db.clock import database_utcnow

        target_data_source_id = data_source_id or self._data_source_id
        if target_data_source_id is None:
            return
        async with self._session_factory() as session:
            now = await database_utcnow(session)
            manifest = await session.get(
                SAGSourceManifest,
                (target_data_source_id, source_id),
            )
            if manifest is None:
                pass
            else:
                manifest.cleanup_required = True
                manifest.cleanup_error = message[:4000]
                manifest.cleanup_updated_at = now
            await session.execute(
                update(SAGOperation)
                .where(
                    SAGOperation.data_source_id == target_data_source_id,
                    SAGOperation.source_id == source_id,
                    SAGOperation.status == "failed",
                    SAGOperation.retryable.is_(False),
                    SAGOperation.cleanup_completed_at.is_(None),
                )
                .values(cleanup_error=message[:4000])
            )
            await session.commit()

    @staticmethod
    def _safe_operation_failure_message(code: str, exc: Exception) -> str:
        """Persist a useful classification without storing provider secrets or content."""

        return f"{code}: {type(exc).__name__}"

    @staticmethod
    def _safe_cleanup_failure_message(exc: Exception) -> str:
        return f"generation cleanup failed: {type(exc).__name__}"

    async def _advance_process_operation(
        self,
        request: ProcessSourceRequest,
        *,
        observer: StageObserver | None = None,
    ) -> OperationResult:
        from pydantic import TypeAdapter

        from zleap.sag.operations import OperationCheckpoint
        from zleap.sag.pipeline import (
            ChunkSet,
            ChunkSetRef,
            EventSetRef,
            ParsedSource,
            StageEvent,
            StageEventType,
            StageName,
        )
        from zleap.sag.pipeline.events import notify_observer

        store = self._operations()
        execution = await store.execution(request.context.operation_id)
        if execution is None:
            raise StateError("durable operation is missing")
        checkpoint = OperationCheckpoint(str(execution.state.checkpoint))
        work = dict(execution.work_payload)

        if checkpoint is OperationCheckpoint.ACCEPTED:
            parsed = await self.parse(
                request.source,
                request.parse_options,
                observer=observer,
            )
            work["parsed"] = parsed.model_dump(mode="json")
            return await store.checkpoint(request, OperationCheckpoint.PARSED, work)

        if checkpoint is OperationCheckpoint.PARSED:
            parsed = TypeAdapter(ParsedSource).validate_python(work["parsed"])
            chunks = await self.chunk(
                parsed,
                request.chunk_options,
                observer=observer,
            )
            work.pop("parsed", None)
            work["chunks"] = chunks.model_dump(mode="json")
            return await store.checkpoint(request, OperationCheckpoint.CHUNKED, work)

        if checkpoint is OperationCheckpoint.CHUNKED:
            chunks = TypeAdapter(ChunkSet).validate_python(work["chunks"])
            descriptor = request.source.descriptor
            assert descriptor is not None
            generation_id = execution.state.generation_id
            if generation_id is None:
                raise StateError("durable process operation has no generation_id")
            await notify_observer(
                observer,
                StageEvent(
                    run_id=request.context.operation_id,
                    stage=StageName.INDEX,
                    type=StageEventType.STARTED,
                    completed=0,
                    total=len(chunks.chunks),
                ),
            )
            try:
                chunk_ref = await self._index_generation(
                    chunks,
                    descriptor,
                    request.index_options,
                    generation_id=generation_id,
                )
            except Exception as exc:
                await notify_observer(
                    observer,
                    StageEvent(
                        run_id=request.context.operation_id,
                        stage=StageName.INDEX,
                        type=StageEventType.FAILED,
                        error=type(exc).__name__,
                    ),
                )
                raise
            await notify_observer(
                observer,
                StageEvent(
                    run_id=request.context.operation_id,
                    stage=StageName.INDEX,
                    type=StageEventType.SUCCEEDED,
                    completed=chunk_ref.chunk_count,
                    total=chunk_ref.chunk_count,
                ),
            )
            work.pop("chunks", None)
            work["chunk_ref"] = chunk_ref.model_dump(mode="json")
            return await store.checkpoint(request, OperationCheckpoint.INDEXED, work)

        if checkpoint is OperationCheckpoint.INDEXED:
            chunk_ref = TypeAdapter(ChunkSetRef).validate_python(work["chunk_ref"])
            prepare = getattr(self._extract_adapter, "prepare_generation", None)
            if prepare is None:
                raise StateError("configured extract adapter does not support durable preparation")
            await notify_observer(
                observer,
                StageEvent(
                    run_id=request.context.operation_id,
                    stage=StageName.EXTRACT,
                    type=StageEventType.STARTED,
                    completed=0,
                    total=chunk_ref.chunk_count,
                ),
            )

            async def report_extraction_progress(completed: int, total: int) -> None:
                await notify_observer(
                    observer,
                    StageEvent(
                        run_id=request.context.operation_id,
                        stage=StageName.EXTRACT,
                        type=StageEventType.PROGRESS,
                        completed=completed,
                        total=total,
                    ),
                )

            async def save_chunk_checkpoint(fingerprint, chunk_ids, chunk_id, outcome):
                from zleap.sag._extraction_progress import ExtractionCheckpointWriteError
                from zleap.sag.exceptions import (
                    OperationConflictError,
                    ResourceBusyError,
                    StaleFenceError,
                )

                write = asyncio.create_task(
                    store.save_chunk_checkpoint(
                        request,
                        execution_attempt=execution.state.attempts,
                        fingerprint=fingerprint,
                        chunk_ids=chunk_ids,
                        chunk_id=chunk_id,
                        outcome=outcome,
                    )
                )
                try:
                    # Finish the small checkpoint transaction before releasing the
                    # lease, even when pause arrives during commit/connection cleanup.
                    return await asyncio.shield(write)
                except asyncio.CancelledError:
                    await asyncio.gather(write, return_exceptions=True)
                    raise
                except (OperationConflictError, ResourceBusyError, StaleFenceError):
                    raise
                except Exception as exc:
                    raise ExtractionCheckpointWriteError() from exc

            runtime_fingerprint = hashlib.sha256(
                json.dumps(
                    {
                        "llm": self._config.llm.model_dump(mode="json", exclude={"api_key"}),
                        "embedding": self._config.embedding.model_dump(
                            mode="json", exclude={"api_key"}
                        ),
                    },
                    sort_keys=True,
                ).encode()
            ).hexdigest()

            try:
                prepared = await prepare(
                    chunk_ref,
                    request.extraction_options,
                    on_progress=report_extraction_progress,
                    checkpoint=save_chunk_checkpoint,
                    runtime_fingerprint=runtime_fingerprint,
                )
            except Exception as exc:
                failure_stats = dict(getattr(exc, "stats", {}) or {})
                failed_chunks = len(tuple(getattr(exc, "failures", ()) or ()))
                completed_chunks = int(failure_stats.get("chunk_total", chunk_ref.chunk_count))
                await notify_observer(
                    observer,
                    StageEvent(
                        run_id=request.context.operation_id,
                        stage=StageName.EXTRACT,
                        type=StageEventType.FAILED,
                        completed=min(completed_chunks, chunk_ref.chunk_count),
                        total=chunk_ref.chunk_count,
                        stats={
                            "failed_chunks": failed_chunks,
                            "retryable": bool(getattr(exc, "retryable", False)),
                        },
                        error=type(exc).__name__,
                    ),
                )
                raise
            await notify_observer(
                observer,
                StageEvent(
                    run_id=request.context.operation_id,
                    stage=StageName.EXTRACT,
                    type=StageEventType.SUCCEEDED,
                    completed=chunk_ref.chunk_count,
                    total=chunk_ref.chunk_count,
                ),
            )
            # Reload per-Chunk writes before advancing the stage; ``work`` was
            # captured before generation and must never overwrite their progress.
            latest = await store.execution(request.context.operation_id)
            assert latest is not None
            work = dict(latest.work_payload)
            from zleap.sag._extraction_progress import extraction_progress_summary

            if "extraction_progress" in work:
                prepared["stats"]["extraction_progress"] = extraction_progress_summary(
                    work["extraction_progress"], request.context.operation_id
                )
            work["prepared_extraction"] = prepared
            return await store.checkpoint(
                request,
                OperationCheckpoint.EXTRACT_PREPARED,
                work,
            )

        if checkpoint is OperationCheckpoint.EXTRACT_PREPARED:
            commit = getattr(self._extract_adapter, "commit_prepared_generation", None)
            if commit is None:
                raise StateError("configured extract adapter cannot commit prepared extraction")
            event_ref = await commit(work["prepared_extraction"])
            work.pop("prepared_extraction", None)
            work["event_ref"] = event_ref.model_dump(mode="json")
            return await store.checkpoint(request, OperationCheckpoint.EXTRACTED, work)

        if checkpoint is OperationCheckpoint.EXTRACTED:
            chunk_ref = TypeAdapter(ChunkSetRef).validate_python(work["chunk_ref"])
            event_ref = TypeAdapter(EventSetRef).validate_python(work["event_ref"])
            await self._publish_generation_visibility()
            result_payload = {
                "chunk_ref": chunk_ref.model_dump(mode="json"),
                "event_ref": event_ref.model_dump(mode="json"),
                "extraction_progress": event_ref.stats.get("extraction_progress"),
            }
            return await store.complete_process(
                request,
                work_payload=work,
                result_payload=result_payload,
                source_version=chunk_ref.source_version,
                chunk_version=chunk_ref.chunk_version,
                extract_version=event_ref.extract_version,
                chunk_count=chunk_ref.chunk_count,
                event_count=event_ref.event_count,
            )

        return execution.state

    async def _publish_generation_visibility(self) -> None:
        """Ensure a complete derived generation is searchable before it becomes active."""
        repositories = self._repositories
        if repositories is None:
            raise StateError("repository bundle is unavailable")
        await repositories.source_chunks.vector_store.publish(
            (
                repositories.source_chunks.INDEX_NAME,
                repositories.events.INDEX_NAME,
                repositories.event_entities.INDEX_NAME,
                repositories.entities.INDEX_NAME,
            )
        )

    async def _index_generation(
        self,
        chunks: ChunkSet,
        descriptor: SourceDescriptor,
        options: IndexOptions,
        *,
        generation_id: str,
    ) -> ChunkSetRef:
        """Internal durable path; explicit stage APIs cannot activate generations."""
        adapter = self._index_adapter
        writer = getattr(adapter, "index_generation", None)
        if writer is None:
            raise StateError("configured index adapter does not support durable generations")
        async with self._governor.slot(RuntimeResource.MUTATION):
            return await writer(
                chunks,
                descriptor,
                options,
                generation_id=generation_id,
            )

    @asynccontextmanager
    async def _operation_lease(
        self,
        request: ProcessSourceRequest | DeleteSourceRequest | DeleteDataSourceRequest,
    ) -> AsyncIterator[None]:
        """Heartbeat a long model/storage stage without relying on the platform process."""
        stopped = asyncio.Event()
        errors: list[BaseException] = []
        interval = max(5.0, min(30.0, request.context.lease_seconds / 3))

        async def _heartbeat() -> None:
            while True:
                try:
                    await asyncio.wait_for(stopped.wait(), timeout=interval)
                    return
                except TimeoutError:
                    try:
                        await self._operations().heartbeat(request)
                    except BaseException as exc:  # noqa: BLE001 - surfaced after stage
                        errors.append(exc)
                        return

        task = asyncio.create_task(_heartbeat())
        try:
            yield
            if errors:
                raise errors[0]
        finally:
            stopped.set()
            await task

    @staticmethod
    def _operation_failure(exc: Exception) -> tuple[bool, str]:
        from zleap.sag.exceptions import (
            AIAuthError,
            AIError,
            AIInvalidRequestError,
            ConfigError,
            LLMAuthError,
            LLMConfigurationError,
            LLMContentPolicyError,
            LLMContextLengthError,
            LLMError,
            LLMInvalidRequestError,
            NonRetryableError,
            OperationConflictError,
            OperationDeadlineExceededError,
            ResourceBusyError,
            RetryableError,
            StaleFenceError,
            StorageSchemaMismatchError,
            VectorSyncError,
        )

        if isinstance(exc, StaleFenceError):
            return False, "stale_fence"
        if isinstance(exc, OperationConflictError):
            return False, "conflict"
        if isinstance(exc, OperationDeadlineExceededError):
            return True, "deadline_exceeded"
        if isinstance(exc, ConfigError | StorageSchemaMismatchError):
            return False, "configuration_error"
        if isinstance(exc, LLMAuthError | LLMConfigurationError | AIAuthError):
            return False, "configuration_error"
        if isinstance(exc, LLMContentPolicyError):
            return False, "content_policy_rejected"
        if isinstance(exc, LLMContextLengthError):
            return False, "input_too_large"
        if isinstance(exc, LLMInvalidRequestError | AIInvalidRequestError):
            return False, "request_rejected"
        if isinstance(exc, VectorSyncError):
            return True, "dependency_unavailable"
        if isinstance(exc, NonRetryableError):
            return False, "request_rejected"
        failure_codes = {
            str(getattr(failure, "code", ""))
            for failure in tuple(getattr(exc, "failures", ()) or ())
        }
        if "llm_authentication_failed" in failure_codes:
            return False, "configuration_error"
        if "llm_configuration_error" in failure_codes:
            return False, "configuration_error"
        if "llm_content_policy_rejected" in failure_codes:
            return False, "content_policy_rejected"
        if "llm_context_length_exceeded" in failure_codes:
            return False, "input_too_large"
        if "llm_invalid_request" in failure_codes:
            return False, "request_rejected"
        if isinstance(exc, ResourceBusyError | RetryableError | LLMError | AIError):
            explicit = getattr(exc, "retryable", None)
            if explicit is True:
                return True, "dependency_unavailable"
        explicit = getattr(exc, "retryable", None)
        if isinstance(explicit, bool):
            return explicit, "execution_failed"
        return False, "execution_failed"

    async def _raise_if_operation_deadline_elapsed(
        self,
        request: ProcessSourceRequest | DeleteSourceRequest | DeleteDataSourceRequest,
    ) -> None:
        """Observe deadlines only between idempotent stages.

        Cancelling an LLM or storage stage after its side effect but before its
        checkpoint would destroy exact recovery.  A stage therefore finishes and
        persists its checkpoint; the next stage is not started after the deadline.
        """
        from zleap.sag.db.clock import database_utcnow
        from zleap.sag.exceptions import OperationDeadlineExceededError

        deadline = request.context.deadline_at
        if deadline is None:
            return
        async with self._session_factory() as session:
            now = await database_utcnow(session)
        if deadline <= now.replace(tzinfo=UTC):
            raise OperationDeadlineExceededError(
                "operation deadline elapsed at a durable stage boundary"
            )

    async def read_chunk(self, source_id: str, chunk_id: str) -> ChunkRecord | None:
        """Read one persisted chunk without exposing ORM state."""
        async with self._governor.slot(RuntimeResource.SEARCH):
            return await self._records().read_chunk(source_id, chunk_id)

    async def read_evidence(
        self,
        source_id: str,
        chunk_ids: Iterable[str],
        *,
        max_events_per_chunk: int = 50,
    ) -> tuple[EvidenceRecord, ...]:
        """Read chunks and their extracted events for search evidence."""
        async with self._governor.slot(RuntimeResource.SEARCH):
            return await self._records().read_evidence(
                source_id,
                tuple(chunk_ids),
                max_events_per_chunk=max_events_per_chunk,
            )

    async def read_outline(
        self,
        source_id: str,
        *,
        offset: int = 0,
        limit: int = 20,
    ) -> OutlinePage:
        """Read a stable, paged outline for one persisted source."""
        async with self._governor.slot(RuntimeResource.SEARCH):
            return await self._records().read_outline(source_id, offset=offset, limit=limit)

    async def read_graph(
        self,
        source_ids: Iterable[str],
        *,
        event_limit: int = 300,
        entity_limit: int = 300,
    ) -> KnowledgeGraph:
        """Read a bounded event/entity graph for sources in this data source."""
        async with self._governor.slot(RuntimeResource.SEARCH):
            return await self._records().read_graph(
                tuple(source_ids),
                event_limit=event_limit,
                entity_limit=entity_limit,
            )

    async def delete_source(self, request: DeleteSourceRequest) -> OperationResult:
        """Durably hide, clean, and finalize one source under a fence."""
        from zleap.sag.operations import DeleteSourceRequest

        if not isinstance(request, DeleteSourceRequest):
            raise InvalidInputError("delete_source requires DeleteSourceRequest")
        return await self._run_delete_operation(request)

    async def delete_data_source(self, request: DeleteDataSourceRequest) -> OperationResult:
        """Durably hide and remove this engine namespace while retaining fences."""
        from zleap.sag.operations import DeleteDataSourceRequest

        if not isinstance(request, DeleteDataSourceRequest):
            raise InvalidInputError("delete_data_source requires DeleteDataSourceRequest")
        return await self._run_delete_operation(request)

    async def _run_delete_operation(
        self,
        request: DeleteSourceRequest | DeleteDataSourceRequest,
    ) -> OperationResult:
        from zleap.sag.operations import DeleteSourceRequest

        call_started_at = perf_counter()
        self._require_started()
        if request.data_source_id != self._data_source_id:
            from zleap.sag.exceptions import OperationConflictError

            raise OperationConflictError("delete target does not match engine binding")
        repositories = self._repositories
        if repositories is None:
            raise StateError("delete repositories are not initialized")
        store = self._operations()
        state = (
            await store.begin_delete_source(request)
            if isinstance(request, DeleteSourceRequest)
            else await store.begin_delete_data_source(request)
        )
        if state.status == "succeeded" or (state.status == "failed" and not state.retryable):
            await self._emit_operation_event(
                state,
                kind="replayed",
                duration_seconds=perf_counter() - call_started_at,
            )
            return state
        claimed = await store.claim(request)
        if claimed is None:
            current = await store.get(request.context.operation_id)
            if current is None:
                raise StateError("durable delete operation disappeared after begin")
            await self._emit_operation_event(
                current,
                kind="contended",
                duration_seconds=perf_counter() - call_started_at,
            )
            return current
        await self._emit_operation_event(
            claimed.state,
            kind="started",
            duration_seconds=0,
        )
        try:
            async with self._operation_lease(request):
                async with self._governor.slot(RuntimeResource.MUTATION):
                    while True:
                        await self._raise_if_operation_deadline_elapsed(request)
                        execution = await store.execution(request.context.operation_id)
                        if execution is None:
                            raise StateError("durable delete operation is missing")
                        checkpoint = str(execution.state.checkpoint)
                        checkpoint_started_at = perf_counter()
                        if checkpoint == "accepted":
                            state = await store.prepare_delete(request)
                        elif checkpoint == "delete_hidden":
                            batch = await store.next_delete_batch(request)
                            if batch.empty:
                                state = await store.mark_delete_vectors_complete(request)
                            else:
                                await self._delete_vector_groups(
                                    [
                                        (repositories.source_chunks, batch.chunk_ids),
                                        (repositories.events, batch.event_ids),
                                        (repositories.event_entities, batch.association_ids),
                                        (repositories.entities, batch.entity_ids),
                                    ]
                                )
                                state = await store.apply_delete_batch(request, batch)
                        elif checkpoint == "vectors_deleted":
                            state = await store.delete_relations(request)
                        elif checkpoint == "relations_deleted":
                            state = await store.complete_delete(request)
                        else:
                            return execution.state
                        if str(state.checkpoint) != checkpoint:
                            await self._emit_operation_event(
                                state,
                                kind="checkpoint",
                                duration_seconds=perf_counter() - checkpoint_started_at,
                            )
                        if state.terminal:
                            await self._emit_operation_event(
                                state,
                                kind="completed",
                                duration_seconds=perf_counter() - call_started_at,
                            )
                            return state
        except Exception as exc:
            retryable, code = self._operation_failure(exc)
            failed = await store.fail(
                request.context.operation_id,
                code=code,
                message=self._safe_operation_failure_message(code, exc),
                retryable=retryable,
                owner_id=request.context.owner_id,
            )
            await self._emit_operation_event(
                failed,
                kind="completed",
                duration_seconds=perf_counter() - call_started_at,
            )
            return failed

    @staticmethod
    async def _delete_vector_groups(groups: Iterable[tuple[Any, Iterable[str]]]) -> None:
        from zleap.sag.exceptions import VectorSyncError

        for repository, raw_ids in groups:
            record_ids = tuple(dict.fromkeys(str(item) for item in raw_ids))
            if not record_ids:
                continue
            result = await repository.vector_store.delete(repository.INDEX_NAME, record_ids)
            if result.failed_items:
                raise VectorSyncError(
                    provider=repository.vector_store.provider,
                    collection=repository.INDEX_NAME,
                    failed_ids=[item.id for item in result.failed_items],
                    reason=result.failed_items[0].error,
                )

    @_normalize_sync_errors("register_search_algorithm")
    def register_search_algorithm(
        self,
        spec: SearchExecutorSpec,
        *,
        profiles: Iterable[SearchProfile] = (),
        replace: bool = False,
    ) -> None:
        """Atomically stage an algorithm spec and its public profiles before startup."""
        if self._started:
            raise StateError("搜索算法注册必须在 DataEngine.start() 之前完成")
        if self._components is not None:
            from zleap.sag.pipeline import UnsupportedStageOptionError

            raise UnsupportedStageOptionError(
                "外部组件模式由宿主 search_adapter 管理算法注册",
                stage="search",
                code="search_executor_registry_unavailable",
            )
        self._pending_search_algorithms.append((spec, tuple(profiles), replace))

    @_normalize_errors("ingest")
    async def ingest(
        self,
        source: str | Path | SourceInput,
        *,
        descriptor: SourceDescriptor | None = None,
        parse_options: ParseOptions | None = None,
        chunk_options: ChunkOptions | None = None,
        index_options: IndexOptions | None = None,
        max_tokens: int | None = None,
        chunk_mode: str | None = None,
        background: str | None = None,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> ChunkSetRef:
        """Explicit Parse→Chunk→Index convenience; it never stores the result on self."""
        self._require_started()
        from zleap.sag.pipeline import (
            ChunkOptions,
            FileSource,
            TextSource,
        )

        if isinstance(source, Path):
            source_input: Any = FileSource(path=str(source), descriptor=descriptor)
        elif isinstance(source, str):
            try:
                is_file = Path(source).is_file()
            except OSError:
                is_file = False
            source_input = (
                FileSource(path=source, descriptor=descriptor)
                if is_file
                else TextSource(text=source, descriptor=descriptor)
            )
        else:
            source_input = source
        parsed = await self._parse(
            source_input,
            parse_options,
            observer=observer,
            cancellation=cancellation,
        )
        if chunk_options is None and (max_tokens is not None or chunk_mode is not None):
            chunk_options = ChunkOptions()
            if max_tokens is not None:
                chunk_options = chunk_options.model_copy(update={"max_tokens": max_tokens})
            if chunk_mode is not None:
                chunk_options = chunk_options.model_copy(update={"strategy": chunk_mode})
        chunks = await self._chunk(
            parsed,
            chunk_options,
            observer=observer,
            cancellation=cancellation,
        )
        index_descriptor = descriptor or parsed.descriptor
        if index_descriptor.data_source_id:
            if self._components is None:
                if (
                    self._data_source_id is not None
                    and self._data_source_id != index_descriptor.data_source_id
                ):
                    from zleap.sag.exceptions import ConfigError

                    raise ConfigError("descriptor.data_source_id 与 DataEngine 绑定的数据源不一致")
                self._data_source_id = index_descriptor.data_source_id
                await self._ensure_source()
        else:
            if self._components is not None:
                raise InvalidInputError("外部组件模式的 ingest 必须显式提供 data_source_id")
            data_source_id = await self._ensure_source()
            index_descriptor = index_descriptor.model_copy(
                update={"data_source_id": data_source_id}
            )
        if background:
            metadata = dict(index_descriptor.metadata)
            metadata["background"] = background
            index_descriptor = index_descriptor.model_copy(update={"metadata": metadata})
        return await self._index(
            chunks,
            index_descriptor,
            index_options,
            observer=observer,
            cancellation=cancellation,
        )

    @_normalize_errors("run")
    async def run(
        self,
        plan: PipelinePlan,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
    ) -> PipelineRunResult:
        """Run a fixed explicit plan using only local hand-off variables."""
        if plan.index or plan.extract or plan.search:
            self._require_started()
        from zleap.sag.pipeline import PipelineRunner

        context = self._pipeline_context(
            observer=observer,
            cancellation=cancellation,
            manage_search=True,
        )
        return await PipelineRunner().run(
            plan,
            context=context,
        )

    # ── 内部 ──────────────────────────────────────────────────
    def _require_started(self) -> None:
        if not self._started:
            raise StateError("DataEngine 未启动:请先 await engine.start() 或使用 async with")

    def _pipeline_context(
        self,
        *,
        observer: StageObserver | None = None,
        cancellation: CancellationToken | None = None,
        manage_search: bool = False,
    ) -> Any:
        from zleap.sag.pipeline import CancellationToken, PipelineContext

        search_adapter: Any = self._search_adapter
        if search_adapter is not None:
            search_adapter = _ScopeValidatingSearchAdapter(self, search_adapter)
            if manage_search:
                search_adapter = _ManagedPipelineSearchAdapter(self, search_adapter)
        return PipelineContext(
            observer=observer,
            cancellation=cancellation or CancellationToken(),
            source_readers=self._source_readers,
            image_enricher=self._image_enricher,
            index_adapter=self._index_adapter,
            extract_adapter=self._extract_adapter,
            search_adapter=search_adapter,
        )

    def _records(self) -> KnowledgeRecordStore:
        self._require_started()
        if self._components is not None:
            from zleap.sag.pipeline import UnsupportedStageOptionError

            raise UnsupportedStageOptionError(
                "外部组件模式未提供持久化记录能力",
                stage="records",
                code="record_store_unavailable",
            )
        if self._data_source_id is None:
            raise StateError("DataEngine 尚未绑定 data_source_id")
        if self._record_store is None:
            from zleap.sag._record_store import KnowledgeRecordStore

            self._record_store = KnowledgeRecordStore(
                session_factory=self._session_factory,
                repositories=self._repositories,
                data_source_id=self._data_source_id,
            )
        return self._record_store

    def _operations(self) -> OperationStore:
        self._require_started()
        if self._components is not None:
            raise StateError("external component mode has no operation store")
        if self._data_source_id is None:
            raise StateError("DataEngine has not been bound to a data_source_id")
        if self._operation_store is None:
            from zleap.sag._operation_store import OperationStore

            self._operation_store = OperationStore(
                self._session_factory,
                self._data_source_id,
            )
        return self._operation_store

    async def _ensure_source(self) -> str:
        """确保 DataSource 存在,返回 data_source_id(不存在则创建)。"""
        from sqlalchemy import select
        from sqlalchemy.exc import IntegrityError

        from zleap.sag.db import DataSource

        if not self._data_source_id:
            self._data_source_id = str(uuid.uuid4())

        async with self._session_factory() as session:
            exists = await session.execute(
                select(DataSource.id).where(DataSource.id == self._data_source_id)
            )
            if exists.scalar_one_or_none() is None:
                session.add(
                    DataSource(
                        id=self._data_source_id,
                        name=f"sag-{uuid.uuid4().hex[:8]}",
                        description="created by zleap-sag DataEngine",
                    )
                )
                try:
                    await session.commit()
                except IntegrityError:
                    # Two engines may both observe a missing namespace. The loser of the
                    # primary-key race is successful only when the requested row now exists;
                    # unrelated integrity failures must still surface.
                    await session.rollback()
                    raced = await session.execute(
                        select(DataSource.id).where(DataSource.id == self._data_source_id)
                    )
                    if raced.scalar_one_or_none() is None:
                        raise
        return self._data_source_id
