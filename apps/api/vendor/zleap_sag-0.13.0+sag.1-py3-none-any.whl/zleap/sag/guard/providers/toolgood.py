"""Built-in ToolGood.Words content-guard provider."""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Any

from zleap.sag.exceptions import StateError
from zleap.sag.guard.ports import (
    GuardCapability,
    GuardLevel,
    GuardText,
    GuardVerdict,
)

if TYPE_CHECKING:
    from zleap.sag.config import GuardConfig


class ToolgoodGuard:
    name = "toolgood"
    capabilities = frozenset({GuardCapability.BATCH, GuardCapability.MASKING})

    def __init__(self, config: GuardConfig) -> None:
        self._path = Path(config.words_file) if config.words_file else _packaged_words()
        self._searcher: Any | None = None
        self._lock = asyncio.Lock()

    async def warmup(self) -> None:
        async with self._lock:
            if self._searcher is None:
                self._searcher = await asyncio.to_thread(_build_searcher, self._path)

    async def inspect(self, texts: Sequence[GuardText]) -> Sequence[GuardVerdict]:
        await self.warmup()
        searcher = self._searcher
        if searcher is None:  # pragma: no cover - warmup establishes the invariant
            raise StateError("ToolGood.Words searcher is not initialized")
        verdicts: list[GuardVerdict] = []
        for item in texts:
            text = item.text or ""
            hits = searcher.FindAll(text)
            masked = searcher.Replace(text) if hits else None
            verdicts.append(_to_verdict(hits, masked=masked))
        return verdicts


def _packaged_words() -> Path:
    return (
        Path(__file__).resolve().parents[2]
        / "modules"
        / "guard"
        / "toolgood_words"
        / "BannedWords.txt"
    )


def _load_keywords(path: Path) -> list[str]:
    keywords: list[str] = []
    seen: set[str] = set()
    with path.open("r", encoding="utf-8-sig") as stream:
        for raw_line in stream:
            word = raw_line.strip()
            if not word or word.startswith("#") or word in seen:
                continue
            seen.add(word)
            keywords.append(word)
    return keywords


def _build_searcher(path: Path) -> Any:
    from zleap.sag.modules.guard import toolgood_words

    searcher = toolgood_words.WordsSearch()
    searcher.SetKeywords(_load_keywords(path))
    return searcher


def _to_verdict(hits: list[dict[str, Any]], *, masked: str | None) -> GuardVerdict:
    if not hits:
        return GuardVerdict()
    words = tuple(str(hit["Keyword"]) for hit in hits if hit.get("Keyword"))
    return GuardVerdict(
        level=GuardLevel.BLOCK,
        words=words,
        masked=masked,
        raw={"hits": hits},
    )
