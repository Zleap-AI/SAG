"""Built-in content-guard providers."""
