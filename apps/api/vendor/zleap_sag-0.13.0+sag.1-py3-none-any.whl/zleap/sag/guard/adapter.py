"""SearchAdapter decorator that applies a configured content guard."""

from __future__ import annotations

import asyncio
from collections.abc import Mapping, Sequence
from typing import Any, TypeVar

from pydantic import BaseModel

from zleap.sag._safe_error import safe_error_summary
from zleap.sag.guard.policy import GuardPolicy
from zleap.sag.guard.ports import ContentGuard, GuardError, GuardText, GuardVerdict
from zleap.sag.pipeline.contracts import (
    GraphNode,
    SearchGraph,
    SearchHit,
    SearchRequest,
    SearchResult,
)
from zleap.sag.pipeline.ports import SearchAdapter

_T = TypeVar("_T")


class GuardedSearchAdapter:
    """Filter search inputs and outputs without changing search executors."""

    def __init__(
        self,
        inner: SearchAdapter,
        guard: ContentGuard,
        policy: GuardPolicy,
    ) -> None:
        self._inner = inner
        self._guard = guard
        self._policy = policy

    async def search(self, request: SearchRequest) -> SearchResult:
        if not request.options.guard:
            return await self._inner.search(request)

        query_verdicts, query_errors = await self._inspect(
            [GuardText(text=request.query, kind="query", field="query")]
        )
        if self._policy.rejects(query_verdicts[0]):
            return SearchResult(
                query=request.query,
                original_query=request.query,
                stats={
                    "guard": {
                        "query_blocked": True,
                        "events": 0,
                        "chunks": 0,
                        "errors": query_errors,
                    }
                },
            )

        result = await self._inner.search(request)
        events, removed_event_ids, event_errors = await self._sift(result.events, kind="event")
        chunks, removed_chunk_ids, chunk_errors = await self._sift(result.chunks, kind="chunk")

        graph_nodes, graph_was_mapping = _graph_nodes(result.graph)
        graph_errors = 0
        removed_graph_ids: set[str] = set()
        removed_graph_event_ids: set[str] = set()
        removed_graph_chunk_ids: set[str] = set()
        if graph_nodes:
            probes = [
                GuardText(
                    text="\n".join(
                        (
                            node.name or "",
                            node.title or "",
                            node.summary or "",
                            node.content,
                            node.description,
                        )
                    ),
                    kind="graph_node",
                    field="name+title+summary+content+description",
                )
                for node in graph_nodes
            ]
            verdicts, graph_errors = await self._inspect(probes)
            for node, verdict in zip(graph_nodes, verdicts, strict=True):
                if not self._policy.rejects(verdict):
                    continue
                removed_graph_ids.add(node.id)
                if node.event_id:
                    removed_graph_event_ids.add(node.event_id)
                elif node.type == "event":
                    removed_graph_event_ids.add(node.id)
                if node.chunk_id:
                    removed_graph_chunk_ids.add(node.chunk_id)
                elif node.type == "chunk":
                    removed_graph_chunk_ids.add(node.id)

        removed_event_ids.update(removed_graph_event_ids)
        removed_chunk_ids.update(removed_graph_chunk_ids)
        if removed_graph_event_ids:
            events = tuple(hit for hit in events if hit.id not in removed_graph_event_ids)
        if removed_graph_chunk_ids:
            chunks = tuple(hit for hit in chunks if hit.id not in removed_graph_chunk_ids)

        filtered_events = len(result.events) - len(events)
        filtered_chunks = len(result.chunks) - len(chunks)
        errors = query_errors + event_errors + chunk_errors + graph_errors
        removed_ids = {
            *removed_event_ids,
            *removed_chunk_ids,
            *removed_graph_ids,
        }
        if not removed_ids and errors == 0:
            return result

        graph, removed_ids = _prune_graph(
            result.graph,
            removed_ids,
            was_mapping=graph_was_mapping,
        )
        paths = result.paths
        if paths is not None:
            paths = paths.model_copy(
                update={
                    "shortest_paths": _prune_mapping(paths.shortest_paths, removed_ids),
                    "longest_paths": _prune_mapping(paths.longest_paths, removed_ids),
                    "candidate_paths": _prune_mapping(paths.candidate_paths, removed_ids),
                    "nodes_by_depth": _prune_mapping(paths.nodes_by_depth, removed_ids),
                }
            )
        return result.model_copy(
            update={
                "events": events,
                "chunks": chunks,
                "graph": graph,
                "paths": paths,
                "stats": {
                    **result.stats,
                    "guard": {
                        "query_blocked": False,
                        "events": filtered_events,
                        "chunks": filtered_chunks,
                        "errors": errors,
                    },
                },
            }
        )

    async def _sift(
        self,
        hits: tuple[SearchHit, ...],
        *,
        kind: str,
    ) -> tuple[tuple[SearchHit, ...], set[str], int]:
        if not hits:
            return hits, set(), 0
        probes = [
            GuardText(
                text=f"{hit.title or ''}\n{hit.content}",
                kind=kind,
                field="title+content",
            )
            for hit in hits
        ]
        verdicts, errors = await self._inspect(probes)
        removed_ids = {
            hit.id
            for hit, verdict in zip(hits, verdicts, strict=True)
            if self._policy.rejects(verdict)
        }
        kept = tuple(hit for hit in hits if hit.id not in removed_ids)
        return kept, removed_ids, errors

    async def _inspect(
        self,
        probes: Sequence[GuardText],
    ) -> tuple[tuple[GuardVerdict, ...], int]:
        try:
            async with asyncio.timeout(self._policy.timeout_seconds):
                verdicts = tuple(await self._guard.inspect(probes))
        except Exception as exc:
            error = GuardError(safe_error_summary(exc, label="guard inspection failed"))
            return self._policy.on_error(probes, error), 1
        if len(verdicts) != len(probes):
            error = GuardError("verdict 数量与入参不一致")
            return self._policy.on_error(probes, error), 1
        return verdicts, 0


def _graph_nodes(graph: Any) -> tuple[tuple[GraphNode, ...], bool]:
    if isinstance(graph, SearchGraph):
        search_graph = graph
        was_mapping = False
    elif isinstance(graph, dict):
        try:
            search_graph = SearchGraph.model_validate(graph)
        except ValueError:
            return (), True
        was_mapping = True
    else:
        return (), False
    return search_graph.nodes, was_mapping


def _prune_graph(
    graph: Any,
    removed_ids: set[str],
    *,
    was_mapping: bool,
) -> tuple[Any, set[str]]:
    if not removed_ids:
        return graph, removed_ids
    if isinstance(graph, SearchGraph):
        search_graph = graph
    elif isinstance(graph, dict):
        try:
            search_graph = SearchGraph.model_validate(graph)
        except ValueError:
            return graph, removed_ids
    else:
        return graph, removed_ids

    kept_nodes = tuple(
        node for node in search_graph.nodes if not _references_removed_id(node, removed_ids)
    )
    removed_node_ids = {node.id for node in search_graph.nodes if node not in kept_nodes}
    all_removed_ids = {*removed_ids, *removed_node_ids}
    kept_clues = tuple(
        clue for clue in search_graph.clues if not _references_removed_id(clue, all_removed_ids)
    )
    pruned = search_graph.model_copy(update={"nodes": kept_nodes, "clues": kept_clues})
    if was_mapping:
        return pruned.model_dump(mode="json"), all_removed_ids
    return pruned, all_removed_ids


def _prune_mapping(mapping: Mapping[str, _T], removed_ids: set[str]) -> dict[str, _T]:
    return {
        key: value
        for key, value in mapping.items()
        if key not in removed_ids and not _references_removed_id(value, removed_ids)
    }


def _references_removed_id(value: Any, removed_ids: set[str]) -> bool:
    if not removed_ids:
        return False
    if isinstance(value, BaseModel):
        value = value.model_dump(mode="python")
    if isinstance(value, dict):
        for key in ("id", "event_id", "chunk_id", "source_id", "from", "to"):
            item_id = value.get(key)
            if item_id is not None and str(item_id) in removed_ids:
                return True
        return any(_references_removed_id(item, removed_ids) for item in value.values())
    if isinstance(value, (list, tuple, set)):
        return any(_references_removed_id(item, removed_ids) for item in value)
    return value is not None and str(value) in removed_ids
