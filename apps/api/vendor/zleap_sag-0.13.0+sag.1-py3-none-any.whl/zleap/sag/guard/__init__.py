"""Public content-guard plugin surface."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from zleap.sag.guard.policy import GuardPolicy
from zleap.sag.guard.ports import (
    ContentGuard,
    GuardCapability,
    GuardError,
    GuardLevel,
    GuardText,
    GuardVerdict,
)
from zleap.sag.guard.registry import build, register

if TYPE_CHECKING:
    from zleap.sag.config import GuardConfig


def __getattr__(name: str) -> Any:
    if name == "GuardConfig":
        from zleap.sag.config import GuardConfig

        return GuardConfig
    raise AttributeError(name)


__all__ = [
    "ContentGuard",
    "GuardText",
    "GuardVerdict",
    "GuardLevel",
    "GuardCapability",
    "GuardError",
    "GuardConfig",
    "GuardPolicy",
    "register",
    "build",
]
