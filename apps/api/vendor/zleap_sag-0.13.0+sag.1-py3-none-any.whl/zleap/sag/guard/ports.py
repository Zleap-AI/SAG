"""Provider-neutral content-guard contracts."""

from __future__ import annotations

from collections.abc import Sequence
from enum import StrEnum
from typing import Any, Protocol, runtime_checkable

from pydantic import Field

from zleap.sag.exceptions import SagError
from zleap.sag.validation import SagBaseModel as BaseModel


class GuardError(SagError):
    """A content-guard provider failed or violated its result contract."""


class GuardCapability(StrEnum):
    BATCH = "batch"
    MASKING = "masking"
    SCORING = "scoring"
    CATEGORIES = "categories"
    TRISTATE = "tristate"


class GuardText(BaseModel):
    """One text fragment plus optional provider context."""

    text: str | None
    kind: str = "unknown"
    field: str = ""
    language: str | None = None
    hints: dict[str, Any] = Field(default_factory=dict)


class GuardLevel(StrEnum):
    PASS = "pass"
    REVIEW = "review"
    BLOCK = "block"


class GuardVerdict(BaseModel):
    """Normalized verdict for one inspected text fragment."""

    level: GuardLevel = GuardLevel.PASS
    score: float | None = None
    categories: tuple[str, ...] = ()
    words: tuple[str, ...] = ()
    masked: str | None = None
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def blocked(self) -> bool:
        return self.level is GuardLevel.BLOCK


@runtime_checkable
class ContentGuard(Protocol):
    name: str
    capabilities: frozenset[GuardCapability]

    async def warmup(self) -> None: ...

    async def inspect(self, texts: Sequence[GuardText]) -> Sequence[GuardVerdict]: ...
