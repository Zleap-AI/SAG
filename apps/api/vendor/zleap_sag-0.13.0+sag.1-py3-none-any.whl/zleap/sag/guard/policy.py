"""Framework-owned decisions for normalized guard verdicts."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Literal

from zleap.sag.guard.ports import GuardLevel, GuardText, GuardVerdict
from zleap.sag.validation import SagBaseModel as BaseModel


class GuardPolicy(BaseModel):
    on_review: Literal["pass", "block"] = "pass"
    min_score: float | None = None
    block_categories: tuple[str, ...] = ()
    on_failure: Literal["fail_open", "fail_closed"] = "fail_open"
    timeout_seconds: float = 3.0

    def rejects(self, verdict: GuardVerdict) -> bool:
        if verdict.level is GuardLevel.PASS:
            return False
        if verdict.level is GuardLevel.REVIEW and self.on_review == "pass":
            return False
        if self.block_categories and verdict.categories:
            if not set(verdict.categories) & set(self.block_categories):
                return False
        if self.min_score is not None and verdict.score is not None:
            if verdict.score < self.min_score:
                return False
        return True

    def on_error(
        self,
        texts: Sequence[GuardText],
        error: Exception,
    ) -> tuple[GuardVerdict, ...]:
        del error
        level = GuardLevel.BLOCK if self.on_failure == "fail_closed" else GuardLevel.PASS
        return tuple(GuardVerdict(level=level) for _ in texts)
