"""Content-guard provider registry."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

from zleap.sag.exceptions import ConfigError
from zleap.sag.guard.ports import ContentGuard

if TYPE_CHECKING:
    from zleap.sag.config import GuardConfig

GuardFactory = Callable[["GuardConfig"], ContentGuard]

_PROVIDERS: dict[str, GuardFactory] = {}


def register(name: str, factory: GuardFactory) -> None:
    """Register a custom provider; duplicate names are replaced."""

    _PROVIDERS[name] = factory


def build(config: GuardConfig | None) -> ContentGuard | None:
    if config is None or not config.enabled:
        return None
    if not isinstance(config.provider, str):
        return config.provider

    if config.provider not in _PROVIDERS:
        _load_builtin(config.provider)
    try:
        factory = _PROVIDERS[config.provider]
    except KeyError:
        raise ConfigError(
            f"GuardConfig.provider={config.provider!r} 不受支持,"
            f"可选:{sorted(_PROVIDERS)};自定义 provider 需先 guard.register() 或直接传实例"
        ) from None
    return factory(config)


def _load_builtin(name: str) -> None:
    if name != "toolgood":
        return
    from zleap.sag.guard.providers.toolgood import ToolgoodGuard

    register("toolgood", ToolgoodGuard)
