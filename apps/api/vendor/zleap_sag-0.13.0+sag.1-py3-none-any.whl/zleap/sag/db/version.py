"""Single source of truth for the clean SAG 0.8 storage baseline."""

CURRENT_SCHEMA_VERSION = 4

__all__ = ["CURRENT_SCHEMA_VERSION"]
