"""Database-authoritative UTC clock for cross-process durable state."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import func, select

from zleap.sag.exceptions import DatabaseError


async def database_utcnow(session: Any) -> datetime:
    """Return the current database time as naive UTC for SAG timestamp columns."""

    value = await session.scalar(select(func.current_timestamp()))
    if not isinstance(value, datetime):
        raise DatabaseError("database did not return a datetime for CURRENT_TIMESTAMP")
    if value.tzinfo is not None and value.utcoffset() is not None:
        return value.astimezone(UTC).replace(tzinfo=None)
    return value


__all__ = ["database_utcnow"]
