"""normal/lite 关系 schema manifest、只读识别与合同校验。"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from functools import lru_cache
from typing import Literal

from sqlalchemy import MetaData, inspect
from sqlalchemy.engine import Connection
from sqlalchemy.engine.interfaces import (
    ReflectedColumn,
    ReflectedForeignKeyConstraint,
    ReflectedIndex,
    ReflectedPrimaryKeyConstraint,
    ReflectedUniqueConstraint,
)
from sqlalchemy.ext.asyncio import AsyncEngine
from sqlalchemy.sql.elements import quoted_name
from sqlalchemy.sql.schema import Table

from zleap.sag._safe_error import safe_error_summary
from zleap.sag.db.version import CURRENT_SCHEMA_VERSION
from zleap.sag.exceptions import (
    StorageInitializationError,
    StorageInitializationRequiredError,
    StorageLayoutConflictError,
    StorageModeMismatchError,
    StorageModeUndeterminedError,
    StorageSchemaMismatchError,
)

StorageMode = Literal["normal", "lite"]

COMMON_TABLE_NAMES: tuple[str, ...] = (
    "sag_schema_meta",
    "sag_operation",
    "sag_fence",
    "sag_data_source_manifest",
    "sag_source_manifest",
    "sag_search_session",
    "data_source",
    "kb_document",
    "article",
    "article_section",
    "chat_conversation",
    "chat_message",
    "entity_type",
    "entity",
    "event_entity",
    "source_chunk",
    "source_event",
)
MODE_TABLE_NAMES: dict[StorageMode, tuple[str, ...]] = {
    "normal": COMMON_TABLE_NAMES,
    "lite": COMMON_TABLE_NAMES,
}


class StorageModeState(StrEnum):
    """只读扫描得到的物理布局状态。"""

    EMPTY = "EMPTY"
    NORMAL = "NORMAL"
    LITE = "LITE"
    AMBIGUOUS = "AMBIGUOUS"
    CONFLICT = "CONFLICT"


@dataclass(frozen=True)
class RelationSnapshot:
    """一次 Inspector 扫描结果；校验过程不再发起 DDL。"""

    table_names: frozenset[str]
    columns: dict[str, list[ReflectedColumn]]
    primary_keys: dict[str, ReflectedPrimaryKeyConstraint]
    foreign_keys: dict[str, list[ReflectedForeignKeyConstraint]]
    indexes: dict[str, list[ReflectedIndex]]
    unique_constraints: dict[str, list[ReflectedUniqueConstraint]]
    storage_mode_marker: str | None
    schema_version: int | None


@dataclass(frozen=True)
class SchemaValidationResult:
    """合同校验结果：缺整表与已有表内部差异严格分开。"""

    missing_tables: tuple[str, ...]
    schema_diffs: tuple[str, ...]


@lru_cache(maxsize=2)
def mode_metadata(storage_mode: StorageMode) -> MetaData:
    """构造与全局 ORM Metadata 分离的当前模式建表 manifest。"""
    import zleap.sag.db.models  # noqa: F401
    from zleap.sag.db.base import NAMING_CONVENTION, Base

    metadata = MetaData(naming_convention=NAMING_CONVENTION)
    for name in MODE_TABLE_NAMES[storage_mode]:
        Base.metadata.tables[name].to_metadata(metadata)
    return metadata


def mode_tables(storage_mode: StorageMode) -> list[Table]:
    """返回当前模式的明确 Table manifest。"""
    metadata = mode_metadata(storage_mode)

    return [metadata.tables[name] for name in MODE_TABLE_NAMES[storage_mode]]


def _ddl_metadata(storage_mode: StorageMode, dialect_name: str) -> MetaData:
    """为需要 schema 级唯一索引名的方言构造独立 DDL metadata。"""
    metadata = mode_metadata(storage_mode)
    if dialect_name not in {"postgresql", "sqlite"}:
        return metadata

    ddl_metadata = MetaData(naming_convention=metadata.naming_convention)
    for table in metadata.sorted_tables:
        table.to_metadata(ddl_metadata)

    # MySQL 的索引名只需表内唯一；PostgreSQL 和 SQLite 的索引名则与
    # schema 中的其他 relation 共享命名空间。只修改 DDL 副本，避免
    # 改变用于宿主合同校验的正式 metadata。
    seen_relation_names = {table.name for table in ddl_metadata.tables.values()}
    for table in ddl_metadata.sorted_tables:
        indexes = sorted(
            table.indexes,
            key=lambda index: (
                index.name or "",
                tuple(column.name for column in index.columns),
            ),
        )
        for index in indexes:
            if index.name is None:
                continue
            if index.name not in seen_relation_names:
                seen_relation_names.add(index.name)
                continue

            base_name = f"{table.name}_{index.name}"
            candidate = base_name
            suffix = 2
            while candidate in seen_relation_names:
                candidate = f"{base_name}_{suffix}"
                suffix += 1
            index.name = quoted_name(candidate, quote=None)
            seen_relation_names.add(candidate)

    return ddl_metadata


def _read_snapshot(connection: Connection) -> RelationSnapshot:
    inspector = inspect(connection)
    names = frozenset(inspector.get_table_names())
    sag_names = names.intersection(set(COMMON_TABLE_NAMES))
    columns = {name: inspector.get_columns(name) for name in sag_names}
    storage_mode_marker: str | None = None
    schema_version: int | None = None
    marker_columns = {item["name"] for item in columns.get("sag_schema_meta", [])}
    if {"id", "storage_mode", "schema_version"}.issubset(marker_columns):
        row = connection.exec_driver_sql(
            "SELECT storage_mode, schema_version FROM sag_schema_meta WHERE id = 1"
        ).first()
        if row is not None:
            storage_mode_marker = str(row[0])
            schema_version = int(row[1])
    return RelationSnapshot(
        table_names=names,
        columns=columns,
        primary_keys={name: inspector.get_pk_constraint(name) for name in sag_names},
        foreign_keys={name: inspector.get_foreign_keys(name) for name in sag_names},
        indexes={name: inspector.get_indexes(name) for name in sag_names},
        unique_constraints={name: inspector.get_unique_constraints(name) for name in sag_names},
        storage_mode_marker=storage_mode_marker,
        schema_version=schema_version,
    )


async def inspect_relation_schema(engine: AsyncEngine) -> RelationSnapshot:
    """使用 SQLAlchemy reflection 只读扫描关系 schema。"""
    async with engine.connect() as connection:
        return await connection.run_sync(_read_snapshot)


class StorageModeDetector:
    """以持久模式标记判定布局；四个向量对象名在两种模式中完全相同。"""

    @staticmethod
    def detect(
        snapshot: RelationSnapshot,
        *,
        normal_vector_objects: frozenset[str] = frozenset(),
        vector_mode: str | None = None,
    ) -> StorageModeState:
        marker = snapshot.storage_mode_marker
        # 持久模式标记是权威；不受非 SAG 管理表影响。
        if marker is not None:
            if marker not in ("normal", "lite"):
                return StorageModeState.CONFLICT
            return StorageModeState(marker.upper())

        # Unmanaged tables neither identify a mode nor block SAG initialization.
        sag_tables = snapshot.table_names.intersection(set(COMMON_TABLE_NAMES))

        if not sag_tables:
            if vector_mode == "AMBIGUOUS":
                return StorageModeState.AMBIGUOUS
            return StorageModeState.EMPTY

        # 共享关系表和四个向量对象均不能区分 local/saas，已有库必须先补
        # sag_schema_meta，不能再把无标记库默认为 normal。
        _ = normal_vector_objects
        return StorageModeState.AMBIGUOUS

    @staticmethod
    def ensure_matches(state: StorageModeState, storage_mode: StorageMode) -> None:
        if state == StorageModeState.CONFLICT:
            raise StorageLayoutConflictError("关系库和向量库中出现互斥的模式专属结构")
        if state == StorageModeState.AMBIGUOUS:
            raise StorageModeUndeterminedError("现有 SAG 结构不足以唯一识别 storage_mode")
        if state in (StorageModeState.NORMAL, StorageModeState.LITE):
            actual = state.value.lower()
            if actual != storage_mode:
                raise StorageModeMismatchError(
                    f"storage_mode={storage_mode} 不能访问已识别为 {actual} 的存储"
                )


def _type_signature(column_type: object) -> tuple[object, ...]:
    """把不同方言反射类型归一为可比较的语义签名。"""
    affinity = getattr(column_type, "_type_affinity", type(column_type))
    name = getattr(affinity, "__name__", str(affinity)).upper()
    concrete_name = type(column_type).__name__.upper()
    # MySQL 没有独立布尔类型：BOOLEAN 建表后反射回 TINYINT(1)，其 affinity 是
    # Integer。只有具体类型为 TINYINT 且 display_width == 1 才是布尔语义，
    # 普通 TINYINT(4) 仍算整数；INT(1) 不会误判为布尔。
    if concrete_name == "TINYINT" and getattr(column_type, "display_width", None) == 1:
        family = "BOOLEAN"
    elif "CHAR" in name or "STRING" in name:
        family = "STRING"
    elif "BIGINT" in name:
        family = "BIGINT"
    elif "INT" in name:
        family = "INTEGER"
    elif "TEXT" in name:
        family = "TEXT"
    elif "JSON" in name:
        family = "JSON"
    elif "DATE" in name or "TIME" in name:
        family = "DATETIME"
    elif "BOOL" in name:
        family = "BOOLEAN"
    elif "NUMERIC" in name or "DECIMAL" in name:
        family = "NUMERIC"
    elif "BINARY" in name or "BLOB" in name:
        family = "BINARY"
    else:
        family = name
    # SQLite 不保存 BLOB 长度，TEXT/JSON/DateTime 也没有可移植长度语义；
    # 只有字符串长度和数值精度属于跨方言合同。
    return (
        family,
        getattr(column_type, "length", None) if family == "STRING" else None,
        getattr(column_type, "precision", None) if family == "NUMERIC" else None,
        getattr(column_type, "scale", None) if family == "NUMERIC" else None,
    )


def _index_signatures(snapshot: RelationSnapshot, table_name: str) -> set[tuple]:
    signatures: set[tuple] = set()
    for item in snapshot.indexes.get(table_name, []):
        signatures.add((tuple(item.get("column_names") or ()), bool(item.get("unique", False))))
    for unique_item in snapshot.unique_constraints.get(table_name, []):
        signatures.add((tuple(unique_item.get("column_names") or ()), True))
    return signatures


def _fk_signature(item: ReflectedForeignKeyConstraint) -> tuple:
    options = {str(k).lower(): str(v).upper() for k, v in (item.get("options") or {}).items()}
    return (
        tuple(item["constrained_columns"]),
        item["referred_table"],
        tuple(item["referred_columns"]),
        options.get("ondelete"),
        options.get("onupdate"),
    )


class SchemaContractValidator:
    """逐对象校验已有表；不创建、修复或迁移任何对象。"""

    @staticmethod
    def validate(snapshot: RelationSnapshot, storage_mode: StorageMode) -> SchemaValidationResult:
        tables = mode_tables(storage_mode)
        missing = tuple(t.name for t in tables if t.name not in snapshot.table_names)
        diffs: list[str] = []

        if "sag_schema_meta" in snapshot.table_names and snapshot.storage_mode_marker is None:
            diffs.append("sag_schema_meta: 缺少 id=1 的 storage_mode 标记")
        if (
            "sag_schema_meta" in snapshot.table_names
            and snapshot.schema_version != CURRENT_SCHEMA_VERSION
        ):
            diffs.append(
                "sag_schema_meta.schema_version: "
                f"{snapshot.schema_version} != {CURRENT_SCHEMA_VERSION}"
            )

        for table in tables:
            if table.name not in snapshot.table_names:
                continue
            actual_columns = {item["name"]: item for item in snapshot.columns.get(table.name, [])}
            expected_columns = {column.name: column for column in table.columns}
            for name, expected in expected_columns.items():
                actual = actual_columns.get(name)
                if actual is None:
                    diffs.append(f"{table.name}.{name}: 缺少字段")
                    continue
                expected_type = _type_signature(expected.type)
                actual_type = _type_signature(actual["type"])
                if expected_type != actual_type:
                    diffs.append(f"{table.name}.{name}: 类型 {actual_type} != {expected_type}")
                if bool(actual.get("nullable", True)) != bool(expected.nullable):
                    diffs.append(
                        f"{table.name}.{name}: nullable={actual.get('nullable')} "
                        f"!= {expected.nullable}"
                    )
            for name, actual in actual_columns.items():
                if name not in expected_columns and not bool(actual.get("nullable", True)):
                    diffs.append(f"{table.name}.{name}: 不允许额外的非空字段")

            expected_pk = tuple(column.name for column in table.primary_key.columns)
            primary_key = snapshot.primary_keys.get(table.name)
            actual_pk = tuple(primary_key["constrained_columns"]) if primary_key else ()
            if actual_pk != expected_pk:
                diffs.append(f"{table.name}: 主键 {actual_pk} != {expected_pk}")

            actual_indexes = _index_signatures(snapshot, table.name)
            for index in table.indexes:
                expected_index = (
                    tuple(column.name for column in index.columns),
                    bool(index.unique),
                )
                if expected_index not in actual_indexes:
                    diffs.append(
                        f"{table.name}: 缺少索引 columns={expected_index[0]} "
                        f"unique={expected_index[1]}"
                    )

            actual_fks = {_fk_signature(item) for item in snapshot.foreign_keys.get(table.name, [])}
            for constraint in table.foreign_key_constraints:
                expected_fk = (
                    tuple(element.parent.name for element in constraint.elements),
                    next(iter(constraint.elements)).column.table.name,
                    tuple(element.column.name for element in constraint.elements),
                    constraint.ondelete.upper() if constraint.ondelete else None,
                    constraint.onupdate.upper() if constraint.onupdate else None,
                )
                if expected_fk not in actual_fks:
                    diffs.append(f"{table.name}: 缺少或错误外键 {expected_fk}")

        return SchemaValidationResult(missing, tuple(diffs))


async def create_missing_relation_tables(engine: AsyncEngine, storage_mode: StorageMode) -> None:
    """创建当前 manifest 缺表，并在同一事务写入持久模式标记。"""
    metadata = _ddl_metadata(storage_mode, engine.dialect.name)
    tables = [metadata.tables[name] for name in MODE_TABLE_NAMES[storage_mode]]
    marker_table = metadata.tables["sag_schema_meta"]

    def _create_and_stamp(sync_connection: Connection) -> None:
        metadata.create_all(sync_connection, tables=tables, checkfirst=True)
        current = sync_connection.execute(
            marker_table.select()
            .with_only_columns(marker_table.c.storage_mode)
            .where(marker_table.c.id == 1)
        ).scalar_one_or_none()
        if current is None:
            sync_connection.execute(
                marker_table.insert().values(
                    id=1,
                    storage_mode=storage_mode,
                    schema_version=CURRENT_SCHEMA_VERSION,
                )
            )
        elif current != storage_mode:
            raise StorageModeMismatchError(
                f"storage_mode={storage_mode} 不能访问标记为 {current} 的关系存储"
            )

    try:
        async with engine.begin() as connection:
            await connection.run_sync(_create_and_stamp)
    except StorageModeMismatchError:
        raise
    except Exception as exc:
        if not _is_already_exists_error(exc):
            raise StorageInitializationError(
                safe_error_summary(
                    exc,
                    label=f"创建 storage_mode={storage_mode} 关系 schema 失败",
                )
            ) from exc
        # 并发初始化的另一实例已创建对象；调用方会立即重新
        # reflection 并做完整合同校验，不会盲目继续。


def _is_already_exists_error(exc: Exception) -> bool:
    """只识别各方言的“对象已存在”并发竞态。"""
    original = getattr(exc, "orig", exc)
    args = getattr(original, "args", ())
    codes = {str(value).upper() for value in args[:1]}
    code = getattr(original, "pgcode", None) or getattr(original, "sqlstate", None)
    if code is not None:
        codes.add(str(code).upper())
    if codes.intersection({"1050", "1062", "1555", "2067", "23505", "42P07", "42710"}):
        return True
    message = str(original).lower()
    return any(
        marker in message
        for marker in (
            "already exists",
            "duplicate table",
            "duplicate entry",
            "resource_already_exists_exception",
            "unique constraint failed: sag_schema_meta.id",
        )
    )


async def prepare_relation_schema(
    engine: AsyncEngine,
    *,
    provider: str,
    storage_mode: StorageMode,
    explicit_init: bool = False,
    normal_vector_objects: frozenset[str] = frozenset(),
    vector_mode: str | None = None,
) -> StorageModeState:
    """识别、校验并按 provider 规则补建完整表，最后再次复检。"""
    snapshot = await inspect_relation_schema(engine)
    state = StorageModeDetector.detect(
        snapshot,
        normal_vector_objects=normal_vector_objects,
        vector_mode=vector_mode,
    )
    if state is StorageModeState.CONFLICT:
        StorageModeDetector.ensure_matches(state, storage_mode)
    validation = SchemaContractValidator.validate(snapshot, storage_mode)
    if validation.schema_diffs:
        raise StorageSchemaMismatchError(
            "已有关系表不符合 schema 合同", diffs=list(validation.schema_diffs)
        )
    StorageModeDetector.ensure_matches(state, storage_mode)

    may_create = provider == "sqlite" or explicit_init
    if validation.missing_tables and not may_create:
        raise StorageInitializationRequiredError(
            "关系库缺少当前模式的完整表，请先显式调用 init_schema()",
            missing_objects=list(validation.missing_tables),
        )
    if validation.missing_tables:
        await create_missing_relation_tables(engine, storage_mode)

    final_snapshot = await inspect_relation_schema(engine)
    final_state = StorageModeDetector.detect(
        final_snapshot,
        normal_vector_objects=normal_vector_objects,
        vector_mode=vector_mode,
    )
    StorageModeDetector.ensure_matches(final_state, storage_mode)
    final_validation = SchemaContractValidator.validate(final_snapshot, storage_mode)
    if final_validation.missing_tables or final_validation.schema_diffs:
        diffs = list(final_validation.schema_diffs) + [
            f"{name}: 创建后仍缺失" for name in final_validation.missing_tables
        ]
        raise StorageSchemaMismatchError("关系 schema 初始化后复检失败", diffs=diffs)
    return final_state
