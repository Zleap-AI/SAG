"""公开存储组合入口。

宿主应用可在自己的 API/Worker 组合根中构建一次 ``StorageResources``，并明确
管理关系库与向量库的生命周期。相同连接参数只代表物理单库，两侧 runtime/连接池
仍始终独立。
"""

from typing import Any

from zleap.sag.config import (
    ElasticsearchVectorConfig,
    LanceDBVectorConfig,
    OceanBaseConnectionConfig,
    OceanBaseVectorConfig,
    ParadeDBVectorConfig,
    PgVectorConfig,
    PostgresConnectionConfig,
    PostgresTLSConfig,
    RelationalConfig,
    VectorConfig,
)
from zleap.sag.core.adapters import (
    BulkResult,
    FailedItem,
    Filter,
    VectorHit,
    VectorQuery,
    VectorRecord,
)
from zleap.sag.core.resources import StorageResources
from zleap.sag.core.resources import build_storage as _build_storage
from zleap.sag.exceptions import SagError


def build_storage(config: Any = None) -> StorageResources:
    """Build public storage resources without leaking provider exceptions."""
    try:
        return _build_storage(config)
    except SagError:
        raise
    except Exception as exc:
        raise SagError.wrap(exc, operation="build_storage") from exc


__all__ = [
    "ElasticsearchVectorConfig",
    "BulkResult",
    "FailedItem",
    "Filter",
    "LanceDBVectorConfig",
    "OceanBaseConnectionConfig",
    "OceanBaseVectorConfig",
    "ParadeDBVectorConfig",
    "PgVectorConfig",
    "PostgresConnectionConfig",
    "PostgresTLSConfig",
    "RelationalConfig",
    "StorageResources",
    "VectorConfig",
    "VectorHit",
    "VectorQuery",
    "VectorRecord",
    "build_storage",
]
