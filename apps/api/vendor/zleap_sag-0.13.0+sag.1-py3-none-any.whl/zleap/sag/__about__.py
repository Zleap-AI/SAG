"""Single source of truth for the package version (read by hatchling)."""

__version__ = "0.13.0"
