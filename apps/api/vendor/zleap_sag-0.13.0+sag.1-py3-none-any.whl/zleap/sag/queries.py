"""Public stable-query contracts."""

from __future__ import annotations

from datetime import datetime

from pydantic import Field, model_validator

from zleap.sag.exceptions import ValidationError as SagValidationError
from zleap.sag.pipeline.contracts import (
    ContractModel,
    SearchRequest,
    SearchResult,
)


class SearchPageRequest(ContractModel):
    request: SearchRequest | None = None
    cursor: str | None = None
    cursor_request: SearchRequest | None = None
    page_size: int = Field(default=50, ge=1, le=200)
    ttl_seconds: int = Field(default=300, ge=30, le=3600)

    @model_validator(mode="after")
    def _exactly_one_entrypoint(self) -> SearchPageRequest:
        if (self.request is None) == (self.cursor is None):
            raise SagValidationError("exactly one of request or cursor is required")
        if self.cursor is not None and self.cursor_request is None:
            raise SagValidationError("cursor_request is required when resuming a cursor")
        if self.request is not None and self.cursor_request is not None:
            raise SagValidationError("cursor_request is only valid when resuming a cursor")
        return self


class SearchPage(ContractModel):
    session_id: str
    result: SearchResult
    offset: int = Field(ge=0)
    page_size: int = Field(ge=1)
    total: int = Field(ge=0)
    next_cursor: str | None = None
    expires_at: datetime
    revision: dict[str, int] = Field(default_factory=dict)


__all__ = ["SearchPage", "SearchPageRequest"]
