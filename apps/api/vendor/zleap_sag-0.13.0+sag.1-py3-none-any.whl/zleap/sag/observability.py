"""Provider-neutral, best-effort observation of bounded SAG engine events."""

from __future__ import annotations

import inspect
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from enum import StrEnum
from typing import Literal, Protocol, TypeAlias

from pydantic import Field

from zleap.sag.operations import (
    OperationCheckpoint,
    OperationStatus,
    OperationType,
)
from zleap.sag.pipeline.contracts import ContractModel


class OperationEventKind(StrEnum):
    STARTED = "started"
    CHECKPOINT = "checkpoint"
    CONTENDED = "contended"
    REPLAYED = "replayed"
    COMPLETED = "completed"


class OperationEvent(ContractModel):
    """Low-cardinality event; durable or tenant identifiers are intentionally absent."""

    kind: OperationEventKind
    operation_type: OperationType
    checkpoint: OperationCheckpoint
    status: OperationStatus
    duration_seconds: float = Field(ge=0)
    attempts: int = Field(ge=0)
    failure_code: str | None = None
    retryable: bool | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))


class SearchOutcome(StrEnum):
    SUCCEEDED = "succeeded"
    CURSOR_EXPIRED = "cursor_expired"
    CURSOR_INVALID = "cursor_invalid"
    DEPENDENCY_UNAVAILABLE = "dependency_unavailable"
    REQUEST_REJECTED = "request_rejected"
    EXECUTION_FAILED = "execution_failed"


class SearchStrategyMetric(StrEnum):
    VECTOR = "vector"
    ATOMIC = "atomic"
    FULL_EXPAND = "full_expand"
    PRUNED_EXPAND_LLM = "pruned_expand_llm"
    PRUNED_EXPAND_RERANK = "pruned_expand_rerank"
    PRUNED_EXPAND_RFF = "pruned_expand_rff"
    CUSTOM = "custom"

    @classmethod
    def from_strategy(cls, strategy: str) -> SearchStrategyMetric:
        try:
            return cls(strategy)
        except ValueError:
            return cls.CUSTOM


class SearchEvent(ContractModel):
    """Low-cardinality search result; query, cursor and scope are never included."""

    outcome: SearchOutcome
    strategy: SearchStrategyMetric
    return_type: Literal["event", "chunk"]
    paged: bool
    resumed: bool
    duration_seconds: float = Field(ge=0)
    result_count: int = Field(ge=0)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))


EngineEvent: TypeAlias = OperationEvent | SearchEvent


class EngineObserver(Protocol):
    def __call__(self, event: EngineEvent) -> Awaitable[None] | None: ...


Observer = EngineObserver | Callable[[EngineEvent], Awaitable[None] | None]


async def notify_engine_observer(
    observer: Observer | None,
    event: EngineEvent,
) -> None:
    """Keep telemetry failures outside durable operations and search results."""

    if observer is None:
        return
    try:
        result = observer(event)
        if inspect.isawaitable(result):
            await result
    except Exception:
        return


__all__ = [
    "EngineEvent",
    "EngineObserver",
    "OperationEvent",
    "OperationEventKind",
    "SearchEvent",
    "SearchOutcome",
    "SearchStrategyMetric",
]
