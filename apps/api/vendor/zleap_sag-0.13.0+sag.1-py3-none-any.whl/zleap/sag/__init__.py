"""zleap-sag —— SAG 数据引擎(写入 / 抽取 / 检索 / 查询)。

主入口::

    from zleap.sag import DataEngine, EngineConfig

细节按需从子模块导入(遵循主流库惯例,保持顶层精简):

- 存储配置/资源 → ``zleap.sag.storage`` (VectorConfig / StorageResources / build_storage)
- 其他配置子模型 → ``zleap.sag.config``
  (LLMConfig / VLMConfig / ImageProcessingConfig / EmbeddingConfig / RerankConfig / EntityTypeConfig)
- 持久写入/删除 → ``zleap.sag.operations`` (OperationContext / ProcessSourceRequest / OperationResult)
- 稳定分页/读取 → ``zleap.sag.queries`` / ``zleap.sag.records``
- 维护与状态   → ``zleap.sag.maintenance`` / ``zleap.sag.status``
- 启动模型探测 → ``zleap.sag.preflight`` (verify_model_access)
- 显式流水线合同 → ``zleap.sag.pipeline`` (SearchRequest / ChunkSetRef / EventSetRef 等)
- 异常层级   → ``zleap.sag.exceptions`` (均继承自 :class:`SagError`)
"""

from zleap.sag.__about__ import __version__
from zleap.sag.config import EngineConfig
from zleap.sag.engine import DataEngine
from zleap.sag.exceptions import SagError
from zleap.sag.maintenance import MaintenancePolicy, MaintenanceResult
from zleap.sag.observability import (
    EngineEvent,
    EngineObserver,
    OperationEvent,
    OperationEventKind,
    SearchEvent,
    SearchOutcome,
    SearchStrategyMetric,
)
from zleap.sag.status import EngineCapabilities, EngineHealth, SchemaStatus

__all__ = [
    "__version__",
    "DataEngine",
    "EngineCapabilities",
    "EngineConfig",
    "EngineEvent",
    "EngineHealth",
    "EngineObserver",
    "MaintenancePolicy",
    "MaintenanceResult",
    "OperationEvent",
    "OperationEventKind",
    "SagError",
    "SchemaStatus",
    "SearchEvent",
    "SearchOutcome",
    "SearchStrategyMetric",
]
