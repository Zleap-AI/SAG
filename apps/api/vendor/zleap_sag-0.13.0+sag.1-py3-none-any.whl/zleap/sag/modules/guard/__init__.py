"""Vendored content-guard implementations."""
