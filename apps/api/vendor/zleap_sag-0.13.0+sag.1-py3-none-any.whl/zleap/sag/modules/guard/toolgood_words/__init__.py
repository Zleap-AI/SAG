"""Lazy loader for the vendored ToolGood.Words Python implementation.

Source: ``D:\\zleap-platform\\ToolGood.Words\\python``
License: Apache License 2.0
"""

from __future__ import annotations

import importlib.util
from functools import cache, lru_cache
from pathlib import Path
from types import ModuleType
from typing import Any

_BASE_DIR = Path(__file__).resolve().parent
_MODULE_FILES = {
    "Pinyin": "ToolGood.Words.Pinyin.py",
    "StringSearch": "ToolGood.Words.StringSearch.py",
    "Translate": "ToolGood.Words.Translate.py",
    "WordsSearch": "ToolGood.Words.WordsSearch.py",
}


@cache
def _load_module(file_name: str) -> ModuleType:
    module_path = _BASE_DIR / file_name
    module_name = f"{__name__}.{module_path.stem.replace('.', '_')}"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load ToolGood.Words module: {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def __getattr__(name: str) -> Any:
    file_name = _MODULE_FILES.get(name)
    if file_name is None:
        raise AttributeError(name)
    return getattr(_load_module(file_name), name)


__all__ = ["Pinyin", "StringSearch", "Translate", "WordsSearch"]
