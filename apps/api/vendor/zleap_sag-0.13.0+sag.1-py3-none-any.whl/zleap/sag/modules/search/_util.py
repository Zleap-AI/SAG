"""Search 模块共用的工具。"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC
from typing import Any


def _record_id(row: Mapping[str, Any], field: str) -> str | None:
    value = row.get(field) or row.get("id")
    return str(value) if value else None


def _naive_utc(value: Any) -> Any:
    if value is None or value.tzinfo is None:
        return value
    return value.astimezone(UTC).replace(tzinfo=None)


def _physical_source_types(source_types: tuple[str, ...]) -> tuple[str, ...]:
    mapping = {
        "text": "ARTICLE",
        "article": "ARTICLE",
        "chat": "CHAT",
        "recording": "RECORDING",
    }
    return tuple(dict.fromkeys(mapping[item] for item in source_types))


__all__ = ["_record_id", "_naive_utc", "_physical_source_types"]
