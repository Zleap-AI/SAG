"""Bounded deterministic path analysis over a request-local production route trace."""

from __future__ import annotations

import math
from collections import defaultdict
from typing import cast

from pydantic import JsonValue

from zleap.sag.modules.search.tracker import RouteTraceSnapshot, Tracker
from zleap.sag.pipeline.contracts import GraphClue, GraphNode, PathAnalysisResult


def _path_confidence(path: tuple[GraphClue, ...]) -> float:
    return math.prod(clue.confidence for clue in path)


def _path_key(path: tuple[GraphClue, ...]) -> tuple[int, float, tuple[str, ...]]:
    return len(path), -_path_confidence(path), tuple(clue.id for clue in path)


class PathAnalyzer:
    """Enumerate simple query-to-target paths with hard depth and count limits.

    ``target_event_ids`` 语义为“最终答案目标 id”：event 模式下是 event id，chunk 模式下
    是 chunk id，此时返回的路径集均以 chunk_id 为键。
    """

    HARD_MAX_DEPTH = 32
    HARD_MAX_PATHS_PER_EVENT = 200

    def analyze(
        self,
        *,
        trace: Tracker | RouteTraceSnapshot,
        target_event_ids: list[str],
        max_depth: int,
        max_paths_per_event: int = 20,
    ) -> PathAnalysisResult:
        snapshot = trace.snapshot() if isinstance(trace, Tracker) else trace
        effective_depth = max(1, min(int(max_depth), self.HARD_MAX_DEPTH))
        effective_limit = max(
            1,
            min(int(max_paths_per_event), self.HARD_MAX_PATHS_PER_EVENT),
        )

        paths_by_event: dict[str, tuple[tuple[GraphClue, ...], ...]] = {}
        truncated_events: list[str] = []
        cycle_edges_skipped = 0
        depth_edges_skipped = 0

        for event_id in dict.fromkeys(target_event_ids):
            if event_id not in snapshot.nodes:
                continue
            found, truncated, skipped_cycles, skipped_depth = self._enumerate_paths(
                snapshot,
                event_id,
                max_depth=effective_depth,
                max_paths=effective_limit,
            )
            cycle_edges_skipped += skipped_cycles
            depth_edges_skipped += skipped_depth
            ordered = tuple(sorted(found, key=_path_key))
            if ordered:
                paths_by_event[event_id] = ordered
            if truncated:
                truncated_events.append(event_id)

        shortest_paths = {event_id: paths[0] for event_id, paths in paths_by_event.items()}
        longest_paths = {
            event_id: sorted(
                paths,
                key=lambda path: (
                    -len(path),
                    -_path_confidence(path),
                    tuple(clue.id for clue in path),
                ),
            )[0]
            for event_id, paths in paths_by_event.items()
        }
        nodes_by_depth = self._entities_by_hop(snapshot, paths_by_event)
        return PathAnalysisResult(
            shortest_paths=shortest_paths,
            longest_paths=longest_paths,
            candidate_paths=paths_by_event,
            nodes_by_depth=nodes_by_depth,
            stats={
                "max_depth": effective_depth,
                "max_paths_per_event": effective_limit,
                "target_event_count": len(tuple(dict.fromkeys(target_event_ids))),
                "event_with_path_count": len(paths_by_event),
                "total_path_count": sum(len(paths) for paths in paths_by_event.values()),
                "truncated": bool(truncated_events),
                "truncated_event_ids": cast(JsonValue, truncated_events),
                "cycle_edges_skipped": cycle_edges_skipped,
                "depth_edges_skipped": depth_edges_skipped,
            },
        )

    @staticmethod
    def _enumerate_paths(
        snapshot: RouteTraceSnapshot,
        event_id: str,
        *,
        max_depth: int,
        max_paths: int,
    ) -> tuple[list[tuple[GraphClue, ...]], bool, int, int]:
        found: list[tuple[GraphClue, ...]] = []
        seen_path_keys: set[tuple[str, ...]] = set()
        truncated = False
        cycle_edges_skipped = 0
        depth_edges_skipped = 0

        def walk(
            node_id: str,
            reversed_path: tuple[GraphClue, ...],
            visited: frozenset[str],
        ) -> None:
            nonlocal cycle_edges_skipped, depth_edges_skipped, truncated
            node = snapshot.nodes[node_id]
            if node.type == "query" and node.category == "origin":
                path = tuple(reversed(reversed_path))
                key = tuple(clue.id for clue in path)
                if key not in seen_path_keys:
                    seen_path_keys.add(key)
                    found.append(path)
                return
            incoming_ids = tuple(sorted(snapshot.incoming.get(node_id, ())))
            if len(reversed_path) >= max_depth:
                if incoming_ids:
                    depth_edges_skipped += len(incoming_ids)
                    truncated = True
                return
            for clue_id in incoming_ids:
                if len(found) >= max_paths:
                    truncated = True
                    return
                clue = snapshot.clues[clue_id]
                if clue.from_id in visited:
                    cycle_edges_skipped += 1
                    continue
                walk(
                    clue.from_id,
                    (*reversed_path, clue),
                    visited | {clue.from_id},
                )

        walk(event_id, (), frozenset({event_id}))
        return found, truncated, cycle_edges_skipped, depth_edges_skipped

    @staticmethod
    def _entities_by_hop(
        snapshot: RouteTraceSnapshot,
        paths_by_event: dict[str, tuple[tuple[GraphClue, ...], ...]],
    ) -> dict[str, tuple[GraphNode, ...]]:
        by_hop: dict[int, dict[str, GraphNode]] = defaultdict(dict)
        for paths in paths_by_event.values():
            for path in paths:
                for clue in path:
                    for node_id in (clue.from_id, clue.to_id):
                        node = snapshot.nodes.get(node_id)
                        if node is not None and node.type == "entity":
                            by_hop[node.hop][node.id] = node
        return {
            str(hop): tuple(nodes[node_id] for node_id in sorted(nodes))
            for hop, nodes in sorted(by_hop.items())
        }


__all__ = ["PathAnalyzer", "PathAnalysisResult"]
