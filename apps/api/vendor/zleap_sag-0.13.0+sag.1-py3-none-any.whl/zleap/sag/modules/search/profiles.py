"""Stable built-in search profiles.

Profiles contain defaults only. A request may override supported fields, and the
resolver freezes the merged values into one :class:`SearchExecutionPlan`.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import ConfigDict, Field, model_validator

from zleap.sag.core.adapters import Capability
from zleap.sag.exceptions import ValidationError as SagValidationError
from zleap.sag.pipeline.options import (
    BuiltinSearchStrategy,
    EntityRecallOptions,
    EventRecallOptions,
    GraphSearchOptions,
    QueryProcessingOptions,
    RankingOptions,
    RecallOptions,
    SearchOutputOptions,
    SelectionOptions,
)
from zleap.sag.validation import SagBaseModel as BaseModel


class SearchExecutorKind(StrEnum):
    VECTOR = "vector"
    ATOMIC = "atomic"
    PRODUCTION = "production"


class SearchProfilePolicy(BaseModel):
    """Public strategy constraints, independent from an executor implementation."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    allowed_return_types: frozenset[Literal["event", "chunk"]] = frozenset({"event", "chunk"})
    allowed_ranking_methods: frozenset[Literal["vector", "weighted", "rrf", "rerank", "llm"]] = (
        frozenset({"vector", "weighted", "rrf", "rerank", "llm"})
    )
    allowed_entity_extraction: frozenset[Literal["disabled", "rewrite", "llm", "lexical"]] = (
        frozenset({"disabled", "rewrite", "llm", "lexical"})
    )
    allow_query_rewrite: bool = True
    allow_query_normalization: bool = True
    allow_graph: bool = True
    allow_graph_output: bool = True
    allow_paths: bool = True
    allow_selection: bool = True
    allow_candidate_pool: bool = True


class SearchProfile(BaseModel):
    """An immutable profile snapshot registered under a public strategy name."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str
    executor: str
    query: QueryProcessingOptions
    recall: RecallOptions
    graph: GraphSearchOptions
    ranking: RankingOptions
    selection: SelectionOptions
    output: SearchOutputOptions = Field(default_factory=SearchOutputOptions)
    required_capabilities: frozenset[Capability] = frozenset()
    policy: SearchProfilePolicy = Field(default_factory=SearchProfilePolicy)

    @model_validator(mode="after")
    def _require_resolved_switches(self) -> SearchProfile:
        required = {
            "query.rewrite": self.query.rewrite,
            "query.entity_extraction": self.query.entity_extraction,
            "query.normalization": self.query.normalization,
            "graph.enabled": self.graph.enabled,
            "graph.max_hops": self.graph.max_hops,
            "ranking.method": self.ranking.method,
            "selection.enabled": self.selection.enabled,
            "selection.include_selection_rationale": (self.selection.include_selection_rationale),
        }
        missing = [name for name, value in required.items() if value is None]
        if missing:
            raise SagValidationError(f"Profile 存在未解析开关: {', '.join(missing)}")
        if self.graph.enabled is False and self.graph.max_hops != 0:
            raise SagValidationError("关闭图扩展的 Profile 必须设置 max_hops=0")
        if self.graph.enabled is True and not self.graph.max_hops:
            raise SagValidationError("启用图扩展的 Profile 必须设置 max_hops>0")
        return self


def builtin_search_profiles() -> tuple[SearchProfile, ...]:
    """Return fresh immutable instances for an engine-local registry."""

    vector = SearchProfile(
        name=BuiltinSearchStrategy.VECTOR,
        executor=SearchExecutorKind.VECTOR,
        query=QueryProcessingOptions(
            rewrite=False,
            entity_extraction="disabled",
            normalization=False,
            max_rewrites=0,
        ),
        recall=RecallOptions(
            entity=EntityRecallOptions(enabled=False),
            event=EventRecallOptions(vector_top_k=20, vector_threshold=0.4),
            merge="union",
        ),
        graph=GraphSearchOptions(enabled=False, max_hops=0),
        ranking=RankingOptions(
            method="vector",
            candidate_limit=20,
            on_timeout="error",
        ),
        selection=SelectionOptions(
            enabled=False,
            max_candidates=20,
            include_selection_rationale=False,
        ),
        policy=SearchProfilePolicy(
            allowed_return_types=frozenset({"chunk"}),
            allowed_ranking_methods=frozenset({"vector"}),
            allowed_entity_extraction=frozenset({"disabled"}),
            allow_query_rewrite=False,
            allow_query_normalization=False,
            allow_graph=False,
            allow_graph_output=False,
            allow_paths=False,
            allow_selection=False,
            allow_candidate_pool=False,
        ),
        required_capabilities=frozenset({Capability.VECTOR_KNN, Capability.FILTERED_KNN}),
    )
    atomic = SearchProfile(
        name=BuiltinSearchStrategy.ATOMIC,
        executor=SearchExecutorKind.ATOMIC,
        query=QueryProcessingOptions(
            rewrite=False,
            entity_extraction="llm",
            normalization=False,
            max_rewrites=0,
        ),
        recall=RecallOptions(
            entity=EntityRecallOptions(
                enabled=True,
                top_k=20,
                vector_threshold=0.9,
                # 等价"无上限"：atomic 通道1 对实体可达事项不做限流。
                max_events_per_entity=1000,
            ),
            event=EventRecallOptions(vector_top_k=20, vector_threshold=0.4),
            merge="union",
            candidate_pool_size=0,
        ),
        graph=GraphSearchOptions(
            enabled=True,
            max_hops=1,
            # entities_per_hop / events_per_hop / relation_threshold 刻意不设置：
            # relation_source="relational" 路不消费这三个配额。
            event_threshold=0.0,
            seed_event_limit=None,
        ),
        ranking=RankingOptions(
            method="llm",
            candidate_limit=1000,
            rerank_top_n=1000,
            llm_select_top_n=5,
            # atomic 的模板由 AtomicSearchExecutor.execute 传入，本字段不被消费。
            llm_prompt_name="select_useful_relations_local",
            llm_include_thought_process=False,
            llm_include_content=False,
            on_timeout="error",
        ),
        selection=SelectionOptions(
            enabled=False,
            max_candidates=20,
            include_selection_rationale=False,
        ),
        policy=SearchProfilePolicy(
            allowed_ranking_methods=frozenset({"vector", "llm"}),
            allowed_entity_extraction=frozenset({"llm"}),
            allow_query_rewrite=False,
            allow_query_normalization=False,
            allow_graph_output=True,
            allow_paths=True,
            allow_candidate_pool=False,
        ),
        required_capabilities=frozenset(
            {
                Capability.VECTOR_KNN,
                Capability.FILTERED_KNN,
                Capability.GRAPH_RELATION_LOOKUP,
                Capability.LLM_STRUCTURED_OUTPUT,
            }
        ),
    )
    benchmark = SearchProfile(
        name=BuiltinSearchStrategy.FULL_EXPAND,
        executor=SearchExecutorKind.PRODUCTION,
        query=QueryProcessingOptions(
            rewrite=False,
            entity_extraction="llm",
            normalization=False,
            max_rewrites=0,
        ),
        recall=RecallOptions(
            entity=EntityRecallOptions(
                enabled=True,
                top_k=15,
                vector_threshold=0.9,
                max_events_per_entity=10,
            ),
            event=EventRecallOptions(vector_top_k=20, vector_threshold=0.3),
            merge="union",
            # SAG-Benchmark multi 策略：不建候选池，全量可达集交给后续剪枝。
            candidate_pool_size=0,
        ),
        graph=GraphSearchOptions(
            enabled=True,
            max_hops=1,
            entities_per_hop=15,
            events_per_hop=50,
            event_threshold=0.4,
            relation_threshold=0.45,
            seed_event_limit=15,
        ),
        ranking=RankingOptions(
            method="llm",
            candidate_limit=100,
            # 让全部 100 条粗排候选进入 LLM 精排（SAG2 multi 的 llm_rank_top_n=100）。
            rerank_top_n=100,
            # 与 SAG2 multi 对齐：LLM 最终只挑选 5 条事件（rerank_top_k=5），
            # 剩余 5 条由 _hydrate_chunks_topped_up 用 query-event/chunk 相似度补齐到 top_k=10。
            llm_select_top_n=5,
            # 保持 0.10 公共默认：精选只返回有序索引，不强制模型输出推理字段。
            llm_prompt_name="select_useful_relations_local",
            llm_include_content=True,
            llm_max_content_chars=2000,
            llm_include_thought_process=False,
            timeout_seconds=60.0,
            on_timeout="fallback_to_score",
        ),
        selection=SelectionOptions(
            enabled=False,
            # 与 SAG-Benchmark multi 对齐：粗排 top100 候选全部进入 LLM 精排，
            # 不能截断到 20（否则精排召回系统性偏低）。
            max_candidates=100,
            include_selection_rationale=False,
        ),
        policy=SearchProfilePolicy(
            allowed_return_types=frozenset({"event", "chunk"}),
            allowed_ranking_methods=frozenset({"vector", "weighted", "llm"}),
            allowed_entity_extraction=frozenset({"llm"}),
            allow_query_rewrite=False,
            allow_query_normalization=False,
            allow_graph=True,
            allow_graph_output=True,
            allow_paths=True,
            allow_selection=False,
            allow_candidate_pool=False,
        ),
        required_capabilities=frozenset(
            {
                Capability.VECTOR_KNN,
                Capability.FILTERED_KNN,
                Capability.GRAPH_RELATION_LOOKUP,
                Capability.LLM_STRUCTURED_OUTPUT,
            }
        ),
    )
    precise = SearchProfile(
        name=BuiltinSearchStrategy.PRUNED_EXPAND_LLM,
        executor=SearchExecutorKind.PRODUCTION,
        query=QueryProcessingOptions(
            rewrite=False,
            entity_extraction="llm",
            normalization=False,
            max_rewrites=0,
        ),
        recall=RecallOptions(
            entity=EntityRecallOptions(
                enabled=True,
                top_k=15,
                vector_threshold=0.9,
                max_events_per_entity=10,
            ),
            event=EventRecallOptions(vector_top_k=20, vector_threshold=0.3),
            merge="union",
            candidate_pool_size=500,
        ),
        graph=GraphSearchOptions(
            enabled=True,
            max_hops=1,
            entities_per_hop=10,
            events_per_hop=50,
            event_threshold=0.4,
            relation_threshold=0.45,
            seed_event_limit=15,
        ),
        ranking=RankingOptions(
            method="llm",
            candidate_limit=100,
            rerank_top_n=50,
            llm_prompt_name="select_useful_relations_local",
            llm_include_content=True,
            llm_max_content_chars=2000,
            timeout_seconds=60.0,
            on_timeout="fallback_to_score",
        ),
        selection=SelectionOptions(
            enabled=False,
            max_candidates=50,
            include_selection_rationale=False,
        ),
        required_capabilities=frozenset(
            {
                Capability.VECTOR_KNN,
                Capability.FILTERED_KNN,
                Capability.GRAPH_RELATION_LOOKUP,
            }
        ),
    )
    rerank_precise = SearchProfile(
        name=BuiltinSearchStrategy.PRUNED_EXPAND_RERANK,
        executor=SearchExecutorKind.PRODUCTION,
        query=QueryProcessingOptions(
            rewrite=False,
            entity_extraction="llm",
            normalization=False,
            max_rewrites=0,
        ),
        recall=RecallOptions(
            entity=EntityRecallOptions(
                enabled=True,
                top_k=15,
                vector_threshold=0.9,
                max_events_per_entity=10,
            ),
            event=EventRecallOptions(vector_top_k=20, vector_threshold=0.3),
            merge="union",
            candidate_pool_size=500,
        ),
        graph=GraphSearchOptions(
            enabled=True,
            max_hops=1,
            entities_per_hop=10,
            events_per_hop=50,
            event_threshold=0.4,
            relation_threshold=0.45,
            seed_event_limit=15,
        ),
        ranking=RankingOptions(
            method="rerank",
            candidate_limit=100,
            rerank_top_n=50,
            rerank_threshold=0.5,
            timeout_seconds=3.0,
            on_timeout="fallback_to_score",
        ),
        selection=SelectionOptions(
            enabled=False,
            max_candidates=50,
            include_selection_rationale=False,
        ),
        required_capabilities=frozenset(
            {
                Capability.VECTOR_KNN,
                Capability.FILTERED_KNN,
                Capability.GRAPH_RELATION_LOOKUP,
                Capability.RERANK,
            }
        ),
    )
    fast = SearchProfile(
        name=BuiltinSearchStrategy.PRUNED_EXPAND_RFF,
        executor=SearchExecutorKind.PRODUCTION,
        query=QueryProcessingOptions(
            rewrite=False,
            entity_extraction="disabled",
            normalization=False,
            max_rewrites=0,
        ),
        recall=RecallOptions(
            entity=EntityRecallOptions(
                enabled=True,
                top_k=10,
                vector_threshold=0.5,
                max_events_per_entity=20,
            ),
            event=EventRecallOptions(vector_top_k=20, vector_threshold=0.4),
            merge="rrf",
            candidate_pool_size=500,
        ),
        graph=GraphSearchOptions(
            enabled=True,
            max_hops=1,
            entities_per_hop=10,
            events_per_hop=50,
            event_threshold=0.65,
            relation_threshold=0.45,
            seed_event_limit=15,
        ),
        ranking=RankingOptions(
            method="rrf",
            candidate_limit=20,
            rrf_k=60,
            on_timeout="error",
        ),
        selection=SelectionOptions(
            enabled=False,
            max_candidates=20,
            include_selection_rationale=False,
        ),
        policy=SearchProfilePolicy(allow_selection=False),
        required_capabilities=frozenset(
            {
                Capability.VECTOR_KNN,
                Capability.FILTERED_KNN,
                Capability.LEXICAL_SEARCH,
                Capability.GRAPH_RELATION_LOOKUP,
            }
        ),
    )
    return vector, atomic, benchmark, precise, rerank_precise, fast


__all__ = [
    "SearchExecutorKind",
    "SearchProfile",
    "SearchProfilePolicy",
    "builtin_search_profiles",
]
