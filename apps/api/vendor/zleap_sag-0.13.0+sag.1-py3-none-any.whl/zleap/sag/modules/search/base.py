"""共享图检索子步骤工具库。

:class:`BaseGraphSearchExecutor` 提供查询处理、召回、图扩展、排序、结果填充等具体子步骤的实现，
供子类按需组合调用。每个子类拥有自己的 ``execute()``，负责编排各步骤的调用顺序与参数。
生产变体（``production.py``）与原子化消融变体（``atomic.py``）各自独立，互不依赖。
"""

from __future__ import annotations

import json
import logging
import math
import time
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from zleap.sag.core.ai.models import LLMMessage, LLMRole
from zleap.sag.exceptions import LLMStructuredOutputError
from zleap.sag.modules.search._util import _record_id
from zleap.sag.modules.search.assembly import ResultHydrator
from zleap.sag.modules.search.graph import GraphCollector
from zleap.sag.modules.search.planning import SearchExecutionPlan
from zleap.sag.modules.search.pool import EventCandidateSource
from zleap.sag.pipeline.contracts import (
    SearchHit,
    SearchRequest,
)
from zleap.sag.pipeline.errors import StageInputError
from zleap.sag.utils import get_logger

logger = get_logger("search.base")

_PER_ENTITY_VECTOR_TOP_K = 5
# score_relations_by_event_ids 的 size 界定关系行数，去重成实体发生在截断之后：
# 同一实体常挂在多个 seed 事项上，按 entities_per_hop 取关系会拿不到那么多新实体。
_EXPAND_RELATION_FANOUT = 3


class _InvalidModelOutput(ValueError):
    pass


@dataclass(slots=True)
class _SearchExecutionState:
    query_embedding: list[float] | None = None
    rewritten_query: str | None = None
    rewritten_entities: list[str] = field(default_factory=list)
    seen_entity_ids: set[str] = field(default_factory=set)
    seen_event_ids: set[str] = field(default_factory=set)
    event_score_cache: dict[str, float] = field(default_factory=dict)
    event_score_components: dict[str, dict[str, float]] = field(default_factory=dict)
    recall_channels: dict[str, list[str]] = field(default_factory=dict)
    timings: dict[str, float] = field(default_factory=dict)
    stage_stats: dict[str, Any] = field(default_factory=dict)
    graph: GraphCollector = field(init=False)
    active_query_id: str = ""
    candidates: EventCandidateSource | None = None


def _elapsed(started: float) -> float:
    return round(time.perf_counter() - started, 6)


def _finite_score(value: Any, *, label: str) -> float:
    score = float(value)
    if not math.isfinite(score):
        raise _InvalidModelOutput(f"{label} 必须是有限数值")
    return score


def _sort_scores(scores: Mapping[str, float]) -> list[str]:
    return sorted(scores, key=lambda item_id: (-scores[item_id], item_id))


def _format_score_range(scores: Iterable[float]) -> str:
    values = list(scores)
    if not values:
        return "-"
    return f"[{min(values):.4f}, {max(values):.4f}]"


def _response_dict(response: Any) -> dict[str, Any]:
    if isinstance(response, dict):
        return response
    if hasattr(response, "model_dump"):
        value = response.model_dump(mode="python")
        if isinstance(value, dict):
            return value
    content = getattr(response, "content", response)
    if isinstance(content, str):
        try:
            value = json.loads(content)
        except json.JSONDecodeError as exc:
            raise _InvalidModelOutput("LLM 未返回合法 JSON") from exc
        if isinstance(value, dict):
            return value
    raise _InvalidModelOutput("LLM 未返回 JSON 对象")


# atomic 专用精选模板：两支共用方括号索引契约与文本纠错解析路径。
_ATOMIC_SELECT_PROMPTS = frozenset({"llm_rank_events_cot_atomic"})


class BaseGraphSearchExecutor:
    """共享子步骤工具库：查询处理、召回、图扩展、排序、结果填充的具体实现。

    子类不继承 ``execute()``；各自定义完整的执行编排，按需调用这里的工具方法。
    行为接缝通过 hook 方法声明，子类覆写以表达各自的消融取值。
    """

    def __init__(
        self,
        *,
        repositories: Any,
        embedding: Any,
        llm: Any,
        rerank: Any,
        prompts: Any,
    ) -> None:
        self.repositories = repositories
        self.embedding = embedding
        self.llm = llm
        self.rerank = rerank
        self.prompts = prompts
        self._hydrator = ResultHydrator(repositories)

    # ---------- 图扩展抽象钩子：子类必须覆写，以提供各自的实体/事项扩展实现 ----------

    async def _expand_entities_for_hop(
        self,
        frontier: list[str],
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        """从上一跳 seed 事项出发，扩展出本跳新实体。

        Args:
            frontier: 本跳起始事项的 event_id 有序列表（上一跳扩展结果或初始种子）。

        Returns:
            ``(relation_rows, entity_ids)``：
            - ``relation_rows``：事项→实体的关系行，用于写入检索图的扩展边。
            - ``entity_ids``：去重后的新实体 id 列表，作为下一步 ``_expand_events_for_hop`` 的输入。
        """
        raise NotImplementedError

    async def _expand_events_for_hop(
        self,
        entity_ids: list[str],
        total_event_limit: int,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> list[dict[str, Any]]:
        """从本跳新实体出发，取回候选事项关系行。

        Args:
            entity_ids: 本跳通过 ``_expand_entities_for_hop`` 扩展出的新实体 id 列表。
            total_event_limit: 本跳最多取回的关系行总数（对应 ``plan.graph.events_per_hop``）。

        Returns:
            ``event_relations``：实体→事项的关系行列表，
            调用方据此打分、过滤，并将通过阈值的事项设为下一跳的 frontier。
        """
        raise NotImplementedError

    async def _process_query(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
        *,
        strict_query_understanding: bool,
    ) -> None:
        scope_fingerprint = json.dumps(
            request.scope.model_dump(mode="json"),
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        state.active_query_id = state.graph.record_query(
            request.query,
            scope_fingerprint=scope_fingerprint,
        )

        if plan.query.rewrite:
            rewritten, entities = await self._rewrite_query(request.query, plan, state)
            state.rewritten_query = rewritten
            state.rewritten_entities = entities
            if rewritten == request.query:
                return
            state.active_query_id = state.graph.record_rewrite(
                origin_id=state.active_query_id,
                rewritten=rewritten,
                scope_fingerprint=scope_fingerprint,
            )
        elif plan.query.entity_extraction == "llm":
            try:
                state.rewritten_entities = await self._extract_entities(request.query, plan, state)
            except (LLMStructuredOutputError, _InvalidModelOutput) as exc:
                if strict_query_understanding:
                    raise
                # Entity extraction only enriches recall. The query embedding and
                # direct-event channel remain valid, so an invalid structured model
                # reply must degrade the precise search instead of turning search,
                # summary, and QA into a 503. Transport/configuration errors still
                # propagate: those indicate the configured model is unavailable.
                state.stage_stats["query"] = {
                    "fallback_reason": "entity_extraction_invalid_model_output",
                }
                logger.warning(
                    "[BASE][查询处理] 实体抽取输出无效，降级为直接召回",
                    extra={"error_type": type(exc).__name__},
                )

    async def _rewrite_query(
        self,
        query: str,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> tuple[str, list[str]]:
        max_entities = self._max_entities(plan)
        messages = self._prompt_messages(
            "rewrite_and_extract_entities",
            query=query,
            current_timestamp=datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC"),
            max_entities=max_entities,
        )
        response = _response_dict(
            await self.llm.chat_with_schema(
                messages,
                response_schema={
                    "type": "object",
                    "properties": {
                        "rewritten_query": {"type": "string", "minLength": 1},
                        "entities": {
                            "type": "array",
                            "maxItems": max_entities,
                            "items": {"type": "string", "minLength": 1},
                        },
                    },
                    "required": ["rewritten_query", "entities"],
                    "additionalProperties": False,
                },
                structured_output_mode=plan.structured_output_mode,
            )
        )
        rewritten = str(response.get("rewritten_query") or "").strip()
        if not rewritten:
            raise _InvalidModelOutput("查询改写结果为空")
        entities = self._validate_entity_names(response.get("entities"), max_entities)
        self._record_prompt_version(state, "rewrite_and_extract_entities")
        return rewritten, entities

    async def _extract_entities(
        self,
        query: str,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> list[str]:
        max_entities = self._max_entities(plan)
        response = _response_dict(
            await self.llm.chat_with_schema(
                self._prompt_messages(
                    "extract_named_entities",
                    query=query,
                    max_entities=max_entities,
                ),
                response_schema={
                    "type": "object",
                    "properties": {
                        "named_entities": {
                            "type": "array",
                            "maxItems": max_entities,
                            "items": {"type": "string", "minLength": 1},
                        }
                    },
                    "required": ["named_entities"],
                    "additionalProperties": False,
                },
                structured_output_mode=plan.structured_output_mode,
            )
        )
        raw_entities = response.get("named_entities", response.get("entities"))
        if not isinstance(raw_entities, list):
            raise _InvalidModelOutput("NER named_entities 不是列表")
        result: list[str] = []
        seen: set[str] = set()
        for raw_name in raw_entities:
            name = str(raw_name).strip()
            if name and name not in seen:
                seen.add(name)
                result.append(name)
            if len(result) >= max_entities:
                break
        self._record_prompt_version(state, "extract_named_entities")
        return result

    async def _recall_direct_events(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> list[dict[str, Any]]:
        limit = plan.recall.event.vector_top_k or plan.ranking.candidate_limit or 20
        assert state.candidates is not None
        return await state.candidates.recall_direct(limit)

    async def _recall_entities(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
        *,
        entity_lexical_fallback: bool,
        entity_vector_top_k_per_entity: int | None = None,
    ) -> dict[str, dict[str, Any]]:
        if plan.recall.entity.enabled is False:
            return {}
        top_k = plan.recall.entity.top_k
        if not top_k:
            return {}
        if not state.rewritten_entities and not entity_lexical_fallback:
            # atomic：NER 抽不到实体时整个实体通道放弃，不降级到实体名 BM25。
            return {}
        # 实体召回二选一：抽取到 LLM 实体时只走实体名向量通道，否则只走整句 BM25 通道。
        if state.rewritten_entities:
            channel = "entity_rewrite_vector"
            name_vectors = await self.embedding.batch_generate(list(state.rewritten_entities))
            # 每个实体名单独召回，逐名限 5 条以免实体数多时总量爆炸。
            per_entity_k = (
                entity_vector_top_k_per_entity
                if entity_vector_top_k_per_entity is not None
                else min(_PER_ENTITY_VECTOR_TOP_K, top_k)
            )
            rows = await self.repositories.entities.search_similar_batch(
                name_vectors,
                k=per_entity_k,
                data_source_ids=list(request.scope.data_source_ids),
            )
        else:
            channel = "entity_bm25"
            rows = await self.repositories.entities.search_by_query_bm25(
                state.rewritten_query or request.query,
                data_source_ids=list(request.scope.data_source_ids),
                size=top_k,
            )
        entities: dict[str, dict[str, Any]] = {}
        threshold = plan.recall.entity.vector_threshold
        for row in rows:
            entity_id = _record_id(row, "entity_id")
            if not entity_id:
                raise StageInputError(
                    "实体召回结果缺少 entity_id",
                    stage="search",
                    code="invalid_search_result",
                )
            score = float(row.get("score", 0.0))
            if channel != "entity_bm25" and threshold is not None and score < threshold:
                continue
            entry = entities.setdefault(entity_id, {"row": row, "scores": {}})
            if score >= entry["scores"].get(channel, 0.0):
                entry["scores"][channel] = score
                entry["row"] = row

        if logger.isEnabledFor(logging.INFO):
            best_scores = {
                entity_id: max(entry["scores"].values()) for entity_id, entry in entities.items()
            }
            logger.info(
                "[BASE][实体召回] channel=%s, top_k=%d, threshold=%s, 命中=%d/%d, 命中分数区间=%s",
                channel,
                top_k,
                threshold,
                len(entities),
                len(rows),
                _format_score_range(best_scores.values()),
            )
        return entities

    def _record_direct_route(
        self,
        rows: list[dict[str, Any]],
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> None:
        threshold = plan.recall.event.vector_threshold
        scores: dict[str, float] = {}
        for row in rows:
            event_id = _record_id(row, "event_id")
            if not event_id:
                raise StageInputError(
                    "事项召回结果缺少 event_id",
                    stage="search",
                    code="invalid_search_result",
                )
            score = float(row.get("score", 0.0))
            if threshold is not None and score < threshold:
                continue
            scores[event_id] = max(scores.get(event_id, 0.0), score)
            state.event_score_cache[event_id] = scores[event_id]
            state.event_score_components.setdefault(event_id, {})["vector"] = scores[event_id]
            state.seen_event_ids.add(event_id)
            state.graph.record_event(
                row=row,
                query_id=state.active_query_id,
                method="event_vector",
                confidence=score,
                source="vector_projection",
                metadata={"data_source_ids": list(request.scope.data_source_ids)},
            )
        state.recall_channels["event_vector"] = _sort_scores(scores)
        logger.info(
            "[BASE][事项直连召回] threshold=%s, 命中=%d/%d, 分数区间=%s",
            threshold,
            len(scores),
            len(rows),
            _format_score_range(scores.values()),
        )

    async def _recall_events_from_entities(
        self,
        entities: dict[str, dict[str, Any]],
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
        *,
        use_relational: bool,
        apply_entity_event_threshold: bool,
    ) -> None:
        """实体→事项路由召回。

        ``use_relational=True`` 走关系表全量直取（atomic）；
        ``use_relational=False`` 走向量候选池按 per-entity 配额取回（production）。
        调用方（子类 ``execute()``）负责传入与自身变体对应的值。
        """
        if not entities:
            state.recall_channels["entity_event"] = []
            return
        assert state.candidates is not None
        for entity_id, entry in entities.items():
            state.seen_entity_ids.add(entity_id)
            state.graph.record_entity(
                row=entry["row"],
                query_id=state.active_query_id,
                scores=entry["scores"],
                source="vector_projection",
            )

        relations: Sequence[Mapping[str, Any]]
        if use_relational:
            _entity_event_ids = (
                await self.repositories.event_entity_relations.fetch_event_ids_for_entities(
                    list(entities),
                    data_source_ids=list(request.scope.data_source_ids),
                )
            )
            relations = (
                await self.repositories.event_entity_relations.fetch_relations_by_event_ids(
                    _entity_event_ids,
                    data_source_ids=list(request.scope.data_source_ids),
                )
                if _entity_event_ids
                else []
            )
        else:
            relations = await state.candidates.events_for_keys(
                list(entities),
                per_entity_limit=plan.recall.entity.max_events_per_entity or 10,
            )
        relation_by_event: dict[str, list[Mapping[str, Any]]] = {}
        for relation in relations:
            event_id = _record_id(relation, "event_id")
            relation_entity_id = _record_id(relation, "entity_id")
            if event_id and relation_entity_id in entities:
                relation_by_event.setdefault(event_id, []).append(relation)
        candidate_ids = list(relation_by_event)
        missing_ids = [item for item in candidate_ids if item not in state.event_score_cache]
        scored_rows = await state.candidates.score_events(missing_ids) if missing_ids else []
        rows_by_id = {
            event_id: row
            for row in scored_rows
            if (event_id := _record_id(row, "event_id")) is not None
        }
        for event_id, row in rows_by_id.items():
            state.event_score_cache[event_id] = float(row.get("score", 0.0))

        threshold = plan.recall.event.vector_threshold
        route_scores: dict[str, float] = {}
        for event_id, event_relations in relation_by_event.items():
            score = state.event_score_cache.get(event_id)
            if score is None or (
                apply_entity_event_threshold and threshold is not None and score < threshold
            ):
                continue
            route_scores[event_id] = score
            state.event_score_components.setdefault(event_id, {})["vector"] = score
            state.seen_event_ids.add(event_id)
            event_row = rows_by_id.get(event_id, {"event_id": event_id})
            state.graph.record_event_routes(
                row=event_row,
                event_id=event_id,
                relations=event_relations,
                source="vector_projection" if event_id in rows_by_id else "route_stub",
            )
        state.recall_channels["entity_event"] = _sort_scores(route_scores)
        logger.info(
            "[BASE][实体路由召回] 实体=%d, 关联事项=%d, threshold=%s, 命中=%d, 分数区间=%s",
            len(entities),
            len(relation_by_event),
            threshold,
            len(route_scores),
            _format_score_range(route_scores.values()),
        )

    async def _expand_graph(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> None:
        assert state.candidates is not None

        # 将所有召回通道（event_vector、entity_event 等）的命中事项合并，
        # 按向量分数降序排列，截取前 seed_event_limit 条作为第一跳的起始边界。
        merged_scores = {
            event_id: state.event_score_cache.get(event_id, 0.0)
            for channel in state.recall_channels.values()
            for event_id in channel
        }
        # frontier：当前跳的种子事项列表（event_id 有序列表），每跳结束后替换为本跳新发现的事项。
        frontier = _sort_scores(merged_scores)
        if plan.graph.seed_event_limit is not None:
            # atomic 时 plan.graph.seed_event_limit 为 None 不截断
            frontier = frontier[: plan.graph.seed_event_limit]

        # 累积所有跳扩展出的新事项分数，最终写入 recall_channels["graph"]。
        expanded_scores: dict[str, float] = {}

        for hop in range(1, (plan.graph.max_hops or 0) + 1):
            if not frontier:
                break

            # 第一步：从本跳 frontier 事项出发，找与之关联的实体（事项→实体方向）。
            selected_relations, entity_ids = await self._expand_entities_for_hop(
                frontier,
                request,
                plan,
                state,
            )
            if not entity_ids:
                break

            # 补全实体元数据并登记到检索图。
            entity_rows = await self.repositories.entities.get_entities_by_ids(
                entity_ids,
                data_source_ids=list(request.scope.data_source_ids),
            )
            entity_map = {
                entity_id: row
                for row in entity_rows
                if (entity_id := _record_id(row, "entity_id")) is not None
            }
            for entity_id in entity_ids:
                state.seen_entity_ids.add(entity_id)
                state.graph.record_expansion_entity(
                    row=entity_map.get(entity_id, {"entity_id": entity_id}),
                    hop=hop,
                    source="vector_projection" if entity_id in entity_map else "route_stub",
                )
            # 将 frontier 事项→新实体 的边写入检索图。
            for row in selected_relations:
                event_id = _record_id(row, "event_id")
                entity_id = _record_id(row, "entity_id")
                if event_id in frontier and entity_id in entity_ids:
                    state.graph.record_expansion_edge(
                        method="event_entity_relation",
                        from_id=event_id,
                        to_id=entity_id,
                        confidence=float(row.get("score", 0.0)),
                        hop=hop,
                        relation=str(row.get("description") or ""),
                    )

            # 第二步：从本跳新实体出发，找与之关联的事项（实体→事项方向），
            # 这些事项是下一跳的候选 frontier。
            total_event_limit = plan.graph.events_per_hop or 50
            event_relations = await self._expand_events_for_hop(
                entity_ids,
                total_event_limit,
                request,
                plan,
                state,
            )
            # 以 event_id 为键聚合关联行，过滤掉实体不在本跳范围内的行。
            relation_map: dict[str, list[dict[str, Any]]] = {}
            for row in event_relations:
                event_id = _record_id(row, "event_id")
                entity_id = _record_id(row, "entity_id")
                if event_id and entity_id in entity_ids:
                    relation_map.setdefault(event_id, []).append(row)
            if not relation_map:
                break

            # 对尚未在缓存中的候选事项做向量打分，排除已见事项防止循环。
            scored_events = await state.candidates.score_events(
                list(relation_map),
                exclude_event_ids=list(state.seen_event_ids),
                limit=len(relation_map),
            )
            next_scores: dict[str, float] = {}
            event_rows: dict[str, dict[str, Any]] = {}
            for row in scored_events:
                event_id = _record_id(row, "event_id")
                if not event_id:
                    raise StageInputError(
                        "图扩展事项缺少 event_id",
                        stage="search",
                        code="invalid_search_result",
                    )
                score = float(row.get("score", 0.0))
                # 低于阈值的事项不进入下一跳，避免图扩展沿低相关路径蔓延。
                if plan.graph.event_threshold is not None and score < plan.graph.event_threshold:
                    continue
                next_scores[event_id] = score
                event_rows[event_id] = row

            # 更新 frontier 为本跳扩展出的新事项，供下一跳继续扩展。
            frontier = _sort_scores(next_scores)
            for event_id in frontier:
                score = next_scores[event_id]
                state.seen_event_ids.add(event_id)
                state.event_score_cache[event_id] = score
                state.event_score_components.setdefault(event_id, {})["vector"] = score
                expanded_scores[event_id] = score
                state.graph.record_expansion_event(
                    row=event_rows[event_id],
                    hop=hop,
                )
                # 将新实体→新事项的边写入检索图。
                for relation in relation_map[event_id]:
                    entity_id = str(relation["entity_id"])
                    state.graph.record_expansion_edge(
                        method="entity_event_relation",
                        from_id=entity_id,
                        to_id=event_id,
                        confidence=float(relation.get("score", 1.0)),
                        hop=hop,
                        relation=str(relation.get("description") or ""),
                    )

        state.recall_channels["graph"] = _sort_scores(expanded_scores)

    async def _rerank(
        self,
        query: str,
        event_ids: list[str],
        records: dict[str, dict[str, Any]],
        plan: SearchExecutionPlan,
    ) -> tuple[list[str], dict[str, float]]:
        """Rerank hook implemented by variants that allow rerank ranking."""

        del query, event_ids, records, plan
        raise StageInputError(
            "当前 Search Executor 不支持 rerank",
            stage="search",
            code="unsupported_ranking_method",
        )

    async def _rank_events(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
        *,
        rescore_candidates: bool = False,
        llm_prompt_name: str | None = None,
        llm_text_fields: str = "title_content",
        strict_llm_rank_empty: bool = True,
    ) -> tuple[list[str], dict[str, float], dict[str, Any]]:
        candidate_ids = list(
            dict.fromkeys(
                event_id for channel in state.recall_channels.values() for event_id in channel
            )
        )
        assert state.candidates is not None
        if rescore_candidates and candidate_ids:
            # atomic Step6：粗排前用 query 向量对全部候选重做一次 kNN，
            # 让召回阶段记 0 分的 entity→event 事项拿到真实分。
            for row in await state.candidates.score_events(candidate_ids):
                event_id = _record_id(row, "event_id")
                if event_id is None:
                    continue
                score = float(row.get("score", 0.0))
                state.event_score_cache[event_id] = score
                state.event_score_components.setdefault(event_id, {})["vector"] = score
        vector_scores: dict[str, float] = {}
        for candidate_id in candidate_ids:
            score = state.event_score_components.get(candidate_id, {}).get("vector", 0.0)
            if not score:
                score = state.candidates.pool_score(candidate_id) or 0.0
            vector_scores[candidate_id] = score
        candidate_limit = plan.ranking.candidate_limit or len(vector_scores)
        coarse_ids = _sort_scores(vector_scores)[:candidate_limit]
        method = plan.ranking.method or "vector"
        if method in {"vector", "weighted"}:
            return coarse_ids, vector_scores, {"method": method, "fallback_reason": None}
        if method == "rrf":
            lexical_rows = await self.repositories.events.search_bm25_by_text(
                state.rewritten_query or request.query,
                coarse_ids,
                k=len(coarse_ids),
                data_source_ids=list(request.scope.data_source_ids),
            )
            lexical_ids = [
                event_id
                for row in lexical_rows
                if (event_id := _record_id(row, "event_id")) is not None
            ]
            state.recall_channels["event_bm25"] = lexical_ids
            scores = self._rrf_scores(
                [
                    [item for item in channel if item in vector_scores]
                    for name, channel in state.recall_channels.items()
                    if name != "event_bm25"
                ]
                + [lexical_ids],
                k=plan.ranking.rrf_k or 60,
            )
            for event_id, score in scores.items():
                state.event_score_components.setdefault(event_id, {})["rrf"] = score
            return (
                _sort_scores(scores)[:candidate_limit],
                scores,
                {
                    "method": "rrf",
                    "rrf_k": plan.ranking.rrf_k or 60,
                    "fallback_reason": None,
                },
            )
        if not coarse_ids:
            return [], {}, {"method": method, "fallback_reason": None}
        records = await self.repositories.events.get_events_by_ids(coarse_ids)
        record_map = {
            event_id: row
            for row in records
            if (event_id := _record_id(row, "event_id")) is not None
        }
        ordered_ids = [event_id for event_id in coarse_ids if event_id in record_map]
        # LLM ranking cannot change the order of a singleton and this ranker treats
        # an empty model result as invalid, so it cannot legitimately filter the
        # candidate either.  Keep the deterministic recall score instead of adding
        # latency and a provider-shaped-output failure point.
        if method == "llm" and len(ordered_ids) == 1:
            event_id = ordered_ids[0]
            logger.info("[BASE][LLM挑选] 候选=1, 跳过模型排序")
            return (
                ordered_ids,
                {event_id: vector_scores[event_id]},
                {"method": method, "fallback_reason": None},
            )
        try:
            if method == "rerank":
                ranked_ids, scores = await self._rerank(
                    state.rewritten_query or request.query,
                    ordered_ids,
                    record_map,
                    plan,
                )
                component = "rerank"
            elif method == "llm":
                ranked_ids, scores = await self._llm_rank(
                    state.rewritten_query or request.query,
                    ordered_ids,
                    record_map,
                    plan,
                    state,
                    llm_prompt_name=llm_prompt_name,
                    llm_text_fields=llm_text_fields,
                    strict_llm_rank_empty=strict_llm_rank_empty,
                )
                component = "llm"
            else:
                raise StageInputError(
                    f"Production Executor 不支持 ranking.method={method!r}",
                    stage="search",
                    code="unsupported_ranking_method",
                )
        except TimeoutError:
            if plan.ranking.on_timeout != "fallback_to_score":
                raise
            return (
                coarse_ids,
                vector_scores,
                {
                    "method": method,
                    "fallback_reason": "ranking_timeout",
                },
            )
        except _InvalidModelOutput as exc:
            if plan.ranking.on_timeout != "fallback_to_score":
                raise
            return (
                coarse_ids,
                vector_scores,
                {
                    "method": method,
                    "fallback_reason": f"invalid_model_output: {exc}",
                },
            )
        except LLMStructuredOutputError as exc:
            if plan.ranking.on_timeout != "fallback_to_score":
                raise
            return (
                coarse_ids,
                vector_scores,
                {
                    "method": method,
                    "fallback_reason": f"invalid_model_output: {exc.code}@{exc.path}",
                },
            )
        for event_id, score in scores.items():
            state.event_score_components.setdefault(event_id, {})[component] = score
        return ranked_ids, scores, {"method": method, "fallback_reason": None}

    async def _llm_rank(
        self,
        query: str,
        event_ids: list[str],
        records: dict[str, dict[str, Any]],
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
        *,
        llm_prompt_name: str | None = None,
        llm_text_fields: str | None = None,
        strict_llm_rank_empty: bool | None = None,
    ) -> tuple[list[str], dict[str, float]]:
        """LLM 精排。

        名次挑选契约（select_useful_relations_local / llm_rank_events_cot）只返回
        有序索引、LLM 不产分，scores 返回空 dict，hit.score 为 None；
        打分契约（默认模板）返回 LLM 自带分数。
        """
        limit = min(plan.ranking.rerank_top_n or len(event_ids), len(event_ids))
        event_ids = event_ids[:limit]
        atomic_variant = plan.resolved_strategy == "atomic"
        if llm_prompt_name is None:
            llm_prompt_name = (
                "llm_rank_events_cot_atomic"
                if atomic_variant
                else plan.ranking.llm_prompt_name or "llm_rank_events"
            )
        if llm_text_fields is None:
            llm_text_fields = "content_only" if atomic_variant else "title_content"
        if strict_llm_rank_empty is None:
            strict_llm_rank_empty = not atomic_variant
        include_content = (
            plan.ranking.llm_include_content
            if plan.ranking.llm_include_content is not None
            else True
        )
        # Atomic historically sends the complete relation text. Production profiles
        # bound each candidate (2,000 chars by default) to protect prompt size.
        max_chars = None if atomic_variant else (plan.ranking.llm_max_content_chars or 2000)
        lines = []
        relation_texts: list[str] = []
        for index, event_id in enumerate(event_ids):
            row = records[event_id]
            if llm_text_fields == "content_only":
                text = str(row.get("content") or "")
                if max_chars is not None:
                    text = text[:max_chars]
                text = text.strip()
            else:
                text = str(row.get("title") or "")
                if include_content:
                    content = str(row.get("content") or row.get("summary") or "")
                    if max_chars is not None:
                        content = content[:max_chars]
                    text = f"{text} {content}".strip()
            lines.append(f"[{index}] {text}")
            relation_texts.append(text)
        # Profile owns product-specific prompt selection. A custom plan that only
        # asks for LLM ranking keeps the generic scored-results contract.
        template_name = llm_prompt_name
        # LLM 精排最终挑选的事件数。llm_select_top_n 优先（对齐 SAG2 multi 的 rerank_top_k），
        # 否则退回 plan.top_k（默认行为）。最终结果若不足 plan.top_k，
        # 由 _hydrate_chunks_topped_up 用 query-event 或 query-chunk 相似度补齐。
        llm_target = min(plan.ranking.llm_select_top_n or plan.top_k, len(event_ids))
        if template_name in _ATOMIC_SELECT_PROMPTS:
            # atomic 专用契约：方括号索引 + 文本纠错解析（逐字搬自 atomic step7）。
            # 两支只差 schema 里的 thought_process，解析路径完全共用。
            messages = self._prompt_messages(
                template_name,
                question=query,
                relations="\n".join(lines),
                top_k=llm_target,
            )
            properties: dict[str, Any] = {
                "useful_relations": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            }
            required = ["useful_relations"]
            if template_name == "llm_rank_events_cot_atomic":
                properties["thought_process"] = {"type": "string"}
                required.insert(0, "thought_process")
            schema: dict[str, Any] = {
                "type": "object",
                "properties": properties,
                "required": required,
            }
        elif template_name == "select_useful_relations_local":
            messages = self._prompt_messages(
                template_name,
                question=query,
                relations="\n".join(lines),
                top_k=llm_target,
            )
            schema = {
                "type": "object",
                "properties": {
                    "useful_relations": {
                        "type": "array",
                        "items": {"type": ["integer", "string"]},
                        "maxItems": llm_target,
                    }
                },
                "required": ["useful_relations"],
                "additionalProperties": False,
            }
        elif template_name == "llm_rank_events_cot":
            # 显式 CoT 契约：thought_process + useful_relations（"[id]" 字符串）。
            # 对齐 SAG2 multi Step7：越界丢弃、不足补齐；只保留模型名次，不伪造分数。
            messages = self._prompt_messages(
                template_name,
                query=query,
                events_list="\n".join(lines),
                max_results=llm_target,
            )
            schema = {
                "type": "object",
                "properties": {
                    "thought_process": {"type": "string"},
                    "useful_relations": {
                        "type": "array",
                        "items": {"type": "string"},
                        "maxItems": llm_target,
                    },
                },
                "required": ["thought_process", "useful_relations"],
                "additionalProperties": False,
            }
        else:
            messages = self._prompt_messages(
                template_name,
                query=query,
                events_list="\n".join(lines),
                max_results=llm_target,
            )
            schema = {
                "type": "object",
                "properties": {
                    "results": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "index": {"type": "integer"},
                                "score": {"type": "number", "minimum": 0, "maximum": 1},
                            },
                            "required": ["index", "score"],
                            "additionalProperties": False,
                        },
                        "maxItems": llm_target,
                    }
                },
                "required": ["results"],
                "additionalProperties": False,
            }
        logger.info("[BASE][LLM挑选] template=%s, 候选=%d", template_name, len(event_ids))
        try:
            response = _response_dict(
                await self.llm.chat_with_schema(
                    messages,
                    response_schema=schema,
                    structured_output_mode=plan.structured_output_mode,
                )
            )
        except Exception as exc:
            logger.error(
                "[BASE][LLM挑选] template=%s 调用失败: %s",
                template_name,
                exc,
            )
            raise
        logger.info(
            "[BASE][LLM挑选] template=%s, 候选=%d, output_fields=%d",
            template_name,
            len(event_ids),
            len(response),
        )
        if (
            template_name in {"llm_rank_events_cot", "llm_rank_events_cot_atomic"}
            and plan.ranking.llm_include_thought_process
            and isinstance(response.get("thought_process"), str)
        ):
            logger.info(
                "[BASE][LLM挑选] thought_process: %s",
                response["thought_process"],
            )
        ranked: list[str] = []
        scores: dict[str, float] = {}
        if template_name in _ATOMIC_SELECT_PROMPTS:
            # atomic 解析契约：只认方括号内的索引，无方括号整行丢弃；
            # 索引无效时回退到"用行文本匹配原候选文本"纠错。逐字搬自 atomic step7。
            raw_results = response.get("useful_relations")
            if not isinstance(raw_results, list):
                raise _InvalidModelOutput("useful_relations 不是列表")
            for raw_line in raw_results:
                line = str(raw_line)
                if "[" not in line or "]" not in line:
                    continue
                raw_index = line[line.find("[") + 1 : line.find("]")].strip()
                index = int(raw_index) if raw_index.isdigit() else -1
                if 0 <= index < len(event_ids):
                    event_id = event_ids[index]
                    if event_id not in ranked:
                        ranked.append(event_id)
                    continue
                corrected = self._correct_rerank_line(line, relation_texts, event_ids)
                if corrected and corrected not in ranked:
                    ranked.append(corrected)
            ranked = ranked[:llm_target]
        elif template_name == "select_useful_relations_local":
            # 名次挑选契约：LLM 只返回有序索引、不产分，scores 保持为空（hit.score 为 None）。
            raw_results = response.get("useful_relations")
            if not isinstance(raw_results, list):
                raise _InvalidModelOutput("useful_relations 不是列表")
            for raw_index in raw_results:
                try:
                    index = int(raw_index)
                except (TypeError, ValueError) as exc:
                    raise _InvalidModelOutput("LLM rank index 非整数") from exc
                if not 0 <= index < len(event_ids):
                    raise _InvalidModelOutput("LLM rank index 越界")
                event_id = event_ids[index]
                if event_id not in ranked:
                    ranked.append(event_id)
        elif template_name == "llm_rank_events_cot":
            raw_results = response.get("useful_relations")
            if not isinstance(raw_results, list):
                raise _InvalidModelOutput("useful_relations 不是列表")
            target = llm_target
            seen: set[str] = set()
            for raw_index in raw_results:
                try:
                    index = int(str(raw_index).strip("[]"))
                except (TypeError, ValueError):
                    continue
                if not 0 <= index < len(event_ids):
                    continue
                event_id = event_ids[index]
                if event_id in seen:
                    continue
                seen.add(event_id)
                ranked.append(event_id)
                if len(ranked) >= target:
                    break
            if len(ranked) < target:
                # SAG2 multi 行为：不足时按 query-event 相似度补齐到 target。
                # 候选已过 recall/expand 阈值，补齐池直接按相似度分排序即可。
                backfill_pool = [event_id for event_id in event_ids if event_id not in seen]
                backfill_pool.sort(
                    key=lambda eid: float(state.event_score_cache.get(eid, 0.0)),
                    reverse=True,
                )
                for event_id in backfill_pool[: target - len(ranked)]:
                    ranked.append(event_id)
        else:
            raw_results = response.get("results")
            if not isinstance(raw_results, list):
                raise _InvalidModelOutput("LLM rank results 不是列表")
            for item in raw_results:
                if not isinstance(item, dict):
                    raise _InvalidModelOutput("LLM rank 结果项不是对象")
                try:
                    index = int(item["index"])
                except (KeyError, TypeError, ValueError) as exc:
                    raise _InvalidModelOutput("LLM rank index 非整数") from exc
                if not 0 <= index < len(event_ids):
                    raise _InvalidModelOutput("LLM rank index 越界")
                score = _finite_score(item.get("score"), label="LLM rank score")
                if not 0.0 <= score <= 1.0:
                    raise _InvalidModelOutput("LLM rank score 超出 [0,1]")
                event_id = event_ids[index]
                scores[event_id] = max(scores.get(event_id, 0.0), score)
            ranked = _sort_scores(scores)
        if not ranked:
            if not strict_llm_rank_empty:
                # atomic benchmark 行为：LLM 未返回有效结果时静默返回空列表。
                return [], {}
            raise _InvalidModelOutput("LLM rank 未返回有效结果")
        self._record_prompt_version(state, template_name)
        return ranked, scores

    async def _hydrate_chunks_topped_up(
        self,
        final_event_ids: list[str],
        ranked_event_ids: list[str],
        scores: dict[str, float],
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> tuple[SearchHit, ...]:
        # 事项去重到 chunk 后数量会缩水（父事项无 chunk_id、多事项同 chunk），需要补齐到 top_k。
        chunks = await self._hydrator.chunks_from_events(final_event_ids, scores)
        deficit = plan.top_k - len(chunks)
        if deficit <= 0:
            return chunks

        lite = getattr(self.repositories.source_chunks, "storage_mode", "normal") == "lite"
        if lite:
            # Lite 未存 chunk 向量，只能把剩余高分事项接在挑选结果后面再统一 event->chunk。
            extra_event_ids = [
                event_id for event_id in ranked_event_ids if event_id not in set(final_event_ids)
            ]
            if not extra_event_ids:
                return chunks
            chunks = (
                await self._hydrator.chunks_from_events(
                    final_event_ids + extra_event_ids,
                    scores,
                )
            )[: plan.top_k]
            logger.info(
                "[BASE][Chunk兜底] mode=lite, 缺口=%d, 追加事项=%d, 最终=%d",
                deficit,
                len(extra_event_ids),
                len(chunks),
            )
            return chunks

        seen_chunk_ids = {hit.id for hit in chunks}
        rows = await self.repositories.source_chunks.search_similar_by_content(
            state.query_embedding,
            k=plan.top_k + len(seen_chunk_ids),
            data_source_ids=list(request.scope.data_source_ids),
        )
        selected_rows: list[dict[str, Any]] = []
        for row in rows:
            chunk_id = _record_id(row, "chunk_id")
            if not chunk_id or chunk_id in seen_chunk_ids:
                continue
            seen_chunk_ids.add(chunk_id)
            selected_rows.append(row)
            if len(selected_rows) >= deficit:
                break
        supplements = self._hydrator.chunks_from_rows(
            selected_rows,
            recall_channel="query_chunk_fallback",
        )
        state.recall_channels["query_chunk_fallback"] = [hit.id for hit in supplements]
        logger.info(
            "[BASE][Chunk兜底] mode=normal, 缺口=%d, 候选=%d, 补充=%d",
            deficit,
            len(rows),
            len(supplements),
        )
        return chunks + supplements

    def _record_chunk_route(
        self,
        chunks: tuple[SearchHit, ...],
        state: _SearchExecutionState,
    ) -> None:
        """为返回的 chunk 注册 chunk 节点与 event→chunk / query→chunk 边。"""

        assert state.graph is not None  # execute() 无条件构造 GraphCollector
        for hit in chunks:
            raw_events = hit.metadata.get("event_ids")
            event_ids = [str(item) for item in raw_events] if isinstance(raw_events, list) else []
            state.graph.record_chunk(
                row={
                    "chunk_id": hit.id,
                    "source_id": hit.source_id,
                    "data_source_id": hit.data_source_id,
                    "heading": hit.title,
                    "content": hit.content,
                    "score": hit.score,
                },
                query_id=state.active_query_id,
                event_ids=event_ids,
                confidence=float(hit.score) if hit.score is not None else 1.0,
                source="query_chunk_fallback" if not event_ids else "vector_projection",
            )

    @staticmethod
    def _correct_rerank_line(
        predict_line: str,
        relation_texts: list[str],
        relation_ids: list[str],
    ) -> str | None:
        """LLM 返回的索引无效时，用行文本内容匹配回原候选（逐字搬自 atomic step7）。"""

        text = predict_line[predict_line.find("]") + 1 :].strip()
        for line_text, id_ in zip(relation_texts, relation_ids, strict=False):
            if line_text.strip() == text:
                return id_
        return None

    @staticmethod
    def _rrf_scores(channels: list[list[str]], *, k: int) -> dict[str, float]:
        scores: dict[str, float] = {}
        for channel in channels:
            for rank, event_id in enumerate(channel, start=1):
                scores[event_id] = scores.get(event_id, 0.0) + 1.0 / (k + rank)
        return scores

    @staticmethod
    def _format_query_entities(entities: list[str]) -> str:
        if not entities:
            return ""
        listed = ", ".join(entities[:10])
        suffix = ", ..." if len(entities) > 10 else ""
        return f" [{listed}{suffix}]"

    @staticmethod
    def _format_scored_ids(item_ids: Iterable[str], scores: Mapping[str, float]) -> str:
        # 无分数（名次挑选契约）只打印 id，不显示假的 0.0000。
        parts = [
            f"{item_id}={scores[item_id]:.4f}" if item_id in scores else item_id
            for item_id in item_ids
        ]
        return ", ".join(parts) or "-"

    @classmethod
    def _format_top_scores(cls, scores: Mapping[str, float], limit: int = 3) -> str:
        return cls._format_scored_ids(_sort_scores(scores)[:limit], scores)

    @staticmethod
    def _max_entities(plan: SearchExecutionPlan) -> int:
        return min(
            50,
            plan.recall.entity.top_k or 20,
        )

    @staticmethod
    def _validate_entity_names(value: Any, limit: int) -> list[str]:
        if not isinstance(value, list):
            raise _InvalidModelOutput("entities 不是列表")
        names: list[str] = []
        seen: set[str] = set()
        for item in value:
            raw = item.get("name") if isinstance(item, dict) else item
            name = str(raw or "").strip()
            if not name:
                raise _InvalidModelOutput("entity name 为空")
            if name not in seen:
                seen.add(name)
                names.append(name)
        return names[:limit]

    def _prompt_messages(self, template_name: str, **variables: Any) -> list[LLMMessage]:
        config = self.prompts.get_template_config(template_name)
        messages: list[LLMMessage] = []
        if system := config.get("system"):
            messages.append(
                LLMMessage(
                    role=LLMRole.SYSTEM,
                    content=str(system).format(**variables),
                )
            )
        for example in config.get("examples") or []:
            if not isinstance(example, dict):
                continue
            if example.get("user"):
                messages.append(
                    LLMMessage(
                        role=LLMRole.USER,
                        content=str(example["user"]).format(**variables),
                    )
                )
            if example.get("assistant"):
                messages.append(
                    LLMMessage(
                        role=LLMRole.ASSISTANT,
                        content=str(example["assistant"]).format(**variables),
                    )
                )
        messages.append(
            LLMMessage(
                role=LLMRole.USER,
                content=self.prompts.render(template_name, **variables),
            )
        )
        return messages

    def _record_prompt_version(self, state: _SearchExecutionState, template_name: str) -> None:
        config = self.prompts.get_template_config(template_name)
        state.stage_stats.setdefault("prompts", {})[template_name] = str(
            config.get("version") or "unversioned"
        )


__all__ = ["BaseGraphSearchExecutor"]
