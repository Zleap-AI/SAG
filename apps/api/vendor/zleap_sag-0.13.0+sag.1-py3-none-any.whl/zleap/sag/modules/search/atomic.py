"""Atomic search variant: owns its own execute() with relational graph expansion."""

from __future__ import annotations

import asyncio
import math
import time
from typing import Any

from zleap.sag.modules.search._util import _naive_utc, _physical_source_types, _record_id
from zleap.sag.modules.search.assembly import SearchResultBuilder
from zleap.sag.modules.search.base import (
    BaseGraphSearchExecutor,
    _elapsed,
    _SearchExecutionState,
)
from zleap.sag.modules.search.graph import GraphCollector
from zleap.sag.modules.search.planning import SearchExecutionPlan
from zleap.sag.modules.search.pool import VectorCandidateSource
from zleap.sag.pipeline.contracts import SearchHit, SearchRequest, SearchResult
from zleap.sag.pipeline.errors import StageInputError
from zleap.sag.utils import get_logger

logger = get_logger("search.atomic")


class AtomicSearchExecutor(BaseGraphSearchExecutor):
    """原子化消融策略：拥有独立的 execute() 编排，并持有关系表图扩展实现。

    每个 hook 方法对应一条不可改变的 atomic 行为特征，含义见 ``base.py`` 中同名 hook 的文档。
    改动前先读 ``ATOMIC_TO_PRODUCTION_MIGRATION.md`` 第四节。
    """

    def __init__(
        self,
        *,
        repositories: object,
        embedding: object,
        llm: object,
        prompts: object,
    ) -> None:
        # atomic policy 不允许 rerank 方法，因此不接受 rerank 依赖。
        super().__init__(
            repositories=repositories,
            embedding=embedding,
            llm=llm,
            rerank=None,
            prompts=prompts,
        )

    # --- 图扩展钩子实现（关系表路） ---

    async def _expand_entities_for_hop(
        self,
        frontier: list[str],
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        """关系表全量直取：不打分、不截断，与 atomic step5 前半程逐条等价。

        Args:
            frontier: 本跳起始事项的 event_id 列表；atomic 不截断，全量传入。
        """
        relations = await self.repositories.event_entity_relations.fetch_relations_by_event_ids(
            list(frontier),
            data_source_ids=list(request.scope.data_source_ids),
        )
        entity_ids = list(
            dict.fromkeys(
                entity_id
                for row in relations
                if (entity_id := _record_id(row, "entity_id")) is not None
                and entity_id not in state.seen_entity_ids
            )
        )
        return relations, entity_ids

    async def _expand_events_for_hop(
        self,
        entity_ids: list[str],
        total_event_limit: int,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> list[dict[str, Any]]:
        """关系表全量直取：上一跳新实体可达的全部新事项，不做 per-entity 配额。

        Args:
            entity_ids: 本跳通过 ``_expand_entities_for_hop`` 扩展出的新实体 id 列表。
            total_event_limit: atomic 不消费此配额；关系表全量取，不按 per-entity 截断。
        """
        repository = self.repositories.event_entity_relations
        event_ids = await repository.fetch_event_ids_for_entities(
            list(entity_ids),
            data_source_ids=list(request.scope.data_source_ids),
        )
        fresh_ids = [event_id for event_id in event_ids if event_id not in state.seen_event_ids]
        if not fresh_ids:
            return []
        # 事项→实体的归属回填：graph 边需要知道每个新事项挂在本跳哪些实体上。
        relations = await repository.fetch_relations_by_event_ids(
            fresh_ids,
            data_source_ids=list(request.scope.data_source_ids),
        )
        entity_id_set = set(entity_ids)
        # [{"event_id": str, "entity_id": str}]
        return [row for row in relations if row.get("entity_id") in entity_id_set]

    # --- execute() ---

    async def execute(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
    ) -> SearchResult:
        """atomic 完整搜索编排：NER 实体抽取 → 向量召回 → 关系表图扩展 → CoT LLM 精排 → 水合。

        atomic 的核心消融特征：
        - 查询理解 strict=True：NER 抽取失败直接报错，不降级。
        - 候选源固定为 VectorCandidateSource（无候选池），向量字段用 title。
        - 实体路由召回走关系表全量直取（use_relational=True），不按向量阈值过滤。
        - 图扩展同样走关系表，不截断、不打分。
        - 排序前对全部候选重做向量打分（rescore_candidates=True），用 CoT 精选模板。
        """
        from zleap.sag.core.storage.repositories.search_scope import (
            RepositorySearchScope,
            reset_search_scope,
            set_search_scope,
        )

        # 初始化执行状态、检索图记录器和结果构建器，三者共享 recall_channels / timings / stage_stats。
        state = _SearchExecutionState()
        state.graph = GraphCollector(
            enabled=plan.output.return_graph,
            entities=self.repositories.entities,
            events=self.repositories.events,
            max_paths_per_event=plan.output.max_paths_per_event,
        )
        builder = SearchResultBuilder(
            request,
            plan,
            hydrator=self._hydrator,
            graph=state.graph,
        )
        state.recall_channels = builder.recall_channels
        state.timings = builder.timings
        state.stage_stats = builder.stage_stats
        logger.info(
            "[ATOMIC] 开始搜索: strategy=%s, query_chars=%d, top_k=%d, "
            "return_type=%s, data_sources=%d, sources=%d",
            request.options.strategy,
            len(request.query),
            plan.top_k,
            plan.return_type,
            len(request.scope.data_source_ids),
            len(request.scope.source_ids),
        )
        # 将请求 scope 写入 contextvars，供关系表查询的 apply_source_event_scope 读取。
        scope_token = set_search_scope(
            RepositorySearchScope(
                data_source_ids=request.scope.data_source_ids,
                source_ids=request.scope.source_ids,
                source_types=_physical_source_types(tuple(request.scope.source_types)),
                start_time=_naive_utc(request.scope.start_time),
                end_time=_naive_utc(request.scope.end_time),
            )
        )
        try:
            # --- Stage 1: 查询处理 ---
            # strict=True：NER 结构化输出无效时直接抛出，不允许降级为纯向量召回。
            query_started = time.perf_counter()
            await self._process_query(request, plan, state, strict_query_understanding=True)
            # 用重写后的查询（若有）生成向量，作为后续向量召回和图扩展的 query embedding。
            state.query_embedding = await self.embedding.generate(
                state.rewritten_query or request.query
            )
            if not state.query_embedding or not all(
                math.isfinite(float(v)) for v in state.query_embedding
            ):
                raise StageInputError(
                    "Query embedding 为空或包含非法数值",
                    stage="search",
                    code="invalid_query_embedding",
                )
            state.timings["query"] = _elapsed(query_started)
            logger.info(
                "[ATOMIC][查询处理] rewritten=%s, entity_extraction=%s, entities=%d, "
                "embedding_dimensions=%d, elapsed=%.3fs",
                state.rewritten_query is not None,
                plan.query.entity_extraction,
                len(state.rewritten_entities),
                len(state.query_embedding),
                state.timings["query"],
            )

            # atomic 不使用候选池，始终走 VectorCandidateSource；向量字段用 title 而非 content。
            state.candidates = VectorCandidateSource(
                repositories=self.repositories,
                query_embedding=state.query_embedding,
                data_source_ids=list(request.scope.data_source_ids),
                start_time=_naive_utc(request.scope.start_time),
                end_time=_naive_utc(request.scope.end_time),
                vector_field="title",
            )

            # --- Stage 2: 召回 ---
            # 两个通道并发执行：直连事项向量召回 + 实体向量召回。
            # entity_lexical_fallback=False：NER 抽不到实体时放弃实体通道，不降级到 BM25。
            recall_started = time.perf_counter()
            direct_task = self._recall_direct_events(request, plan, state)
            entity_task = self._recall_entities(
                request,
                plan,
                state,
                entity_lexical_fallback=False,
                entity_vector_top_k_per_entity=plan.recall.entity.top_k,
            )
            direct_rows, recalled_entities = await asyncio.gather(direct_task, entity_task)
            # 将直连召回结果过滤、打分并登记到检索图。
            self._record_direct_route(direct_rows, request, plan, state)
            # 实体→事项路由：走关系表全量直取，不按向量阈值过滤（apply_entity_event_threshold=False）。
            await self._recall_events_from_entities(
                recalled_entities,
                request,
                plan,
                state,
                use_relational=True,
                apply_entity_event_threshold=False,
            )
            state.timings["recall"] = _elapsed(recall_started)
            recall_counts = {
                channel: len(event_ids) for channel, event_ids in state.recall_channels.items()
            }
            logger.info(
                "[ATOMIC][召回] channels=%s, recalled_entities=%d, unique_events=%d, elapsed=%.3fs",
                recall_counts,
                len(recalled_entities),
                len(state.seen_event_ids),
                state.timings["recall"],
            )
            if not state.seen_event_ids:
                logger.warning("[ATOMIC][召回] 所有通道均未命中，检查 scope、索引文档及过滤阈值")

            # --- Stage 3: 图扩展 ---
            # 从召回事项出发，沿关系表向外扩展 max_hops 跳，找到关联事项加入候选集。
            expand_started = time.perf_counter()
            if plan.graph.enabled and plan.graph.max_hops:
                await self._expand_graph(request, plan, state)
            state.timings["graph"] = _elapsed(expand_started)
            logger.info(
                "[ATOMIC][图扩展] enabled=%s, max_hops=%d, unique_events=%d, elapsed=%.3fs",
                plan.graph.enabled,
                plan.graph.max_hops,
                len(state.seen_event_ids),
                state.timings["graph"],
            )

            # --- Stage 4: 排序 ---
            # rescore_candidates=True：排序前对全部候选重做 query 向量打分，
            # 让关系表路径召回的事项（初始分为 0）获得真实向量分。
            # 使用 CoT 精选模板，仅传入 content 字段，strict_llm_rank_empty=False 允许空结果降级。
            rank_started = time.perf_counter()
            ranked_ids, ranked_scores, ranking_stats = await self._rank_events(
                request,
                plan,
                state,
                rescore_candidates=True,
                llm_prompt_name="llm_rank_events_cot_atomic",
                llm_text_fields="content_only",
                strict_llm_rank_empty=False,
            )
            final_event_ids = ranked_ids[: plan.top_k]
            state.timings["ranking"] = _elapsed(rank_started)
            logger.info(
                "[ATOMIC][排序] method=%s, candidates=%d, ranked=%d, final=%d, "
                "fallback=%s, elapsed=%.3fs",
                ranking_stats.get("method"),
                len(state.seen_event_ids),
                len(ranked_ids),
                len(final_event_ids),
                ranking_stats.get("fallback_reason"),
                state.timings["ranking"],
            )

            # --- Stage 5: 结果填充 ---
            # 按 return_type 决定返回事项还是 chunk；chunk 模式下用 topped-up 补齐到 top_k。
            hydrate_started = time.perf_counter()
            await builder.record_ranked_events(ranked_ids, ranked_scores)
            if plan.return_type == "chunk":
                chunks = await self._hydrate_chunks_topped_up(
                    final_event_ids,
                    ranked_ids,
                    ranked_scores,
                    request,
                    plan,
                    state,
                )
                events: tuple[SearchHit, ...] = ()
                self._record_chunk_route(chunks, state)
            else:
                events = await self._hydrator.events(
                    final_event_ids,
                    ranked_scores,
                    components=state.event_score_components,
                )
                chunks = ()
            state.timings["hydrate"] = _elapsed(hydrate_started)

            builder.set_rewritten_query(state.rewritten_query)
            builder.set_ranking(**ranking_stats)
            builder.set_pool_stats(state.candidates.pool_stats() if state.candidates else None)
            result = await builder.build(
                events=events,
                chunks=chunks,
                final_event_ids=final_event_ids,
                final_chunk_ids=(
                    [hit.id for hit in chunks] if plan.return_type == "chunk" else None
                ),
            )
            logger.info(
                "[ATOMIC] 搜索完成: events=%d, chunks=%d, total=%.3fs",
                len(result.events),
                len(result.chunks),
                state.timings["total"],
            )
            return result
        finally:
            reset_search_scope(scope_token)


__all__ = ["AtomicSearchExecutor"]
