"""Built-in executors with one explicit implementation per search algorithm."""

from __future__ import annotations

import json
from typing import Any

from zleap.sag.modules.search._util import _naive_utc, _physical_source_types
from zleap.sag.modules.search.assembly import ResultHydrator, SearchResultBuilder
from zleap.sag.modules.search.config import VectorConfig
from zleap.sag.modules.search.planning import SearchExecutionPlan
from zleap.sag.pipeline.contracts import SearchRequest, SearchResult


def _portable_dict(value: dict[str, Any] | None) -> dict[str, Any]:
    return json.loads(json.dumps(value or {}, default=str, ensure_ascii=False))


class VectorSearchExecutor:
    """Chunk-vector search with no graph, LLM, ORM hydration, or shared runtime state."""

    def __init__(self, vector_searcher: Any, *, repositories: Any = None) -> None:
        self._vector_searcher = vector_searcher
        self._hydrator: ResultHydrator | None = (
            ResultHydrator(repositories) if repositories is not None else None
        )

    async def execute(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
    ) -> SearchResult:
        from zleap.sag.core.storage.repositories.search_scope import (
            RepositorySearchScope,
            reset_search_scope,
            set_search_scope,
        )

        threshold = (
            plan.recall.event.vector_threshold
            if plan.recall.event.vector_threshold is not None
            else (plan.ranking.score_threshold if plan.ranking.score_threshold is not None else 0.4)
        )
        config = VectorConfig(
            top_k=plan.top_k,
            return_type="chunk",
            similarity_threshold=threshold,
        )
        builder = SearchResultBuilder(
            request,
            plan,
            hydrator=self._hydrator,
        )
        scope_token = set_search_scope(
            RepositorySearchScope(
                data_source_ids=request.scope.data_source_ids,
                source_ids=request.scope.source_ids,
                source_types=_physical_source_types(tuple(request.scope.source_types)),
                start_time=_naive_utc(request.scope.start_time),
                end_time=_naive_utc(request.scope.end_time),
            )
        )
        try:
            raw = await self._vector_searcher.search_chunks(
                query=request.query,
                data_source_ids=list(request.scope.data_source_ids),
                config=config,
            )
            sections = [
                item for item in raw.get("sections", [])[: plan.top_k] if isinstance(item, dict)
            ]
            builder.record_channel(
                "chunk_vector",
                [
                    str(item.get("chunk_id") or item.get("id"))
                    for item in sections
                    if item.get("chunk_id") or item.get("id")
                ],
            )
            raw_timings = _portable_dict(raw.get("_timings"))
            builder.timings["query"] = float(raw_timings.get("vector_gen") or 0.0)
            builder.timings["recall"] = float(raw_timings.get("es_search") or 0.0)
            chunks = ResultHydrator.chunks_from_rows(
                sections,
                recall_channel="chunk_vector",
            )
            builder.set_ranking(method="vector", fallback_reason=None)
            builder.record_ranked_chunks(chunks)
            return await builder.build(chunks=chunks)
        finally:
            reset_search_scope(scope_token)


__all__ = ["VectorSearchExecutor"]
