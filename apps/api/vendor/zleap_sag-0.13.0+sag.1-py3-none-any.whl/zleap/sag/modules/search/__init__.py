"""
搜索模块

提供 SAG 搜索引擎的公开 Profile、Executor 与具体算法。

架构：
- SearchOrchestrator: 唯一公开搜索编排入口
- VectorSearchExecutor / AtomicSearchExecutor: 独立算法执行器
- ProductionSearchExecutor: 生产级执行器，覆盖 full_expand / precise / rerank / fast
- VectorSearcher: 纯向量检索器
"""

from zleap.sag.modules.search.atomic import AtomicSearchExecutor
from zleap.sag.modules.search.config import VectorConfig
from zleap.sag.modules.search.executors import VectorSearchExecutor
from zleap.sag.modules.search.orchestrator import SearchOrchestrator
from zleap.sag.modules.search.planning import SearchExecutionPlan, SearchPlanResolver
from zleap.sag.modules.search.production import ProductionSearchExecutor
from zleap.sag.modules.search.profiles import (
    SearchExecutorKind,
    SearchProfile,
    SearchProfilePolicy,
    builtin_search_profiles,
)
from zleap.sag.modules.search.registry import (
    SearchExecutorRegistry,
    SearchExecutorSpec,
    SearchProfileRegistry,
)
from zleap.sag.modules.search.vector import VectorSearcher

__all__ = [
    # 配置
    "VectorConfig",
    "VectorSearcher",
    "AtomicSearchExecutor",
    "ProductionSearchExecutor",
    "VectorSearchExecutor",
    "SearchExecutionPlan",
    "SearchExecutorKind",
    "SearchExecutorRegistry",
    "SearchExecutorSpec",
    "SearchOrchestrator",
    "SearchPlanResolver",
    "SearchProfile",
    "SearchProfilePolicy",
    "SearchProfileRegistry",
    "builtin_search_profiles",
]
