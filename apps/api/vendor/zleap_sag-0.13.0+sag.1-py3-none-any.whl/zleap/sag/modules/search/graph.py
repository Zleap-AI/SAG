"""Request-local graph collection for production search execution.

GraphCollector owns the whole graph pipeline — collect, hydrate, reverse-reason,
output — so the production algorithm only faces record_* calls and one build().
When disabled it is a pure no-op: no Tracker is built, no nodes/edges are
recorded, no hydration or path analysis runs.
"""

from __future__ import annotations

import asyncio
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal

from zleap.sag.exceptions import InvalidInputError, StateError
from zleap.sag.modules.search.path_analyzer import PathAnalyzer
from zleap.sag.modules.search.tracker import Tracker, _stable_id
from zleap.sag.pipeline.contracts import PathAnalysisResult, SearchGraph


def _record_id(row: Mapping[str, Any], field: str) -> str | None:
    value = row.get(field) or row.get("id")
    return str(value) if value else None


@dataclass(frozen=True, slots=True)
class GraphOutput:
    """build() 的一次性产物：图谱与路径分析结果。"""

    graph: SearchGraph | None
    path_result: PathAnalysisResult | None


class GraphCollector:
    """封装一次生产搜索的图谱：收集 → hydration → 反向推理 → 输出。

    enabled=False 时 record_* 全部 no-op（不建 Tracker、不建节点/边、不做反向推理），
    算法调用方无需感知，也不需要到处写 if。
    """

    def __init__(
        self,
        *,
        enabled: bool,
        entities: Any,
        events: Any,
        max_paths_per_event: int = 20,
    ) -> None:
        self._enabled = enabled
        self._tracker_or_none = Tracker() if enabled else None
        self._entities = entities
        self._events = events
        self._max_paths_per_event = max_paths_per_event

    @property
    def _tracker(self) -> Tracker:
        tracker = self._tracker_or_none
        if tracker is None:
            raise StateError("图谱收集未启用")
        return tracker

    # ---- 收集（记录接口，逐一对应现有调用点；enabled=False 时全部 no-op）----

    def record_query(self, query: str, *, scope_fingerprint: str) -> str:
        """注册 query 节点，返回节点 id（供 state.active_query_id 使用）。"""

        if not self._enabled:
            return _stable_id("query", query.strip(), scope_fingerprint)
        node = self._tracker.build_query_node(query, scope_fingerprint=scope_fingerprint)
        self._tracker.add_node(node)
        return node.id

    def record_rewrite(self, origin_id: str, rewritten: str, *, scope_fingerprint: str) -> str:
        """注册改写节点并连 origin→rewrite 边，返回改写节点 id。"""

        if not self._enabled:
            return _stable_id("query", rewritten.strip(), scope_fingerprint)
        node = self._tracker.build_query_node(
            rewritten,
            scope_fingerprint=scope_fingerprint,
            rewritten=True,
        )
        self._tracker.add_node(node)
        if node.id != origin_id:
            self._tracker.add_edge(
                stage="query",
                method="rewrite",
                from_id=origin_id,
                to_id=node.id,
                confidence=1.0,
                visibility="intermediate",
            )
        return node.id

    def record_event(
        self,
        *,
        row: Mapping[str, Any],
        query_id: str,
        method: str,
        confidence: float,
        stage: str = "recall",
        hop: int = 0,
        source: str = "route_stub",
        metadata: Mapping[str, Any] | None = None,
    ) -> str:
        """注册 event 节点并连 query→event 边（覆盖直连召回）。"""

        if not self._enabled:
            return ""
        node = self._tracker.build_event_node(row, stage=stage, hop=hop)
        self._tracker.add_node(node, source=source)
        self._tracker.add_edge(
            stage=stage,
            method=method,
            from_id=query_id,
            to_id=node.id,
            confidence=confidence,
            hop=hop,
            visibility="intermediate",
            metadata=metadata,
        )
        return node.id

    def record_entity(
        self,
        *,
        row: Mapping[str, Any],
        query_id: str,
        scores: Mapping[str, float],
        hop: int = 0,
        stage: str = "recall",
        source: str = "vector_projection",
    ) -> str:
        """注册 entity 节点，并为每个 (channel, score) 连 query→entity 边。"""

        if not self._enabled:
            return ""
        node = self._tracker.build_entity_node(row, stage=stage, hop=hop)
        self._tracker.add_node(node, source=source)
        for method, score in scores.items():
            self._tracker.add_edge(
                stage=stage,
                method=method,
                from_id=query_id,
                to_id=node.id,
                confidence=score,
                hop=hop,
                visibility="intermediate",
            )
        return node.id

    def record_event_routes(
        self,
        *,
        row: Mapping[str, Any],
        event_id: str,
        relations: Sequence[Mapping[str, Any]],
        stage: str = "recall",
        hop: int = 0,
        source: str = "route_stub",
    ) -> str:
        """注册经实体路由召回的 event 节点，并为每条关系连 entity→event 边。"""

        if not self._enabled:
            return ""
        node = self._tracker.build_event_node(row, stage=stage, hop=hop)
        self._tracker.add_node(node, source=source)
        for relation in relations:
            entity_id = str(relation["entity_id"])
            self._tracker.add_edge(
                stage=stage,
                method="entity_relation",
                from_id=entity_id,
                to_id=event_id,
                confidence=float(relation.get("score", 1.0)),
                hop=hop,
                visibility="intermediate",
                relation=str(relation.get("description") or ""),
            )
        return node.id

    def record_expansion_entity(
        self,
        *,
        row: Mapping[str, Any],
        hop: int,
        source: str = "route_stub",
    ) -> str:
        """注册图扩展新增的 entity 节点。"""

        if not self._enabled:
            return ""
        node = self._tracker.build_entity_node(row, stage="expand", hop=hop)
        self._tracker.add_node(node, source=source)
        return node.id

    def record_expansion_event(
        self,
        *,
        row: Mapping[str, Any],
        hop: int,
        source: str = "vector_projection",
    ) -> str:
        """注册图扩展新增的 event 节点。"""

        if not self._enabled:
            return ""
        node = self._tracker.build_event_node(row, stage="expand", hop=hop)
        self._tracker.add_node(node, source=source)
        return node.id

    def record_expansion_edge(
        self,
        *,
        method: str,
        from_id: str,
        to_id: str,
        confidence: float,
        hop: int = 0,
        relation: str = "",
    ) -> None:
        """注册图扩展阶段的 event→entity / entity→event 边。"""

        if not self._enabled:
            return
        self._tracker.add_edge(
            stage="expand",
            method=method,
            from_id=from_id,
            to_id=to_id,
            confidence=confidence,
            hop=hop,
            visibility="intermediate",
            relation=relation,
        )

    def record_chunk(
        self,
        *,
        row: Mapping[str, Any],
        query_id: str,
        event_ids: list[str] | None = None,
        confidence: float = 1.0,
        stage: str = "recall",
        hop: int = 0,
        source: str = "vector_projection",
    ) -> str:
        """注册 chunk 节点并画入边：关联事件已在图中 → 逐条连 event→chunk；否则连 query→chunk。

        边的选择只由 chunk 的来源决定：
        - 事件派生 chunk（_hydrate_chunks 返回）恒带 event_ids，其事件已在召回阶段入图
          → 画 event→chunk（method="chunk_link"）；
        - 兜底召回 chunk（query_chunk_fallback 补满 top_k，production.py:1160）无 event_ids
          → 画 query→chunk（method="query_chunk_fallback"）。
        防御：event 端点不在图中时跳过该条边不抛错；若最终一条 event→chunk 都没连上
        （含陈旧引用、事件被裁剪），改连 query→chunk，保证 chunk 不孤立、可被反向推理命中。
        """

        if not self._enabled:
            return ""
        node = self._tracker.build_chunk_node(row, stage=stage, hop=hop)
        self._tracker.add_node(node, source=source)
        linked_any = False
        for event_id in dict.fromkeys(event_ids or ()):
            if event_id not in self._tracker.all_nodes:
                continue
            self._tracker.add_edge(
                stage=stage,
                method="chunk_link",
                from_id=event_id,
                to_id=node.id,
                confidence=confidence,
                hop=hop,
                visibility="intermediate",
            )
            linked_any = True
        if not linked_any:
            self._tracker.add_edge(
                stage=stage,
                method="query_chunk_fallback",
                from_id=query_id,
                to_id=node.id,
                confidence=confidence,
                hop=hop,
                visibility="intermediate",
            )
        return node.id

    # ---- 反向推理 + 输出（仅 enabled 时有效）----

    async def build(
        self,
        *,
        final_event_ids: list[str],
        data_source_ids: list[str],
        return_paths: bool,
        return_type: Literal["event", "chunk"],
        max_hops: int | None,
        final_chunk_ids: list[str] | None = None,
    ) -> GraphOutput:
        if not self._enabled:
            return GraphOutput(graph=None, path_result=None)
        if return_type == "chunk" and final_chunk_ids is None:
            # None 表示调用方漏传参数；[] 才是合法的"本次无 chunk 返回"，走优雅降级。
            raise InvalidInputError("return_type='chunk' 时必须提供 final_chunk_ids（可为空列表）")
        target_ids = (final_chunk_ids or []) if return_type == "chunk" else final_event_ids
        self._mark_final_edges(target_ids)
        await self._hydrate_answer_nodes(target_ids, data_source_ids)
        graph = self._tracker.build_answer_graph(target_ids)
        path_result = None
        if return_paths:
            path_result = PathAnalyzer().analyze(
                trace=self._tracker,
                target_event_ids=target_ids,
                max_depth=3 + 2 * (max_hops or 0),
                max_paths_per_event=self._max_paths_per_event,
            )
        return GraphOutput(graph=graph, path_result=path_result)

    def _mark_final_edges(self, event_ids: list[str]) -> None:
        for event_id in event_ids:
            for clue_id in tuple(self._tracker.incoming.get(event_id, ())):
                clue = self._tracker.all_clues[clue_id]
                self._tracker.add_edge(
                    stage=clue.stage,
                    method=clue.method,
                    from_id=clue.from_id,
                    to_id=clue.to_id,
                    confidence=clue.confidence,
                    hop=clue.hop,
                    visibility="final",
                    relation=clue.relation,
                    description=clue.description,
                    metadata=clue.metadata,
                )

    async def _hydrate_answer_nodes(
        self,
        target_ids: list[str],
        data_source_ids: list[str],
    ) -> None:
        graph = self._tracker.build_answer_graph(target_ids)
        entity_ids = [node.id for node in graph.nodes if node.type == "entity"]
        graph_event_ids = [node.id for node in graph.nodes if node.type == "event"]
        entity_rows, event_rows = await asyncio.gather(
            self._entities.get_entities_by_ids(
                entity_ids,
                data_source_ids=data_source_ids,
            ),
            self._events.get_events_by_ids(graph_event_ids),
        )
        for row in entity_rows:
            entity_id = _record_id(row, "entity_id")
            if entity_id and entity_id in self._tracker.all_nodes:
                existing = self._tracker.all_nodes[entity_id]
                self._tracker.add_node(
                    self._tracker.build_entity_node(
                        row,
                        stage=existing.stage,
                        hop=existing.hop,
                    ),
                    source="vector_projection",
                )
        for row in event_rows:
            event_id = _record_id(row, "event_id")
            if event_id and event_id in self._tracker.all_nodes:
                existing = self._tracker.all_nodes[event_id]
                self._tracker.add_node(
                    self._tracker.build_event_node(
                        row,
                        stage=existing.stage,
                        hop=existing.hop,
                    ),
                    source="vector_projection",
                )


__all__ = ["GraphCollector", "GraphOutput"]
