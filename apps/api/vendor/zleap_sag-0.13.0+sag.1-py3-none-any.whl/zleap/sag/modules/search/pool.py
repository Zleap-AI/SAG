"""候选池（Candidate Pool）：生产搜索可选的 event 召回内存源。

- VectorCandidateSource：现有向量库调用原样搬入，池关闭/降级时使用，行为不变。
- PooledCandidateSource：由一次 query→event 检索（k=pool_size）建池，entity→event 与
  key→event 改读内存；事件行自带 entity_ids 用于拼反向索引。
"""

from __future__ import annotations

import asyncio
from typing import Any, Protocol

from zleap.sag._safe_error import safe_error_type
from zleap.sag.modules.search._util import _record_id
from zleap.sag.utils import get_logger

logger = get_logger("search.pool")


class EventCandidateSource(Protocol):
    async def recall_direct(self, limit: int) -> list[dict[str, Any]]: ...

    async def score_events(
        self,
        event_ids: list[str],
        *,
        exclude_event_ids: list[str] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]: ...

    async def events_for_keys(
        self,
        entity_ids: list[str],
        per_entity_limit: int,
        *,
        exclude_event_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]: ...

    def pool_score(self, event_id: str) -> float | None: ...

    def pool_stats(self) -> dict[str, Any] | None: ...


class VectorCandidateSource:
    """现有向量库调用原样搬运，行为与池化前一致。"""

    def __init__(
        self,
        *,
        repositories: Any,
        query_embedding: list[float],
        data_source_ids: list[str],
        start_time: Any = None,
        end_time: Any = None,
        vector_field: str = "content",
    ) -> None:
        self._repositories = repositories
        self._query_embedding = query_embedding
        self._data_source_ids = data_source_ids
        self._start_time = start_time
        self._end_time = end_time
        self._search_similar = getattr(repositories.events, f"search_similar_by_{vector_field}")

    async def recall_direct(self, limit: int) -> list[dict[str, Any]]:
        return await self._search_similar(
            self._query_embedding,
            k=limit,
            data_source_ids=self._data_source_ids,
            start_time=self._start_time,
            end_time=self._end_time,
        )

    async def score_events(
        self,
        event_ids: list[str],
        *,
        exclude_event_ids: list[str] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        if not event_ids:
            return []
        return await self._search_similar(
            self._query_embedding,
            k=limit or len(event_ids),
            data_source_ids=self._data_source_ids,
            event_ids=event_ids,
            exclude_event_ids=exclude_event_ids,
        )

    async def events_for_keys(
        self,
        entity_ids: list[str],
        per_entity_limit: int,
        *,
        exclude_event_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        return await self._repositories.event_entities.get_relations_by_entity_ids_limited(
            entity_ids,
            per_entity_limit=per_entity_limit,
            data_source_ids=self._data_source_ids,
            exclude_event_ids=exclude_event_ids,
        )

    def pool_score(self, event_id: str) -> float | None:
        return None

    def pool_stats(self) -> dict[str, Any] | None:
        return None


class PooledCandidateSource:
    """内存三结构：_events（id→行+分）、_events_by_entity（key→池内事项）、_ordered_ids（按分降序）。"""

    def __init__(
        self,
        *,
        repositories: Any,
        query_embedding: list[float],
        data_source_ids: list[str],
        pool_size: int,
        start_time: Any = None,
        end_time: Any = None,
        vector_field: str = "content",
    ) -> None:
        self._pool_size = pool_size
        self._vector = VectorCandidateSource(
            repositories=repositories,
            query_embedding=query_embedding,
            data_source_ids=data_source_ids,
            start_time=start_time,
            end_time=end_time,
            vector_field=vector_field,
        )
        self._events: dict[str, dict[str, Any]] = {}
        self._events_by_entity: dict[str, list[str]] = {}
        self._ordered_ids: list[str] = []
        self._built = False
        self._degraded = False
        self._lock = asyncio.Lock()

    async def _ensure_built(self) -> None:
        if self._built or self._degraded:
            return
        async with self._lock:
            if self._built or self._degraded:
                return
            try:
                rows = await self._vector.recall_direct(self._pool_size)
            except Exception as error:
                self._degraded = True
                logger.warning(
                    "[POOL] 建池失败，降级回 VectorCandidateSource",
                    extra={"error_type": safe_error_type(error)},
                )
                return
            for row in rows:
                event_id = _record_id(row, "event_id")
                if not event_id:
                    continue
                self._events[event_id] = row
                for entity_id in row.get("entity_ids") or ():
                    if not entity_id:
                        continue
                    entity_list = self._events_by_entity.setdefault(str(entity_id), [])
                    if event_id not in entity_list:
                        entity_list.append(event_id)
            self._ordered_ids = sorted(
                self._events,
                key=lambda event_id: (self._events[event_id].get("score", 0.0), event_id),
                reverse=True,
            )
            self._built = True
            logger.info(
                "[POOL] 建池完成 requested=%d actual=%d keys=%d",
                self._pool_size,
                len(self._events),
                len(self._events_by_entity),
            )

    async def recall_direct(self, limit: int) -> list[dict[str, Any]]:
        await self._ensure_built()
        if self._degraded:
            return await self._vector.recall_direct(limit)
        return [self._events[event_id] for event_id in self._ordered_ids[:limit]]

    async def score_events(
        self,
        event_ids: list[str],
        *,
        exclude_event_ids: list[str] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        await self._ensure_built()
        if self._degraded:
            return await self._vector.score_events(
                event_ids,
                exclude_event_ids=exclude_event_ids,
                limit=limit,
            )
        excluded = set(exclude_event_ids or ())
        wanted = [
            event_id
            for event_id in event_ids
            if event_id in self._events and event_id not in excluded
        ]
        if limit is not None:
            wanted_set = set(wanted)
            wanted = [event_id for event_id in self._ordered_ids if event_id in wanted_set][:limit]
        return [self._events[event_id] for event_id in wanted]

    async def events_for_keys(
        self,
        entity_ids: list[str],
        per_entity_limit: int,
        *,
        exclude_event_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        await self._ensure_built()
        if self._degraded:
            return await self._vector.events_for_keys(
                entity_ids,
                per_entity_limit=per_entity_limit,
                exclude_event_ids=exclude_event_ids,
            )
        excluded = set(exclude_event_ids or ())
        relations: list[dict[str, Any]] = []
        for entity_id in dict.fromkeys(entity_ids):
            taken = 0
            for event_id in self._events_by_entity.get(entity_id, ()):
                if event_id in excluded:
                    continue
                row = self._events[event_id]
                relations.append(
                    {
                        "event_id": event_id,
                        "entity_id": entity_id,
                        "score": float(row.get("score", 0.0)),
                        "description": str(row.get("description") or row.get("summary") or ""),
                        "data_source_id": row.get("data_source_id"),
                    }
                )
                taken += 1
                if taken >= per_entity_limit:
                    break
        return relations

    def pool_score(self, event_id: str) -> float | None:
        if not self._built or self._degraded:
            return None
        row = self._events.get(event_id)
        return float(row.get("score", 0.0)) if row else None

    def pool_stats(self) -> dict[str, Any] | None:
        if not self._built or self._degraded:
            return None
        scores = [float(self._events[event_id].get("score", 0.0)) for event_id in self._ordered_ids]
        return {
            "requested": self._pool_size,
            "actual": len(self._events),
            "saturated": len(self._events) >= self._pool_size,
            "key_count": len(self._events_by_entity),
            "relation_count": sum(len(ids) for ids in self._events_by_entity.values()),
            "min_score": min(scores) if scores else None,
        }


__all__ = ["EventCandidateSource", "PooledCandidateSource", "VectorCandidateSource"]
