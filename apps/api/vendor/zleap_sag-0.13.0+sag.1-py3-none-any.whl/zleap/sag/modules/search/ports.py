"""Provider-neutral execution ports for composed search strategies."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

from zleap.sag.pipeline.contracts import SearchRequest, SearchResult

if TYPE_CHECKING:
    from zleap.sag.modules.search.planning import SearchExecutionPlan


class SearchStrategyExecutor(Protocol):
    async def execute(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
    ) -> SearchResult: ...


__all__ = ["SearchStrategyExecutor"]
