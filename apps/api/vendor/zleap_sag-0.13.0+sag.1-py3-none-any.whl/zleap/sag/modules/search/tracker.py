"""Request-local route tracing for production search execution."""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any, Literal

from zleap.sag.exceptions import InvalidInputError
from zleap.sag.pipeline.contracts import GraphClue, GraphNode, SearchGraph
from zleap.sag.pipeline.errors import StageInputError

_SOURCE_PRIORITY = {
    "route_stub": 0,
    "vector_projection": 1,
    "relation_detail": 2,
}
_VISIBILITY_PRIORITY = {"debug": 0, "intermediate": 1, "final": 2}


def _stable_id(prefix: str, *parts: object) -> str:
    payload = json.dumps(parts, ensure_ascii=False, separators=(",", ":"), default=str)
    return f"{prefix}-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:24]}"


def _portable(value: Any) -> Any:
    return json.loads(json.dumps(value, ensure_ascii=False, default=str))


def _confidence(value: float) -> float:
    score = float(value)
    if not math.isfinite(score):
        raise InvalidInputError("clue confidence 必须是有限数值")
    return min(1.0, max(0.0, score))


@dataclass(frozen=True, slots=True)
class RouteTraceSnapshot:
    """Read-only snapshot consumed by graph and path analysis."""

    nodes: Mapping[str, GraphNode]
    clues: Mapping[str, GraphClue]
    incoming: Mapping[str, tuple[str, ...]]


class Tracker:
    """Collect and deterministically merge nodes and route clues for one request."""

    def __init__(self) -> None:
        self.all_nodes: dict[str, GraphNode] = {}
        self.all_clues: dict[str, GraphClue] = {}
        self.incoming: dict[str, list[str]] = {}
        self._node_sources: dict[str, int] = {}
        self._clue_keys: dict[tuple[str, str, str, str, int], str] = {}

    @staticmethod
    def build_query_node(
        query: str,
        *,
        scope_fingerprint: str,
        rewritten: bool = False,
    ) -> GraphNode:
        text = query.strip()
        if not text:
            raise StageInputError(
                "查询节点内容不能为空",
                stage="search",
                code="invalid_route_node",
            )
        return GraphNode(
            id=_stable_id("query", text, scope_fingerprint),
            type="query",
            category="rewrite" if rewritten else "origin",
            content=text,
            description="重写的请求" if rewritten else "原始搜索内容",
        )

    @staticmethod
    def build_entity_node(
        entity: Mapping[str, Any],
        *,
        stage: str | None = None,
        hop: int = 0,
    ) -> GraphNode:
        entity_id = entity.get("entity_id") or entity.get("id") or entity.get("key_id")
        if not entity_id:
            raise StageInputError(
                "实体投影缺少稳定 entity_id",
                stage="search",
                code="invalid_route_node",
            )
        return GraphNode(
            id=str(entity_id),
            type="entity",
            category=str(entity.get("type") or entity.get("category") or ""),
            name=str(entity.get("name") or ""),
            content=str(entity.get("name") or ""),
            description=str(entity.get("description") or ""),
            stage=stage,
            hop=max(0, int(hop)),
            metadata=_portable(
                {
                    key: entity[key]
                    for key in ("data_source_id", "source_id", "normalized_name")
                    if entity.get(key) is not None
                }
            ),
        )

    @staticmethod
    def build_event_node(
        event: Mapping[str, Any],
        *,
        stage: str | None = None,
        hop: int = 0,
    ) -> GraphNode:
        event_id = event.get("event_id") or event.get("id")
        if not event_id:
            raise StageInputError(
                "事项投影缺少稳定 event_id",
                stage="search",
                code="invalid_route_node",
            )
        return GraphNode(
            id=str(event_id),
            event_id=str(event_id),
            type="event",
            category=str(event.get("category") or event.get("type") or ""),
            title=str(event.get("title") or ""),
            summary=str(event.get("summary") or ""),
            content=str(event.get("content") or event.get("summary") or ""),
            description=str(event.get("content") or ""),
            stage=stage,
            hop=max(0, int(hop)),
            metadata=_portable(
                {
                    key: event[key]
                    for key in (
                        "data_source_id",
                        "source_id",
                        "source_type",
                        "chunk_id",
                        "start_time",
                        "end_time",
                    )
                    if event.get(key) is not None
                }
            ),
        )

    @staticmethod
    def build_chunk_node(
        chunk: Mapping[str, Any],
        *,
        stage: str | None = None,
        hop: int = 0,
    ) -> GraphNode:
        chunk_id = chunk.get("chunk_id") or chunk.get("id")
        if not chunk_id:
            raise StageInputError(
                "Chunk 投影缺少稳定 chunk_id",
                stage="search",
                code="invalid_route_node",
            )
        return GraphNode(
            id=str(chunk_id),
            chunk_id=str(chunk_id),
            type="chunk",
            category="chunk",
            title=str(chunk.get("heading") or chunk.get("title") or ""),
            content=str(chunk.get("content") or ""),
            description=str(chunk.get("content") or ""),
            stage=stage,
            hop=max(0, int(hop)),
            metadata=_portable(
                {
                    key: chunk[key]
                    for key in ("data_source_id", "source_id", "score", "heading")
                    if chunk.get(key) is not None
                }
            ),
        )

    def add_node(
        self,
        node: GraphNode | Mapping[str, Any],
        *,
        source: str = "route_stub",
    ) -> GraphNode:
        candidate = node if isinstance(node, GraphNode) else GraphNode.model_validate(node)
        priority = _SOURCE_PRIORITY.get(source, 0)
        existing = self.all_nodes.get(candidate.id)
        if existing is None:
            self.all_nodes[candidate.id] = candidate
            self._node_sources[candidate.id] = priority
            return candidate
        if existing.type != candidate.type:
            raise StageInputError(
                f"RouteTrace 节点 {candidate.id!r} 的类型发生冲突",
                stage="search",
                code="inconsistent_route_node",
            )

        old_priority = self._node_sources[candidate.id]
        existing_data = existing.model_dump(mode="python")
        candidate_data = candidate.model_dump(mode="python")
        merged = dict(existing_data)
        for key, value in candidate_data.items():
            if key in {"id", "type", "contract_version", "metadata"}:
                continue
            if key == "hop" and value == 0 and existing.hop > 0:
                continue
            if value not in (None, "", (), [], {}):
                if priority >= old_priority or merged.get(key) in (None, "", (), [], {}):
                    merged[key] = value
        metadata = dict(existing.metadata)
        if priority >= old_priority:
            metadata.update(candidate.metadata)
        else:
            metadata = {**candidate.metadata, **metadata}
        merged["metadata"] = metadata
        merged_node = GraphNode.model_validate(merged)
        self.all_nodes[candidate.id] = merged_node
        self._node_sources[candidate.id] = max(priority, old_priority)
        return merged_node

    def add_edge(
        self,
        *,
        stage: str,
        method: str,
        from_id: str,
        to_id: str,
        confidence: float = 1.0,
        hop: int = 0,
        visibility: Literal["debug", "intermediate", "final"] = "intermediate",
        relation: str = "",
        description: str = "",
        metadata: Mapping[str, Any] | None = None,
    ) -> GraphClue:
        if from_id not in self.all_nodes or to_id not in self.all_nodes:
            raise StageInputError(
                f"RouteTrace 边端点不存在: {from_id!r} -> {to_id!r}",
                stage="search",
                code="invalid_route_edge",
            )
        if visibility not in _VISIBILITY_PRIORITY:
            raise InvalidInputError(f"未知 clue visibility: {visibility}")
        key = (stage, method, from_id, to_id, max(0, int(hop)))
        existing_id = self._clue_keys.get(key)
        if existing_id is not None:
            existing = self.all_clues[existing_id]
            merged_metadata = dict(existing.metadata)
            merged_metadata.update(_portable(dict(metadata or {})))
            merged = existing.model_copy(
                update={
                    "confidence": max(existing.confidence, _confidence(confidence)),
                    "visibility": (
                        visibility
                        if _VISIBILITY_PRIORITY[visibility]
                        > _VISIBILITY_PRIORITY[existing.visibility]
                        else existing.visibility
                    ),
                    "relation": relation or existing.relation,
                    "description": description or existing.description,
                    "metadata": merged_metadata,
                }
            )
            self.all_clues[existing_id] = merged
            return merged

        clue_id = _stable_id("clue", *key)
        clue = GraphClue(
            id=clue_id,
            stage=stage,
            method=method,
            from_id=from_id,
            to_id=to_id,
            confidence=_confidence(confidence),
            hop=max(0, int(hop)),
            visibility=visibility,
            relation=relation,
            description=description,
            metadata=_portable(dict(metadata or {})),
        )
        self._clue_keys[key] = clue_id
        self.all_clues[clue_id] = clue
        self.incoming.setdefault(to_id, []).append(clue_id)
        return clue

    def add_clue(self, **kwargs: Any) -> GraphClue:
        """Alias retained for callers migrating from the historical Tracker API."""

        return self.add_edge(**kwargs)

    def snapshot(self) -> RouteTraceSnapshot:
        return RouteTraceSnapshot(
            nodes=MappingProxyType(dict(self.all_nodes)),
            clues=MappingProxyType(dict(self.all_clues)),
            incoming=MappingProxyType(
                {node_id: tuple(clue_ids) for node_id, clue_ids in self.incoming.items()}
            ),
        )

    def build_answer_graph(self, target_ids: list[str]) -> SearchGraph:
        """Return only nodes and clues that can reach one of the final answer targets (events or chunks)."""

        wanted_nodes: set[str] = set()
        wanted_clues: set[str] = set()
        stack = [node_id for node_id in dict.fromkeys(target_ids) if node_id in self.all_nodes]
        while stack:
            node_id = stack.pop()
            if node_id in wanted_nodes:
                continue
            wanted_nodes.add(node_id)
            for clue_id in self.incoming.get(node_id, ()):
                clue = self.all_clues[clue_id]
                wanted_clues.add(clue_id)
                if clue.from_id not in wanted_nodes:
                    stack.append(clue.from_id)
        return SearchGraph(
            nodes=tuple(self.all_nodes[node_id] for node_id in sorted(wanted_nodes)),
            clues=tuple(self.all_clues[clue_id] for clue_id in sorted(wanted_clues)),
        )


__all__ = ["RouteTraceSnapshot", "Tracker"]
