"""Built-in search algorithm catalog assembled by the engine composition root."""

from __future__ import annotations

from functools import partial
from typing import Any

from zleap.sag.core.adapters import Capability
from zleap.sag.modules.search.atomic import AtomicSearchExecutor
from zleap.sag.modules.search.executors import VectorSearchExecutor
from zleap.sag.modules.search.planning import SearchExecutionPlan
from zleap.sag.modules.search.production import ProductionSearchExecutor
from zleap.sag.modules.search.registry import SearchExecutorSpec


def builtin_executor_specs(
    *,
    session_factory: Any,
    repositories: Any | None = None,
    vector_searcher: Any | None = None,
    embedding: Any = None,
    llm: Any = None,
    rerank: Any = None,
    prompts: Any = None,
    available_capabilities: frozenset[Capability] = frozenset(),
) -> tuple[SearchExecutorSpec, ...]:
    """Create specs only for algorithms whose base runtime dependencies exist."""

    specs: list[SearchExecutorSpec] = []
    if vector_searcher is not None:
        specs.append(
            SearchExecutorSpec(
                name="vector",
                executor=VectorSearchExecutor(
                    vector_searcher,
                    repositories=repositories,
                ),
                version="2",
                supported_return_types=frozenset({"chunk"}),
                supported_ranking_methods=frozenset({"vector"}),
                supports_graph=False,
                supports_graph_output=False,
                supports_paths=False,
                required_capabilities=frozenset({Capability.VECTOR_KNN, Capability.FILTERED_KNN}),
            )
        )

    if repositories is not None and embedding is not None:
        specs.append(
            SearchExecutorSpec(
                name="atomic",
                executor=AtomicSearchExecutor(
                    repositories=repositories,
                    embedding=embedding,
                    llm=llm,
                    prompts=prompts,
                ),
                version="2",
                supported_ranking_methods=frozenset({"vector", "llm"}),
                supports_graph_output=True,
                supports_refs=True,
                supports_paths=True,
            )
        )

    if repositories is not None and embedding is not None:
        lexical_available = Capability.LEXICAL_SEARCH in available_capabilities
        specs.append(
            SearchExecutorSpec(
                name="production",
                executor=ProductionSearchExecutor(
                    repositories=repositories,
                    embedding=embedding,
                    llm=llm,
                    rerank=rerank,
                    prompts=prompts,
                ),
                version="2",
                supports_paths=True,
                capability_resolver=partial(
                    _production_capabilities,
                    lexical_available=lexical_available,
                ),
            )
        )
    return tuple(specs)


def _production_capabilities(
    plan: SearchExecutionPlan,
    *,
    lexical_available: bool,
) -> frozenset[Capability]:
    required = {Capability.VECTOR_KNN, Capability.FILTERED_KNN}
    if plan.recall.entity.enabled or plan.graph.enabled:
        required.add(Capability.GRAPH_RELATION_LOOKUP)
    if plan.ranking.method == "rerank":
        required.add(Capability.RERANK)
    # 只在拿不到 LLM 实体时才走实体名 BM25，事项 BM25 仅 rff 排序使用。
    # 与 production._recall_entities 的运行时门同构：enabled=False 直接短路。
    # 注意此处 `is not False`（None 视为开）与上方 `enabled or`（None 视为关）语义
    # 不同：后者仅决定图关系依赖，前者须与运行时门的默认值口径一致。
    entity_recall = plan.recall.entity.enabled is not False and bool(plan.recall.entity.top_k)
    lexical_entity_recall = entity_recall and plan.query.entity_extraction in {
        "disabled",
        "lexical",
    }
    # LLM 抽取可能返回空实体 → 运行时降级到实体名 BM25（production._recall_entities
    # 二选一通道）。仅当后端无词法时保守声明该依赖，交 Plan 预检查拦截/fallback；
    # 词法可用时不声明，避免封死 pgvector 上 LLM 抽到实体即可正常执行的路径。
    lexical_entity_fallback_risk = (
        entity_recall
        and plan.query.entity_extraction in {"llm", "rewrite"}
        and not lexical_available
    )
    if (
        lexical_entity_recall
        or lexical_entity_fallback_risk
        or plan.recall.event.lexical_top_k
        or plan.ranking.method == "rrf"
    ):
        required.add(Capability.LEXICAL_SEARCH)
    if (
        plan.query.rewrite
        or plan.query.entity_extraction in {"rewrite", "llm"}
        or plan.ranking.method == "llm"
        or plan.selection.enabled
    ):
        required.add(Capability.LLM_STRUCTURED_OUTPUT)
    return frozenset(required)


__all__ = ["builtin_executor_specs"]
