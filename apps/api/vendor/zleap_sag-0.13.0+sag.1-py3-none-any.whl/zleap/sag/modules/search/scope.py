"""Search scope resolution and anti-expansion validation."""

from __future__ import annotations

from typing import Any

from zleap.sag.pipeline.contracts import SearchScope
from zleap.sag.pipeline.errors import StageInputError, UnsupportedStageOptionError


async def resolve_search_scope(scope: SearchScope, resolver: Any = None) -> SearchScope:
    if not scope.creator_ids:
        return scope
    if resolver is None:
        raise UnsupportedStageOptionError(
            "creator_ids 需要宿主注入 SearchScopeResolver",
            stage="search",
            code="search_scope_resolver_required",
        )

    resolved = await resolver.resolve(scope)
    if not isinstance(resolved, SearchScope):
        raise StageInputError(
            "SearchScopeResolver 必须返回 SearchScope",
            stage="search",
            code="invalid_search_scope_resolution",
        )
    if resolved.creator_ids:
        raise StageInputError(
            "SearchScopeResolver 返回结果不能保留 creator_ids",
            stage="search",
            code="invalid_search_scope_resolution",
        )
    if not set(resolved.data_source_ids).issubset(scope.data_source_ids):
        raise StageInputError(
            "SearchScopeResolver 不能扩大 data_source_ids",
            stage="search",
            code="invalid_search_scope_resolution",
        )
    if scope.source_ids and not set(resolved.source_ids).issubset(scope.source_ids):
        raise StageInputError(
            "SearchScopeResolver 不能扩大 source_ids",
            stage="search",
            code="invalid_search_scope_resolution",
        )
    if scope.source_types and not set(resolved.source_types).issubset(scope.source_types):
        raise StageInputError(
            "SearchScopeResolver 不能扩大 source_types",
            stage="search",
            code="invalid_search_scope_resolution",
        )
    if scope.start_time and (resolved.start_time is None or resolved.start_time < scope.start_time):
        raise StageInputError(
            "SearchScopeResolver 不能扩大 start_time 范围",
            stage="search",
            code="invalid_search_scope_resolution",
        )
    if scope.end_time and (resolved.end_time is None or resolved.end_time > scope.end_time):
        raise StageInputError(
            "SearchScopeResolver 不能扩大 end_time 范围",
            stage="search",
            code="invalid_search_scope_resolution",
        )
    return resolved


__all__ = ["resolve_search_scope"]
