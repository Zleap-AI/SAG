"""Profile-driven search composition entry point."""

from __future__ import annotations

from typing import Any, ClassVar, Literal

from zleap.sag.core.adapters import Capability
from zleap.sag.modules.search.assembly import (
    CANONICAL_TIMING_STAGES,
    canonical_stats_skeleton,
)
from zleap.sag.modules.search.planning import SearchExecutionPlan, SearchPlanResolver
from zleap.sag.modules.search.registry import (
    SearchExecutorRegistry,
    SearchExecutorSpec,
    SearchProfileRegistry,
)
from zleap.sag.modules.search.scope import resolve_search_scope
from zleap.sag.pipeline.contracts import SearchRequest, SearchResult
from zleap.sag.pipeline.errors import (
    MissingSearchCapabilityError,
    SearchPlanError,
    StageInputError,
)
from zleap.sag.utils import get_logger

logger = get_logger("search.orchestrator")


class SearchOrchestrator:
    """Resolve one immutable plan and dispatch it to an engine-local executor."""

    def __init__(
        self,
        *,
        profiles: SearchProfileRegistry,
        executors: SearchExecutorRegistry,
        available_capabilities: frozenset[Capability] | None = None,
        scope_resolver: object | None = None,
        storage_mode: Literal["normal", "lite"] = "normal",
    ) -> None:
        self._profiles = profiles
        self._resolver = SearchPlanResolver(profiles)
        self._executors = executors
        self._scope_resolver = scope_resolver
        self._storage_mode = storage_mode
        if available_capabilities is not None and scope_resolver is not None:
            available_capabilities = frozenset(
                {*available_capabilities, Capability.SCOPE_RESOLUTION}
            )
        self._available_capabilities = available_capabilities

    @property
    def resolver(self) -> SearchPlanResolver:
        return self._resolver

    @property
    def executors(self) -> SearchExecutorRegistry:
        return self._executors

    async def search(self, request: SearchRequest) -> SearchResult:
        needs_scope_resolution = bool(request.scope.creator_ids)
        scope = await resolve_search_scope(request.scope, self._scope_resolver)
        if scope is not request.scope:
            request = request.model_copy(update={"scope": scope})

        plan = self._resolver.resolve(
            request.options,
            needs_scope_resolution=needs_scope_resolution,
        )
        if self._storage_mode == "lite" and plan.resolved_strategy == "vector":
            if request.options.fallback_strategy is not None:
                plan = self._resolver.resolve_fallback(
                    request.options,
                    fallback_reason="search_strategy_unavailable_in_storage_mode",
                    needs_scope_resolution=needs_scope_resolution,
                )
            if plan.resolved_strategy == "vector":
                raise StageInputError(
                    "storage_mode='lite' 不写入 chunk embedding，不能执行 vector 搜索",
                    stage="search",
                    code="search_strategy_unavailable_in_storage_mode",
                )
        plan = self._downgrade_entity_vector_recall(plan)
        try:
            plan, spec = self._prepare(plan)
        except SearchPlanError as exc:
            if request.options.fallback_strategy is None or not self._allows_fallback(exc):
                raise
            plan = self._resolver.resolve_fallback(
                request.options,
                fallback_reason=exc.code,
                needs_scope_resolution=needs_scope_resolution,
            )
            plan, spec = self._prepare(plan)
        return await self._execute_prepared(request, plan, spec)

    async def execute_plan(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
    ) -> SearchResult:
        prepared_plan, spec = self._prepare(plan)
        return await self._execute_prepared(request, prepared_plan, spec)

    def _downgrade_entity_vector_recall(
        self,
        plan: SearchExecutionPlan,
    ) -> SearchExecutionPlan:
        """lite 不写 entity.vector，实体向量召回改走实体名 BM25。"""
        if self._storage_mode != "lite":
            return plan
        if plan.recall.entity.enabled is False or not plan.recall.entity.top_k:
            return plan
        if plan.query.entity_extraction == "disabled":
            return plan
        logger.warning(
            "[搜索] storage_mode='lite' 未写入 entity.vector，策略 %r 的实体召回降级为实体名 "
            "BM25：entity_extraction=%r->'disabled'（top_k=%d 保持不变）",
            plan.resolved_strategy,
            plan.query.entity_extraction,
            plan.recall.entity.top_k,
        )
        return plan.model_copy(
            update={
                "query": plan.query.model_copy(update={"entity_extraction": "disabled"}),
                "fallback_reason": plan.fallback_reason
                or "entity_vector_recall_unavailable_in_storage_mode",
            }
        )

    def _prepare(
        self,
        plan: SearchExecutionPlan,
    ) -> tuple[SearchExecutionPlan, SearchExecutorSpec]:
        spec = self._executors.get(plan.executor)
        plan = spec.validate(plan)
        required = plan.required_capabilities | spec.capabilities_for(plan)
        self._require_capabilities(required, strategy=plan.resolved_strategy)
        if required != plan.required_capabilities:
            plan = plan.model_copy(update={"required_capabilities": required})
        return plan, spec

    async def _execute_prepared(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        spec: SearchExecutorSpec,
    ) -> SearchResult:
        result = await spec.executor.execute(request, plan)

        if plan.return_type == "event" and result.chunks:
            raise SearchPlanError(
                f"Executor {plan.executor!r} 在 return_type='event' 下返回了 chunks，"
                "违反 SearchResult 互斥契约",
                stage="search",
                code="search_result_contract_violation",
            )
        if plan.return_type == "chunk" and result.events:
            raise SearchPlanError(
                f"Executor {plan.executor!r} 在 return_type='chunk' 下返回了 events，"
                "违反 SearchResult 互斥契约",
                stage="search",
                code="search_result_contract_violation",
            )

        stats = self._normalize_stats(dict(result.stats))
        stats["strategy"] = {
            "requested": plan.requested_strategy,
            "resolved": plan.resolved_strategy,
            "executor": plan.executor,
            "executor_version": spec.version,
            "fallback_reason": plan.fallback_reason,
            "plan_fingerprint": plan.fingerprint,
        }
        return result.model_copy(update={"stats": stats})

    @staticmethod
    def _normalize_stats(stats: dict[str, Any]) -> dict[str, Any]:
        """补齐 canonical stats 骨架的缺失 key —— 宿主自定义算法没走统一层也有一致形态。

        已有 key 不覆盖；timing 保留宿主额外 key，canonical 缺的阶段补 0.0；
        骨架子 dict 与已有值类型不符（非 dict）时保留原值，不静默替换。
        """

        skeleton = canonical_stats_skeleton()
        for key, zero_value in skeleton.items():
            if key not in stats:
                stats[key] = zero_value
                continue
            if isinstance(zero_value, dict) and isinstance(stats[key], dict):
                stats[key] = {**zero_value, **stats[key]}
        timing = stats["timing"] if isinstance(stats["timing"], dict) else {}
        # canonical 阶段缺的补 0.0，宿主已有值与额外 key 全保留
        stats["timing"] = {**dict.fromkeys(CANONICAL_TIMING_STAGES, 0.0), **timing}
        return stats

    # 能力缺失 → 修复手段。门禁拦截的目的就是给出可操作的下一步,而非仅报状态。
    _CAPABILITY_REMEDIATIONS: ClassVar[dict[Capability, str]] = {
        Capability.RERANK: "配置 rerank 模型(EngineConfig.rerank / 环境变量 RERANK_MODEL)",
        Capability.LEXICAL_SEARCH: (
            "换用带词法检索的向量后端(SAG_VECTOR_PROVIDER=lancedb/elasticsearch),"
            "或改用 --entity-extraction=llm 以外的查询实体抽取方式"
        ),
    }

    def _require_capabilities(
        self,
        required: frozenset[Capability],
        *,
        strategy: str,
    ) -> None:
        if self._available_capabilities is None:
            return
        missing = sorted(
            capability.value
            for capability in required
            if capability not in self._available_capabilities
        )
        if missing:
            hints = "; ".join(
                hint
                for capability, hint in self._CAPABILITY_REMEDIATIONS.items()
                if capability.value in missing
            )
            message = f"策略 {strategy!r} 缺少能力: {', '.join(missing)}"
            if hints:
                message = f"{message}。修复: {hints}"
            raise MissingSearchCapabilityError(
                message,
                stage="search",
                code=f"missing_search_capability:{','.join(missing)}",
            )

    @staticmethod
    def _allows_fallback(exc: SearchPlanError) -> bool:
        return isinstance(exc, MissingSearchCapabilityError) or exc.code == (
            "search_executor_not_registered"
        )


__all__ = ["SearchOrchestrator"]
