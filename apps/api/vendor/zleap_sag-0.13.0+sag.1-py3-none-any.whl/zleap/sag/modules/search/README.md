# 搜索模块

## 运行时模型

搜索运行时明确分为四层：

1. `SearchProfile`：面向调用方的公开策略，保存默认参数、Profile 约束和目标 Executor 名。
2. `SearchExecutionPlan`：`SearchPlanResolver` 合并请求与 Profile 后生成的只读计划。
3. `SearchExecutorSpec`：算法注册描述，包含实现、版本、支持的返回/排序/图路径能力、额外校验和动态能力需求。
4. `SearchOrchestrator`：统一完成范围解析、Executor 查找、计划校验、能力校验、显式 fallback 和执行。

能力校验的对照面由 `DataEngine.start()` 经 `engine.py::_derive_search_capabilities`
推导：向量后端如实声明的 `capabilities` + 配置事实（`RERANK` 仅在
`EngineConfig.rerank` 已配置时声明）。因此未配置 rerank 的部署上 rerank 系策略在
Plan 阶段即被拒（结构化 `MissingSearchCapabilityError`，声明 `fallback_strategy`
则降级）；无词法后端（pgvector/OceanBase）上，LLM 实体抽取开实体召回的 plan 因
运行时可能降级到实体名 BM25 而被保守拒绝（同样可 fallback）。

`BuiltinSearchAdapter` 只是 Pipeline Port 的薄适配器，不创建算法，也不接收
Embedding、LLM、Rerank 或 PromptManager。所有内置算法由 `DataEngine.start()`
在组合根创建并注册，注册表随后冻结，请求期间不允许修改路由。

```text
SearchRequest
    -> ProfileRegistry
    -> SearchPlanResolver
    -> SearchExecutorRegistry[SearchExecutorSpec]
    -> SearchOrchestrator
    -> Executor.execute(request, plan)
```

## 内置注册

| Executor | Profile | 状态 | 输出能力 |
|---|---|---|---|
| `vector` | `vector` | 独立 Vector Executor | REFS, STAGE_STATS |
| `atomic` | `atomic` | 独立 Atomic Executor | GRAPH, PATHS, REFS, STAGE_STATS |
| `production` | `full_expand` / `pruned_expand_llm` / `pruned_expand_rerank` / `pruned_expand_rff` | 生产 ProductionSearchExecutor | 全部 |

组合根直接把具体 Searcher 注入对应 Executor。不存在第二套策略分发器，也不通过
私有字段发现算法。Pipeline Adapter 只依赖 Orchestrator。

## 统一返回形态（canonical shape）

所有内置 Executor 产出同构的 `SearchResult`，装配逻辑收敛在
`modules/search/assembly.py`（`ResultHydrator` + `SearchResultBuilder`）。
调用方不需要知道策略名就能读取：

- `stats` 六个 key 恒存在：`recall` / `ranking` / `graph` / `result` / `timing` / `prompts`
  （`strategy` 由 orchestrator 注入）。`timing` 的六个 key 固定
  （`query`/`recall`/`graph`/`ranking`/`hydrate`/`total`），未经历的阶段补 `0.0`
  —— `0.0` 表示"该策略没有这个阶段"，不是"耗时为零"。
- chunk hit 的 `metadata` 语义固定：事项派生为 `{"event_ids": [...]}`，
  直接向量命中/兜底补齐为 `{"recall_channel": "<通道名>"}`。
- `graph` 恒为 `SearchGraph | None`；`atomic` 与 production 系策略均通过
  `GraphCollector` 产出规范图谱与路径，未请求图谱时为 `None`。
- 输出类选项（图谱/路径/关联/阶段统计）的处理：`atomic` 与 production 系策略产出
  完整图谱字段；对 `vector` 请求这些选项时**剥离并记 warning 日志**，
  不报错——这属于"该策略没有这个阶段"，`stats` 里对应字段仍是规范零值形态。
  return_type / ranking.method / 图扩展（`graph.enabled`）等非输出类选项
  不支持时仍显式报 `unsupported_search_executor_plan`。输出能力沿用布尔声明：
  `supports_graph_output`（return_graph）/ `supports_paths`（return_paths）/
  `supports_refs`（include_chunk / include_event）；`include_stage_stats`
  无需声明，纯 stats 增强所有执行器容忍。

宿主自定义 executor 未走统一层时，orchestrator 收口处会补齐缺失的
canonical key（已有 key 不覆盖）。profile policy 允许的输出能力若超出目标
spec 声明，`engine.start()` 期的交叉校验直接失败（防漂移）。

新算法接入只需产出「排序后的 id + 分数 + 召回通道记账」，用
`SearchResultBuilder` 的 `stage()` / `record_channel()` / `set_ranking()`
记账后 `build()`，规范形态免费拿到；走 repositories 的 hydrator 方法必须包在
`set_search_scope` 上下文内调用。

## 生产图谱收集

`ProductionSearchExecutor` 的图谱收集（节点/边构建、hydration、反向路径推理）收敛在
`GraphCollector`（`modules/search/graph.py`）内，算法侧只调用 `record_*` 记录接口和
一次 `build`。图谱可整体旁路：`SearchOutputOptions(return_graph=False)` 时
`GraphCollector` 不建 `Tracker`、不记录任何节点/边、不做路径分析，算法本体零改动、
零额外开销。

`return_type="chunk"` 时图谱以返回的 chunk 为最终答案节点锚定：为每个返回 chunk 注册
`type="chunk"` 节点；由事项派生（`_hydrate_chunks` 返回，metadata.event_ids 非空）的
chunk 连 `event→chunk` 边，无事项的兜底 chunk（`query_chunk_fallback`）连 `query→chunk`
边；关联事项均不在图中（端点未注册/陈旧引用）时同样回退连 `query→chunk`，保证 chunk
不孤立、可被反向推理命中。反向推理从 chunk 出发，经 event→entity→query 回溯；`return_paths=True` 时的
`PathAnalysisResult` 中的最短、最长和候选路径均以 `chunk_id` 为键。
`GraphNode.type` 新增 `"chunk"` 枚举值，`GraphNode.chunk_id` 携带 chunk 标识。

## 宿主扩展

算法注册必须发生在 `DataEngine.start()` 之前。替换已有生产实现：

```python
from zleap.sag.modules.search import SearchExecutorSpec

engine.register_search_algorithm(
    SearchExecutorSpec(
        name="production",
        executor=HostProductionExecutor(),
        version="host-1",
        supports_paths=True,
    ),
    replace=True,
)
await engine.start()
```

新增公开策略时，在同一次 `register_search_algorithm(..., profiles=(profile,))`
调用中同时提交 Executor Spec 与一个或多个 `SearchProfile`。启动时会校验所有
Profile 都能解析到已注册 Executor，再冻结两个注册表。

注册只接受完整 `SearchExecutorSpec`，避免算法实现与能力声明分两处维护。

## 排序候选调试输出

设置 `SearchOutputOptions(include_ranked_candidates=True)` 后，
`SearchResult.stats["ranked_candidates"]` 返回排序完成、最终 `top_k` 截断前的
前 20 条候选（不足 20 条时返回实际数量）。默认关闭，不增加该字段或候选详情查询；
原有 `stats.recall.<channel>.candidate_count` 和最终搜索结果保持不变。

每条记录包含 `rank`、`id`、`candidate_type`、`chunk_id`、`heading`、`score`
和 `recall_channels`；事项候选还包含 `title`。事项按排序器给出的顺序保留，
不按 chunk 去重，即使 `return_type="chunk"` 也可通过 `chunk_id` 对照最终结果。
只给名次的 LLM 排序结果的 `score` 为 `null`，缺失的 chunk 信息也为 `null`。

此快照已经过粗排候选限制、LLM 挑选或 rerank 阈值过滤，且最多展示 20 条，
因此未出现在快照中不能直接推断为未召回。快照不包含后续 chunk 补齐结果。
向量策略返回其现有检索窗口内的排序 chunk，最多 20 条；开启开关不会扩大检索窗口。
