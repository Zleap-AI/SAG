"""Shared assembly layer producing the canonical SearchResult shape.

所有内置策略共用这里的装配逻辑：执行器只需产出「排序后的 id + 分数 + 召回通道记账」，
规范形态（SearchHit 字段语义、stats 骨架、顶层字段填充规则）由本模块保证。
"""

from __future__ import annotations

import time
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from typing import Any, cast

from pydantic import JsonValue

from zleap.sag.modules.search._util import _record_id
from zleap.sag.modules.search.graph import GraphCollector
from zleap.sag.modules.search.planning import SearchExecutionPlan
from zleap.sag.pipeline.contracts import (
    SearchChunkRef,
    SearchEventRef,
    SearchGraph,
    SearchHit,
    SearchRequest,
    SearchResult,
)
from zleap.sag.utils import get_logger

logger = get_logger("search.assembly")

CANONICAL_TIMING_STAGES: tuple[str, ...] = (
    "query",
    "recall",
    "graph",
    "ranking",
    "hydrate",
    "total",
)


def canonical_stats_skeleton() -> dict[str, Any]:
    """规范 stats 骨架的零值形态；未经历的阶段值为 0.0 / 0 / 空。"""

    return {
        "recall": {},
        "ranking": {"method": None, "fallback_reason": None},
        "graph": {"enabled": False, "node_count": 0, "clue_count": 0},
        "result": {"event_count": 0, "chunk_count": 0},
        "timing": dict.fromkeys(CANONICAL_TIMING_STAGES, 0.0),
        "prompts": {},
    }


class ResultHydrator:
    """把 id / 原始数据行转成规范 ``SearchHit``，不持有任何执行状态。

    注意：所有走 repositories 的方法都必须在 ``set_search_scope`` 上下文内调用，
    否则仓储查询会漏掉 scope 过滤。本层不接管作用域生命周期，由 executor 自己包。
    """

    def __init__(self, repositories: Any) -> None:
        self.repositories = repositories

    @staticmethod
    def _chunk_metadata(row: Mapping[str, Any], **base: JsonValue) -> dict[str, JsonValue]:
        metadata = dict(base)
        if row.get("chunk_type") is not None:
            metadata["chunk_type"] = cast(JsonValue, row.get("chunk_type"))
        if row.get("references") is not None:
            metadata["references"] = cast(JsonValue, row.get("references"))
        extra_data = row.get("extra_data")
        if isinstance(extra_data, Mapping):
            for key in ("record_group_id", "table_index", "cell_range", "sheet_name"):
                if extra_data.get(key) is not None:
                    metadata[key] = cast(JsonValue, extra_data[key])
        return metadata

    async def events(
        self,
        event_ids: list[str],
        scores: Mapping[str, float],
        *,
        components: Mapping[str, Mapping[str, float]] | None = None,
    ) -> tuple[SearchHit, ...]:
        rows = await self.repositories.events.get_events_by_ids(event_ids)
        record_map = {
            event_id: row for row in rows if (event_id := _record_id(row, "event_id")) is not None
        }
        score_components = components or {}
        return tuple(
            SearchHit(
                id=event_id,
                source_id=str(record_map[event_id]["source_id"])
                if record_map[event_id].get("source_id") is not None
                else None,
                data_source_id=str(record_map[event_id]["data_source_id"])
                if record_map[event_id].get("data_source_id") is not None
                else None,
                score=scores.get(event_id),
                title=str(record_map[event_id].get("title") or "") or None,
                content=str(
                    record_map[event_id].get("content") or record_map[event_id].get("summary") or ""
                ),
                metadata={"scores": cast(JsonValue, dict(score_components.get(event_id, {})))},
                chunk_id=str(record_map[event_id].get("chunk_id") or "") or None,
            )
            for event_id in event_ids
            if event_id in record_map
        )

    async def chunks_from_events(
        self,
        event_ids: list[str],
        scores: Mapping[str, float],
    ) -> tuple[SearchHit, ...]:
        event_rows = await self.repositories.events.get_events_by_ids(
            event_ids,
            source_includes=["chunk_id", "source_id", "data_source_id"],
        )
        event_map = {
            event_id: row
            for row in event_rows
            if (event_id := _record_id(row, "event_id")) is not None
        }
        chunk_to_events: dict[str, list[str]] = {}
        without_chunk: list[str] = []
        for event_id in event_ids:
            chunk_id = event_map.get(event_id, {}).get("chunk_id")
            if chunk_id:
                chunk_to_events.setdefault(str(chunk_id), []).append(event_id)
            else:
                without_chunk.append(event_id)
        chunks = await self.repositories.source_chunks.get_chunks_by_ids(
            list(chunk_to_events),
            include_vectors=False,
        )
        chunk_map = {
            chunk_id: row for row in chunks if (chunk_id := _record_id(row, "chunk_id")) is not None
        }
        hits: list[SearchHit] = []
        for chunk_id, linked_events in chunk_to_events.items():
            row = chunk_map.get(chunk_id)
            if row is None:
                continue
            # 名次挑选契约下 scores 为空，全 0 平手时 max 取首个（即 LLM 名次最高的事项）。
            best_event = max(linked_events, key=lambda event_id: scores.get(event_id, 0.0))
            hits.append(
                SearchHit(
                    id=chunk_id,
                    source_id=str(row["source_id"]) if row.get("source_id") is not None else None,
                    data_source_id=str(row["data_source_id"])
                    if row.get("data_source_id") is not None
                    else None,
                    score=scores.get(best_event),
                    title=str(row.get("heading") or "") or None,
                    content=str(row.get("content") or ""),
                    metadata=self._chunk_metadata(row, event_ids=cast(JsonValue, linked_events)),
                )
            )
        logger.info(
            "[ASSEMBLY][事项转Chunk] 事项=%d, 无chunk_id=%d%s, 唯一chunk=%d, "
            "chunk缺失=%d, 多事项共享chunk=%s, 最终chunk=%d",
            len(event_ids),
            len(without_chunk),
            f"({without_chunk[:5]})" if without_chunk else "",
            len(chunk_to_events),
            len(chunk_to_events) - len(chunk_map),
            {
                chunk_id: len(linked)
                for chunk_id, linked in chunk_to_events.items()
                if len(linked) > 1
            }
            or "-",
            len(hits),
        )
        # 有分数（打分契约 / fallback）按分数降序；无分数（名次挑选契约）保持
        # event_ids 名次顺序，不退化成按 chunk id 字母序。
        if any(hit.score is not None for hit in hits):
            return tuple(sorted(hits, key=lambda hit: (-(hit.score or 0.0), hit.id)))
        return tuple(hits)

    @staticmethod
    def chunks_from_rows(
        rows: Sequence[Mapping[str, Any]],
        *,
        recall_channel: str,
    ) -> tuple[SearchHit, ...]:
        """直接向量命中的 chunk 行转规范 hit（vector 召回与 production 兜底共用）。"""

        hits: list[SearchHit] = []
        for row in rows:
            chunk_id = _record_id(row, "chunk_id")
            if not chunk_id:
                continue
            hits.append(
                SearchHit(
                    id=chunk_id,
                    source_id=str(row["source_id"]) if row.get("source_id") is not None else None,
                    data_source_id=str(row["data_source_id"])
                    if row.get("data_source_id") is not None
                    else None,
                    score=float(row.get("score", 0.0)),
                    title=str(row.get("heading") or "") or None,
                    content=str(row.get("content") or ""),
                    metadata=ResultHydrator._chunk_metadata(row, recall_channel=recall_channel),
                )
            )
        return tuple(hits)

    async def chunk_refs_by_event(
        self, chunk_id_by_event: Mapping[str, str]
    ) -> dict[str, tuple[SearchChunkRef, ...]]:
        if not chunk_id_by_event:
            return {}
        chunk_rows = await self.repositories.source_chunks.get_chunks_by_ids(
            list(dict.fromkeys(chunk_id_by_event.values())),
            include_vectors=False,
        )
        chunk_map = {
            str(row["chunk_id"]): row for row in chunk_rows if row.get("chunk_id") is not None
        }
        return {
            eid: (
                SearchChunkRef(
                    chunk_id=cid,
                    heading=str(chunk_map[cid].get("heading") or ""),
                    content=str(chunk_map[cid].get("content") or ""),
                ),
            )
            for eid, cid in chunk_id_by_event.items()
            if cid in chunk_map
        }

    async def event_refs_by_chunk(
        self, chunk_ids: list[str]
    ) -> dict[str, tuple[SearchEventRef, ...]]:
        if not chunk_ids:
            return {}
        event_rows = await self.repositories.events.get_events_by_chunk_ids(
            chunk_ids,
            source_includes=["title", "summary", "content"],
        )
        grouped: dict[str, list[SearchEventRef]] = {}
        for row in event_rows:
            grouped.setdefault(str(row["chunk_id"]), []).append(
                SearchEventRef(
                    event_id=str(row["event_id"]),
                    title=str(row.get("title") or ""),
                    summary=str(row.get("summary") or ""),
                    content=str(row.get("content") or ""),
                )
            )
        return {cid: tuple(refs) for cid, refs in grouped.items()}

    async def attach_refs(
        self,
        *,
        events: tuple[SearchHit, ...],
        chunks: tuple[SearchHit, ...],
        plan: SearchExecutionPlan,
    ) -> tuple[tuple[SearchHit, ...], tuple[SearchHit, ...]]:
        """按 ``include_chunk`` / ``include_event`` 给 hit 挂上反向关联。"""

        if plan.output.include_event and chunks:
            refs_by_chunk = await self.event_refs_by_chunk([hit.id for hit in chunks])
            chunks = tuple(
                hit.model_copy(update={"event": refs_by_chunk.get(hit.id, ())}) for hit in chunks
            )
        if plan.output.include_chunk and events:
            chunk_id_by_event = {hit.id: hit.chunk_id for hit in events if hit.chunk_id}
            refs_by_event = await self.chunk_refs_by_event(chunk_id_by_event)
            events = tuple(
                hit.model_copy(update={"chunk": refs_by_event.get(hit.id, ())}) for hit in events
            )
        return events, chunks


class SearchResultBuilder:
    """累积执行过程中的记账，产出规范 ``SearchResult``。

    执行器只需要：用 :meth:`stage` 计时、用 :meth:`record_channel` 记召回通道、
    用 :meth:`set_ranking` 声明排序结果，剩下的形态由 :meth:`build` 保证。
    """

    def __init__(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        *,
        hydrator: ResultHydrator | None = None,
        graph: GraphCollector | None = None,
    ) -> None:
        self._request = request
        self._plan = plan
        self._hydrator = hydrator
        self._graph = graph
        self._started = time.perf_counter()
        self.recall_channels: dict[str, list[str]] = {}
        self.timings: dict[str, float] = {}
        self.stage_stats: dict[str, Any] = {}
        self._ranking: dict[str, Any] = {}
        self._rewritten_query: str | None = None
        self._pool_stats: Mapping[str, Any] | None = None
        self._ranked_candidates: list[dict[str, Any]] = []

    async def record_ranked_events(
        self, event_ids: Sequence[str], scores: Mapping[str, float]
    ) -> None:
        """Snapshot ranker output before final top_k; never rerank or backfill it."""
        if not self._plan.output.include_ranked_candidates:
            return
        ids = list(event_ids[:20])
        if not ids:
            return
        assert self._hydrator is not None
        rows = await self._hydrator.repositories.events.get_events_by_ids(
            ids, source_includes=["chunk_id", "title"]
        )
        records = {event_id: row for row in rows if (event_id := _record_id(row, "event_id"))}
        chunk_ids = list(
            dict.fromkeys(str(row["chunk_id"]) for row in records.values() if row.get("chunk_id"))
        )
        chunks = (
            await self._hydrator.repositories.source_chunks.get_chunks_by_ids(
                chunk_ids, include_vectors=False
            )
            if chunk_ids
            else []
        )
        headings = {
            str(row["chunk_id"]): row.get("heading") for row in chunks if row.get("chunk_id")
        }
        self._ranked_candidates = []
        for rank, event_id in enumerate(ids, 1):
            row = records.get(event_id, {})
            chunk_id = str(row["chunk_id"]) if row.get("chunk_id") else None
            self._ranked_candidates.append(
                {
                    "rank": rank,
                    "id": event_id,
                    "candidate_type": "event",
                    "chunk_id": chunk_id,
                    "title": row.get("title"),
                    "heading": headings.get(chunk_id) if chunk_id is not None else None,
                    "score": scores.get(event_id),
                    "recall_channels": [
                        name
                        for name, channel_ids in self.recall_channels.items()
                        if event_id in channel_ids
                    ],
                }
            )

    def record_ranked_chunks(self, chunks: Sequence[SearchHit]) -> None:
        if not self._plan.output.include_ranked_candidates:
            return
        self._ranked_candidates = [
            {
                "rank": rank,
                "id": hit.id,
                "candidate_type": "chunk",
                "chunk_id": hit.id,
                "heading": hit.title,
                "score": hit.score,
                "recall_channels": [
                    name for name, ids in self.recall_channels.items() if hit.id in ids
                ],
            }
            for rank, hit in enumerate(chunks[:20], 1)
        ]

    @contextmanager
    def stage(self, name: str) -> Iterator[None]:
        """计时上下文，写入 canonical timing key。"""

        started = time.perf_counter()
        try:
            yield
        finally:
            self.timings[name] = round(time.perf_counter() - started, 6)

    def record_channel(self, name: str, ids: Sequence[str]) -> None:
        self.recall_channels[name] = list(ids)

    def set_ranking(self, **stats: Any) -> None:
        self._ranking = dict(stats)

    def set_rewritten_query(self, query: str | None) -> None:
        self._rewritten_query = query

    def record_prompt(self, name: str, version: str) -> None:
        self.stage_stats.setdefault("prompts", {})[name] = version

    def set_pool_stats(self, stats: Mapping[str, Any] | None) -> None:
        self._pool_stats = stats

    async def build(
        self,
        *,
        events: tuple[SearchHit, ...] = (),
        chunks: tuple[SearchHit, ...] = (),
        final_event_ids: list[str] | None = None,
        final_chunk_ids: list[str] | None = None,
    ) -> SearchResult:
        plan = self._plan
        if self._hydrator is not None:
            events, chunks = await self._hydrator.attach_refs(
                events=events,
                chunks=chunks,
                plan=plan,
            )
        graph: SearchGraph | None = None
        path_result = None
        if self._graph is not None and plan.output.return_graph:
            out = await self._graph.build(
                final_event_ids=final_event_ids or [],
                final_chunk_ids=(
                    (final_chunk_ids if final_chunk_ids is not None else [hit.id for hit in chunks])
                    if plan.return_type == "chunk"
                    else None
                ),
                data_source_ids=list(self._request.scope.data_source_ids),
                return_paths=plan.output.return_paths,
                return_type=plan.return_type,
                max_hops=plan.graph.max_hops,
            )
            graph, path_result = out.graph, out.path_result
        self.timings["total"] = round(time.perf_counter() - self._started, 6)

        stats: dict[str, Any] = {
            "recall": {
                channel: {"candidate_count": len(ids)}
                for channel, ids in self.recall_channels.items()
            },
            "ranking": self._ranking,
            "graph": {
                "enabled": bool(plan.graph.enabled),
                "node_count": len(graph.nodes) if graph else 0,
                "clue_count": len(graph.clues) if graph else 0,
            },
            "result": {"event_count": len(events), "chunk_count": len(chunks)},
            "timing": {stage: self.timings.get(stage, 0.0) for stage in CANONICAL_TIMING_STAGES},
            "prompts": self.stage_stats.get("prompts", {}),
        }
        stats["ranking"].setdefault("method", plan.ranking.method)
        stats["ranking"].setdefault("fallback_reason", None)
        if plan.output.include_ranked_candidates:
            stats["ranked_candidates"] = self._ranked_candidates
        if self._pool_stats is not None:
            stats["recall"]["candidate_pool"] = self._pool_stats
        if "query" in self.stage_stats:
            stats["query"] = self.stage_stats["query"]
        if path_result is not None:
            stats["path_analysis"] = path_result.stats
        if plan.output.include_stage_stats:
            stats["stages"] = self.stage_stats

        return SearchResult(
            query=self._rewritten_query or self._request.query,
            original_query=self._request.query,
            rewritten_query=self._rewritten_query,
            events=events,
            chunks=chunks,
            graph=graph,
            paths=path_result,
            stats=stats,
        )


__all__ = [
    "CANONICAL_TIMING_STAGES",
    "ResultHydrator",
    "SearchResultBuilder",
    "canonical_stats_skeleton",
]
