"""
搜索模块配置

支持两种搜索策略：
- VECTOR: 纯向量搜索
- ATOMIC: 原子事项检索
"""

from typing import Literal

from pydantic import Field

from zleap.sag.models.base import pipelineBaseModel


class VectorConfig(pipelineBaseModel):
    """
    向量检索器配置

    独立于三阶段搜索，直接使用 Query 向量检索 Event/Chunk，
    支持 title/heading 和 content 向量的混合搜索。

    示例：
        config = VectorConfig(
            return_type="event",
            top_k=20,
            title_weight=0.3,
            content_weight=0.7,
            similarity_threshold=0.4
        )
    """

    # 返回数量
    top_k: int = Field(default=20, ge=1, le=1000, description="最终返回的最大数量")

    # 返回类型
    return_type: Literal["chunk", "event"] = Field(
        default="event", description="返回类型：chunk=段落(SourceChunk)，event=事项(SourceEvent)"
    )

    # 向量权重（需满足 title_weight + content_weight = 1.0）
    title_weight: float = Field(
        default=0.3,
        ge=0.0,
        le=1.0,
        description="标题向量权重（事件用 title_vector，段落用 heading_vector）",
    )

    content_weight: float = Field(
        default=0.7, ge=0.0, le=1.0, description="内容向量权重（content_vector）"
    )

    # 相似度阈值（直接用作召回）
    similarity_threshold: float = Field(
        default=0.4, ge=0.0, le=1.0, description="相似度阈值，低于此分数的结果会被过滤"
    )


__all__ = [
    "VectorConfig",
]
