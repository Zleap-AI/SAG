"""Production search variant: owns its own execute() with production-specific orchestration."""

from __future__ import annotations

import asyncio
import math
import time
from typing import Any

from zleap.sag.modules.search._util import _naive_utc, _physical_source_types, _record_id
from zleap.sag.modules.search.assembly import SearchResultBuilder
from zleap.sag.modules.search.base import (
    _EXPAND_RELATION_FANOUT,
    BaseGraphSearchExecutor,
    _elapsed,
    _finite_score,
    _InvalidModelOutput,
    _SearchExecutionState,
    _sort_scores,
)
from zleap.sag.modules.search.graph import GraphCollector
from zleap.sag.modules.search.planning import SearchExecutionPlan
from zleap.sag.modules.search.pool import PooledCandidateSource, VectorCandidateSource
from zleap.sag.pipeline.contracts import SearchHit, SearchRequest, SearchResult
from zleap.sag.pipeline.errors import StageInputError
from zleap.sag.utils import get_logger

logger = get_logger("search.production")


class ProductionSearchExecutor(BaseGraphSearchExecutor):
    """生产变体：拥有独立的 execute() 编排，并持有向量图扩展与 rerank 实现。

    每个 hook 方法对应一条 production 行为特征，含义见 ``base.py`` 中同名 hook 的文档。
    """

    # --- 图扩展钩子实现（向量路） ---

    async def _expand_entities_for_hop(
        self,
        frontier: list[str],
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        """向量关系索引：关系行带相似度分，可按阈值剪枝、按配额截断。

        Args:
            frontier: 本跳起始事项的 event_id 有序列表。
        """
        # 用 query embedding 对关系向量索引打分，取配额的 _EXPAND_RELATION_FANOUT 倍：
        # 同一实体可能挂在多个 seed 事项上，多取后去重才能凑够 entities_per_hop 个新实体。
        relation_rows = await self.repositories.event_entities.score_relations_by_event_ids(
            state.query_embedding,
            frontier,
            data_source_ids=list(request.scope.data_source_ids),
            exclude_entity_ids=list(state.seen_entity_ids),
            size=(plan.graph.entities_per_hop or 20) * _EXPAND_RELATION_FANOUT,
        )
        # 第一层剪枝：丢弃相似度低于阈值的关系行，避免沿弱相关路径扩展。
        relation_threshold = plan.graph.relation_threshold
        selected_relations = [
            row
            for row in relation_rows
            if relation_threshold is None or float(row.get("score", 0.0)) >= relation_threshold
        ]
        # 第二层截断：从通过阈值的关系行中提取 entity_id，去重后截取 entities_per_hop 个。
        # seen_entity_ids 在此作为去重屏障，已在之前跳处理过的实体不重复进入。
        entity_ids = list(
            dict.fromkeys(
                entity_id
                for row in selected_relations
                if (entity_id := _record_id(row, "entity_id")) is not None
                and entity_id not in state.seen_entity_ids
            )
        )[: plan.graph.entities_per_hop]
        return selected_relations, entity_ids

    async def _expand_events_for_hop(
        self,
        entity_ids: list[str],
        total_event_limit: int,
        request: SearchRequest,
        plan: SearchExecutionPlan,
        state: _SearchExecutionState,
    ) -> list[dict[str, Any]]:
        """向量候选池：按 per-entity 配额取回候选事项关系行。

        Args:
            entity_ids: 本跳通过 ``_expand_entities_for_hop`` 扩展出的新实体 id 列表。
            total_event_limit: 本跳事项关系行总数上限，均摊到每个实体得到 per_entity_limit。

        Returns:
            每条关系行包含 ``event_id``、``entity_id``、``score``、``description``、
            ``data_source_id`` 字段，供 ``_expand_graph`` 打分、过滤并写入检索图扩展边。
        """
        assert state.candidates is not None
        # 将总配额均摊到每个实体，避免实体多时单个实体垄断配额。
        per_entity_limit = max(1, math.ceil(total_event_limit / len(entity_ids)))
        # state.candidates 由 execute() 按 pool_size 决定：
        #   pool_size > 0 → PooledCandidateSource，从内存倒排索引读取（pool.py:211）
        #   pool_size == 0 → VectorCandidateSource，走向量库实时查询（pool.py:90）
        return await state.candidates.events_for_keys(
            entity_ids,
            per_entity_limit=per_entity_limit,
            exclude_event_ids=list(state.seen_event_ids),
        )

    # --- execute() ---

    async def execute(
        self,
        request: SearchRequest,
        plan: SearchExecutionPlan,
    ) -> SearchResult:
        """production 完整搜索编排：NER 实体抽取 → 向量召回 → 向量图扩展 → LLM/rerank 精排 → 水合。

        production 的核心特征（与 atomic 的主要差异）：
        - 查询理解 strict=False：NER 抽取失败时降级为直连向量召回，不报错。
        - 候选源按 pool_size 选择：pool_size > 0 → PooledCandidateSource（内存倒排），
          pool_size == 0 → VectorCandidateSource（实时向量查询）；向量字段用 content。
        - 实体路由召回走向量候选池（use_relational=False），按 entity_event 向量阈值过滤。
        - entity_lexical_fallback=True：NER 无实体时允许降级到整句 BM25 实体召回。
        - 图扩展走向量关系索引（_expand_entities_for_hop 带相似度分和阈值剪枝）。
        - 排序不重做向量打分（rescore_candidates=False）；prompt 由 plan 指定；
          llm_text_fields=title_content；strict_llm_rank_empty=True（空结果视为错误）。
        """
        from zleap.sag.core.storage.repositories.search_scope import (
            RepositorySearchScope,
            reset_search_scope,
            set_search_scope,
        )

        # 初始化执行状态、检索图记录器和结果构建器，三者共享 recall_channels / timings / stage_stats。
        state = _SearchExecutionState()
        state.graph = GraphCollector(
            enabled=plan.output.return_graph,
            entities=self.repositories.entities,
            events=self.repositories.events,
            max_paths_per_event=plan.output.max_paths_per_event,
        )
        builder = SearchResultBuilder(
            request,
            plan,
            hydrator=self._hydrator,
            graph=state.graph,
        )
        state.recall_channels = builder.recall_channels
        state.timings = builder.timings
        state.stage_stats = builder.stage_stats
        logger.info(
            "[PRODUCTION] 开始搜索: strategy=%s, query_chars=%d, top_k=%d, "
            "return_type=%s, data_sources=%d, sources=%d",
            request.options.strategy,
            len(request.query),
            plan.top_k,
            plan.return_type,
            len(request.scope.data_source_ids),
            len(request.scope.source_ids),
        )
        # 将请求 scope 写入 contextvars，供关系表查询的 apply_source_event_scope 读取。
        scope_token = set_search_scope(
            RepositorySearchScope(
                data_source_ids=request.scope.data_source_ids,
                source_ids=request.scope.source_ids,
                source_types=_physical_source_types(tuple(request.scope.source_types)),
                start_time=_naive_utc(request.scope.start_time),
                end_time=_naive_utc(request.scope.end_time),
            )
        )
        try:
            # --- Stage 1: 查询处理 ---
            # strict=False：NER 结构化输出无效时降级为仅直连向量召回，不中断请求。
            query_started = time.perf_counter()
            await self._process_query(request, plan, state, strict_query_understanding=False)
            # 用重写后的查询（若有）生成向量，作为后续召回和图扩展的 query embedding。
            state.query_embedding = await self.embedding.generate(
                state.rewritten_query or request.query
            )
            if not state.query_embedding or not all(
                math.isfinite(float(v)) for v in state.query_embedding
            ):
                raise StageInputError(
                    "Query embedding 为空或包含非法数值",
                    stage="search",
                    code="invalid_query_embedding",
                )
            state.timings["query"] = _elapsed(query_started)
            logger.info(
                "[PRODUCTION][查询处理] rewritten=%s, entity_extraction=%s, entities=%d, "
                "embedding_dimensions=%d, elapsed=%.3fs",
                state.rewritten_query is not None,
                plan.query.entity_extraction,
                len(state.rewritten_entities),
                len(state.query_embedding),
                state.timings["query"],
            )

            # 候选源按配置选择：
            #   pool_size > 0 → PooledCandidateSource，一次性向量查询后建内存倒排索引，
            #                    适合后续多次 events_for_keys 调用（图扩展多跳场景）；
            #   pool_size == 0 → VectorCandidateSource，每次调用都实时查向量库；
            # 两者向量字段均用 content（atomic 用 title）。
            pool_size = plan.recall.candidate_pool_size
            candidate_kwargs: dict[str, Any] = {
                "repositories": self.repositories,
                "query_embedding": state.query_embedding,
                "data_source_ids": list(request.scope.data_source_ids),
                "start_time": _naive_utc(request.scope.start_time),
                "end_time": _naive_utc(request.scope.end_time),
                "vector_field": "content",
            }
            state.candidates = (
                PooledCandidateSource(pool_size=pool_size, **candidate_kwargs)
                if pool_size
                else VectorCandidateSource(**candidate_kwargs)
            )

            # --- Stage 2: 召回 ---
            # 两个通道并发执行：直连事项向量召回 + 实体向量召回。
            # entity_lexical_fallback=True：NER 抽不到实体时降级到整句 BM25 实体召回。
            recall_started = time.perf_counter()
            direct_task = self._recall_direct_events(request, plan, state)
            entity_task = self._recall_entities(request, plan, state, entity_lexical_fallback=True)
            direct_rows, recalled_entities = await asyncio.gather(direct_task, entity_task)
            # 将直连召回结果过滤、打分并登记到检索图。
            self._record_direct_route(direct_rows, request, plan, state)
            # 实体→事项路由：走向量候选池（use_relational=False），
            # apply_entity_event_threshold=True 按向量阈值过滤低相关事项。
            await self._recall_events_from_entities(
                recalled_entities,
                request,
                plan,
                state,
                use_relational=False,
                apply_entity_event_threshold=True,
            )
            state.timings["recall"] = _elapsed(recall_started)
            recall_counts = {
                channel: len(event_ids) for channel, event_ids in state.recall_channels.items()
            }
            logger.info(
                "[PRODUCTION][召回] channels=%s, recalled_entities=%d, unique_events=%d, "
                "elapsed=%.3fs",
                recall_counts,
                len(recalled_entities),
                len(state.seen_event_ids),
                state.timings["recall"],
            )
            if not state.seen_event_ids:
                logger.warning(
                    "[PRODUCTION][召回] 所有通道均未命中，检查 scope、索引文档及过滤阈值"
                )

            # --- Stage 3: 图扩展 ---
            # 从召回事项出发，沿向量关系索引扩展 max_hops 跳；
            # 与 atomic 不同，每跳按 relation_threshold 和 entities_per_hop 剪枝截断。
            expand_started = time.perf_counter()
            if plan.graph.enabled and plan.graph.max_hops:
                await self._expand_graph(request, plan, state)
            state.timings["graph"] = _elapsed(expand_started)
            logger.info(
                "[PRODUCTION][图扩展] enabled=%s, max_hops=%d, unique_events=%d, elapsed=%.3fs",
                plan.graph.enabled,
                plan.graph.max_hops,
                len(state.seen_event_ids),
                state.timings["graph"],
            )

            # --- Stage 4: 排序 ---
            # rescore_candidates=False：不重做向量打分，直接用召回阶段缓存的分数粗排。
            # prompt 名由 plan.ranking.llm_prompt_name 指定，默认 llm_rank_events。
            # llm_text_fields=title_content：同时传标题和内容给 LLM；
            # strict_llm_rank_empty=True：LLM 未返回有效结果时视为错误，不静默降级。
            rank_started = time.perf_counter()
            ranked_ids, ranked_scores, ranking_stats = await self._rank_events(
                request,
                plan,
                state,
                rescore_candidates=False,
                llm_prompt_name=plan.ranking.llm_prompt_name or "llm_rank_events",
                llm_text_fields="title_content",
                strict_llm_rank_empty=True,
            )
            final_event_ids = ranked_ids[: plan.top_k]
            state.timings["ranking"] = _elapsed(rank_started)
            logger.info(
                "[PRODUCTION][排序] method=%s, candidates=%d, ranked=%d, final=%d, "
                "fallback=%s, elapsed=%.3fs",
                ranking_stats.get("method"),
                len(state.seen_event_ids),
                len(ranked_ids),
                len(final_event_ids),
                ranking_stats.get("fallback_reason"),
                state.timings["ranking"],
            )

            # --- Stage 5: 结果填充 ---
            # 按 return_type 决定返回事项还是 chunk；chunk 模式下用 topped-up 补齐到 top_k。
            hydrate_started = time.perf_counter()
            await builder.record_ranked_events(ranked_ids, ranked_scores)
            if plan.return_type == "chunk":
                chunks = await self._hydrate_chunks_topped_up(
                    final_event_ids,
                    ranked_ids,
                    ranked_scores,
                    request,
                    plan,
                    state,
                )
                events: tuple[SearchHit, ...] = ()
                self._record_chunk_route(chunks, state)
            else:
                events = await self._hydrator.events(
                    final_event_ids,
                    ranked_scores,
                    components=state.event_score_components,
                )
                chunks = ()
            state.timings["hydrate"] = _elapsed(hydrate_started)

            builder.set_rewritten_query(state.rewritten_query)
            builder.set_ranking(**ranking_stats)
            builder.set_pool_stats(state.candidates.pool_stats() if state.candidates else None)
            result = await builder.build(
                events=events,
                chunks=chunks,
                final_event_ids=final_event_ids,
                final_chunk_ids=(
                    [hit.id for hit in chunks] if plan.return_type == "chunk" else None
                ),
            )
            logger.info(
                "[PRODUCTION] 搜索完成: events=%d, chunks=%d, total=%.3fs",
                len(result.events),
                len(result.chunks),
                state.timings["total"],
            )
            return result
        finally:
            reset_search_scope(scope_token)

    async def _rerank(
        self,
        query: str,
        event_ids: list[str],
        records: dict[str, dict[str, Any]],
        plan: SearchExecutionPlan,
    ) -> tuple[list[str], dict[str, float]]:
        limit = min(plan.ranking.rerank_top_n or len(event_ids), len(event_ids))
        documents = [
            {
                "id": event_id,
                "text": str(
                    records[event_id].get("content")
                    or records[event_id].get("summary")
                    or records[event_id].get("title")
                    or ""
                ),
            }
            for event_id in event_ids[:limit]
        ]
        response = await asyncio.wait_for(
            self.rerank.rerank(query, documents, top_n=limit),
            timeout=plan.ranking.timeout_seconds,
        )
        scores: dict[str, float] = {}
        for item in response:
            if not isinstance(item, dict):
                raise _InvalidModelOutput("Rerank 结果项不是对象")
            event_id = str(item.get("id") or "")
            if not event_id and item.get("index") is not None:
                try:
                    event_id = documents[int(item["index"])]["id"]
                except (IndexError, TypeError, ValueError) as exc:
                    raise _InvalidModelOutput("Rerank index 越界") from exc
            if event_id not in records:
                raise _InvalidModelOutput("Rerank 返回未知事项 ID")
            score = _finite_score(item.get("score", 0.0), label="Rerank score")
            if not 0.0 <= score <= 1.0:
                raise _InvalidModelOutput("Rerank score 超出 [0,1]")
            scores[event_id] = max(scores.get(event_id, 0.0), score)
        if not scores:
            raise _InvalidModelOutput("Rerank 未返回有效结果")
        threshold = plan.ranking.rerank_threshold
        ranked = [
            event_id
            for event_id in _sort_scores(scores)
            if threshold is None or scores[event_id] >= threshold
        ]
        return ranked, scores


__all__ = ["ProductionSearchExecutor"]
