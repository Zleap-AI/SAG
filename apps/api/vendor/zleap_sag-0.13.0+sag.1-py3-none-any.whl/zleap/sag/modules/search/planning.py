"""Resolve public search options into an immutable execution plan."""

from __future__ import annotations

import hashlib
import json
from typing import Any, Literal, TypeVar

from pydantic import ConfigDict

from zleap.sag.core.adapters import Capability
from zleap.sag.modules.search.profiles import SearchProfile
from zleap.sag.modules.search.registry import SearchProfileRegistry
from zleap.sag.pipeline.errors import SearchPlanError
from zleap.sag.pipeline.options import (
    GraphSearchOptions,
    QueryProcessingOptions,
    RankingOptions,
    RecallOptions,
    SearchOptions,
    SearchOutputOptions,
    SelectionOptions,
)
from zleap.sag.utils import get_logger
from zleap.sag.validation import SagBaseModel as BaseModel

logger = get_logger("search.planning")

OptionsT = TypeVar("OptionsT", bound=BaseModel)


class SearchExecutionPlan(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    plan_version: Literal["1.0"] = "1.0"
    requested_strategy: str
    resolved_strategy: str
    executor: str
    fallback_reason: str | None = None
    top_k: int
    return_type: Literal["event", "chunk"]
    # 请求级结构化输出模式覆盖；None 表示沿用引擎级默认（见 ModelConfig.structured_output_mode）。
    structured_output_mode: str | None = None
    query: QueryProcessingOptions
    recall: RecallOptions
    graph: GraphSearchOptions
    ranking: RankingOptions
    selection: SelectionOptions
    output: SearchOutputOptions
    required_capabilities: frozenset[Capability]

    @property
    def fingerprint(self) -> str:
        document = self.model_dump(mode="json")
        document["required_capabilities"] = sorted(
            capability.value for capability in self.required_capabilities
        )
        payload = json.dumps(
            document,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(merged.get(key), dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _merge_options(base: OptionsT, override: OptionsT) -> OptionsT:
    payload = _deep_merge(
        base.model_dump(mode="python"),
        override.model_dump(
            mode="python",
            exclude_none=True,
            exclude_unset=True,
        ),
    )
    return type(base).model_validate(payload)


class SearchPlanResolver:
    def __init__(self, profiles: SearchProfileRegistry) -> None:
        self._profiles = profiles

    def resolve(
        self,
        options: SearchOptions,
        *,
        needs_scope_resolution: bool = False,
    ) -> SearchExecutionPlan:
        requested = options.strategy
        profile = self._profiles.get(requested)
        return self._build(
            profile,
            options,
            requested_strategy=requested,
            needs_scope_resolution=needs_scope_resolution,
        )

    def resolve_fallback(
        self,
        options: SearchOptions,
        *,
        fallback_reason: str,
        needs_scope_resolution: bool = False,
    ) -> SearchExecutionPlan:
        fallback_strategy = options.fallback_strategy
        if fallback_strategy is None:
            raise SearchPlanError(
                "请求没有声明 fallback_strategy",
                stage="search",
                code="search_fallback_not_declared",
            )
        fallback = self._profiles.get(fallback_strategy)
        fallback_options = options.model_copy(
            update={"strategy": fallback_strategy, "fallback_strategy": None}
        )
        return self._build(
            fallback,
            fallback_options,
            requested_strategy=options.strategy,
            fallback_reason=fallback_reason,
            needs_scope_resolution=needs_scope_resolution,
        )

    def _build(
        self,
        profile: SearchProfile,
        options: SearchOptions,
        *,
        requested_strategy: str,
        fallback_reason: str | None = None,
        needs_scope_resolution: bool,
    ) -> SearchExecutionPlan:
        query = _merge_options(profile.query, options.query)
        recall = _merge_options(profile.recall, options.recall)

        graph_override = options.graph
        if graph_override.enabled is False and graph_override.max_hops is None:
            graph_override = graph_override.model_copy(update={"max_hops": 0})
        elif graph_override.max_hops == 0 and graph_override.enabled is None:
            graph_override = graph_override.model_copy(update={"enabled": False})
        graph = _merge_options(profile.graph, graph_override)

        ranking = _merge_options(profile.ranking, options.ranking)

        selection_override = options.selection
        # 显式关闭 selection 时，profile 声明的 rationale 随之失效——rationale 是
        # selection 的输出字段，留着会和下面的互斥校验打架（profile 开、调用方关）。
        # 与上面 graph.enabled/max_hops 的派生同形。
        if (
            selection_override.enabled is False
            and selection_override.include_selection_rationale is None
        ):
            selection_override = selection_override.model_copy(
                update={"include_selection_rationale": False}
            )
        selection = _merge_options(profile.selection, selection_override)
        output = _merge_options(profile.output, options.output)

        if graph.enabled is False and graph.max_hops != 0:
            raise SearchPlanError(
                "关闭图扩展时 resolved max_hops 必须为 0",
                stage="search",
                code="invalid_search_plan",
            )
        if graph.enabled is True and not graph.max_hops:
            raise SearchPlanError(
                "启用图扩展时 resolved max_hops 必须大于 0",
                stage="search",
                code="invalid_search_plan",
            )
        if output.return_paths and not output.return_graph:
            raise SearchPlanError(
                "return_paths=True 要求同时设置 return_graph=True",
                stage="search",
                code="invalid_search_plan",
            )
        if query.rewrite is False and query.max_rewrites not in (None, 0):
            raise SearchPlanError(
                "query.rewrite=False 时 max_rewrites 必须为 0 或省略",
                stage="search",
                code="invalid_search_plan",
            )
        if selection.enabled is False and (
            selection.custom_prompt is not None or selection.include_selection_rationale is True
        ):
            raise SearchPlanError(
                "关闭 Selection 时不能提供 custom_prompt 或返回 rationale",
                stage="search",
                code="invalid_search_plan",
            )
        if (
            recall.candidate_pool_size
            and ranking.candidate_limit is not None
            and ranking.candidate_limit > recall.candidate_pool_size
        ):
            raise SearchPlanError(
                f"ranking.candidate_limit={ranking.candidate_limit} 超过 "
                f"recall.candidate_pool_size={recall.candidate_pool_size}",
                stage="search",
                code="invalid_search_plan",
            )
        output = self._validate_profile_policy(
            profile,
            return_type=options.return_type,
            query=query,
            graph=graph,
            ranking=ranking,
            selection=selection,
            output=output,
            recall=recall,
        )

        required = set(profile.required_capabilities)
        if (
            query.rewrite
            or query.entity_extraction in {"rewrite", "llm"}
            or ranking.method == "llm"
            or selection.enabled
        ):
            required.add(Capability.LLM_STRUCTURED_OUTPUT)
        if needs_scope_resolution:
            required.add(Capability.SCOPE_RESOLUTION)

        return SearchExecutionPlan(
            requested_strategy=requested_strategy,
            resolved_strategy=str(profile.name),
            executor=str(profile.executor),
            fallback_reason=fallback_reason,
            top_k=options.top_k,
            return_type=options.return_type,
            structured_output_mode=options.structured_output_mode,
            query=query,
            recall=recall,
            graph=graph,
            ranking=ranking,
            selection=selection,
            output=output,
            required_capabilities=frozenset(required),
        )

    def _validate_profile_policy(
        self,
        profile: SearchProfile,
        *,
        return_type: str,
        query: QueryProcessingOptions,
        graph: GraphSearchOptions,
        ranking: RankingOptions,
        selection: SelectionOptions,
        output: SearchOutputOptions,
        recall: RecallOptions,
    ) -> SearchOutputOptions:
        """校验 policy；输出类选项不支持时剥离并记 warning（图谱等仅 production 支持，
        对 vector/atomic 请求这些输出属于"该策略没有这个阶段"，静默降级不报错）。
        其余类别（return_type/ranking/query/graph 扩展/selection）仍是显式报错。
        """

        policy = profile.policy
        unsupported: list[str] = []
        if return_type not in policy.allowed_return_types:
            unsupported.append(f"return_type={return_type!r}")
        if ranking.method not in policy.allowed_ranking_methods:
            unsupported.append(f"ranking.method={ranking.method!r}")
        if query.entity_extraction not in policy.allowed_entity_extraction:
            unsupported.append(f"query.entity_extraction={query.entity_extraction!r}")
        if query.rewrite and not policy.allow_query_rewrite:
            unsupported.append("query.rewrite=True")
        if query.normalization and not policy.allow_query_normalization:
            unsupported.append("query.normalization=True")
        if graph.enabled and not policy.allow_graph:
            unsupported.append("graph.enabled=True")
        if selection.enabled and not policy.allow_selection:
            unsupported.append("selection.enabled=True")
        if recall.candidate_pool_size and not policy.allow_candidate_pool:
            unsupported.append("recall.candidate_pool_size")
        if unsupported:
            raise SearchPlanError(
                f"搜索 Profile {profile.name!r} 不允许以下选项: " + ", ".join(unsupported),
                stage="search",
                code="unsupported_search_profile_plan",
            )

        ignored: list[str] = []
        if output.return_graph and not policy.allow_graph_output:
            ignored.append("return_graph")
        if output.return_paths and not policy.allow_paths:
            ignored.append("return_paths")
        if ignored:
            logger.warning(
                "[搜索] 策略 %r 不支持输出选项 %s，已忽略；仅 production 系策略返回图谱/路径",
                profile.name,
                ", ".join(ignored),
            )
            output = output.model_copy(update=dict.fromkeys(ignored, False))
        return output


__all__ = ["SearchExecutionPlan", "SearchPlanResolver"]
