"""Engine-local registries for search profiles and algorithm executors."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from dataclasses import dataclass
from dataclasses import replace as dataclass_replace
from typing import TYPE_CHECKING, Literal

from zleap.sag.core.adapters import Capability
from zleap.sag.exceptions import InvalidInputError, StateError
from zleap.sag.modules.search.ports import SearchStrategyExecutor
from zleap.sag.modules.search.profiles import SearchProfile, builtin_search_profiles
from zleap.sag.pipeline.errors import SearchPlanError, UnknownSearchStrategyError
from zleap.sag.utils import get_logger

if TYPE_CHECKING:
    from zleap.sag.modules.search.planning import SearchExecutionPlan

logger = get_logger("search.registry")

ReturnType = Literal["event", "chunk"]
RankingMethod = Literal["vector", "weighted", "rrf", "rerank", "llm"]
PlanValidator = Callable[["SearchExecutionPlan"], None]
CapabilityResolver = Callable[["SearchExecutionPlan"], frozenset[Capability]]


@dataclass(frozen=True, slots=True)
class SearchExecutorSpec:
    """One registered algorithm implementation and its execution contract."""

    name: str
    executor: SearchStrategyExecutor
    version: str = "1"
    supported_return_types: frozenset[ReturnType] = frozenset({"event", "chunk"})
    supported_ranking_methods: frozenset[RankingMethod] = frozenset(
        {"vector", "weighted", "rrf", "rerank", "llm"}
    )
    # 图扩展（graph.enabled，多跳召回）：不支持时显式报错。与输出无关。
    supports_graph: bool = True
    # 以下输出能力不支持时剥离选项 + 记 warning（仅 production 系返回完整图谱字段）：
    supports_graph_output: bool = True  # return_graph
    supports_paths: bool = False  # return_paths
    supports_refs: bool = True  # include_chunk / include_event
    # include_stage_stats 无需声明：纯 stats 增强，所有执行器容忍（不填则无 stages 键）。
    required_capabilities: frozenset[Capability] = frozenset()
    capability_resolver: CapabilityResolver | None = None
    validator: PlanValidator | None = None

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise InvalidInputError("Executor 名不能为空")
        if not self.version.strip():
            raise InvalidInputError("Executor version 不能为空")

    def validate(self, plan: SearchExecutionPlan) -> SearchExecutionPlan:
        """校验计划与本 spec 契约的一致性。

        return_type / ranking.method / 图扩展不支持时显式报错；
        输出类选项（图谱/路径/关联）不支持时剥离并记 warning——
        对 vector/atomic 请求这些输出属于"该策略没有这个阶段"，静默降级不报错。
        返回剥离后的 plan（未剥离时原样返回）。
        """

        unsupported: list[str] = []
        if plan.return_type not in self.supported_return_types:
            unsupported.append(f"return_type={plan.return_type!r}")
        if plan.ranking.method not in self.supported_ranking_methods:
            unsupported.append(f"ranking.method={plan.ranking.method!r}")
        if plan.graph.enabled and not self.supports_graph:
            unsupported.append("graph.enabled=True")
        if unsupported:
            raise SearchPlanError(
                f"搜索 Executor {self.name!r} 不支持以下执行计划: " + ", ".join(unsupported),
                stage="search",
                code="unsupported_search_executor_plan",
            )

        ignored: dict[str, bool] = {}
        if plan.output.return_graph and not self.supports_graph_output:
            ignored["return_graph"] = False
        if plan.output.return_paths and not self.supports_paths:
            ignored["return_paths"] = False
        if not self.supports_refs:
            if plan.output.include_chunk:
                ignored["include_chunk"] = False
            if plan.output.include_event:
                ignored["include_event"] = False
        if ignored:
            logger.warning(
                "[搜索] Executor %r 不支持输出选项 %s，已忽略；图谱/关联等完整输出仅 production 系策略支持",
                self.name,
                ", ".join(f"output.{option}" for option in ignored),
            )
            plan = plan.model_copy(update={"output": plan.output.model_copy(update=ignored)})
        if self.validator is not None:
            self.validator(plan)
        return plan

    def capabilities_for(self, plan: SearchExecutionPlan) -> frozenset[Capability]:
        dynamic = self.capability_resolver(plan) if self.capability_resolver else frozenset()
        return self.required_capabilities | dynamic


class SearchProfileRegistry:
    def __init__(self, profiles: Iterable[SearchProfile] = ()) -> None:
        self._profiles: dict[str, SearchProfile] = {}
        self._frozen = False
        for profile in profiles:
            self.register(profile)

    @classmethod
    def with_builtins(cls) -> SearchProfileRegistry:
        return cls(builtin_search_profiles())

    def register(self, profile: SearchProfile, *, replace: bool = False) -> None:
        if self._frozen:
            raise StateError("搜索 Profile 注册表已冻结")
        name = str(profile.name)
        if name in self._profiles and not replace:
            raise InvalidInputError(f"搜索 Profile 已注册: {name}")
        self._profiles[name] = profile

    def get(self, name: str) -> SearchProfile:
        try:
            return self._profiles[name]
        except KeyError as exc:
            choices = ", ".join(self.names())
            raise UnknownSearchStrategyError(
                f"未知搜索策略 {name!r}; 可选: {choices}",
                stage="search",
                code="unknown_search_strategy",
            ) from exc

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._profiles))

    def values(self) -> tuple[SearchProfile, ...]:
        return tuple(self._profiles[name] for name in self.names())

    def freeze(self) -> None:
        self._frozen = True

    @property
    def frozen(self) -> bool:
        return self._frozen


class SearchExecutorRegistry:
    def __init__(self, specs: Iterable[SearchExecutorSpec] = ()) -> None:
        self._specs: dict[str, SearchExecutorSpec] = {}
        self._frozen = False
        for spec in specs:
            self.register(spec)

    def register(
        self,
        spec: SearchExecutorSpec,
        *,
        replace: bool = False,
    ) -> None:
        """Register one complete, typed algorithm contract."""

        if self._frozen:
            raise StateError("搜索 Executor 注册表已冻结")
        normalized = spec.name.strip()
        if normalized in self._specs and not replace:
            raise InvalidInputError(f"搜索 Executor 已注册: {normalized}")
        if normalized != spec.name:
            spec = dataclass_replace(spec, name=normalized)
        self._specs[normalized] = spec

    def get(self, name: str) -> SearchExecutorSpec:
        try:
            return self._specs[name]
        except KeyError as exc:
            raise SearchPlanError(
                f"搜索 Executor 未注册: {name}",
                stage="search",
                code="search_executor_not_registered",
            ) from exc

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._specs))

    def validate_profiles(self, profiles: SearchProfileRegistry) -> None:
        missing = sorted(
            {str(profile.executor) for profile in profiles.values()} - set(self._specs)
        )
        if missing:
            raise SearchPlanError(
                "Profile 引用了未注册的搜索 Executor: " + ", ".join(missing),
                stage="search",
                code="search_executor_catalog_incomplete",
            )
        self._validate_profile_policy_alignment(profiles)

    def _validate_profile_policy_alignment(self, profiles: SearchProfileRegistry) -> None:
        """profile.policy 允许的能力必须是目标 spec 声明能力的子集。

        让两套独立 gate 在 engine.start() 期交叉对齐：漂移直接启动失败，
        而不是等某个请求恰好命中才报 unsupported_search_executor_plan。
        policy 目前只有 allow_graph_output / allow_paths 两个输出开关，逐项比对。
        """

        drifts: list[str] = []
        for profile in profiles.values():
            spec = self._specs.get(str(profile.executor))
            if spec is None:
                continue
            policy = profile.policy
            if policy.allow_graph_output and not spec.supports_graph_output:
                drifts.append(
                    f"{profile.name}: allow_graph_output 但 {spec.name} 未声明 supports_graph_output"
                )
            if policy.allow_paths and not spec.supports_paths:
                drifts.append(f"{profile.name}: allow_paths 但 {spec.name} 未声明 supports_paths")
        if drifts:
            raise SearchPlanError(
                "搜索 Profile policy 与 Executor 输出能力漂移: " + "; ".join(drifts),
                stage="search",
                code="search_profile_executor_capability_drift",
            )

    def freeze(self) -> None:
        self._frozen = True

    @property
    def frozen(self) -> bool:
        return self._frozen


__all__ = [
    "CapabilityResolver",
    "PlanValidator",
    "SearchExecutorRegistry",
    "SearchExecutorSpec",
    "SearchProfileRegistry",
]
