"""
向量检索器

独立于三阶段的向量检索器，直接使用 Query 向量检索 Event/Chunk，
支持 title/heading 和 content 向量的混合搜索。

使用示例：
    from zleap.sag.modules.search import VectorSearcher, VectorConfig

    config = VectorConfig(
        return_type="event",
        top_k=20,
        title_weight=0.3,
        content_weight=0.7,
        similarity_threshold=0.4
    )

    searcher = VectorSearcher(
        session_factory=session_factory,
        repositories=repositories,
        embedding=embedding,
    )
    events = await searcher.search(
        query="人工智能技术发展",
        data_source_ids=["source_1", "source_2"],
        config=config
    )
"""

import time
from typing import Any

from zleap.sag.exceptions import ConfigError
from zleap.sag.modules.load.processor import DocumentProcessor
from zleap.sag.utils import get_logger

logger = get_logger("search.vector")


class VectorSearcher:
    """
    向量检索器

    支持段落(SourceChunk)和事项(SourceEvent)的混合向量搜索。
    使用 ES script_score 查询实现 title/heading + content 的混合相似度计算。
    """

    INDEX_EVENTS = "event_vectors_wide"
    INDEX_CHUNKS = "source_chunks"

    def __init__(
        self,
        session_factory: Any = None,
        repositories: Any = None,
        embedding: Any = None,
    ):
        """初始化向量检索器"""
        if session_factory is None or repositories is None or embedding is None:
            raise ConfigError(
                "VectorSearcher 需要显式注入 session_factory、repositories 和 embedding"
            )
        self.repositories = repositories
        self.session_factory = session_factory
        self.processor = DocumentProcessor(embedding_client=embedding)

    async def search_chunks(
        self,
        query: str,
        data_source_ids: list[str],
        query_vector: list[float] | None = None,
        config: Any | None = None,
    ) -> dict[str, Any]:
        """
        执行向量搜索，返回段落格式

        供 VectorSearchExecutor 调用；内部只做向量召回。
        使用 ES kNN 向量搜索（避免 script_score 的编译限制）。

        Args:
            query: 查询文本
            data_source_ids: 信息源ID列表
            query_vector: 可选的预计算向量（避免重复计算）
            config: VectorConfig

        Returns:
            {
                "sections": [...],  # 段落列表，按相似度降序
                "_timings": {...}   # 耗时统计
            }
        """
        start_time = time.perf_counter()

        # 从 VectorConfig 获取参数
        top_k = 20
        min_score = 0.0

        if config:
            top_k = getattr(config, "top_k", top_k)
            min_score = getattr(config, "similarity_threshold", min_score)

        logger.info(
            "【向量检索】开始: query_chars=%d, top_k=%d, min_score=%.4f",
            len(query),
            top_k,
            min_score,
        )

        # Step 1: 生成查询向量
        vector_time = 0.0
        if query_vector is None:
            vector_start = time.perf_counter()
            query_vector = await self.processor.generate_embedding(query)
            vector_time = time.perf_counter() - vector_start
            logger.info(f"✓ 向量生成完成，维度={len(query_vector)}，耗时={vector_time:.3f}s")
        else:
            logger.info(f"✓ 使用预计算向量，维度={len(query_vector)}")

        # Step 2: 使用 SourceChunkRepository 的 kNN 搜索（避免 script_score 编译限制）
        chunk_repo = self.repositories.source_chunks

        es_start = time.perf_counter()
        es_results = await chunk_repo.search_similar_by_content(
            query_vector=query_vector,
            k=top_k,
            data_source_ids=data_source_ids,
        )
        es_time = time.perf_counter() - es_start
        logger.info(f"✓ ES kNN 搜索完成，命中 {len(es_results)} 个段落，耗时={es_time:.3f}s")

        if not es_results:
            logger.info("【向量检索】未找到匹配段落")
            total_time = time.perf_counter() - start_time
            return {
                "sections": [],
                "_timings": {
                    "vector_gen": vector_time,
                    "es_search": es_time,
                    "total": total_time,
                },
            }

        # Step 3: 格式化结果（ES kNN 直接返回完整文档）
        sections = []
        for result in es_results:
            score = result.get("score", 0.0)
            if score < min_score:
                continue

            sections.append(
                {
                    "chunk_id": result.get("chunk_id"),
                    "source_id": result.get("source_id"),
                    "data_source_id": result.get("data_source_id"),
                    "heading": result.get("heading"),
                    "content": result.get("content"),
                    "rank": result.get("rank"),
                    "chunk_type": result.get("chunk_type"),
                    "references": result.get("references") or [],
                    "score": score,
                    "weight": score,
                }
            )

        sections = sorted(sections, key=lambda x: x["score"], reverse=True)

        sections = sections[:top_k]

        total_time = time.perf_counter() - start_time

        logger.info(f"【向量检索】完成，返回 {len(sections)} 个段落，总耗时={total_time:.3f}s")
        if sections:
            logger.info(
                "【向量检索】分数区间: %.4f..%.4f",
                min(float(section["score"]) for section in sections),
                max(float(section["score"]) for section in sections),
            )

        return {
            "sections": sections,
            "_timings": {
                "vector_gen": vector_time,
                "es_search": es_time,
                "total": total_time,
            },
        }


__all__ = ["VectorSearcher"]
