"""
事项保存器 - 负责持久化

职责：
- 保存事项到数据库（MySQL）
- 同步到向量存储
- 批量处理优化
"""

import time
import uuid
from dataclasses import dataclass
from typing import Any

from sqlalchemy import delete, select, update
from sqlalchemy.orm import selectinload

from zleap.sag._safe_error import safe_error_type
from zleap.sag.core.storage.repositories.compensation import (
    capture_vector_snapshots,
    restore_vector_snapshots,
)
from zleap.sag.core.storage.repositories.entity_repository import EntityVectorRepository
from zleap.sag.core.storage.repositories.event_repository import EventVectorRepository
from zleap.sag.db import Entity, EventEntity, SourceEvent
from zleap.sag.db.models import EntityType as DBEntityType
from zleap.sag.exceptions import ConfigError, ExtractRollbackError, StateError
from zleap.sag.modules.extract.config import ExtractConfig
from zleap.sag.modules.extract.parser import ResultParser
from zleap.sag.utils import get_logger

logger = get_logger("extract.saver")


@dataclass(frozen=True)
class RelationCommitResult:
    event_ids: list[str]
    created_entity_ids: list[str]


class EventSaver:
    """事项保存器 - 负责持久化"""

    def __init__(
        self,
        session_factory: Any = None,
        repositories: Any = None,
        embedding: Any = None,
    ):
        """初始化保存器"""
        if session_factory is None or repositories is None or embedding is None:
            raise ConfigError("EventSaver 需要显式注入 session_factory、repositories 和 embedding")
        self.session_factory = session_factory
        self.repositories = repositories
        self.embedding = embedding
        self.logger = get_logger("extract.saver")

        # 向量库相关（延迟初始化）
        self._event_repo_or_none: EventVectorRepository | None = None
        self._entity_repo_or_none: EntityVectorRepository | None = None

    @property
    def _event_repo(self) -> EventVectorRepository:
        if self._event_repo_or_none is None:
            raise StateError("事项向量仓储尚未初始化")
        return self._event_repo_or_none

    @property
    def _entity_repo(self) -> EntityVectorRepository:
        if self._entity_repo_or_none is None:
            raise StateError("实体向量仓储尚未初始化")
        return self._entity_repo_or_none

    async def commit(self, events: list[SourceEvent], config: ExtractConfig) -> list[SourceEvent]:
        """
        提交事项（保存到DB + 同步向量库）

        Args:
            events: 事项列表（已完成解析，包含实体关联）
            config: 提取配置

        Returns:
            保存后的事项列表（包含完整关系数据）
        """
        self.logger.info(f"开始提交 {len(events)} 个事项")
        self._prepare_generation_records(events, config)

        old_event_statuses, old_association_ids = await self._active_event_state_for_sources(
            events, config
        )
        old_event_ids = list(old_event_statuses)
        event_ids = [str(event.id) for event in events]
        created_entity_ids: list[str] = []
        vector_groups: list[tuple[Any, list[str]]] = []
        vector_snapshots: list[Any] = []
        relation_committed = False
        vector_mutation_started = False
        try:
            # 1. 关系数据先落库，但任何后续失败都会执行补偿回滚。
            relation_result = await self._save_to_database(events, config)
            event_ids = relation_result.event_ids
            created_entity_ids = relation_result.created_entity_ids
            relation_committed = True

            # 2. 重新加载（带完整关系数据）
            fresh_events = await self._load_events_with_relations(event_ids)
            associations = self._collect_event_entities(fresh_events)
            association_ids = [str(item.id) for item in associations]
            entity_ids = sorted({str(item.entity_id) for item in associations})

            if config.write_plan.write_event_vectors:
                vector_groups.append(
                    (
                        self.repositories.events,
                        list(dict.fromkeys([*old_event_ids, *event_ids])),
                    )
                )
            if config.write_plan.write_entity_index:
                vector_groups.append((self.repositories.entities, entity_ids))
            if config.write_plan.write_event_entity_vectors:
                vector_groups.append(
                    (
                        self.repositories.event_entities,
                        list(dict.fromkeys([*old_association_ids, *association_ids])),
                    )
                )
            vector_snapshots = await capture_vector_snapshots(vector_groups)

            # 3. 同步到向量库（normal/lite 均把事项-实体关联写到正式索引）
            if config.write_plan.write_event_vectors:
                vector_mutation_started = True
                obsolete_vector_groups = [(self.repositories.events, old_event_ids)]
                if config.write_plan.write_event_entity_vectors:
                    obsolete_vector_groups.append(
                        (self.repositories.event_entities, old_association_ids)
                    )
                for repository, obsolete_ids in obsolete_vector_groups:
                    if not obsolete_ids:
                        continue
                    result = await repository.vector_store.delete(
                        repository.INDEX_NAME, obsolete_ids
                    )
                    if result.failed_items:
                        from zleap.sag.exceptions import VectorSyncError

                        raise VectorSyncError(
                            provider=repository.vector_store.provider,
                            collection=repository.INDEX_NAME,
                            failed_ids=[item.id for item in result.failed_items],
                            reason=result.failed_items[0].error,
                        )
                await self._sync_to_vector_store(fresh_events, config)

            self.logger.info(f"提交完成: {len(fresh_events)} 个事项")
            return fresh_events
        except Exception as exc:
            rollback_errors: list[str] = []
            if vector_mutation_started:
                rollback_errors.extend(
                    await restore_vector_snapshots(vector_groups, vector_snapshots)
                )
            if relation_committed:
                if created_entity_ids:
                    rollback_errors.extend(
                        await self._restore_event_relations(
                            event_ids,
                            old_event_statuses,
                            created_entity_ids=created_entity_ids,
                        )
                    )
                else:
                    rollback_errors.extend(
                        await self._restore_event_relations(event_ids, old_event_statuses)
                    )
            if rollback_errors:
                raise ExtractRollbackError(compensation_complete=False) from exc
            if relation_committed:
                from zleap.sag.exceptions import VectorSyncError

                if isinstance(exc, VectorSyncError):
                    failed_ids = list(exc.failed_ids) or event_ids
                    raise VectorSyncError(
                        provider=exc.provider or "unknown",
                        collection=exc.collection,
                        failed_ids=failed_ids,
                        reason="Extract 关系与向量变更已全部回滚",
                        compensation_complete=True,
                    ) from exc
                raise ExtractRollbackError(
                    compensation_complete=True,
                    provider=getattr(exc, "provider", None),
                ) from exc
            raise

    async def _active_event_state_for_sources(
        self, events: list[SourceEvent], config: ExtractConfig
    ) -> tuple[dict[str, Any], list[str]]:
        source_keys = {
            (event.source_type, event.source_id)
            for event in events
            if hasattr(event, "source_type") and hasattr(event, "source_id")
        }
        if not source_keys:
            source_keys = {(config.source_type, config.source_id)}
        if not source_keys:
            return {}, []
        async with self.session_factory() as session:
            statuses: dict[str, Any] = {}
            for source_type, source_id in source_keys:
                rows = await session.execute(
                    select(SourceEvent.id, SourceEvent.status).where(
                        SourceEvent.source_type == source_type,
                        SourceEvent.source_id == source_id,
                        (
                            SourceEvent.generation_id == config.generation_id
                            if config.generation_id is not None
                            else SourceEvent.not_deleted()
                        ),
                    )
                )
                statuses.update({str(row.id): row.status for row in rows.all()})
            association_ids: list[str] = []
            if statuses:
                association_ids = [
                    str(item)
                    for item in (
                        await session.execute(
                            select(EventEntity.id).where(EventEntity.event_id.in_(list(statuses)))
                        )
                    )
                    .scalars()
                    .all()
                ]
            return statuses, association_ids

    async def _restore_event_relations(
        self,
        new_event_ids: list[str],
        old_event_statuses: dict[str, Any],
        *,
        created_entity_ids: list[str] | None = None,
    ) -> list[str]:
        errors: list[str] = []
        try:
            async with self.session_factory() as session:
                if new_event_ids:
                    await session.execute(
                        delete(SourceEvent).where(SourceEvent.id.in_(new_event_ids))
                    )
                for event_id, status in old_event_statuses.items():
                    await session.execute(
                        update(SourceEvent).where(SourceEvent.id == event_id).values(status=status)
                    )
                if created_entity_ids:
                    referenced_entities = select(EventEntity.entity_id)
                    await session.execute(
                        delete(Entity)
                        .where(Entity.id.in_(created_entity_ids))
                        .where(~Entity.id.in_(referenced_entities))
                    )
                await session.commit()
        except Exception as exc:
            errors.append(f"relation_restore_exception({safe_error_type(exc)})")
        return errors

    def _collect_event_entities(self, events: list[SourceEvent]) -> list[EventEntity]:
        """收集事项中的所有事件-实体关联"""
        event_entities: list[EventEntity] = []
        for event in events:
            if hasattr(event, "event_associations") and event.event_associations:
                event_entities.extend(event.event_associations)
        return event_entities

    async def _save_to_database(
        self, events: list[SourceEvent], config: ExtractConfig
    ) -> RelationCommitResult:
        """
        保存事项到数据库

        Args:
            events: 事项列表

        Returns:
            事项ID列表
        """
        event_ids: list[str] = []
        created_entity_ids: set[str] = set()

        # 每个持久化来源只有一份 current 结果；顺序重试在同一事务内替换旧事项。
        source_keys = {(event.source_type, event.source_id) for event in events}
        if not source_keys:
            source_keys = {(config.source_type, config.source_id)}

        async with self.session_factory() as session:
            events_with_raw_entities: list[SourceEvent] = []
            for event in events:
                extra_data = getattr(event, "extra_data", None)
                if isinstance(extra_data, dict) and "raw_entities" in extra_data:
                    events_with_raw_entities.append(event)
            if events_with_raw_entities:
                entity_types = await self._load_entity_types(session, config)
                parser = ResultParser(config, session_factory=self.session_factory)
                await parser.process_entity_associations(
                    events_with_raw_entities,
                    entity_types,
                    session=session,
                    created_entity_ids=created_entity_ids,
                )

            # Managed generations never touch the active generation.  A retry only
            # replaces its own invisible generation.  Legacy stage calls retain the
            # historical replace-in-place contract.
            for source_type, source_id in source_keys:
                if config.generation_id is not None:
                    await session.execute(
                        delete(SourceEvent).where(
                            SourceEvent.source_type == source_type,
                            SourceEvent.source_id == source_id,
                            SourceEvent.generation_id == config.generation_id,
                        )
                    )
                else:
                    await session.execute(
                        update(SourceEvent)
                        .where(
                            SourceEvent.source_type == source_type,
                            SourceEvent.source_id == source_id,
                            SourceEvent.not_deleted(),
                        )
                        .values(status="DELETED")
                    )

            for event in events:
                event_ids.append(event.id)
                session.add(event)

                # 添加实体关联
                if hasattr(event, "event_associations") and event.event_associations:
                    for assoc in event.event_associations:
                        session.add(assoc)

            await session.commit()

        self.logger.info(f"已保存 {len(event_ids)} 个事项到数据库")
        return RelationCommitResult(
            event_ids=event_ids,
            created_entity_ids=sorted(created_entity_ids),
        )

    @staticmethod
    def _prepare_generation_records(events: list[SourceEvent], config: ExtractConfig) -> None:
        """Assign retry-stable IDs and generation ownership before any persistence."""
        generation_id = config.generation_id
        if generation_id is None:
            return
        old_to_new: dict[str, str] = {}
        for position, event in enumerate(events):
            old_id = str(event.id)
            stable_key = ":".join(
                (
                    str(position),
                    str(event.rank),
                    str(event.level),
                    str(event.chunk_id or "parent"),
                )
            )
            new_id = str(
                uuid.uuid5(
                    uuid.NAMESPACE_URL,
                    f"zleap-sag:{generation_id}:event:{stable_key}",
                )
            )
            old_to_new[old_id] = new_id
            event.id = new_id
            event.generation_id = generation_id

        for event in events:
            if event.parent_id is not None:
                event.parent_id = old_to_new.get(str(event.parent_id), str(event.parent_id))
            for association in getattr(event, "event_associations", ()) or ():
                association.event_id = str(event.id)
                association.id = str(
                    uuid.uuid5(
                        uuid.NAMESPACE_URL,
                        (
                            f"zleap-sag:{generation_id}:association:"
                            f"{event.id}:{association.entity_id}"
                        ),
                    )
                )

    async def _load_entity_types(
        self,
        session: Any,
        config: ExtractConfig,
    ) -> list[DBEntityType]:
        """Load the entity contract inside the relation commit transaction."""
        defaults = list(
            (
                await session.execute(
                    select(DBEntityType)
                    .where(DBEntityType.is_default.is_(True))
                    .where(DBEntityType.is_active.is_(True))
                )
            )
            .scalars()
            .all()
        )
        custom: list[DBEntityType] = []
        if config.data_source_id:
            custom = list(
                (
                    await session.execute(
                        select(DBEntityType)
                        .where(DBEntityType.data_source_id == config.data_source_id)
                        .where(DBEntityType.is_active.is_(True))
                    )
                )
                .scalars()
                .all()
            )
        deduped: list[DBEntityType] = []
        seen: set[str] = set()
        for entity_type in [*defaults, *custom]:
            if entity_type.type not in seen:
                seen.add(entity_type.type)
                deduped.append(entity_type)
        return deduped

    async def _load_events_with_relations(self, event_ids: list[str]) -> list[SourceEvent]:
        """
        从数据库加载事项（预加载关系数据）

        Args:
            event_ids: 事项ID列表

        Returns:
            事项列表（包含完整关系数据）
        """
        if not event_ids:
            return []

        async with self.session_factory() as session:
            result = await session.execute(
                select(SourceEvent)
                .where(SourceEvent.id.in_(event_ids))
                .options(
                    selectinload(SourceEvent.event_associations).selectinload(EventEntity.entity)
                )
            )
            events = list(result.scalars().all())

            # 确保数据在 session 外可访问
            session.expire_on_commit = False

            # 触发关系数据加载
            for event in events:
                _ = event.created_time
                _ = event.updated_time
                if hasattr(event, "event_associations"):
                    for assoc in event.event_associations:
                        _ = assoc.id
                        if assoc.entity:
                            _ = assoc.entity.name
                            _ = assoc.entity.type

            return events

    async def _sync_to_vector_store(self, events: list[SourceEvent], config: ExtractConfig) -> None:
        """
        同步事项和实体到向量库

        Args:
            events: 事项列表
            config: 提取配置
        """
        self.logger.info(f"开始同步 {len(events)} 个事项到向量库")

        # 初始化向量库客户端（延迟初始化）
        if self._event_repo_or_none is None:
            self._event_repo_or_none = self.repositories.events
            self._entity_repo_or_none = self.repositories.entities

        # 连接失败必须暴露给调用方，不能把关系成功伪装成全链路成功。
        await self._event_repo.vector_store.ping()

        # 收集所有唯一的实体
        unique_entities = await self._collect_unique_entities(events)

        # 1. 两种模式都同步实体索引；lite/SAAS 只写 BM25 元数据。
        if unique_entities and config.write_plan.write_entity_index:
            await self._sync_entities(list(unique_entities.values()), config)

        # 2. 同步事项
        await self._sync_events(events, config)

        # 3. 同步事件-实体关联（如果启用）
        if config.write_plan.write_event_entity_vectors:
            await self._sync_event_entities(events, config)

        # 统计状态
        entity_status = (
            f"{len(unique_entities)} 个实体"
            if config.write_plan.write_entity_vectors
            else f"{len(unique_entities)} 个实体元数据(不含vector)"
        )

        # 统计事件-实体关联数量
        event_entity_count = sum(
            len(e.event_associations) for e in events if hasattr(e, "event_associations")
        )
        event_entity_status = (
            f"{event_entity_count} 个关联"
            if config.write_plan.write_event_entity_vectors
            else "事件-实体关联同步已禁用"
        )

        self.logger.info(
            f"向量库同步完成: {len(events)} 个事项, {entity_status}, {event_entity_status}"
        )

        await self._optimize_vector_store()

    async def _optimize_vector_store(self) -> None:
        """写入完成后压实 + 建索引(经中立合同;自动维护索引的后端为 no-op)。

        LanceDB 不会在写入时自动建索引:没有这一步,kNN 永远是全表 brute-force,
        标量 where 也是全表扫;且每次 merge_insert 都留下新 fragment,不压实会让
        表体积随写入次数持续膨胀。失败不阻断提取——索引只影响性能,不影响正确性。
        """
        assert self._event_repo is not None
        try:
            if not await self._event_repo.vector_store.optimize():
                # 部分表压实/建索引失败:不影响本次提取结果,但后续 kNN 会退化为
                # 全表扫描,必须留痕而不是静默丢掉。
                self.logger.warning("向量库优化部分失败: 索引未全部建立，检索性能可能下降")
        except Exception as e:  # pragma: no cover - 优化失败不应影响提取结果
            self.logger.warning(
                "向量库优化跳过",
                extra={"error_type": safe_error_type(e)},
            )

    async def __aenter__(self):
        """异步上下文管理器入口"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """退出业务作用域；共享向量资源由 DataEngine 统一关闭。"""
        return False

    async def _collect_unique_entities(self, events: list[SourceEvent]) -> dict[str, Entity]:
        """收集所有唯一的实体"""
        unique_entities = {}

        for event in events:
            if hasattr(event, "event_associations") and event.event_associations:
                for assoc in event.event_associations:
                    entity_id = assoc.entity_id
                    if entity_id not in unique_entities:
                        entity = await self._load_entity_by_id(entity_id)
                        if entity:
                            unique_entities[entity_id] = entity

        return unique_entities

    async def _load_entity_by_id(self, entity_id: str) -> Entity:
        """从数据库加载实体"""
        async with self.session_factory() as session:
            result = await session.execute(select(Entity).where(Entity.id == entity_id))
            return result.scalar_one_or_none()

    async def _sync_entities(self, entities: list[Entity], config: ExtractConfig) -> dict[str, Any]:
        """
        同步实体到向量库（批量处理）

        Args:
            entities: 实体列表
            config: 提取配置

        Returns:
            统计信息
        """
        if not entities:
            return {"total": 0, "indexed": 0}

        # 过滤不需要索引的实体类型
        original_count = len(entities)
        # entities = [e for e in entities if should_index_entity_to_vector_store(e.type)]

        if len(entities) < original_count:
            skipped = original_count - len(entities)
            self.logger.info(f"过滤掉 {skipped} 个不需要索引的实体")

        if not entities:
            self.logger.info("所有实体都被过滤，跳过向量同步")
            return {"total": 0, "indexed": 0}

        return await self._batch_sync_entities(entities, config)

    async def _batch_sync_entities(
        self, entities: list[Entity], config: ExtractConfig
    ) -> dict[str, Any]:
        """
        批量同步实体到向量库（使用批量处理工具）

        Args:
            entities: 实体列表
            config: 提取配置

        Returns:
            统计信息
        """
        from zleap.sag.utils.batch import batch_generate_embeddings, batch_upsert_vectors

        start_time = time.perf_counter()

        def build_document(entity: Entity, vector: list[float] | None = None) -> dict[str, Any]:
            document: dict[str, Any] = {
                "id": entity.id,
                "entity_id": entity.id,
                "data_source_id": entity.data_source_id,
                "type": entity.type,
                "name": entity.name,
                "normalized_name": entity.normalized_name or entity.name,
                "description": entity.description or "",
                "created_time": (entity.created_time.isoformat() if entity.created_time else None),
            }
            if vector is not None:
                document["vector"] = self._entity_repo.prepare_vector(vector)
            return document

        if config.write_plan.write_entity_vectors:
            embedding_result = await batch_generate_embeddings(
                items=entities,
                text_extractor=lambda e: e.name,
                embedding_client=self.embedding,
                batch_size=config.embedding_batch_size,
                on_success=build_document,
                concurrency=config.embedding_concurrency,
            )
            documents = embedding_result["results"]
            embedding_failed = embedding_result["failed"]
            embedding_failed_ids = sorted(
                {str(entity.id) for entity in entities}
                - {str(document["id"]) for document in documents}
            )
        else:
            documents = [build_document(entity) for entity in entities]
            embedding_failed = 0
            embedding_failed_ids = []

        # 阶段2: 批量索引
        index_result = await batch_upsert_vectors(
            documents=documents,
            repository=self._entity_repo,
            collection=self._entity_repo.INDEX_NAME,
            batch_size=config.vector_batch_size,
            concurrency=config.vector_write_concurrency,
        )

        indexed = index_result["indexed"]
        vector_failed = index_result["failed"]

        if embedding_failed_ids:
            from zleap.sag.exceptions import VectorSyncError

            raise VectorSyncError(
                provider=self._entity_repo.vector_store.provider,
                collection=self._entity_repo.INDEX_NAME,
                failed_ids=embedding_failed_ids,
                reason="embedding generation failed",
            )

        total_time = time.perf_counter() - start_time

        stats = {
            "total": len(entities),
            "indexed": indexed,
            "embedding_failed": embedding_failed,
            "vector_failed": vector_failed,
            "time": f"{total_time:.2f}s",
        }

        if vector_failed > 0 or embedding_failed > 0:
            self.logger.warning(f"实体同步部分失败: {stats}")
        else:
            self.logger.info(f"实体同步成功: {indexed}/{len(entities)} 条, 耗时{total_time:.2f}s")

        return stats

    async def _sync_events(
        self, events: list[SourceEvent], config: ExtractConfig
    ) -> dict[str, Any]:
        """
        同步事项到向量库（批量处理）

        Args:
            events: 事项列表
            config: 提取配置

        Returns:
            统计信息
        """
        if not events:
            return {"total": 0, "indexed": 0}

        return await self._batch_sync_events(events, config)

    async def _batch_sync_events(
        self, events: list[SourceEvent], config: ExtractConfig
    ) -> dict[str, Any]:
        """
        批量同步事项到向量库（两阶段处理）

        Args:
            events: 事项列表
            config: 提取配置

        Returns:
            统计信息
        """
        start_time = time.perf_counter()

        embedding_client = self.embedding

        from collections.abc import Sequence

        from zleap.sag.utils.batch import run_batches, split_batches

        async def _embed_event_batch(
            _index: int, batch: Sequence[SourceEvent]
        ) -> tuple[list[dict[str, Any]], int]:
            """向量化一批事项；批失败降级为逐条重试，与历史行为一致。"""
            batch_documents: list[dict[str, Any]] = []
            failed = 0
            try:
                # 准备文本（每个事项需要2个向量，使用 embedding 专用长度限制）
                content_texts = [
                    f"{event.title}\n\n{event.content[: config.embedding_max_length]}"
                    for event in batch
                ]

                # 批量生成向量
                if config.write_plan.write_event_title_vectors:
                    title_vectors = await embedding_client.batch_generate(
                        [event.title for event in batch]
                    )
                else:
                    title_vectors = [None] * len(batch)
                content_vectors = await embedding_client.batch_generate(content_texts)

                # 构建文档
                for event, title_vec, content_vec in zip(
                    batch, title_vectors, content_vectors, strict=True
                ):
                    batch_documents.append(
                        self._build_event_document(event, title_vec, content_vec)
                    )

            except Exception as e:
                self.logger.warning(
                    "批量生成向量失败，降级重试",
                    extra={"error_type": safe_error_type(e)},
                )
                for event in batch:
                    try:
                        title_vec = (
                            await embedding_client.generate(event.title)
                            if config.write_plan.write_event_title_vectors
                            else None
                        )
                        content_for_vec = (
                            f"{event.title}\n\n{event.content[: config.embedding_max_length]}"
                        )
                        content_vec = await embedding_client.generate(content_for_vec)
                        batch_documents.append(
                            self._build_event_document(event, title_vec, content_vec)
                        )
                    except Exception as retry_e:
                        self.logger.error(
                            "单条生成向量失败",
                            extra={"error_type": safe_error_type(retry_e)},
                        )
                        failed += 1
            return batch_documents, failed

        # 阶段1: 批量生成向量（批间并发，受 governor embedding 限额约束；
        # run_batches 按批序返回，文档顺序与串行版本一致）
        batch_results = await run_batches(
            split_batches(events, config.embedding_batch_size),
            _embed_event_batch,
            concurrency=config.embedding_concurrency,
        )
        documents = [doc for batch_docs, _failed in batch_results for doc in batch_docs]
        embedding_failed = sum(failed for _docs, failed in batch_results)

        # 阶段2: 批量索引（使用工具）
        from zleap.sag.utils.batch import batch_upsert_vectors

        index_result = await batch_upsert_vectors(
            documents=documents,
            repository=self._event_repo,
            collection=self._event_repo.INDEX_NAME,
            batch_size=config.vector_batch_size,
            concurrency=config.vector_write_concurrency,
        )

        indexed = index_result["indexed"]
        vector_failed = index_result["failed"]
        embedding_failed_ids = sorted(
            {str(event.id) for event in events} - {str(document["id"]) for document in documents}
        )
        if embedding_failed_ids:
            from zleap.sag.exceptions import VectorSyncError

            raise VectorSyncError(
                provider=self._event_repo.vector_store.provider,
                collection=self._event_repo.INDEX_NAME,
                failed_ids=embedding_failed_ids,
                reason="embedding generation failed",
            )
        total_time = time.perf_counter() - start_time

        stats = {
            "total": len(events),
            "indexed": indexed,
            "embedding_failed": embedding_failed,
            "vector_failed": vector_failed,
            "time": f"{total_time:.2f}s",
        }

        if vector_failed > 0 or embedding_failed > 0:
            self.logger.warning(f"事项同步部分失败: {stats}")
        else:
            self.logger.info(f"事项同步成功: {indexed}/{len(events)} 条, 耗时{total_time:.2f}s")

        return stats

    async def _sync_event_entities(
        self, events: list[SourceEvent], config: ExtractConfig
    ) -> dict[str, Any]:
        """
        同步事件-实体关联到向量库（批量处理）

        Args:
            events: 事项列表
            config: 提取配置

        Returns:
            统计信息
        """
        if not events:
            return {"total": 0, "indexed": 0}

        start_time = time.perf_counter()

        embedding_client = self.embedding

        # 收集所有 EventEntity 关联
        event_entities = self._collect_event_entities(events)
        event_by_id = {event.id: event for event in events}

        if not event_entities:
            self.logger.info("没有事件-实体关联需要同步")
            return {"total": 0, "indexed": 0}

        # 阶段1: 批量生成向量（使用工具）
        from zleap.sag.utils.batch import batch_generate_embeddings, batch_upsert_vectors

        def build_document(assoc: EventEntity, vector: list[float]) -> dict[str, Any]:
            event = event_by_id.get(assoc.event_id)
            return {
                "id": assoc.id,
                "event_id": assoc.event_id,
                "entity_id": assoc.entity_id,
                "data_source_id": config.data_source_id,
                "description": assoc.description or "",
                "vector": self.repositories.event_entities.prepare_vector(vector),
                "source_type": event.source_type if event else "",
                "source_id": event.source_id if event else "",
                "generation_id": event.generation_id if event else config.generation_id,
                "article_id": event.article_id if event else "",
                "conversation_id": event.conversation_id if event else "",
                "parent_id": event.parent_id if event else "",
                "level": event.level if event else 0,
                "created_time": (assoc.created_time.isoformat() if assoc.created_time else None),
            }

        embedding_result = await batch_generate_embeddings(
            items=event_entities,
            text_extractor=lambda a: a.description or f"{a.event_id}-{a.entity_id}",
            embedding_client=embedding_client,
            batch_size=config.embedding_batch_size,
            on_success=build_document,
            concurrency=config.embedding_concurrency,
        )

        documents = embedding_result["results"]
        embedding_failed = embedding_result["failed"]
        embedding_failed_ids = sorted(
            {str(association.id) for association in event_entities}
            - {str(document["id"]) for document in documents}
        )

        # 阶段2: 批量索引（使用工具）
        index_result = await batch_upsert_vectors(
            documents=documents,
            repository=self.repositories.event_entities,
            collection=self.repositories.event_entities.INDEX_NAME,
            batch_size=config.vector_batch_size,
            concurrency=config.vector_write_concurrency,
        )

        indexed = index_result["indexed"]
        vector_failed = index_result["failed"]
        if embedding_failed_ids:
            from zleap.sag.exceptions import VectorSyncError

            raise VectorSyncError(
                provider=self.repositories.event_entities.vector_store.provider,
                collection=self.repositories.event_entities.INDEX_NAME,
                failed_ids=embedding_failed_ids,
                reason="embedding generation failed",
            )
        total_time = time.perf_counter() - start_time

        stats = {
            "total": len(event_entities),
            "indexed": indexed,
            "embedding_failed": embedding_failed,
            "vector_failed": vector_failed,
            "time": f"{total_time:.2f}s",
        }

        if vector_failed > 0 or embedding_failed > 0:
            self.logger.warning(f"事件-实体关联同步部分失败: {stats}")
        else:
            self.logger.info(
                f"事件-实体关联同步成功: {indexed}/{len(event_entities)} 条, 耗时{total_time:.2f}s"
            )

        return stats

    def _build_event_document(
        self,
        event: SourceEvent,
        title_vec: list[float] | None,
        content_vec: list[float],
    ) -> dict[str, Any]:
        """构建事项文档（用于向量库索引）"""
        # 提取关联实体ID
        entity_ids = []
        entity_types = []
        if hasattr(event, "event_associations") and event.event_associations:
            entity_ids = [assoc.entity_id for assoc in event.event_associations]
            entity_types = sorted(
                {
                    assoc.entity.type
                    for assoc in event.event_associations
                    if getattr(assoc, "entity", None) is not None
                }
            )

        extra_fields: dict[str, Any] = {}
        if event.extra_data and "tags" in event.extra_data:
            extra_fields["tags"] = event.extra_data["tags"]
        if event.category:
            extra_fields["category"] = event.category
        if event.keywords:
            extra_fields["keywords"] = self._normalize_keywords_for_vector(event.keywords)

        return {
            "id": event.id,
            "event_id": event.id,
            "data_source_id": event.data_source_id,
            "source_type": event.source_type,
            "source_id": event.source_id,
            "generation_id": event.generation_id,
            "article_id": event.article_id,
            "conversation_id": event.conversation_id,
            "chunk_id": event.chunk_id,
            "parent_id": event.parent_id,
            "level": event.level,
            "type": event.type,
            "priority": event.priority,
            "status": event.status,
            "rank": event.rank,
            "title": event.title,
            "summary": event.summary or "",
            "content": event.content,
            "title_vector": title_vec,
            "content_vector": content_vec,
            "entity_ids": entity_ids,
            "entity_types": entity_types,
            "reference": self._normalize_reference_for_vector(event.references),
            "extra_data": event.extra_data,
            "start_time": event.start_time.isoformat() if event.start_time else None,
            "end_time": event.end_time.isoformat() if event.end_time else None,
            "created_time": (event.created_time.isoformat() if event.created_time else None),
            **extra_fields,
        }

    @staticmethod
    def _normalize_keywords_for_vector(keywords: Any) -> dict[str, Any]:
        if isinstance(keywords, dict):
            return keywords
        return {"extracted": keywords}

    @staticmethod
    def _normalize_reference_for_vector(reference: Any) -> dict[str, Any]:
        if isinstance(reference, dict):
            return reference
        if reference is None:
            return {}
        if isinstance(reference, list):
            return {"ids": reference}
        return {"value": reference}
