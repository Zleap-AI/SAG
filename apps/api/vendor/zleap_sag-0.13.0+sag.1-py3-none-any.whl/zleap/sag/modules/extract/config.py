"""Validated internal configuration for the Extract implementation."""

from __future__ import annotations

from typing import Literal

from pydantic import ConfigDict, Field, model_validator

from zleap.sag.exceptions import ValidationError as SagValidationError
from zleap.sag.models.base import pipelineBaseModel
from zleap.sag.pipeline.options import ExtractionLimits, RelatedEventContextOptions


class ExtractionWritePlan(pipelineBaseModel):
    """由 local/saas 写入规则派生的不可变向量计划。"""

    model_config = ConfigDict(frozen=True, extra="forbid")

    write_event_vectors: bool
    write_event_title_vectors: bool
    write_entity_index: bool
    write_entity_vectors: bool
    write_event_entity_vectors: bool

    @classmethod
    def from_storage_mode(
        cls,
        storage_mode: Literal["normal", "lite"],
        *,
        write_entity_vectors: bool | None = None,
        write_event_entity_vectors: bool = True,
    ) -> ExtractionWritePlan:
        """由 storage_mode 派生写入计划。

        normal 模式允许调用方关闭实体向量；实体元数据仍会写入。事项-实体
        关联向量也可关闭：该索引每个
        事项-实体关联都要单独生成一次 embedding（关联数通常是事项数的十几倍），
        而只有生产搜索执行器会读它。复现外部基准时可以关掉它
        以省下大半的 embedding 调用，其余各项仍严格由 manifest 决定。
        """
        if storage_mode == "normal":
            return cls(
                write_event_vectors=True,
                write_event_title_vectors=True,
                write_entity_index=True,
                write_entity_vectors=(
                    True if write_entity_vectors is None else write_entity_vectors
                ),
                write_event_entity_vectors=write_event_entity_vectors,
            )
        return cls(
            write_event_vectors=True,
            write_event_title_vectors=False,
            write_entity_index=True,
            write_entity_vectors=False,
            write_event_entity_vectors=write_event_entity_vectors,
        )


class ExtractBaseConfig(pipelineBaseModel):
    """Internal execution config; all public semantics come from ExtractionOptions."""

    model_config = ConfigDict(extra="forbid")

    storage_mode: Literal["normal", "lite"] = Field(..., exclude=True)
    write_plan: ExtractionWritePlan

    max_concurrency: int = Field(default=5, ge=1, le=100)
    request_rejection_retries: int = Field(default=1, ge=0, le=2)
    request_recovery_min_chars: int = Field(default=400, ge=100, le=10_000)
    embedding_batch_size: int = Field(default=10, ge=1, le=100)
    vector_batch_size: int = Field(default=50, ge=1, le=500)
    # 落库阶段批间并发上限。必须不超过引擎 governor 的对应限额，否则多余的
    # 批只会在 governor 信号量上排队，超过 acquire 超时后被误判为资源耗尽。
    # 默认 1 保持历史串行行为；平台适配层从 RuntimeLimits 填充真实值。
    embedding_concurrency: int = Field(default=1, ge=1, le=64)
    vector_write_concurrency: int = Field(default=1, ge=1, le=64)
    embedding_max_length: int = Field(default=500, ge=100, le=1_000)
    chunk_min_length: int = Field(default=20, ge=0)
    filter_image_sections: bool = False

    related_events: RelatedEventContextOptions = Field(default_factory=RelatedEventContextOptions)
    timezone: str = "Asia/Shanghai"
    custom_prompt: str | None = None
    background: str | None = None
    guidance_rules: tuple[str, ...] = ()
    # 逐字复刻模式（透传自 ExtractionOptions.verbatim_prompt）
    verbatim_prompt: bool = False
    # 抽取合同模式（透传自 ExtractionOptions.contract）。它与 storage_mode 无关：合同决定
    # LLM 输出哪些字段，storage_mode 决定向量怎么落盘。刻意不用 lite/normal，避免混淆。
    contract: Literal["minimal", "rich"] = "rich"
    # Event-local violations may be dropped; parent-summary requests stay strict.
    on_contract_violation: Literal["raise", "drop_event"] = "raise"
    # 与 custom_prompt 同源的 few-shot 示例；verbatim 模式下必须与提示词配套，
    # 否则内置示例会与外部提示词的事项/实体约定冲突。
    custom_examples: tuple[tuple[str, str], ...] = ()
    limits: ExtractionLimits = Field(default_factory=ExtractionLimits)
    max_retries: int = Field(default=5, ge=0, le=10)

    enable_article_summary: bool = False
    enable_parent_summary: bool = False
    parent_summary_token_budget: int = Field(default=18_000, ge=500, le=100_000)

    @model_validator(mode="after")
    def _validate_write_plan(self) -> ExtractBaseConfig:
        # normal 的实体向量与两个模式的事项-实体关联向量允许显式关闭；
        # 其余各项必须与 manifest 一致。
        expected = ExtractionWritePlan.from_storage_mode(
            self.storage_mode,
            write_entity_vectors=self.write_plan.write_entity_vectors,
            write_event_entity_vectors=self.write_plan.write_event_entity_vectors,
        )
        if self.write_plan != expected:
            raise SagValidationError("write_plan 必须由 storage_mode 对应的 manifest 派生")
        return self


class ExtractConfig(ExtractBaseConfig):
    """Execution config combined with an adapter-resolved persisted source identity."""

    data_source_id: str
    source_type: Literal["ARTICLE", "CHAT", "RECORDING"]
    source_id: str
    source_version: str
    chunk_ids: tuple[str, ...] = Field(min_length=1)
    # Present only for the durable managed lifecycle.  It is deliberately an
    # internal adapter-resolved value rather than a caller-controlled option.
    generation_id: str | None = None
    # Durable replay fixes the prompt's clock to the extraction task's first run.
    reference_time: str | None = None
