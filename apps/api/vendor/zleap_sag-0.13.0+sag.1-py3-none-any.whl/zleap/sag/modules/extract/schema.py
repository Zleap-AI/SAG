"""Canonical response schema and semantic validation for Extract."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Annotated, Any, Literal

import jsonschema
from pydantic import ConfigDict, Field, ValidationError, field_validator

from zleap.sag.exceptions import ErrorCode, ExtractError, InvalidInputError
from zleap.sag.exceptions import ValidationError as SagValidationError
from zleap.sag.validation import SagBaseModel

StrictReference = Annotated[int, Field(strict=True, ge=1)]


class _ExtractionModel(SagBaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ExtractedEntity(_ExtractionModel):
    type: str = Field(min_length=1, max_length=200)
    name: str = Field(min_length=1, max_length=2_000)
    description: str = Field(min_length=1, max_length=10_000)

    @field_validator("type", "name", "description", mode="before")
    @classmethod
    def _strip_text(cls, value: object) -> object:
        return value.strip() if isinstance(value, str) else value


class ExtractedEvent(_ExtractionModel):
    # minimal 契约：只保留 title/content/entities/is_valid。summary/category/keywords/
    # priority/status/references 已移除，配合 extra="forbid" 使模型无法再输出这些字段。
    title: str = Field(min_length=1, max_length=5_000)
    content: str = Field(min_length=1, max_length=100_000)
    entities: tuple[ExtractedEntity, ...] = ()
    is_valid: bool = True
    # children 保留可选：SAG-Benchmark 复现为单扁平事件不使用，但父事项功能依赖它。
    children: tuple[ExtractedEvent, ...] = ()

    @field_validator("title", "content", mode="before")
    @classmethod
    def _strip_text(cls, value: object) -> object:
        return value.strip() if isinstance(value, str) else value


class FullExtractedEvent(_ExtractionModel):
    # rich 契约：在 minimal 基础上仅增加 summary、reason、references。
    # reason 作为第一个字段——模型先推理再抽取，且仅用于审计，不落库（见 parser.py）。
    reason: str = Field(min_length=1, max_length=10_000)
    title: str = Field(min_length=1, max_length=5_000)
    summary: str = Field(default="", max_length=20_000)
    content: str = Field(min_length=1, max_length=100_000)
    references: tuple[StrictReference, ...]
    entities: tuple[ExtractedEntity, ...] = ()
    is_valid: bool = True
    children: tuple[FullExtractedEvent, ...] = ()

    @field_validator("reason", "title", "summary", "content", mode="before")
    @classmethod
    def _strip_text(cls, value: object) -> object:
        return value.strip() if isinstance(value, str) else value


class ExtractionResponseData(_ExtractionModel):
    # Only ``items`` belongs to the canonical extraction contract. Provider-specific
    # metadata (for example ``meta`` or a misplaced ``confidence``) is intentionally
    # ignored because it is not consumed by the extraction pipeline.
    model_config = ConfigDict(extra="ignore", frozen=True)

    items: tuple[ExtractedEvent, ...]


class ExtractionResponse(_ExtractionModel):
    type: Literal["response"]
    data: ExtractionResponseData


class FullExtractionResponseData(_ExtractionModel):
    # rich 契约不接受 meta/confidence 等额外字段（与 minimal 的 extra="ignore" 不同）。
    items: tuple[FullExtractedEvent, ...]


class FullExtractionResponse(_ExtractionModel):
    type: Literal["response"]
    data: FullExtractionResponseData


# Validate only the envelope first, so one malformed event cannot reject siblings.
# Inheritance preserves minimal/rich extra-field policies without changing the
# provider-facing response schemas.
class _RawResponseData(ExtractionResponseData):
    items: tuple[Any, ...]


class _RawResponse(ExtractionResponse):
    data: _RawResponseData


class _RawFullResponseData(FullExtractionResponseData):
    items: tuple[Any, ...]


class _RawFullResponse(FullExtractionResponse):
    data: _RawFullResponseData


# 抽取合同模式与 storage_mode 无关：合同决定 LLM 输出哪些字段，storage_mode 决定
# 向量怎么落盘。刻意不用 lite/normal，避免与存储层混淆。
ExtractionMode = Literal["minimal", "rich"]

_MODE_RESPONSE: dict[str, type[Any]] = {
    "minimal": ExtractionResponse,
    "rich": FullExtractionResponse,
}


class ExtractionValidationIssue(_ExtractionModel):
    code: str
    path: str
    message: str
    expected: Any = None
    actual: Any = None


@dataclass
class ExtractionValidationReport:
    """Audit of a drop_event validation pass; paths refer to the original payload.

    Counts cover all input nodes, including is_valid=False nodes and descendants
    beyond max_depth. Samples are bounded and never contain event text.
    """

    events_seen: int = 0
    events_kept: int = 0
    events_dropped: int = 0
    events_promoted: int = 0
    issue_counts: dict[str, int] = field(default_factory=dict)
    issues: list[ExtractionValidationIssue] = field(default_factory=list)

    def record_drop(self, issues: Iterable[ExtractionValidationIssue]) -> None:
        self.events_dropped += 1
        for issue in issues:
            self.issue_counts[issue.code] = self.issue_counts.get(issue.code, 0) + 1
            if len(self.issues) < 20:
                self.issues.append(issue)


class ExtractionValidationError(ExtractError):
    """A bounded set of model-repairable extraction validation issues."""

    _code = ErrorCode.EXTRACTION_VALIDATION
    _stage = "extract"

    def __init__(
        self,
        issues: Iterable[ExtractionValidationIssue],
        *,
        cause: BaseException | None = None,
    ) -> None:
        self.issues = tuple(issues)
        summary = "; ".join(f"{issue.path}: {issue.message}" for issue in self.issues[:5])
        super().__init__(
            summary or "提取响应不符合合同",
            details={"issues": [issue.model_dump(mode="json") for issue in self.issues]},
            cause=cause,
        )


def extraction_response_schema(
    mode: ExtractionMode = "rich",
    *,
    input_item_count: int | None = None,
    parent: bool = False,
) -> dict[str, Any]:
    """Return the provider-neutral JSON schema for the requested contract mode.

    ``references`` points at the current request's 1-based input item IDs.  The
    upper bound is therefore a runtime constraint, not a static model field.  Put
    it into the provider schema as well as the semantic validator so structured
    output providers can prevent invalid references during generation.
    """
    if input_item_count is not None and input_item_count < 0:
        raise InvalidInputError("input_item_count must be greater than or equal to zero")

    schema = _MODE_RESPONSE[mode].model_json_schema()
    if mode != "rich" or input_item_count is None:
        return schema

    event_schema = schema["$defs"]["FullExtractedEvent"]
    references_schema = event_schema["properties"]["references"]
    # Some OpenAI-compatible grammar compilers reject JSON Schema uniqueItems.
    # Duplicate references remain mandatory local validation below.
    if parent:
        references_schema["maxItems"] = 0
        references_schema["description"] = (
            "Parent events do not directly reference input chunks; return an empty array."
        )
    else:
        references_schema["minItems"] = 1
        references_schema["items"]["maximum"] = input_item_count
        references_schema["description"] = (
            "Non-empty unique 1-based IDs from the current data.items only; "
            f"the only valid range for this request is 1..{input_item_count}."
        )
    return schema


def _path_from_location(location: tuple[str | int, ...]) -> str:
    path = "$"
    for part in location:
        if isinstance(part, int):
            path += f"[{part}]"
        else:
            path += f".{part}"
    return path


def _schema_issues(
    exc: ValidationError | SagValidationError,
) -> list[ExtractionValidationIssue]:
    if isinstance(exc, SagValidationError):
        errors = exc.details.get("errors", ())
    else:
        errors = exc.errors(
            include_url=False,
            include_context=False,
            include_input=False,
        )

    return [
        ExtractionValidationIssue(
            code=f"schema_{error['type']}",
            path=_path_from_location(tuple(error["loc"])),
            message="Input validation failed",
        )
        for error in errors
    ]


def _walk_events(
    events: tuple[ExtractedEvent | FullExtractedEvent, ...],
    *,
    path: str = "$.data.items",
    depth: int = 0,
) -> Iterable[tuple[ExtractedEvent | FullExtractedEvent, str, int]]:
    for index, event in enumerate(events):
        event_path = f"{path}[{index}]"
        yield event, event_path, depth
        yield from _walk_events(
            event.children,
            path=f"{event_path}.children",
            depth=depth + 1,
        )


def _truncate_event_entities(
    event: ExtractedEvent | FullExtractedEvent,
    *,
    max_entities: int,
) -> ExtractedEvent | FullExtractedEvent:
    """Keep entity output bounded while preserving the model's original order."""
    children = tuple(
        _truncate_event_entities(child, max_entities=max_entities) for child in event.children
    )
    updates: dict[str, Any] = {}
    if len(event.entities) > max_entities:
        updates["entities"] = event.entities[:max_entities]
    if any(new is not old for new, old in zip(children, event.children, strict=True)):
        updates["children"] = children
    return event.model_copy(update=updates) if updates else event


def _truncate_response_entities(
    response: ExtractionResponse | FullExtractionResponse,
    *,
    max_entities: int,
) -> ExtractionResponse | FullExtractionResponse:
    items = tuple(
        _truncate_event_entities(event, max_entities=max_entities) for event in response.data.items
    )
    if all(new is old for new, old in zip(items, response.data.items, strict=True)):
        return response
    data = response.data.model_copy(update={"items": items})
    return response.model_copy(update={"data": data})


def _repair_rich_references(payload: Any, *, input_item_count: int) -> Any:
    """Copy event containers and remove only out-of-range integer references.

    Leave malformed containers/types and duplicate IDs for normal validation.
    Iterative traversal also preserves drop_event's handling of deep bad trees.
    """
    if isinstance(payload, FullExtractionResponse):
        payload = payload.model_dump()
    if not isinstance(payload, dict):
        return payload
    data = payload.get("data")
    if isinstance(data, FullExtractionResponseData):
        data = data.model_dump()
    if not isinstance(data, dict) or not isinstance(data.get("items"), (list, tuple)):
        return payload

    items = list(data["items"])
    result = {**payload, "data": {**data, "items": items}}
    pending = [items]
    while pending:
        siblings = pending.pop()
        for index, raw in enumerate(siblings):
            if isinstance(raw, FullExtractedEvent):
                raw = raw.model_dump()
            if not isinstance(raw, dict):
                continue
            event = dict(raw)
            siblings[index] = event
            references = event.get("references")
            if isinstance(references, (list, tuple)):
                event["references"] = [
                    reference
                    for reference in references
                    if type(reference) is not int or 1 <= reference <= input_item_count
                ]
            children = event.get("children")
            if isinstance(children, (list, tuple)):
                event["children"] = list(children)
                pending.append(event["children"])
    return result


def validate_extraction_response(
    payload: Any,
    *,
    input_item_count: int,
    max_events: int,
    min_entities: int,
    max_entities: int,
    valid_entity_types: set[str] | None = None,
    max_depth: int = 2,
    parent: bool = False,
    mode: ExtractionMode = "rich",
    on_contract_violation: Literal["raise", "drop_event"] = "raise",
    report: ExtractionValidationReport | None = None,
    response_schema: dict[str, Any] | None = None,
) -> ExtractionResponse | FullExtractionResponse:
    """Validate the response schema plus event/entity limits before ORM creation.

    - minimal：无 references/reason，忽略多余字段（meta 等）。
    - rich：先删除越界整数引用，再要求 references（非空、唯一）与 reason；
      ``input_item_count`` 仅在 rich 模式参与校验。
    - drop_event：逐事件隔离错误，保留合法子事件并提升；外壳、批级约束和父摘要仍严格。
      可传入新的 ``report`` 收集原始路径与计数；不改变返回响应结构。
    - response_schema：严格模式下在修复后补做客户端推迟的 JSON Schema 校验。
    """
    if on_contract_violation not in ("raise", "drop_event"):
        raise InvalidInputError("on_contract_violation must be raise or drop_event")
    if input_item_count < 1:
        raise InvalidInputError("input_item_count must be greater than or equal to 1")
    if mode == "rich" and not parent:
        payload = _repair_rich_references(payload, input_item_count=input_item_count)
    # A parent summary must yield exactly one valid root; dropping it would only
    # defer failure to _build_parent_event, outside the repair loop.
    if on_contract_violation == "drop_event" and not parent:
        return _filter_response_events(
            payload,
            input_item_count=input_item_count,
            max_events=max_events,
            min_entities=min_entities,
            max_entities=max_entities,
            valid_entity_types=valid_entity_types,
            max_depth=max_depth,
            mode=mode,
            report=report if report is not None else ExtractionValidationReport(),
        )
    try:
        response = _MODE_RESPONSE[mode].model_validate(payload)
    except SagValidationError as exc:
        raise ExtractionValidationError(_schema_issues(exc), cause=exc) from exc

    response = _truncate_response_entities(response, max_entities=max_entities)
    issues: list[ExtractionValidationIssue] = []
    valid_events = [
        (event, path, depth)
        for event, path, depth in _walk_events(response.data.items)
        if event.is_valid
    ]

    if parent:
        if len(response.data.items) != 1:
            issues.append(
                ExtractionValidationIssue(
                    code="parent_event_count",
                    path="$.data.items",
                    message="父事项必须恰好包含一个顶层事项",
                    expected=1,
                    actual=len(response.data.items),
                )
            )
        elif not response.data.items[0].is_valid:
            issues.append(
                ExtractionValidationIssue(
                    code="parent_event_invalid",
                    path="$.data.items[0].is_valid",
                    message="父事项必须是有效事项",
                    expected=True,
                    actual=False,
                )
            )
    elif len(valid_events) > max_events:
        issues.append(
            ExtractionValidationIssue(
                code="max_events_exceeded",
                path="$.data.items",
                message=f"有效事项最多 {max_events} 个",
                expected=max_events,
                actual=len(valid_events),
            )
        )

    for event, path, depth in valid_events:
        if depth > max_depth:
            issues.append(
                ExtractionValidationIssue(
                    code="max_depth_exceeded",
                    path=path,
                    message=f"事项层级最多为 {max_depth}",
                    expected=max_depth,
                    actual=depth,
                )
            )

        if parent and event.children:
            issues.append(
                ExtractionValidationIssue(
                    code="parent_children_not_empty",
                    path=f"{path}.children",
                    message="父事项响应不能再包含 children",
                    expected=[],
                    actual=len(event.children),
                )
            )

        # rich 契约恢复 references 校验：父事项不得引用，普通事项必须非空、唯一、1-based。
        if mode == "rich" and isinstance(event, FullExtractedEvent):
            references = event.references
            if parent:
                if references:
                    issues.append(
                        ExtractionValidationIssue(
                            code="parent_references_not_empty",
                            path=f"{path}.references",
                            message="父事项不能引用具体 Chunk 输入片段",
                            expected=[],
                            actual=list(references),
                        )
                    )
            elif not references:
                issues.append(
                    ExtractionValidationIssue(
                        code="references_empty",
                        path=f"{path}.references",
                        message="有效事项必须至少引用一个输入片段",
                        expected=f"1..{input_item_count}",
                        actual=[],
                    )
                )
            elif len(set(references)) != len(references):
                issues.append(
                    ExtractionValidationIssue(
                        code="references_duplicate",
                        path=f"{path}.references",
                        message="引用序号不能重复",
                        expected="unique integers",
                        actual=list(references),
                    )
                )
            for reference_index, reference in enumerate(references):
                if reference > input_item_count:
                    issues.append(
                        ExtractionValidationIssue(
                            code="reference_out_of_range",
                            path=f"{path}.references[{reference_index}]",
                            message=f"引用必须位于 1..{input_item_count}",
                            expected=f"1..{input_item_count}",
                            actual=reference,
                        )
                    )

        known_entities = (
            event.entities
            if valid_entity_types is None
            else tuple(entity for entity in event.entities if entity.type in valid_entity_types)
        )
        entity_count = len(known_entities)
        if entity_count < min_entities or entity_count > max_entities:
            issues.append(
                ExtractionValidationIssue(
                    code="entity_count_out_of_range",
                    path=f"{path}.entities",
                    message=f"有效实体数量必须位于 {min_entities}..{max_entities}",
                    expected=f"{min_entities}..{max_entities}",
                    actual=entity_count,
                )
            )

    if issues:
        raise ExtractionValidationError(issues[:20])
    if response_schema is not None:
        # Validate repaired raw values, not Pydantic-coerced values: moving the
        # client's check must not accept e.g. is_valid="true" as a JSON boolean.
        try:
            jsonschema.validate(instance=payload, schema=response_schema)
        except jsonschema.ValidationError as exc:
            raise ExtractionValidationError(
                [
                    ExtractionValidationIssue(
                        code=f"schema_{exc.validator}",
                        path=_path_from_location(tuple(exc.absolute_path)),
                        message="Input validation failed",
                    )
                ],
                cause=exc,
            ) from exc
    return response


def _filter_response_events(
    payload: Any,
    *,
    input_item_count: int,
    max_events: int,
    min_entities: int,
    max_entities: int,
    valid_entity_types: set[str] | None,
    max_depth: int,
    mode: ExtractionMode,
    report: ExtractionValidationReport,
) -> ExtractionResponse | FullExtractionResponse:
    envelope_model = _RawResponse if mode == "minimal" else _RawFullResponse
    event_model = ExtractedEvent if mode == "minimal" else FullExtractedEvent
    try:
        envelope = envelope_model.model_validate(payload)
    except SagValidationError as exc:
        raise ExtractionValidationError(_schema_issues(exc), cause=exc) from exc

    output: list[dict[str, Any]] = []
    # Iterative preorder retains source order and avoids Python recursion on a
    # deeply nested invalid tree. Original depth applies even after promotion.
    pending = [
        (raw, f"$.data.items[{index}]", 0, output, False)
        for index, raw in reversed(list(enumerate(envelope.data.items)))
    ]
    while pending:
        raw, path, depth, destination, parent_dropped = pending.pop()
        report.events_seen += 1
        children = raw.get("children", ()) if isinstance(raw, dict) else ()
        child_items = children if isinstance(children, (list, tuple)) else ()
        own = {**raw, "children": []} if isinstance(raw, dict) else raw
        # A malformed children container is still a violation of this event.
        if isinstance(own, dict) and not isinstance(children, (list, tuple)):
            own["children"] = children
        try:
            if depth > max_depth:
                raise ExtractionValidationError(
                    [
                        ExtractionValidationIssue(
                            code="max_depth_exceeded",
                            path="$",
                            message=f"事项层级最多为 {max_depth}",
                            expected=max_depth,
                            actual=depth,
                        )
                    ]
                )
            event = event_model.model_validate(own)
            if not event.is_valid:
                raise ExtractionValidationError(
                    [
                        ExtractionValidationIssue(
                            code="event_marked_invalid",
                            path="$.is_valid",
                            message="模型标记为无效事项",
                            expected=True,
                            actual=False,
                        )
                    ]
                )
            # Filter before truncation: unknown types must not consume the quota.
            entities = tuple(
                entity
                for entity in event.entities
                if valid_entity_types is None or entity.type in valid_entity_types
            )[:max_entities]
            event = event.model_copy(update={"entities": entities})
            try:
                validated = validate_extraction_response(
                    {"type": "response", "data": {"items": [event]}},
                    max_events=1,
                    input_item_count=input_item_count,
                    min_entities=min_entities,
                    max_entities=max_entities,
                    valid_entity_types=valid_entity_types,
                    max_depth=max_depth,
                    mode=mode,
                )
            except ExtractionValidationError as exc:
                # The strict validator sees a singleton; restore node-relative paths.
                raise ExtractionValidationError(
                    [
                        issue.model_copy(
                            update={"path": issue.path.replace("$.data.items[0]", "$", 1)}
                        )
                        for issue in exc.issues
                    ]
                ) from exc
        except (SagValidationError, ExtractionValidationError) as exc:
            issues = (
                exc.issues if isinstance(exc, ExtractionValidationError) else _schema_issues(exc)
            )
            report.record_drop(
                issue.model_copy(update={"path": path + issue.path[1:]}) for issue in issues
            )
            child_destination = destination
            dropped = True
        else:
            kept = validated.data.items[0].model_dump(mode="json")
            destination.append(kept)
            report.events_kept += 1
            report.events_promoted += int(parent_dropped)
            child_destination = kept["children"]
            dropped = False
        pending.extend(
            (child, f"{path}.children[{index}]", depth + 1, child_destination, dropped)
            for index, child in reversed(list(enumerate(child_items)))
        )

    # Global constraints (notably max_events) remain strict. All survivors are
    # revalidated together before any ORM object is constructed.
    return validate_extraction_response(
        {"type": "response", "data": {"items": output}},
        max_events=max_events,
        input_item_count=input_item_count,
        min_entities=min_entities,
        max_entities=max_entities,
        valid_entity_types=valid_entity_types,
        max_depth=max_depth,
        mode=mode,
    )


def response_to_dict(response: ExtractionResponse | FullExtractionResponse) -> dict[str, Any]:
    return response.model_dump(mode="json")
