"""Strict bilingual Prompt registry and composer for Extract."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Literal

import yaml

from zleap.sag.exceptions import PromptError
from zleap.sag.modules.extract.schema import ExtractionValidationIssue


class ExtractionPromptRole(StrEnum):
    DOCUMENT = "document"
    CHAT = "chat"
    RECORDING = "recording"
    PARENT = "parent"


@dataclass(frozen=True)
class ExtractionPromptDefinition:
    role: ExtractionPromptRole
    language: str
    version: str
    template: str
    example_input: str
    example_output: str


@dataclass(frozen=True)
class ComposedExtractionPrompt:
    role: ExtractionPromptRole
    language: str
    version: str
    system_prompt: str
    example_input: str
    example_output: str
    fingerprint: str
    # 多组 few-shot，按顺序展开成 user/assistant 消息对。单对示例也会归一化进这里，
    # 因此 _build_messages 只需读这一个字段；example_input/example_output 保留为
    # 首组示例，供既有调用方与测试断言。
    examples: tuple[tuple[str, str], ...] = ()


class ExtractionPromptRegistry:
    """Loads an exact language/role pair; Extract never cross-language-falls back."""

    def __init__(self, prompts_dir: Path, language: str) -> None:
        self.prompts_dir = Path(prompts_dir)
        self.language = language
        if language not in {"zh", "en"}:
            raise PromptError(f"Extract 不支持提示词语言: {language}")

    @classmethod
    def from_prompt_manager(cls, prompt_manager: Any) -> ExtractionPromptRegistry:
        return cls(
            prompts_dir=Path(prompt_manager.prompts_dir),
            language=str(prompt_manager.language),
        )

    def load(self, role: ExtractionPromptRole) -> ExtractionPromptDefinition:
        directory = self.prompts_dir if self.language == "zh" else self.prompts_dir / self.language
        path = directory / f"extract_{role.value}.yaml"
        if not path.is_file():
            raise PromptError(
                f"Extract 提示词缺失: language={self.language}, role={role.value}, path={path}"
            )
        with path.open("r", encoding="utf-8") as stream:
            payload = yaml.safe_load(stream)
        key = f"extract_{role.value}"
        config = payload.get(key) if isinstance(payload, dict) else None
        if not isinstance(config, dict):
            raise PromptError(f"Extract 提示词结构无效: {path}")
        template = config.get("template")
        version = config.get("version")
        examples = config.get("examples") or {}
        if not isinstance(template, str) or not template.strip():
            raise PromptError(f"Extract 提示词 template 为空: {path}")
        if not isinstance(version, str) or not version.strip():
            raise PromptError(f"Extract 提示词 version 为空: {path}")
        if not isinstance(examples, dict):
            raise PromptError(f"Extract 提示词 examples 无效: {path}")
        return ExtractionPromptDefinition(
            role=role,
            language=self.language,
            version=version.strip(),
            template=template.strip(),
            example_input=str(examples.get("input") or "").strip(),
            example_output=str(examples.get("output") or "").strip(),
        )

    def validate_all(self) -> None:
        for role in ExtractionPromptRole:
            self.load(role)


def prompt_role_for_source_type(source_type: str) -> ExtractionPromptRole:
    normalized = source_type.upper()
    if normalized in {"ARTICLE", "TEXT"}:
        return ExtractionPromptRole.DOCUMENT
    if normalized == "CHAT":
        return ExtractionPromptRole.CHAT
    if normalized == "RECORDING":
        return ExtractionPromptRole.RECORDING
    raise PromptError(f"Extract 不支持来源类型: {source_type}")


#: rich 契约独有、minimal 的封闭 schema（``extra="forbid"``）不接受的事项字段。
_RICH_ONLY_EVENT_FIELDS = ("reason", "summary", "references")

#: 模板里按契约分支的块标记。开标记可以连写成分支链（rich 段紧接 minimal 段），
#: 由单个 ``# [[/]]`` 收尾；标记行本身不会进入 system prompt。
_MODE_BLOCK_OPEN = {"# [[rich]]": "rich", "# [[minimal]]": "minimal"}
_MODE_BLOCK_CLOSE = "# [[/]]"
_MODE_BLOCK_MARKERS = frozenset({*_MODE_BLOCK_OPEN, _MODE_BLOCK_CLOSE})


def select_mode_blocks(template: str, mode: str) -> str:
    """按契约模式裁剪模板中的分支块。

    rich 与 minimal 的输出字段不同（见 ``_RICH_ONLY_EVENT_FIELDS``），模板里凡是
    指示模型**输出**这些字段的行都必须分模式各写一份 —— 否则 minimal 下模板正文仍在
    要求 summary/references，与 minimal 合同文本和封闭 schema 自相矛盾，模型跟着更长的
    正文走就会触发 ``schema_extra_forbidden`` 重试直至耗尽。

    未加标记的内容对两种模式都保留。标记不闭合或模式名重复时抛 ``PromptError``：
    这类错误会让整个角色的提示词静默走错分支，必须在组装阶段就暴露。
    """
    lines = template.split("\n")
    if not any(line.strip() in _MODE_BLOCK_MARKERS for line in lines):
        return template

    kept: list[str] = []
    active: str | None = None
    chain_modes: set[str] = set()
    open_lineno = 0
    for lineno, line in enumerate(lines, 1):
        token = line.strip()
        if token in _MODE_BLOCK_OPEN:
            branch = _MODE_BLOCK_OPEN[token]
            if branch in chain_modes:
                raise PromptError(
                    f"Extract 提示词模板第 {lineno} 行重复声明 {token} 分支"
                    f"（同一分支链已在第 {open_lineno} 行前出现）"
                )
            chain_modes.add(branch)
            active = branch
            open_lineno = lineno
            continue
        if token == _MODE_BLOCK_CLOSE:
            if active is None:
                raise PromptError(f"Extract 提示词模板第 {lineno} 行的 {token} 没有对应的开标记")
            active = None
            chain_modes.clear()
            continue
        if active is None or active == mode:
            kept.append(line)
    if active is not None:
        raise PromptError(
            f"Extract 提示词模板第 {open_lineno} 行的分支块未闭合，缺少 {_MODE_BLOCK_CLOSE}"
        )
    return "\n".join(kept).strip()


def project_example_output_to_minimal(example_output: str) -> str:
    """把 rich 形状的 gold 示例投影成 minimal 形状。

    YAML 只维护一份 rich 示例，minimal 由此函数剥掉 reason/summary/references，
    使 few-shot 与 minimal 的封闭 schema 一致。minimal 的合同文本已显式列出允许字段并
    禁止合同外字段，实测 qwen3.6-flash / gpt-4o-mini 都不会照抄示例里的多余字段；
    这里的投影是消除"示例与指令互相矛盾"的加固，在合同文本被削弱或换用更弱的模型
    时才是必需的。无法解析时原样返回，让既有的响应校验去报错，而不是在组装提示词
    阶段就抛异常。
    """
    if not example_output:
        return example_output
    try:
        payload = json.loads(example_output)
    except json.JSONDecodeError:
        return example_output
    if not isinstance(payload, dict):
        return example_output
    data = payload.get("data")
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        return example_output
    data["items"] = [_strip_rich_only_fields(item) for item in data["items"]]
    return json.dumps(payload, ensure_ascii=False, indent=2)


def _strip_rich_only_fields(item: Any) -> Any:
    if not isinstance(item, dict):
        return item
    stripped = {key: value for key, value in item.items() if key not in _RICH_ONLY_EVENT_FIELDS}
    children = stripped.get("children")
    if isinstance(children, list):
        stripped["children"] = [_strip_rich_only_fields(child) for child in children]
    return stripped


class ExtractionPromptComposer:
    SCHEMA_VERSION = "extraction-response-v2"

    def __init__(self, registry: ExtractionPromptRegistry) -> None:
        self.registry = registry

    def compose(
        self,
        role: ExtractionPromptRole,
        *,
        custom_prompt: str | None,
        background: str | None,
        guidance_rules: tuple[str, ...],
        timezone: str,
        current_time: str,
        max_events: int,
        min_entities: int,
        max_entities: int,
        input_item_count: int | None = None,
        verbatim_prompt: bool = False,
        custom_examples: tuple[tuple[str, str], ...] = (),
        mode: Literal["minimal", "rich"] = "rich",
    ) -> ComposedExtractionPrompt:
        definition = self.registry.load(role)
        raw_task = custom_prompt or definition.template

        if verbatim_prompt:
            # 逐字复刻不裁剪分支块：外部提示词按原样下发，标记（若有）也照原样保留。
            task = raw_task
            # 逐字复刻模式（用于复现 SAG-Benchmark 等外部成绩）：
            # - system prompt 就是调用方提供的 custom_prompt，不追加任何运行时段落；
            # - few-shot 示例必须与 custom_prompt 同源，否则内置示例会与外部提示词
            #   的约定冲突（例如内置示例输出多事项，而外部提示词强制单事项）；
            # - 不注入 Enforced limits（避免与"强制单事件"等外部提示词约定冲突）。
            if custom_prompt is None:
                raise PromptError("verbatim_prompt=True 必须同时提供 custom_prompt")
            examples = tuple((pair[0].strip(), pair[1].strip()) for pair in custom_examples)
            for index, (pair_input, pair_output) in enumerate(examples, 1):
                if not pair_input or not pair_output:
                    raise PromptError(
                        f"verbatim_prompt 的 custom_examples[{index}] 输入与输出都不能为空"
                    )
            example_input = examples[0][0] if examples else ""
            example_output = examples[0][1] if examples else ""
            system_prompt = task.strip()
            fingerprint_payload = {
                "language": definition.language,
                "role": role.value,
                "version": definition.version,
                "schema_version": self.SCHEMA_VERSION,
                "verbatim": True,
                "task": task,
                # 全部示例都进指纹：否则不同示例组会哈希碰撞，命中彼此的缓存。
                "examples": [list(pair) for pair in examples],
            }
            fingerprint = hashlib.sha256(
                json.dumps(
                    fingerprint_payload,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode("utf-8")
            ).hexdigest()
            return ComposedExtractionPrompt(
                role=role,
                language=definition.language,
                version=definition.version,
                system_prompt=system_prompt,
                example_input=example_input,
                example_output=example_output,
                fingerprint=fingerprint,
                examples=examples,
            )

        # 模板正文与输出合同使用同一模式，避免 minimal 仍要求 rich 字段。
        task = select_mode_blocks(raw_task, mode)

        # rich 恢复 references/reason；minimal 不包含这些字段。
        if mode == "rich":
            reference_range_zh = (
                f"；本次调用只允许 1..{input_item_count}，不得使用段落号、行号或其他编号"
                if input_item_count is not None
                else ""
            )
            reference_range_en = (
                f"; this request allows only 1..{input_item_count}; never use paragraph, line, "
                "or other numbering"
                if input_item_count is not None
                else ""
            )
            contract_zh = (
                "只返回 type=response、data.items 的 JSON。"
                "事项必须包含 reason、title、content、references；实体必须包含 type、name、description。"
                "不要添加 relation 等合同外字段。"
            )
            limit_zh = (
                f"- 每个 Chunk 最多 {max_events} 个有效事项\n"
                f"- 每个有效事项包含 {min_entities}..{max_entities} 个有效实体\n"
                "- 普通事项 references 必须是当前输入 items 的非空、唯一、1-based id"
                f"{reference_range_zh}"
            )
            contract_en = (
                "Return JSON only with type=response and data.items. "
                "Events require reason, title, content, and references; entities require type, "
                "name, and description. Do not add contract-specific fields such as relation."
            )
            limit_en = (
                f"- At most {max_events} valid events per Chunk\n"
                f"- Each valid event has {min_entities}..{max_entities} valid entities\n"
                "- Normal event references are non-empty, unique, 1-based input item IDs"
                f"{reference_range_en}"
            )
        else:
            contract_zh = (
                "只返回 type=response、data.items 的 JSON。"
                "事项必须包含 title、content、entities、is_valid；实体必须包含 type、name、description。"
                "不要添加 relation 等合同外字段。"
            )
            limit_zh = (
                f"- 每个 Chunk 最多 {max_events} 个有效事项\n"
                f"- 每个有效事项包含 {min_entities}..{max_entities} 个有效实体"
            )
            contract_en = (
                "Return JSON only with type=response and data.items. "
                "Events require title, content, entities, and is_valid; entities require type, "
                "name, and description. Do not add contract-specific fields such as relation."
            )
            limit_en = (
                f"- At most {max_events} valid events per Chunk\n"
                f"- Each valid event has {min_entities}..{max_entities} valid entities"
            )

        if definition.language == "zh":
            sections = [
                task,
                "## 运行上下文",
                f"- 时区：{timezone}",
                f"- 当前时间：{current_time}",
                f"- 背景：{background or '无额外背景'}",
                "## 调用方指导规则",
                self._numbered_rules(guidance_rules, empty="无额外规则"),
                "## 统一输出合同",
                contract_zh,
                "## 代码强制限制",
                limit_zh,
            ]
        else:
            sections = [
                task,
                "## Runtime context",
                f"- Timezone: {timezone}",
                f"- Current time: {current_time}",
                f"- Background: {background or 'No additional background'}",
                "## Caller guidance",
                self._numbered_rules(guidance_rules, empty="No additional rules"),
                "## Canonical output contract",
                contract_en,
                "## Enforced limits",
                limit_en,
            ]
        system_prompt = "\n\n".join(sections)
        role_fingerprint_payload: dict[str, object] = {
            "language": definition.language,
            "role": role.value,
            "version": definition.version,
            "schema_version": self.SCHEMA_VERSION,
            "task": task,
            "background": background,
            "guidance_rules": guidance_rules,
            "timezone": timezone,
            "limits": [max_events, min_entities, max_entities],
            "input_item_count": input_item_count,
            "mode": mode,
        }
        fingerprint = hashlib.sha256(
            json.dumps(
                role_fingerprint_payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
        ).hexdigest()
        # 调用方显式提供 custom_examples 时优先使用；否则在 use_examples 条件满足时
        # 使用 YAML 自带示例（parent 或默认 limits）。
        use_examples = custom_prompt is None and (
            role is ExtractionPromptRole.PARENT
            or (max_events, min_entities, max_entities) == (20, 1, 20)
        )

        def _project(example_output: str) -> str:
            # 内置示例与调用方示例都按 rich 形状维护（YAML gold 是唯一维护的形状），
            # minimal 下统一投影掉 reason/summary/references，与 extra="forbid" 保持一致。
            return (
                project_example_output_to_minimal(example_output)
                if mode == "minimal"
                else example_output
            )

        if custom_examples:
            examples = tuple(
                (pair[0].strip(), _project(pair[1].strip())) for pair in custom_examples
            )
        elif use_examples:
            examples = ((definition.example_input, _project(definition.example_output)),)
        else:
            examples = ()
        builtin_input = examples[0][0] if examples else ""
        builtin_output = examples[0][1] if examples else ""
        return ComposedExtractionPrompt(
            role=role,
            language=definition.language,
            version=definition.version,
            system_prompt=system_prompt,
            example_input=builtin_input,
            example_output=builtin_output,
            fingerprint=fingerprint,
            examples=examples,
        )

    @staticmethod
    def _numbered_rules(rules: tuple[str, ...], *, empty: str) -> str:
        if not rules:
            return empty
        return "\n".join(f"{index}. {rule}" for index, rule in enumerate(rules, 1))


def build_repair_message(
    issues: tuple[ExtractionValidationIssue, ...],
    *,
    language: str,
) -> str:
    """Build a bounded, non-secret validation repair request."""
    rows = []
    for index, issue in enumerate(issues[:20], 1):
        expected = json.dumps(issue.expected, ensure_ascii=False, default=str)[:500]
        actual = json.dumps(issue.actual, ensure_ascii=False, default=str)[:500]
        rows.append(f"{index}. {issue.path}: {issue.message}; expected={expected}; actual={actual}")
    if language == "zh":
        header = "上一次输出不符合提取合同。请完整重新生成 JSON，只修复以下问题："
        footer = "不要解释，不要使用 Markdown，不要改变输入事实。"
    else:
        header = (
            "The previous output violated the extraction contract. Regenerate the complete JSON "
            "and fix only these issues:"
        )
        footer = "Do not explain, use Markdown, or alter the input facts."
    return "\n".join([header, *rows, footer])
