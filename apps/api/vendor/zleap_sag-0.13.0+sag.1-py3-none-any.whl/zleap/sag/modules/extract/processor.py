"""LLM generation, Prompt composition, and repair validation for Extract."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any
from zoneinfo import ZoneInfo

from sqlalchemy import select

from zleap.sag.core.ai.models import LLMMessage, LLMRole
from zleap.sag.db.models import EntityType as DBEntityType
from zleap.sag.db.models import SourceEvent
from zleap.sag.exceptions import (
    ConfigError,
    ExtractError,
    LLMError,
    LLMStructuredOutputError,
    StateError,
)
from zleap.sag.modules.extract.config import ExtractConfig
from zleap.sag.modules.extract.prompts import (
    ExtractionPromptComposer,
    ExtractionPromptRegistry,
    ExtractionPromptRole,
    build_repair_message,
    prompt_role_for_source_type,
)
from zleap.sag.modules.extract.schema import (
    ExtractionValidationError,
    ExtractionValidationIssue,
    ExtractionValidationReport,
    extraction_response_schema,
    response_to_dict,
    validate_extraction_response,
)
from zleap.sag.utils import get_logger

if TYPE_CHECKING:
    from zleap.sag.core.storage.repositories.event_repository import EventVectorRepository
    from zleap.sag.modules.load.processor import DocumentProcessor

logger = get_logger("extract.processor")


@dataclass
class ExtractionGenerationStats:
    generation_attempts: int = 0
    validation_retry_count: int = 0
    validation_issue_counts: dict[str, int] = field(default_factory=dict)
    prompt_role: str = ""
    prompt_fingerprint: str = ""
    entity_type_fingerprint: str = ""
    # Event counts describe successful drop_event validation passes only.
    events_seen: int = 0
    events_kept: int = 0
    events_dropped: int = 0
    events_promoted: int = 0

    def record_issues(self, issues: tuple[ExtractionValidationIssue, ...]) -> None:
        for issue in issues:
            self.validation_issue_counts[issue.code] = (
                self.validation_issue_counts.get(issue.code, 0) + 1
            )


def entity_type_contract_fingerprint(entity_types: list[DBEntityType]) -> str:
    """Hash the entity contract that influences prompting and persisted values."""
    contract = sorted(
        (
            {
                "type": str(entity_type.type),
                "name": str(entity_type.name),
                "description": str(entity_type.description or ""),
                "value_format": getattr(entity_type, "value_format", None),
                "value_constraints": getattr(entity_type, "value_constraints", None),
            }
            for entity_type in entity_types
        ),
        key=lambda item: (item["type"], item["name"]),
    )
    return hashlib.sha256(
        json.dumps(
            contract,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
    ).hexdigest()


class ExtractionRetryExhausted(ExtractError):
    def __init__(
        self,
        *,
        attempts: int,
        issues: tuple[ExtractionValidationIssue, ...],
    ) -> None:
        self.attempts = attempts
        self.issues = issues
        # 局部变量:消息与 code= 都要用,且不能在 super().__init__ 前赋 self.code(会被基类默认值覆盖)
        code = issues[0].code if issues else "extraction_retry_exhausted"
        super().__init__(
            f"提取内容校验重试耗尽: attempts={attempts}, code={code}",
            code=code,
        )


class EventProcessor:
    """Build source-specific inputs and produce canonical, validated responses."""

    def __init__(
        self,
        llm_client: Any,
        embedding: Any,
        prompt_manager: Any,
        config: ExtractConfig,
        session_factory: Any = None,
        repositories: Any = None,
    ) -> None:
        if llm_client is None or embedding is None:
            raise ConfigError("EventProcessor 需要显式注入 llm_client 和 embedding")
        self.llm_client = llm_client
        self.embedding = embedding
        self.prompt_manager = prompt_manager
        self.config = config
        if session_factory is None or repositories is None:
            raise ConfigError("EventProcessor 需要显式注入 session_factory 和 repositories")
        self.session_factory = session_factory
        self.repositories = repositories
        self.entity_types: list[DBEntityType] = []
        self.stats = ExtractionGenerationStats()
        self._event_repo: EventVectorRepository | None = None
        self._embedding_client: DocumentProcessor | None = None
        registry = ExtractionPromptRegistry.from_prompt_manager(prompt_manager)
        self._prompt_composer = ExtractionPromptComposer(registry)

    async def initialize(self, entity_types: list[DBEntityType]) -> None:
        self.entity_types = entity_types
        self.stats.entity_type_fingerprint = entity_type_contract_fingerprint(entity_types)

    async def process(
        self,
        items: list[Any],
        metadata: dict[str, Any],
        source_type: str,
        *,
        parent: bool = False,
    ) -> dict[str, Any]:
        if not items:
            return {
                "type": "response",
                "data": {"items": []},
            }

        role = ExtractionPromptRole.PARENT if parent else prompt_role_for_source_type(source_type)
        related_events = [] if parent else await self._recall_related_events(items, source_type)
        user_input = self._build_input(
            items,
            metadata,
            source_type,
            related_events,
            parent=parent,
        )
        now = self.config.reference_time or datetime.now(ZoneInfo(self.config.timezone)).strftime(
            "%Y-%m-%d %H:%M"
        )
        composed = self._prompt_composer.compose(
            role,
            custom_prompt=None if parent else self.config.custom_prompt,
            background=self.config.background,
            guidance_rules=self.config.guidance_rules,
            timezone=self.config.timezone,
            current_time=now,
            max_events=(1 if parent else self.config.limits.max_events_per_chunk),
            min_entities=self.config.limits.min_entities_per_event,
            max_entities=self.config.limits.max_entities_per_event,
            input_item_count=len(items),
            verbatim_prompt=(False if parent else self.config.verbatim_prompt),
            custom_examples=(() if parent else self.config.custom_examples),
            mode=self.config.contract,
        )
        self.stats = ExtractionGenerationStats(
            prompt_role=role.value,
            prompt_fingerprint=composed.fingerprint,
            entity_type_fingerprint=entity_type_contract_fingerprint(self.entity_types),
        )
        base_messages = self._build_messages(composed, user_input)
        schema = extraction_response_schema(
            mode=self.config.contract,
            input_item_count=len(items),
            parent=parent,
        )
        valid_types = {entity_type.type for entity_type in self.entity_types}
        last_issues: tuple[ExtractionValidationIssue, ...] = ()
        last_invalid_output = ""

        for attempt in range(self.config.max_retries + 1):
            messages = list(base_messages)
            if last_issues:
                messages.extend(
                    [
                        LLMMessage(
                            role=LLMRole.ASSISTANT,
                            content=self._bounded_invalid_output(last_invalid_output),
                        ),
                        LLMMessage(
                            role=LLMRole.USER,
                            content=build_repair_message(
                                last_issues,
                                language=composed.language,
                            ),
                        ),
                    ]
                )
            self.stats.generation_attempts += 1
            try:
                result = await self._chat_with_schema_once(
                    messages,
                    schema,
                    # Rich references must be repaired before any local schema
                    # rejection. The complete schema still goes to the provider.
                    defer_validation=not parent
                    and (
                        self.config.contract == "rich"
                        or self.config.on_contract_violation == "drop_event"
                    ),
                )
                last_invalid_output = json.dumps(result, ensure_ascii=False, default=str)
                report = ExtractionValidationReport()
                response = validate_extraction_response(
                    result,
                    input_item_count=len(items),
                    max_events=self.config.limits.max_events_per_chunk,
                    min_entities=self.config.limits.min_entities_per_event,
                    max_entities=self.config.limits.max_entities_per_event,
                    valid_entity_types=valid_types,
                    parent=parent,
                    mode=self.config.contract,
                    on_contract_violation=self.config.on_contract_violation,
                    report=report,
                    response_schema=schema if self.config.contract == "rich" else None,
                )
                self.stats.events_seen += report.events_seen
                self.stats.events_kept += report.events_kept
                self.stats.events_dropped += report.events_dropped
                self.stats.events_promoted += report.events_promoted
                for code, count in report.issue_counts.items():
                    self.stats.validation_issue_counts[code] = (
                        self.stats.validation_issue_counts.get(code, 0) + count
                    )
                if report.events_dropped:
                    logger.warning(
                        "事件合同过滤: seen=%d kept=%d dropped=%d promoted=%d issues=%s",
                        report.events_seen,
                        report.events_kept,
                        report.events_dropped,
                        report.events_promoted,
                        [(issue.code, issue.path) for issue in report.issues],
                    )
                return response_to_dict(response)
            except ExtractionValidationError as exc:
                last_issues = exc.issues
            except LLMStructuredOutputError as exc:
                last_invalid_output = ""
                last_issues = (
                    ExtractionValidationIssue(
                        code=exc.code,
                        path=exc.path,
                        message="模型返回的结构不符合当前提取合同",
                        expected=exc.expected,
                        actual=exc.actual,
                    ),
                )
            except LLMError as exc:
                if not self._is_repairable_structured_error(exc):
                    raise
                last_invalid_output = ""
                last_issues = (
                    ExtractionValidationIssue(
                        code="structured_output_parse_failed",
                        path="$",
                        message=str(exc)[:1_000],
                        expected="valid canonical JSON",
                        actual=None,
                    ),
                )

            self.stats.record_issues(last_issues)
            if attempt < self.config.max_retries:
                self.stats.validation_retry_count += 1
                issue = last_issues[0] if last_issues else None
                logger.warning(
                    "Chunk 输出校验失败，带原因重新生成 (%d/%d): %s path=%s expected=%s actual=%s",
                    attempt + 1,
                    self.config.max_retries,
                    issue.code if issue else "unknown",
                    issue.path if issue else "-",
                    issue.expected if issue else "-",
                    issue.actual if issue else "-",
                )

        raise ExtractionRetryExhausted(
            attempts=self.stats.generation_attempts,
            issues=last_issues,
        )

    def _build_messages(
        self,
        composed: Any,
        user_input: dict[str, Any],
    ) -> list[LLMMessage]:
        messages = [
            LLMMessage(role=LLMRole.SYSTEM, content=composed.system_prompt),
        ]
        # compose() 已把单对示例归一化进 examples，这里只需按顺序展开。
        examples = getattr(composed, "examples", ()) or ()
        if not examples and composed.example_input and composed.example_output:
            examples = ((composed.example_input, composed.example_output),)
        for pair_input, pair_output in examples:
            messages.extend(
                [
                    LLMMessage(role=LLMRole.USER, content=pair_input),
                    LLMMessage(role=LLMRole.ASSISTANT, content=pair_output),
                ]
            )
        messages.append(
            LLMMessage(
                role=LLMRole.USER,
                content=json.dumps(user_input, ensure_ascii=False),
            )
        )
        return messages

    def _build_input(
        self,
        items: list[Any],
        metadata: dict[str, Any],
        source_type: str,
        related_events: list[dict[str, Any]],
        *,
        parent: bool,
    ) -> dict[str, Any]:
        items_data = [
            {"id": index, "content": self._format_item(item, source_type, parent=parent)}
            for index, item in enumerate(items, 1)
        ]
        source_label = "parent" if parent else source_type.lower()
        if source_label == "article":
            source_label = "article"
        meta: dict[str, Any] = {
            "source_type": source_label,
            "source_title": metadata.get("document_title", ""),
            "source_summary": metadata.get("document_summary", ""),
            "entity_types": [
                {
                    "type": entity_type.type,
                    "description": entity_type.description or f"{entity_type.name} entity",
                }
                for entity_type in self.entity_types
            ],
        }
        previous_context = metadata.get("previous_context")
        if previous_context:
            meta["previous_context"] = previous_context
        if related_events:
            meta["related_events"] = related_events
        return {"type": "request", "data": {"items": items_data, "meta": meta}}

    @staticmethod
    def _format_item(item: Any, source_type: str, *, parent: bool) -> str:
        if parent:
            title = getattr(item, "title", "")
            summary = getattr(item, "summary", "")
            content = getattr(item, "content", "")
            return f"标题: {title}\n摘要: {summary}\n内容: {content}"
        content = getattr(item, "content", "") or ""
        if source_type == "CHAT":
            sender = (
                getattr(item, "sender_name", None) or getattr(item, "sender_id", None) or "未知"
            )
            role = getattr(item, "sender_role", None) or "USER"
            timestamp = getattr(item, "timestamp", None)
            time_text = timestamp.isoformat() if timestamp else "unknown-time"
            return f"{sender}[{role}] ({time_text}): {content}"
        if source_type == "RECORDING":
            extra = getattr(item, "extra_data", None) or {}
            speaker = (
                extra.get("speaker")
                or getattr(item, "sender_name", None)
                or getattr(item, "sender_id", None)
                or "Speaker"
            )
            start = extra.get("start_ms", extra.get("start", "?"))
            end = extra.get("end_ms", extra.get("end", "?"))
            return f"{speaker} [{start}-{end}ms]: {content}"
        return content

    async def _chat_with_schema_once(
        self,
        messages: list[LLMMessage],
        schema: dict[str, Any],
        *,
        defer_validation: bool = False,
    ) -> dict[str, Any]:
        method = getattr(self.llm_client, "chat_with_schema_once", None)
        if method is None:
            method = self.llm_client.chat_with_schema
        kwargs = {"validate_response_schema": False} if defer_validation else {}
        return await method(messages, response_schema=schema, **kwargs)

    @staticmethod
    def _is_repairable_structured_error(exc: LLMError) -> bool:
        message = str(exc).lower()
        return any(
            marker in message
            for marker in (
                "schema",
                "json",
                "结构化",
                "响应不符合",
                "不是有效",
            )
        )

    @staticmethod
    def _bounded_invalid_output(output: str) -> str:
        if not output:
            return "{}"
        return output[:50_000]

    async def _recall_related_events(
        self, items: list[Any], _source_type: str | None = None
    ) -> list[dict[str, Any]]:
        if not self.config.related_events.enabled:
            return []
        try:
            await self._ensure_recall_deps()
            event_repo = self._event_repo
            embedding_client = self._embedding_client
            if event_repo is None or embedding_client is None:
                raise StateError("历史事项召回依赖初始化失败")
            content_text = " ".join((getattr(item, "content", "") or "") for item in items)
            content_vector = await embedding_client.generate_embedding(
                content_text[: self.config.embedding_max_length]
            )
            results = await event_repo.search_similar_by_content(
                query_vector=content_vector,
                k=self.config.related_events.top_k,
                data_source_id=self.config.data_source_id,
            )
            results = [
                result
                for result in results
                if result.get("score", 0) >= self.config.related_events.threshold
            ]
            if not results:
                return []
            event_ids = [result["event_id"] for result in results]
            related_events: list[dict[str, Any]] = []
            async with self.session_factory() as session:
                from sqlalchemy.orm import selectinload

                from zleap.sag.db.models import EventEntity

                statement = (
                    select(SourceEvent)
                    .options(
                        selectinload(SourceEvent.event_associations).selectinload(
                            EventEntity.entity
                        )
                    )
                    .where(SourceEvent.id.in_(event_ids))
                )
                db_events = (await session.execute(statement)).scalars().all()
                for event in db_events:
                    related_events.append(
                        {
                            "title": event.title,
                            "category": event.category or "",
                            "entities": [
                                {"type": assoc.entity.type, "name": assoc.entity.name}
                                for assoc in event.event_associations
                                if assoc.entity
                            ][:10],
                        }
                    )
            return related_events
        except Exception as exc:
            logger.info("历史事项召回失败: %s", exc)
            return []

    async def _ensure_recall_deps(self) -> None:
        if self._event_repo is None:
            from zleap.sag.modules.load.processor import DocumentProcessor

            self._event_repo = self.repositories.events
            self._embedding_client = DocumentProcessor(embedding_client=self.embedding)
