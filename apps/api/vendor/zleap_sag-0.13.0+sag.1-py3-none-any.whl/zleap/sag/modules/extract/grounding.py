"""Fail-closed numeric grounding for caller-bounded spreadsheet records."""

from __future__ import annotations

import re
from collections.abc import Iterable
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

from zleap.sag.db import SourceEvent

_NUMBER = re.compile(
    r"(?<![A-Za-z0-9_.])[-+]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?%?(?![A-Za-z0-9_.])"
)


def retain_numerically_grounded_events(
    events: Iterable[SourceEvent],
    *,
    evidence_texts: Iterable[str],
) -> tuple[tuple[SourceEvent, ...], int]:
    """Keep events whose generated numbers all occur in the same record group."""

    evidence_numbers = _numbers("\n".join(evidence_texts))
    retained: list[SourceEvent] = []
    rejected = 0
    for event in events:
        generated_texts = [
            str(value) for value in (event.title, event.summary, event.content) if value
        ]
        generated_texts.extend(_entity_strings(event.extra_data))
        if all(
            _is_grounded_number(number, evidence_numbers)
            for number in _numbers("\n".join(generated_texts))
        ):
            retained.append(event)
        else:
            rejected += 1
    return tuple(retained), rejected


def _numbers(text: str) -> set[Decimal]:
    values: set[Decimal] = set()
    for match in _NUMBER.finditer(text):
        raw = match.group().replace(",", "").removesuffix("%")
        try:
            values.add(Decimal(raw).normalize())
        except InvalidOperation:
            continue
    return values


def _is_grounded_number(number: Decimal, evidence_numbers: set[Decimal]) -> bool:
    """Accept an exact value or its explicit decimal display rounding only."""

    if number in evidence_numbers:
        return True
    exponent = number.as_tuple().exponent
    if not isinstance(exponent, int) or exponent >= 0:
        return False
    quantum = Decimal(1).scaleb(exponent)
    return any(
        evidence.quantize(quantum, rounding=ROUND_HALF_UP) == number
        for evidence in evidence_numbers
    )


def _entity_strings(extra_data: Any) -> list[str]:
    if not isinstance(extra_data, dict):
        return []
    raw_entities = extra_data.get("raw_entities")
    if not isinstance(raw_entities, dict):
        return []
    entities = raw_entities.get("entities")
    if not isinstance(entities, list):
        return []
    return [
        value
        for entity in entities
        if isinstance(entity, dict)
        for value in entity.values()
        if isinstance(value, str)
    ]


__all__ = ["retain_numerically_grounded_events"]
