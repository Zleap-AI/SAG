"""Optional, deterministic extractive article summarization."""

from __future__ import annotations

import asyncio
import hashlib
import re
from dataclasses import dataclass
from typing import Protocol

from zleap.sag.core.adapters import MissingCapabilityError
from zleap.sag.exceptions import ValidationError as SagValidationError


@dataclass(frozen=True)
class ArticleSummary:
    text: str
    algorithm: str
    algorithm_version: str
    content_hash: str


class ArticleSummarizer(Protocol):
    async def summarize(
        self,
        text: str,
        *,
        language: str,
        source_version: str,
    ) -> ArticleSummary: ...


class _LocalTokenizer:
    """Sumy-compatible tokenizer that never downloads NLTK resources."""

    _sentence_pattern = re.compile(r"(?<=[。！？])|(?<=[.!?])\s+|[\r\n]+")
    _word_pattern = re.compile(r"[\w\u3400-\u9fff]+", re.UNICODE)

    def __init__(self, language: str) -> None:
        self.language = language

    def to_sentences(self, paragraph: str) -> tuple[str, ...]:
        return tuple(
            sentence.strip()
            for sentence in self._sentence_pattern.split(paragraph)
            if sentence.strip()
        )

    def to_words(self, sentence: str) -> tuple[str, ...]:
        if self.language == "zh":
            try:
                import jieba

                return tuple(word.strip() for word in jieba.cut(sentence) if word.strip())
            except ImportError:
                pass
        return tuple(self._word_pattern.findall(sentence.lower()))


class SumyArticleSummarizer:
    """Lazy Sumy adapter with bounded multi-window coverage."""

    ALGORITHM = "sumy-lexrank-windowed"
    VERSION = "1"

    def __init__(
        self,
        *,
        output_sentences: int = 12,
        window_chars: int = 20_000,
        max_input_chars: int = 400_000,
    ) -> None:
        self.output_sentences = output_sentences
        self.window_chars = window_chars
        self.max_input_chars = max_input_chars

    async def summarize(
        self,
        text: str,
        *,
        language: str,
        source_version: str,
    ) -> ArticleSummary:
        del source_version
        normalized = text.strip()
        if not normalized:
            raise SagValidationError("文章正文为空，无法生成摘要")
        summary = await asyncio.to_thread(self._summarize_sync, normalized, language)
        return ArticleSummary(
            text=summary,
            algorithm=self.ALGORITHM,
            algorithm_version=self.VERSION,
            content_hash=hashlib.sha256(normalized.encode("utf-8")).hexdigest(),
        )

    def _summarize_sync(self, text: str, language: str) -> str:
        try:
            from sumy.parsers.plaintext import PlaintextParser
            from sumy.summarizers.lex_rank import LexRankSummarizer
        except ImportError as exc:
            raise MissingCapabilityError("文章摘要需要可选依赖，请安装 zleap-sag[summary]") from exc

        bounded = text[: self.max_input_chars]
        windows = [
            bounded[index : index + self.window_chars]
            for index in range(0, len(bounded), self.window_chars)
        ]
        tokenizer = _LocalTokenizer(language)
        summarizer = LexRankSummarizer()

        def summarize_window(value: str, count: int) -> list[str]:
            parser = PlaintextParser.from_string(value, tokenizer)
            try:
                return [str(sentence).strip() for sentence in summarizer(parser.document, count)]
            except ValueError:
                return list(tokenizer.to_sentences(value))[:count]

        if len(windows) == 1:
            selected = summarize_window(windows[0], self.output_sentences)
        else:
            per_window = max(2, self.output_sentences // len(windows) + 1)
            candidates: list[str] = []
            for window in windows:
                candidates.extend(summarize_window(window, per_window))
            selected = summarize_window(
                "\n".join(candidates),
                min(self.output_sentences, len(candidates)),
            )

        positions = {sentence: bounded.find(sentence) for sentence in selected}
        ordered = sorted(selected, key=lambda sentence: positions.get(sentence, -1))
        return "\n".join(sentence for sentence in ordered if sentence).strip()
