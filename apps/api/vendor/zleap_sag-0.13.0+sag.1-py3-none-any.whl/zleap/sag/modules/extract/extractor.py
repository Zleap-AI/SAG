"""
事项提取器

主控制器 - 协调提取流程

流程: chunks → processor(LLM) → filter(过滤) → parser(解析) → saver(保存)
"""

import asyncio
import inspect
import json
import uuid
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.orm import selectinload

from zleap.sag._extraction_progress import ExtractionCheckpointWriteError
from zleap.sag._safe_error import safe_error_summary, safe_error_type
from zleap.sag.core.adapters import MissingCapabilityError
from zleap.sag.core.ai.base import BaseLLMClient
from zleap.sag.core.prompt.manager import PromptManager
from zleap.sag.db import (
    EntityType as DBEntityType,
)
from zleap.sag.db import (
    EventEntity,
    SourceChunk,
    SourceEvent,
)
from zleap.sag.exceptions import (
    ConfigError,
    ExtractError,
    LLMAuthError,
    LLMConfigurationError,
    LLMContentPolicyError,
    LLMContextLengthError,
    LLMError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMTimeoutError,
    OperationConflictError,
    ResourceBusyError,
    StaleFenceError,
    VectorSyncError,
)
from zleap.sag.modules.extract.config import ExtractConfig
from zleap.sag.modules.extract.grounding import retain_numerically_grounded_events
from zleap.sag.modules.extract.parser import ParseContext, ResultParser
from zleap.sag.modules.extract.processor import (
    EventProcessor,
    ExtractionGenerationStats,
    ExtractionRetryExhausted,
)
from zleap.sag.modules.extract.saver import EventSaver
from zleap.sag.modules.extract.summarizer import (
    ArticleSummarizer,
    SumyArticleSummarizer,
)
from zleap.sag.pipeline.context import CancellationToken
from zleap.sag.utils import estimate_tokens, get_logger, get_utc_now

logger = get_logger("extract.extractor")

ProgressCallback = Callable[[int, int], Awaitable[None] | None]


@dataclass(frozen=True)
class ChunkExtractionSuccess:
    events: tuple[SourceEvent, ...]
    stats: ExtractionGenerationStats


ChunkResultCallback = Callable[
    [str, ChunkExtractionSuccess | None, dict[str, Any] | None], Awaitable[None]
]


@dataclass(frozen=True)
class ExtractionBatchResult:
    events: tuple[SourceEvent, ...]
    failures: tuple[dict[str, Any], ...] = ()
    stats: dict[str, Any] = field(default_factory=dict)


class ChunkBatchExtractionError(ExtractError):
    def __init__(
        self,
        failures: list[dict[str, Any]],
        *,
        stats: dict[str, Any],
    ) -> None:
        self.failures = tuple(failures)
        self.stats = stats
        retryable = bool(failures) and all(
            bool(failure.get("retryable", False)) for failure in failures
        )
        super().__init__(
            f"Chunk 重试耗尽，批次未提交: count={len(failures)}",
            code="chunk_retry_exhausted",
            retryable=retryable,
        )


class ParentSummaryBatchError(ExtractError):
    def __init__(
        self,
        cause: Exception,
        *,
        stats: dict[str, Any],
    ) -> None:
        attempts = int(getattr(cause, "attempts", 1))
        code = "parent_summary_failed"
        self.failures = (
            {
                "chunk_id": "parent_summary",
                "code": code,
                "message": safe_error_summary(cause, label="父事项生成失败"),
                "retryable": isinstance(cause, ExtractionRetryExhausted),
                "attempts": attempts,
            },
        )
        self.stats = {
            **stats,
            "parent_summary_status": "failed",
            "generation_attempts": int(stats.get("generation_attempts", 0)) + attempts,
            "validation_retry_count": int(stats.get("validation_retry_count", 0))
            + max(0, attempts - 1),
        }
        super().__init__(
            safe_error_summary(cause, label="父事项生成失败，批次未提交"),
            code=code,
        )


class ArticleSummaryBatchError(ExtractError):
    def __init__(self, cause: Exception) -> None:
        self.stats = {"article_summary_status": "failed"}
        super().__init__(
            safe_error_summary(cause, label="文章摘要失败，未开始 Chunk 提取"),
            code="article_summary_failed",
        )


class EventExtractor:
    """
    事项提取器（主控制器）

    流程: chunks → processor(LLM) → filter(过滤) → parser(解析) → saver(保存)
    """

    def __init__(
        self,
        prompt_manager: PromptManager,
        on_progress: Callable[[int, int], Awaitable[None] | None] | None = None,
        session_factory: Any = None,
        repositories: Any = None,
        embedding: Any = None,
        llm: Any = None,
        article_summarizer: ArticleSummarizer | None = None,
    ):
        """
        初始化事项提取器

        Args:
            prompt_manager: 提示词管理器
            on_progress: 进度回调 (completed, total)
        """
        self.prompt_manager = prompt_manager
        self._on_progress = on_progress
        self._llm_client = llm
        if session_factory is None or repositories is None or embedding is None or llm is None:
            raise ConfigError(
                "EventExtractor 需要显式注入 session_factory、repositories、embedding 和 llm"
            )
        self.session_factory = session_factory
        self.repositories = repositories
        self.embedding = embedding
        self.article_summarizer = article_summarizer
        self.logger = get_logger("extract.extractor")

        # 组件（延迟初始化）
        self._saver: EventSaver | None = None

    async def _get_llm_client(self) -> BaseLLMClient:
        """获取当前 Engine 实例注入的 LLM。"""
        return self._llm_client

    async def extract_batch(
        self,
        config: ExtractConfig,
        *,
        cancellation: CancellationToken | None = None,
    ) -> ExtractionBatchResult:
        if cancellation is None:
            return await self._run_batch(config, commit=True)
        # Cancel generation (including its gather/semaphore children), then drain
        # it before returning. Once commit starts, let its atomic write/rollback
        # boundary finish rather than interrupting it with a pause request.
        prepared = await cancellation.run(lambda: self.prepare_batch(config))
        if cancellation.is_cancelled:
            raise asyncio.CancelledError
        if prepared.stats.get("chunk_total") == 0:
            return prepared
        return await self.commit_prepared(list(prepared.events), config, stats=dict(prepared.stats))

    async def prepare_batch(
        self,
        config: ExtractConfig,
        *,
        on_progress: ProgressCallback | None = None,
        cached_chunks: dict[str, ChunkExtractionSuccess] | None = None,
        on_chunk_result: ChunkResultCallback | None = None,
    ) -> ExtractionBatchResult:
        """Run all non-deterministic generation without mutating derived stores."""
        return await self._run_batch(
            config,
            commit=False,
            on_progress=on_progress,
            cached_chunks=cached_chunks,
            on_chunk_result=on_chunk_result,
        )

    async def commit_prepared(
        self,
        events: list[SourceEvent],
        config: ExtractConfig,
        *,
        stats: dict[str, Any] | None = None,
    ) -> ExtractionBatchResult:
        """Persist a previously prepared canonical batch without another LLM call."""
        await self._save_events(events, config)
        if events:
            events = await self._reload_events_with_relations([event.id for event in events])
        result_stats = dict(stats or {})
        result_stats["event_count"] = len(events)
        return ExtractionBatchResult(events=tuple(events), stats=result_stats)

    async def _run_batch(
        self,
        config: ExtractConfig,
        *,
        commit: bool,
        on_progress: ProgressCallback | None = None,
        cached_chunks: dict[str, ChunkExtractionSuccess] | None = None,
        on_chunk_result: ChunkResultCallback | None = None,
    ) -> ExtractionBatchResult:
        """
        提取事项（统一入口 - 新架构）

        工作流程：
        1. 加载所有chunks
        2. 按max_concurrency并发处理（Semaphore控制）
        3. 每个chunk由一个ExtractorAgent处理
        4. 合并所有结果
        5. 保存到数据库 + Elasticsearch
        6. 更新源状态为已完成

        Args:
            config: 提取配置

        Returns:
            所有chunks提取的事项列表

        Example:
            config = ExtractConfig(
                data_source_id="source-uuid",
                chunk_ids=["chunk-1", "chunk-2", "chunk-3"],
                max_concurrency=3
            )
            events = await extractor.extract(config)
        """
        self.logger.info(
            f"开始批量提取: chunks={len(config.chunk_ids)}, 并发数={config.max_concurrency}"
        )

        try:
            # 1. 加载所有chunks
            chunks = await self._load_chunks(config.chunk_ids)

            if not chunks:
                self.logger.info("没有找到可用的chunks")
                return ExtractionBatchResult(
                    events=(),
                    stats={"chunk_total": 0, "chunk_succeeded": 0},
                )

            # 2. 摘要是所有 Chunk 的前置条件，只生成/加载一次。
            try:
                summary_stats = await self._ensure_article_summary(config)
            except MissingCapabilityError:
                raise
            except Exception as exc:
                raise ArticleSummaryBatchError(exc) from exc

            # 3. 并发处理 chunks；失败只重试当前 Chunk，所有 outcome 汇总后统一判断。
            checkpoint_kwargs: dict[str, Any] = (
                {"cached_chunks": cached_chunks, "on_chunk_result": on_chunk_result}
                if on_chunk_result is not None
                else {}
            )
            (
                all_events,
                failed_chunks,
                generation_stats,
                raw_stats,
            ) = await self._process_chunks_with_agents(
                chunks,
                config,
                on_progress=on_progress,
                **checkpoint_kwargs,
            )
            stats = self._aggregate_generation_stats(
                chunks,
                failed_chunks,
                generation_stats,
                summary_stats=summary_stats,
            )
            stats.update(raw_stats)

            if failed_chunks:
                # 批次原子性：任一 Chunk 重试耗尽即拒绝整批，绝不进入 _save_events，
                # 从而保留该来源的上一份快照，避免留下缺失片段的残缺图谱。
                self.logger.warning(
                    f"Chunk 提取失败，拒绝整批: failed={len(failed_chunks)}, "
                    f"discarded_events={len(all_events)}, 失败示例: "
                    f"{[c.get('chunk_id', 'unknown') for c in failed_chunks[:5]]}"
                )
                raise ChunkBatchExtractionError(failed_chunks, stats=stats)

            self.logger.info(f"批量提取完成: chunks={len(chunks)}, events={len(all_events)}")

            # 4. 按原文顺序重新排序并分配全局 rank
            if all_events:
                # 创建 chunk_id -> chunk.rank 的映射
                chunk_rank_map = {chunk.id: chunk.rank for chunk in chunks}

                # 排序规则：
                # 1. 先按 chunk.rank（保证 chunk 之间的顺序）
                # 2. 再按事项的时间（会话）或 chunk 内 rank（文档）
                def sort_key(event):
                    chunk_order = chunk_rank_map.get(event.chunk_id, 9999)
                    event_order = event.rank or 0
                    return (chunk_order, event_order)

                all_events.sort(key=sort_key)

                # 重新分配全局连续 rank
                for i, event in enumerate(all_events):
                    event.rank = i

                self.logger.info(
                    f"事项已按原文顺序排序: chunks={len(chunks)}, events={len(all_events)}"
                )

            # 5. 可选父事项也必须在任何持久化之前成功。
            parent_status = "disabled"
            if config.enable_parent_summary:
                if len(all_events) >= 2:
                    try:
                        parent, parent_stats, compression_stats = await self._build_parent_event(
                            all_events, config
                        )
                    except Exception as exc:
                        raise ParentSummaryBatchError(exc, stats=stats) from exc
                    all_events = [parent, *all_events]
                    parent_status = "generated"
                    stats["generation_attempts"] += parent_stats.generation_attempts
                    stats["validation_retry_count"] += parent_stats.validation_retry_count
                    stats["parent_prompt_fingerprint"] = parent_stats.prompt_fingerprint
                    stats.update(compression_stats)
                else:
                    parent_status = "skipped_empty" if not all_events else "skipped_single_event"
            stats["parent_summary_status"] = parent_status

            # 6. Durable application flow persists this prepared form in its
            # operation ledger before committing.  The explicit stage API keeps
            # the historical one-call behavior.
            if commit:
                await self._save_events(all_events, config)
                if all_events:
                    event_ids = [e.id for e in all_events]
                    all_events = await self._reload_events_with_relations(event_ids)

            stats["event_count"] = len(all_events)
            return ExtractionBatchResult(
                events=tuple(all_events),
                failures=tuple(failed_chunks),
                stats=stats,
            )

        except Exception as e:
            self.logger.error("提取失败", extra={"error_type": safe_error_type(e)})
            if isinstance(
                e,
                (
                    VectorSyncError,
                    ChunkBatchExtractionError,
                    ParentSummaryBatchError,
                    ArticleSummaryBatchError,
                    MissingCapabilityError,
                    ExtractionCheckpointWriteError,
                    OperationConflictError,
                    ResourceBusyError,
                    StaleFenceError,
                ),
            ):
                raise
            raise ExtractError(safe_error_summary(e, label="提取失败")) from e
        # 向量客户端由 DataEngine/StorageResources 关闭；Extractor 不拥有它。

    async def _load_chunks(self, chunk_ids: Sequence[str]) -> list[SourceChunk]:
        """批量加载chunks（按rank排序）"""
        async with self.session_factory() as session:
            result = await session.execute(
                select(SourceChunk)
                .where(SourceChunk.id.in_(chunk_ids))
                .order_by(SourceChunk.rank)  # 🆕 按 rank 排序
            )
            chunks = list(result.scalars().all())

            if len(chunks) != len(chunk_ids):
                missing = set(chunk_ids) - {c.id for c in chunks}
                self.logger.info("部分 chunk 不存在: count=%d", len(missing))

            return chunks

    async def _process_chunks_with_agents(
        self,
        chunks: list[SourceChunk],
        config: ExtractConfig,
        *,
        on_progress: ProgressCallback | None = None,
        cached_chunks: dict[str, ChunkExtractionSuccess] | None = None,
        on_chunk_result: ChunkResultCallback | None = None,
    ) -> tuple[
        list[SourceEvent],
        list[dict[str, Any]],
        list[ExtractionGenerationStats],
        dict[str, Any],
    ]:
        """
        并发处理chunks（每个chunk一个Agent）

        使用asyncio.Semaphore控制并发数量：
        - 同时最多有max_concurrency个Agent在运行
        - 超出的chunk会自动排队等待
        - 一个chunk完成后，立即启动下一个

        Args:
            chunks: chunk列表
            config: 提取配置

        Returns:
            合并后的所有事项
        """
        semaphore = asyncio.Semaphore(config.max_concurrency)

        # 进度跟踪
        completed = 0
        success_count = 0
        failed_count = 0
        total = len(chunks)
        lock = asyncio.Lock()

        async def process_single_chunk(
            chunk: SourceChunk, index: int
        ) -> tuple[
            list[SourceEvent],
            dict[str, Any] | None,
            ExtractionGenerationStats | None,
        ]:
            """处理单个chunk（带并发控制和进度统计）"""
            nonlocal completed, success_count, failed_count

            async with semaphore:  # 🔒 获取并发槽位（没有就等待）
                is_success = False
                events = []
                error_msg = None
                captured_error: Exception | None = None
                result = None
                reused = chunk.id in (cached_chunks or {})

                try:
                    self.logger.info(
                        "[%d/%d] 开始处理: type=%s",
                        index + 1,
                        total,
                        chunk.source_type,
                    )

                    # 调用chunk级提取（使用ExtractorAgent）
                    result = (
                        cached_chunks[chunk.id]
                        if cached_chunks is not None and reused
                        else await self.extract_from_chunk(chunk, config)
                    )
                    events = list(result.events)
                    chunk_stats = result.stats
                    is_success = True

                except Exception as e:
                    if isinstance(
                        e,
                        (
                            ExtractionCheckpointWriteError,
                            OperationConflictError,
                            ResourceBusyError,
                            StaleFenceError,
                        ),
                    ):
                        raise
                    captured_error = e
                    error_msg = safe_error_summary(e, label="Chunk 提取失败")
                    chunk_stats = None

                failure = (
                    self._chunk_failure(chunk.id, captured_error, error_msg)
                    if captured_error is not None
                    else None
                )
                # Checkpoint writes are mandatory, unlike best-effort UI progress.
                # Persist before counting completion; write failure aborts the batch.
                if on_chunk_result is not None and not reused:
                    await on_chunk_result(chunk.id, result, failure)

                # 更新进度（锁内只做计数，锁外做回调）
                async with lock:
                    completed += 1
                    if is_success:
                        success_count += 1
                    else:
                        failed_count += 1
                    progress = completed * 100 // total
                    # A durable operation supplies a request-local callback.  Falling
                    # back to the constructor callback preserves the explicit-stage
                    # API without mutating shared Engine state between concurrent jobs.
                    progress_callback = on_progress or self._on_progress
                    should_report = progress_callback is not None and (
                        completed % 10 == 0 or completed == total
                    )
                    snap_completed, snap_total = completed, total

                if is_success:
                    self.logger.info(
                        f"✅ [{snap_completed}/{snap_total}] 完成 ({progress}%): "
                        f"input_index={index + 1}, events={len(events)}"
                    )
                else:
                    self.logger.error(
                        "❌ [%d/%d] 失败 (%d%%): input_index=%d, chunk_id=%s, "
                        "rank=%s, heading=%r, content_length=%d, error=%s",
                        snap_completed,
                        snap_total,
                        progress,
                        index + 1,
                        *self._chunk_log_context(chunk),
                        error_msg,
                    )

                if should_report and progress_callback is not None:
                    try:
                        callback_result = progress_callback(snap_completed, snap_total)
                        if inspect.isawaitable(callback_result):
                            await callback_result
                    except Exception as e:
                        self.logger.warning(
                            "进度回调失败",
                            extra={"error_type": safe_error_type(e)},
                        )

                return (events if is_success else []), failure, chunk_stats
                # 🔓 离开时自动释放槽位

        # 并发执行所有chunk
        self.logger.info(f"🚀 启动并发提取: total={total}, concurrency={config.max_concurrency}")

        tasks = [
            asyncio.create_task(process_single_chunk(chunk, i)) for i, chunk in enumerate(chunks)
        ]
        try:
            results = await asyncio.gather(*tasks, return_exceptions=False)
        finally:
            # A failed checkpoint must not leave sibling workers writing after
            # the operation has released its lease or reported failure.
            for task in tasks:
                if not task.done() and not task.cancelling():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

        # 合并结果
        all_events = []
        failed_chunks: list[dict[str, Any]] = []
        generation_stats: list[ExtractionGenerationStats] = []
        zero_event_chunks: list[dict[str, Any]] = []
        for idx, (events, failure, chunk_stats) in enumerate(results):
            all_events.extend(events)
            if failure:
                failed_chunks.append(failure)
            elif len(events) == 0:
                chunk = chunks[idx]
                content = getattr(chunk, "content", "") or ""
                zero_event_chunks.append(
                    {
                        "chunk_id": chunk.id,
                        "heading": getattr(chunk, "heading", ""),
                        "content_length": len(content),
                    }
                )
            if chunk_stats is not None:
                generation_stats.append(chunk_stats)

        # 最终统计
        zero_count = len(zero_event_chunks)
        self.logger.info(
            f"📊 批量提取统计: 总数={total}, 成功={success_count}, "
            f"失败={failed_count}, 零事件={zero_count}, 事项={len(all_events)}"
        )
        if zero_count:
            self.logger.warning("⚠ %d 个 Chunk 未提取到事项", zero_count)

        # chunk_total/succeeded/failed 由 _aggregate_generation_stats 统一计算。
        stats: dict[str, Any] = {
            "zero_event_count": zero_count,
            "zero_event_chunks": zero_event_chunks,
        }
        if cached_chunks is not None:
            stats["chunk_reused"] = len(cached_chunks)
        return all_events, failed_chunks, generation_stats, stats

    @staticmethod
    def _chunk_failure(
        chunk_id: str,
        error: Exception,
        safe_message: str | None,
    ) -> dict[str, Any]:
        """Classify one failed Chunk without persisting provider text or document content."""

        cause: BaseException | None = error
        seen: set[int] = set()
        while cause is not None and id(cause) not in seen:
            seen.add(id(cause))
            if isinstance(cause, ExtractionRetryExhausted):
                return {
                    "chunk_id": chunk_id,
                    "code": cause.code,
                    "message": safe_message or "Chunk 提取校验重试耗尽",
                    # The chunk has already consumed the configured model-repair
                    # attempts. Retrying the whole document repeats every successful
                    # chunk and is both costly and unlikely to change the result.
                    # Operators may retry explicitly after changing the model or
                    # extraction policy; automatic retries are reserved for transient
                    # provider failures such as timeouts and rate limits.
                    "retryable": False,
                    "attempts": cause.attempts,
                }
            if isinstance(cause, LLMAuthError):
                code, retryable = "llm_authentication_failed", False
                break
            if isinstance(cause, LLMContentPolicyError):
                code, retryable = "llm_content_policy_rejected", False
                break
            if isinstance(cause, LLMContextLengthError):
                code, retryable = "llm_context_length_exceeded", False
                break
            if isinstance(cause, LLMConfigurationError):
                code, retryable = "llm_configuration_error", False
                break
            if isinstance(cause, LLMInvalidRequestError):
                code, retryable = "llm_invalid_request", False
                break
            if isinstance(cause, LLMTimeoutError):
                code, retryable = "llm_timeout", True
                break
            if isinstance(cause, LLMRateLimitError):
                code, retryable = "llm_rate_limited", True
                break
            if isinstance(cause, LLMError):
                code, retryable = "llm_unavailable", True
                break
            cause = cause.__cause__ or cause.__context__
        else:
            explicit = getattr(error, "retryable", None)
            code = str(getattr(error, "code", "chunk_extraction_failed"))
            retryable = explicit if isinstance(explicit, bool) else False

        return {
            "chunk_id": chunk_id,
            "code": code,
            "message": safe_message or "Chunk 提取失败",
            "retryable": retryable,
            "attempts": max(1, int(getattr(error, "attempts", 1))),
        }

    async def _save_events(
        self, events: list[SourceEvent], config: ExtractConfig
    ) -> list[SourceEvent]:
        """
        保存事项（使用 EventSaver）

        Args:
            events: 事项列表
            config: 提取配置

        Returns:
            保存后的事项列表（包含完整关系数据）
        """
        if self._saver is None:
            self._saver = EventSaver(
                session_factory=self.session_factory,
                repositories=self.repositories,
                embedding=self.embedding,
            )

        return await self._saver.commit(events, config)

    async def extract_from_chunk(
        self, chunk: SourceChunk, config: ExtractConfig
    ) -> ChunkExtractionSuccess:
        """
        从chunk提取事项

        Args:
            chunk: 来源片段对象
            config: 提取配置

        Returns:
            提取的事项列表
        """
        try:
            self.logger.info("开始从 chunk 提取: type=%s", chunk.source_type)

            # 0. 内容长度过滤
            content_length = chunk.chunk_length or len(chunk.content or "")
            chunk_type = str((chunk.extra_data or {}).get("chunk_type") or "").upper()
            if (
                config.chunk_min_length > 0
                and content_length < config.chunk_min_length
                and chunk_type != "IMAGE"
            ):
                self.logger.info(f"Chunk {chunk.id} 内容太短({content_length}字符)，跳过")
                return ChunkExtractionSuccess(events=(), stats=ExtractionGenerationStats())

            # 1. 加载内容和元数据
            content_items, raw_metadata = await self._load_chunk_content(chunk, config)
            if not content_items:
                self.logger.info("Chunk 无内容（可能全为图片已被过滤）")
                return ChunkExtractionSuccess(events=(), stats=ExtractionGenerationStats())

            # 2. 加载实体类型
            entity_types = await self._load_entity_types_for_chunk(config)

            return await self._extract_chunk_items_with_recovery(
                chunk=chunk,
                config=config,
                content_items=content_items,
                raw_metadata=raw_metadata,
                entity_types=entity_types,
            )

        except Exception as e:
            self.logger.exception(
                "Chunk 提取失败: chunk_id=%s, rank=%s, heading=%r, content_length=%d",
                *self._chunk_log_context(chunk),
                extra={"error_type": safe_error_type(e)},
            )
            if isinstance(
                e,
                (
                    ExtractionRetryExhausted,
                    ExtractionCheckpointWriteError,
                    OperationConflictError,
                    ResourceBusyError,
                    StaleFenceError,
                ),
            ):
                raise
            raise ExtractError(safe_error_summary(e, label="Chunk 提取失败")) from e

    async def _extract_chunk_items_with_recovery(
        self,
        *,
        chunk: SourceChunk,
        config: ExtractConfig,
        content_items: list[Any],
        raw_metadata: dict[str, Any],
        entity_types: list[DBEntityType],
    ) -> ChunkExtractionSuccess:
        """Recover only an anonymous provider rejection for the current Chunk."""

        rejected_attempts = 0
        for attempt in range(config.request_rejection_retries + 1):
            try:
                result = await self._extract_chunk_items_once(
                    chunk=chunk,
                    config=config,
                    content_items=content_items,
                    raw_metadata=raw_metadata,
                    entity_types=entity_types,
                )
            except LLMInvalidRequestError as error:
                # Subclasses already carry a definitive reason.  Retrying policy,
                # context or parameter failures would only delay the terminal result.
                if type(error) is not LLMInvalidRequestError:
                    raise
                rejected_attempts += 1
                if attempt >= config.request_rejection_retries:
                    break
                self.logger.warning(
                    "Chunk 请求被上游匿名拒绝，短退避后仅重试当前 Chunk",
                    extra={"request_failure_kind": "unknown"},
                )
                await asyncio.sleep(0.5 * (attempt + 1))
            else:
                result.stats.generation_attempts += rejected_attempts
                return result

        recovery_items = self._split_recovery_items(
            content_items,
            minimum_chars=config.request_recovery_min_chars,
        )
        if recovery_items is None:
            raise LLMInvalidRequestError("模型服务匿名拒绝输入，且当前 Chunk 无法继续安全拆分")

        self.logger.warning(
            "Chunk 重试仍被匿名拒绝，拆成两个完整子片段继续提取",
            extra={"request_failure_kind": "unknown"},
        )
        recovered_events: list[SourceEvent] = []
        recovered_stats = ExtractionGenerationStats(generation_attempts=rejected_attempts)
        previous_segment = ""
        for item in recovery_items:
            segment_metadata = dict(raw_metadata)
            if previous_segment:
                # Same-Chunk continuity: this is the previous half of *this* Chunk,
                # not a neighbouring Chunk, so heading_strict isolation must not drop it.
                segment_metadata["previous_chunk"] = {
                    "heading": chunk.heading,
                    "content": previous_segment[-300:],
                    "intra_chunk": True,
                }
            result = await self._extract_chunk_items_once(
                chunk=chunk,
                config=config,
                content_items=[item],
                raw_metadata=segment_metadata,
                entity_types=entity_types,
            )
            recovered_events.extend(result.events)
            self._merge_generation_stats(recovered_stats, result.stats)
            previous_segment = str(getattr(item, "content", ""))
        return ChunkExtractionSuccess(events=tuple(recovered_events), stats=recovered_stats)

    async def _extract_chunk_items_once(
        self,
        *,
        chunk: SourceChunk,
        config: ExtractConfig,
        content_items: list[Any],
        raw_metadata: dict[str, Any],
        entity_types: list[DBEntityType],
    ) -> ChunkExtractionSuccess:
        """Execute one complete generation and parse pass for one logical Chunk."""

        processor = EventProcessor(
            llm_client=await self._get_llm_client(),
            embedding=self.embedding,
            prompt_manager=self.prompt_manager,
            config=config,
            session_factory=self.session_factory,
            repositories=self.repositories,
        )
        await processor.initialize(entity_types)

        metadata = {
            "document_title": raw_metadata.get("title", ""),
            "document_summary": (
                raw_metadata.get("summary", "") if config.enable_article_summary else ""
            ),
            "chunk_title": chunk.heading or f"片段{chunk.rank + 1}",
            "previous_context": self._format_previous_context_for_chunk(
                chunk,
                raw_metadata.get("previous_chunk"),
            ),
        }

        raw_result = await processor.process(
            items=content_items,
            metadata=metadata,
            source_type=chunk.source_type,
        )

        parser = ResultParser(config, session_factory=self.session_factory)

        context = ParseContext(
            data_source_id=config.data_source_id,
            source_type=chunk.source_type,
            source_id=chunk.source_id,
            chunk_id=chunk.id,
        )

        raw_items = raw_result.get("data", {}).get("items", [])
        events = parser.parse_events(raw_items, content_items, context)
        if (chunk.extra_data or {}).get("record_group_id"):
            grounded_events, rejected = retain_numerically_grounded_events(
                events,
                evidence_texts=(str(getattr(item, "content", "") or "") for item in content_items),
            )
            events = list(grounded_events)
            if rejected:
                processor.stats.validation_issue_counts["table_number_not_grounded"] = (
                    processor.stats.validation_issue_counts.get("table_number_not_grounded", 0)
                    + rejected
                )
                self.logger.warning(
                    "表格事项包含当前记录组中不存在的数字，已拒绝保存: chunk_id=%s, count=%d",
                    chunk.id,
                    rejected,
                )

        self.logger.info("Chunk 提取完成: events=%d", len(events))
        return ChunkExtractionSuccess(events=tuple(events), stats=processor.stats)

    @staticmethod
    def _split_recovery_items(items: list[Any], *, minimum_chars: int) -> tuple[Any, Any] | None:
        if len(items) != 1:
            return None
        item = items[0]
        content = str(getattr(item, "content", "") or "")
        if len(content) < minimum_chars * 2:
            return None
        midpoint = len(content) // 2
        window = max(40, len(content) // 6)
        boundaries = [
            index + 1
            for index in range(
                max(minimum_chars, midpoint - window), min(len(content), midpoint + window)
            )
            if content[index] in "。！？!?\n"
        ]
        split_at = (
            min(boundaries, key=lambda index: abs(index - midpoint)) if boundaries else midpoint
        )
        first, second = content[:split_at].strip(), content[split_at:].strip()
        if len(first) < minimum_chars or len(second) < minimum_chars:
            return None

        def segment(value: str) -> Any:
            # Never mutate or shallow-copy an ORM instance: SQLAlchemy's state
            # object would be shared.  The extractor only reads this closed set
            # of source fields, while ``id`` deliberately stays equal to the
            # persisted section/message so provenance remains exact.
            fields = {
                name: getattr(item, name, None)
                for name in (
                    "id",
                    "article_id",
                    "sender_id",
                    "sender_name",
                    "sender_role",
                    "timestamp",
                    "extra_data",
                )
            }
            return SimpleNamespace(content=value, **fields)

        return segment(first), segment(second)

    @staticmethod
    def _merge_generation_stats(
        target: ExtractionGenerationStats,
        source: ExtractionGenerationStats,
    ) -> None:
        target.events_seen += source.events_seen
        target.events_kept += source.events_kept
        target.events_dropped += source.events_dropped
        target.events_promoted += source.events_promoted
        target.generation_attempts += source.generation_attempts
        target.validation_retry_count += source.validation_retry_count
        for code, count in source.validation_issue_counts.items():
            target.validation_issue_counts[code] = (
                target.validation_issue_counts.get(code, 0) + count
            )
        target.prompt_role = target.prompt_role or source.prompt_role
        target.prompt_fingerprint = target.prompt_fingerprint or source.prompt_fingerprint
        target.entity_type_fingerprint = (
            target.entity_type_fingerprint or source.entity_type_fingerprint
        )

    async def _ensure_article_summary(self, config: ExtractConfig) -> dict[str, Any]:
        if not config.enable_article_summary:
            return {"article_summary_status": "disabled"}
        if config.source_type != "ARTICLE":
            raise ExtractError("enable_article_summary 只适用于 ARTICLE")

        from zleap.sag.db import Article, ArticleSection

        async with self.session_factory() as session:
            article = await session.get(Article, config.source_id)
            if article is None:
                raise ExtractError(f"文章不存在: {config.source_id}")
            extra = dict(article.extra_data or {})
            cached = extra.get("sag_summary") or {}
            if article.summary and cached.get("source_version") == config.source_version:
                return {
                    "article_summary_status": "cached",
                    "article_summary_fingerprint": cached.get("content_hash", ""),
                }
            text = (article.content or "").strip()
            if not text:
                rows = await session.execute(
                    select(ArticleSection.content)
                    .where(ArticleSection.article_id == config.source_id)
                    .order_by(ArticleSection.rank)
                )
                text = "\n\n".join(
                    content.strip()
                    for content in rows.scalars().all()
                    if content and content.strip()
                )
            if not text:
                raise ExtractError("文章正文为空，无法生成全文摘要")

        summarizer = self.article_summarizer or SumyArticleSummarizer()
        summary = await summarizer.summarize(
            text,
            language=str(self.prompt_manager.language),
            source_version=config.source_version,
        )
        if not summary.text:
            raise ExtractError("文章摘要结果为空")

        async with self.session_factory() as session:
            article = await session.get(Article, config.source_id)
            if article is None:
                raise ExtractError(f"文章不存在: {config.source_id}")
            extra = dict(article.extra_data or {})
            extra["sag_summary"] = {
                "source_version": config.source_version,
                "algorithm": summary.algorithm,
                "algorithm_version": summary.algorithm_version,
                "language": str(self.prompt_manager.language),
                "created_time": get_utc_now().isoformat(),
                "content_hash": summary.content_hash,
            }
            article.summary = summary.text
            article.extra_data = extra
            await session.commit()
        return {
            "article_summary_status": "generated",
            "article_summary_fingerprint": summary.content_hash,
        }

    @staticmethod
    def _aggregate_generation_stats(
        chunks: list[SourceChunk],
        failures: list[dict[str, Any]],
        generation_stats: list[ExtractionGenerationStats],
        *,
        summary_stats: dict[str, Any],
    ) -> dict[str, Any]:
        issue_counts: dict[str, int] = {}
        for item in generation_stats:
            for code, count in item.validation_issue_counts.items():
                issue_counts[code] = issue_counts.get(code, 0) + count
        failed_attempts = sum(int(item.get("attempts", 0)) for item in failures)
        first_prompt = next((item for item in generation_stats if item.prompt_role), None)
        entity_contract = next(
            (item for item in generation_stats if item.entity_type_fingerprint),
            None,
        )
        return {
            "strategy": "sag_extract",
            "source_prompt": first_prompt.prompt_role if first_prompt else "",
            "prompt_fingerprint": (first_prompt.prompt_fingerprint if first_prompt else ""),
            "entity_type_fingerprint": (
                entity_contract.entity_type_fingerprint if entity_contract else ""
            ),
            "schema_version": "extraction-response-v1",
            "chunk_total": len(chunks),
            "chunk_succeeded": len(chunks) - len(failures),
            "chunk_failed": len(failures),
            "generation_attempts": (
                sum(item.generation_attempts for item in generation_stats) + failed_attempts
            ),
            "validation_retry_count": (
                sum(item.validation_retry_count for item in generation_stats)
                + sum(max(0, int(item.get("attempts", 0)) - 1) for item in failures)
            ),
            "events_seen": sum(item.events_seen for item in generation_stats),
            "events_kept": sum(item.events_kept for item in generation_stats),
            "events_dropped": sum(item.events_dropped for item in generation_stats),
            "events_promoted": sum(item.events_promoted for item in generation_stats),
            "validation_issue_counts": issue_counts,
            **summary_stats,
        }

    async def _build_parent_event(
        self,
        child_events: list[SourceEvent],
        config: ExtractConfig,
    ) -> tuple[SourceEvent, ExtractionGenerationStats, dict[str, int]]:
        entity_types = await self._load_entity_types_for_chunk(config)
        processor = EventProcessor(
            llm_client=await self._get_llm_client(),
            embedding=self.embedding,
            prompt_manager=self.prompt_manager,
            config=config,
            session_factory=self.session_factory,
            repositories=self.repositories,
        )
        await processor.initialize(entity_types)
        parent_inputs, compression_stats = self._compress_parent_inputs(
            child_events,
            token_budget=config.parent_summary_token_budget,
        )
        raw_result = await processor.process(
            parent_inputs,
            {"document_title": await self._load_source_title(config)},
            config.source_type,
            parent=True,
        )
        raw_items = raw_result["data"]["items"]
        if len(raw_items) != 1:
            raise ExtractError("父事项响应必须恰好包含一个事项")
        raw_item = raw_items[0]
        # reason 仅用于给模型思考空间 + 审计，不落库；持久化前剥离。
        raw_item = {k: v for k, v in raw_item.items() if k != "reason"}
        parent_id = str(uuid.uuid4())
        parent = SourceEvent(
            id=parent_id,
            data_source_id=config.data_source_id,
            source_type=config.source_type,
            type=config.source_type,
            source_id=config.source_id,
            article_id=config.source_id if config.source_type == "ARTICLE" else None,
            conversation_id=(
                config.source_id if config.source_type in {"CHAT", "RECORDING"} else None
            ),
            chunk_id=None,
            parent_id=None,
            rank=0,
            level=0,
            title=raw_item["title"],
            summary=raw_item.get("summary", ""),
            content=raw_item["content"],
            category=raw_item.get("category") or None,
            keywords=raw_item.get("keywords") or None,
            priority=raw_item.get("priority") or None,
            status=raw_item.get("status") or None,
            start_time=None,
            end_time=None,
            references=[],
            extra_data={
                "raw_entities": {"entities": raw_item.get("entities", [])},
                "raw_data": raw_item,
                "parent_summary": True,
            },
        )
        for index, child in enumerate(child_events, 1):
            if child.parent_id is None:
                child.parent_id = parent_id
            child.level = max(1, int(child.level or 0) + 1)
            child.rank = index
        return parent, processor.stats, compression_stats

    @staticmethod
    def _compress_parent_inputs(
        events: list[SourceEvent],
        *,
        token_budget: int,
    ) -> tuple[list[Any], dict[str, int]]:
        """Fit child events without silently losing the source boundaries.

        Token counts use the same cl100k tokenizer used by the project utility
        and mirror EventProcessor's parent item formatting and JSON envelope.
        Every event first degrades from full content to summary to title. Only
        then may non-protected middle events be dropped. The first, last, and
        HIGH-priority events are never dropped.
        """
        if not events:
            return [], {
                "parent_input_total": 0,
                "parent_input_included": 0,
                "parent_input_downgraded": 0,
                "parent_input_dropped": 0,
            }

        protected = {0, len(events) - 1}
        protected.update(
            index
            for index, event in enumerate(events)
            if str(event.priority or "").upper() == "HIGH"
        )

        variants: list[list[tuple[str, str]]] = []
        for event in events:
            title = (event.title or "").strip()
            content = (event.content or "").strip()
            summary = (event.summary or "").strip()
            event_variants = [(summary, content or summary or title)]
            if summary and summary != content:
                event_variants.append((summary, summary))
            event_variants.append(("", title))
            # Preserve order while eliminating equivalent representations.
            variants.append(list(dict.fromkeys(event_variants)))

        tiers = [0] * len(events)
        included = set(range(len(events)))

        def total_size() -> int:
            items = []
            for item_id, index in enumerate(sorted(included), 1):
                summary, content = variants[index][tiers[index]]
                formatted = f"标题: {events[index].title or ''}\n摘要: {summary}\n内容: {content}"
                items.append({"id": item_id, "content": formatted})
            payload = json.dumps(
                {"type": "request", "data": {"items": items}},
                ensure_ascii=False,
                separators=(",", ":"),
            )
            return estimate_tokens(payload, method="tiktoken")

        # Degrade ordinary middle events first, then protected boundary/high
        # priority events. This preserves their detail for as long as possible.
        for index in [
            *[i for i in range(len(events)) if i not in protected],
            *[i for i in range(len(events)) if i in protected],
        ]:
            while total_size() > token_budget and tiers[index] < len(variants[index]) - 1:
                tiers[index] += 1

        # Dropping is the final fallback and never applies to protected events.
        drop_order = sorted(
            (index for index in included if index not in protected),
            key=lambda index: (
                str(events[index].priority or "").upper() not in {"LOW", "UNKNOWN", ""},
                abs(index - (len(events) - 1) / 2),
            ),
        )
        for index in drop_order:
            if total_size() <= token_budget:
                break
            included.remove(index)

        if total_size() > token_budget:
            raise ExtractError(
                "parent_summary_token_budget 太小，无法保留首尾及高优先级事项的完整标题"
            )

        result: list[Any] = []
        downgraded = 0
        for index, event in enumerate(events):
            if index not in included:
                continue
            summary, content = variants[index][tiers[index]]
            if tiers[index] > 0:
                downgraded += 1
            result.append(
                SimpleNamespace(
                    title=event.title,
                    summary=summary,
                    content=content,
                )
            )
        return result, {
            "parent_input_total": len(events),
            "parent_input_included": len(result),
            "parent_input_downgraded": downgraded,
            "parent_input_dropped": len(events) - len(result),
            "parent_input_estimated_tokens": total_size(),
        }

    async def _load_source_title(self, config: ExtractConfig) -> str:
        from zleap.sag.db import Article, ChatConversation

        model = Article if config.source_type == "ARTICLE" else ChatConversation
        async with self.session_factory() as session:
            source = await session.get(model, config.source_id)
            return (getattr(source, "title", None) or "") if source else ""

    def _format_previous_context(self, previous_chunk: dict[str, Any] | None) -> str:
        """格式化前文上下文"""
        if not previous_chunk:
            return ""

        title = previous_chunk.get("heading") or previous_chunk.get("title") or "前文"
        content = previous_chunk.get("content", "")

        if len(content) > 300:
            content = content[:300] + "..."

        return f"**{title}**\n{content}"

    def _format_previous_context_for_chunk(
        self,
        chunk: SourceChunk,
        previous_chunk: dict[str, Any] | None,
    ) -> str:
        """heading_strict chunks are independent documents and must not share
        context with a neighbouring Chunk.  Context recovered from the same Chunk
        (anonymous-rejection split) stays available and is marked ``intra_chunk``.
        """
        if self._is_heading_strict(chunk) and not (previous_chunk or {}).get("intra_chunk"):
            return ""
        return self._format_previous_context(previous_chunk)

    @staticmethod
    def _is_heading_strict(chunk: SourceChunk) -> bool:
        return (chunk.extra_data or {}).get("chunk_strategy") == "heading_strict"

    @staticmethod
    def _chunk_log_context(chunk: SourceChunk) -> tuple[str, int | None, str, int]:
        """Bounded, non-sensitive Chunk identifiers for failure diagnostics."""
        content = getattr(chunk, "content", "") or ""
        return (
            chunk.id,
            getattr(chunk, "rank", None),
            getattr(chunk, "heading", "") or "",
            getattr(chunk, "chunk_length", 0) or len(content),
        )

    async def _load_chunk_content(self, chunk: SourceChunk, config: ExtractConfig):
        """加载chunk的内容和元数据"""
        if chunk.source_type == "ARTICLE":
            return await self._load_article_content(chunk, config)
        if chunk.source_type in {"CHAT", "RECORDING"}:
            return await self._load_conversation_content(chunk)
        raise ExtractError(f"不支持的类型: {chunk.source_type}")

    async def _load_conversation_content(self, chunk: SourceChunk):
        """加载聊天/录音消息；录音只复用已由宿主提供的文本消息，不做 ASR。"""
        from zleap.sag.db import ChatConversation, ChatMessage

        async with self.session_factory() as session:
            conversation = await session.get(ChatConversation, chunk.source_id)
            if not conversation:
                raise ExtractError(f"会话不存在: {chunk.source_id}")

            message_ids = chunk.references if chunk.references else []
            query = select(ChatMessage).where(
                ChatMessage.conversation_id == chunk.source_id,
                ChatMessage.del_flag == 0,
            )
            if message_ids:
                query = query.where(ChatMessage.id.in_(message_ids))
            messages = list(
                (await session.execute(query.order_by(ChatMessage.timestamp))).scalars().all()
            )

            previous_chunk = None
            if chunk.rank > 0 and not self._is_heading_strict(chunk):
                previous_chunk = (
                    (
                        await session.execute(
                            select(SourceChunk).where(
                                SourceChunk.source_id == chunk.source_id,
                                SourceChunk.source_type == chunk.source_type,
                                SourceChunk.rank == chunk.rank - 1,
                            )
                        )
                    )
                    .scalars()
                    .first()
                )

            return messages, {
                "title": conversation.title or "",
                "summary": "",
                "chunk_rank": chunk.rank,
                "chunk_heading": chunk.heading,
                "previous_chunk": (
                    {"heading": previous_chunk.heading, "content": previous_chunk.content[:800]}
                    if previous_chunk and previous_chunk.content
                    else None
                ),
            }

    async def _load_article_content(self, chunk: SourceChunk, config: ExtractConfig):
        """加载文章片段 + 上文chunk内容作为背景"""
        from zleap.sag.db import Article, ArticleSection

        async with self.session_factory() as session:
            # 1. 加载文章（源背景）
            article = await session.get(Article, chunk.source_id)
            if not article:
                raise ExtractError(f"文章不存在: {chunk.source_id}")

            # 2. 加载当前chunk的sections（待处理内容）
            section_ids = chunk.references if chunk.references else []

            if section_ids:
                query = select(ArticleSection).where(ArticleSection.id.in_(section_ids))
                # 过滤图片类型的 section（避免噪音）
                # 注意：type 可能为 NULL，需要用 or_ 处理
                if config.filter_image_sections:
                    query = query.where(
                        or_(ArticleSection.type.is_(None), ArticleSection.type != "IMAGE")
                    )
                sections_result = await session.execute(query.order_by(ArticleSection.rank))
            else:
                query = select(ArticleSection).where(ArticleSection.article_id == chunk.source_id)
                # 过滤图片类型的 section（避免噪音）
                # 注意：type 可能为 NULL，需要用 or_ 处理
                if config.filter_image_sections:
                    query = query.where(
                        or_(ArticleSection.type.is_(None), ArticleSection.type != "IMAGE")
                    )
                sections_result = await session.execute(query.order_by(ArticleSection.rank))

            sections = list(sections_result.scalars().all())

            # 3. 加载上一个chunk的内容（上文背景）
            previous_chunk = None
            if chunk.rank > 0 and not self._is_heading_strict(chunk):
                prev_result = await session.execute(
                    select(SourceChunk)
                    .where(SourceChunk.source_id == chunk.source_id)
                    .where(SourceChunk.source_type == "ARTICLE")
                    .where(SourceChunk.rank == chunk.rank - 1)
                )
                previous_chunk = prev_result.scalars().first()  # 使用 first() 避免多行报错

            return sections, {
                # Article 表字段（源背景）
                "title": article.title,
                "summary": article.summary,
                # 当前 Chunk 信息
                "chunk_rank": chunk.rank,
                "chunk_heading": chunk.heading,
                # 上文 Chunk（提供上下文）
                "previous_chunk": (
                    {
                        "heading": previous_chunk.heading,
                        "content": (
                            previous_chunk.content[:800]
                            if len(previous_chunk.content or "") > 800
                            else previous_chunk.content
                        ),
                    }
                    if previous_chunk and previous_chunk.content
                    else None
                ),
            }

    async def _load_entity_types_for_chunk(self, config: ExtractConfig) -> list[DBEntityType]:
        """
        Load entity type definitions (always returns non-empty list)

        Priority:
        1. Default global types (is_default=True)
        2. Source-level custom types

        Returns:
            List of DBEntityType objects
        """
        entity_types: list[DBEntityType] = []

        async with self.session_factory() as session:
            # 加载默认类型
            default_result = await session.execute(
                select(DBEntityType)
                .where(DBEntityType.is_default.is_(True))
                .where(DBEntityType.is_active.is_(True))
            )
            default_types = default_result.scalars().all()
            entity_types.extend(default_types)

            # 加载source级别类型
            if config.data_source_id:
                custom_result = await session.execute(
                    select(DBEntityType)
                    .where(DBEntityType.data_source_id == config.data_source_id)
                    .where(DBEntityType.is_active.is_(True))
                )
                custom_types = custom_result.scalars().all()
                entity_types.extend(custom_types)

        # 按 type 去重，只保留首次出现的实体类型
        seen: set = set()
        deduped: list[DBEntityType] = []
        for et in entity_types:
            if et.type not in seen:
                seen.add(et.type)
                deduped.append(et)
        entity_types = deduped

        self.logger.info("实体类型加载完成: count=%d", len(entity_types))

        return entity_types

    async def _reload_events_with_relations(self, event_ids: list[str]) -> list[SourceEvent]:
        """
        Reload events from database with relations preloaded

        Solves cross-session issue: re-query after save to ensure all relations are loaded correctly

        Args:
            event_ids: List of event IDs

        Returns:
            List of events with complete relations
        """
        if not event_ids:
            return []

        async with self.session_factory() as session:
            result = await session.execute(
                select(SourceEvent)
                .where(SourceEvent.id.in_(event_ids))
                .options(
                    selectinload(SourceEvent.event_associations).selectinload(EventEntity.entity)
                )
            )
            events = list(result.scalars().all())

            # 设置 expire_on_commit=False，确保数据在 session 外可访问
            session.expire_on_commit = False

            # 触发关系数据加载（确保所有字段在 session 外可访问）
            for event in events:
                # 触发事项字段加载
                _ = event.title
                _ = event.created_time

                # 触发关联和实体加载
                if hasattr(event, "event_associations"):
                    for assoc in event.event_associations:
                        _ = assoc.id
                        if assoc.entity:
                            _ = assoc.entity.name
                            _ = assoc.entity.type

            self.logger.info(f"重新加载了 {len(events)} 个事项（包含完整关系）")
            return events
