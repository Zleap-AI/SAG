"""Project SAG-derived logical record groups from physical Markdown tables."""

from __future__ import annotations

import re

from zleap.sag.modules.load.chunking.parser.markdown import MarkdownBlockParser
from zleap.sag.modules.load.chunking.types import BlockType, StructuredBlock
from zleap.sag.pipeline.contracts import TableRecordGroup, TableStructure
from zleap.sag.pipeline.errors import StageInputError

_CELL_REFERENCE = re.compile(r"^([A-Z]+)([1-9][0-9]*)$")


def project_table_record_groups(
    blocks: list[StructuredBlock],
    structure: TableStructure,
) -> list[StructuredBlock]:
    """Replace covered physical tables with deterministic group-local projections."""

    table_blocks = [block for block in blocks if block.block_type == BlockType.TABLE]
    referenced_tables = {
        *(group.table_index for group in structure.groups),
        *structure.suppressed_table_indices,
    }
    if any(table_index >= len(table_blocks) for table_index in referenced_tables):
        raise _invalid("record group references a table that does not exist")

    groups_by_table: dict[int, list[TableRecordGroup]] = {}
    for group in structure.groups:
        groups_by_table.setdefault(group.table_index, []).append(group)
    for table_groups in groups_by_table.values():
        table_groups.sort(
            key=lambda group: (
                group.cell_range.row_start,
                group.cell_range.column_start,
                group.record_group_id,
            )
        )

    projected: list[StructuredBlock] = []
    table_index = 0
    for block in blocks:
        if block.block_type != BlockType.TABLE:
            projected.append(block)
            continue
        if table_index in structure.suppressed_table_indices:
            projected.append(
                StructuredBlock(
                    block_id=f"{block.block_id}:suppressed",
                    block_type=BlockType.TEXT,
                    raw_content="表格区域因记录边界不明确，未生成数值检索证据。\n",
                    heading=block.heading,
                    start_index=block.start_index,
                    end_index=block.end_index,
                    metadata={
                        "table_index": table_index,
                        "table_structure_suppressed": True,
                        "keep_if_short": True,
                    },
                )
            )
            table_index += 1
            continue
        matching_groups = groups_by_table.get(table_index)
        if matching_groups is None:
            projected.append(block)
        else:
            projected.extend(_project_table(block, table_index, matching_groups))
        table_index += 1
    return projected


def _project_table(
    block: StructuredBlock,
    table_index: int,
    groups: list[TableRecordGroup],
) -> list[StructuredBlock]:
    lines = block.raw_content.splitlines()
    if len(lines) < 2:
        raise _invalid("record group references a malformed Markdown table")
    header = MarkdownBlockParser._split_table_cells(lines[0])
    if header is None:
        raise _invalid("record group references a malformed Markdown table header")
    logical_rows = [header]
    for line in lines[2:]:
        cells = MarkdownBlockParser._split_table_cells(line)
        if cells is None or len(cells) != len(header):
            raise _invalid("record group references a malformed Markdown table row")
        logical_rows.append(cells)

    output: list[StructuredBlock] = []
    for group in groups:
        cell_range = group.cell_range
        if cell_range.row_end > len(logical_rows) or cell_range.column_end > len(header):
            raise _invalid("record group cell range exceeds the physical table")
        selected = [
            row[cell_range.column_start - 1 : cell_range.column_end]
            for row in logical_rows[cell_range.row_start - 1 : cell_range.row_end]
        ]
        context_values = _identity_values(group, logical_rows)
        canonical_header, canonical_body = _projection_parts(selected, context_values)
        canonical_raw_content = _render_table(canonical_header, canonical_body)
        display_rows = group.metadata.get("display_rows")
        normalized_display_rows: list[list[str]] = []
        if isinstance(display_rows, list):
            for row in display_rows:
                if not isinstance(row, list):
                    normalized_display_rows = []
                    break
                normalized_display_rows.append([str(value) for value in row])
        if normalized_display_rows:
            selected = normalized_display_rows
        projected_header, body = _projection_parts(selected, context_values)
        raw_content = _render_table(projected_header, body)
        # Inference metadata is descriptive only. The validated record boundary
        # remains the authoritative retrieval contract.
        provenance = {
            **group.metadata,
            "record_group_id": group.record_group_id,
            "table_index": table_index,
            "cell_range": cell_range.model_dump(mode="json", exclude={"contract_version"}),
            "identity_cells": list(group.identity_cells),
            "canonical_raw_content": canonical_raw_content,
        }
        output.append(
            StructuredBlock(
                block_id=f"{block.block_id}:record:{group.record_group_id}",
                block_type=BlockType.TABLE,
                raw_content=raw_content,
                heading=block.heading,
                start_index=block.start_index,
                end_index=block.end_index,
                metadata={**block.metadata, **provenance, "record_group_projected": True},
            )
        )
    return output


def _projection_parts(
    selected: list[list[str]], context_values: list[str]
) -> tuple[list[str], list[list[str]]]:
    if context_values:
        context = " / ".join(context_values)
        return [context, *([""] * (len(selected[0]) - 1))], selected
    header, *body = selected
    return header, body


def _identity_values(group: TableRecordGroup, rows: list[list[str]]) -> list[str]:
    values: list[str] = []
    for reference in group.identity_cells:
        match = _CELL_REFERENCE.fullmatch(reference)
        if match is None:
            raise _invalid("identity cell reference is not valid A1 notation")
        column = _column_number(match.group(1))
        row = int(match.group(2))
        cell_range = group.cell_range
        if not (
            cell_range.row_start <= row <= cell_range.row_end
            and cell_range.column_start <= column <= cell_range.column_end
        ):
            raise _invalid("identity cell lies outside its record group")
        value = rows[row - 1][column - 1].strip()
        if value and value not in values:
            values.append(value)
    return values


def _column_number(letters: str) -> int:
    value = 0
    for letter in letters:
        value = value * 26 + ord(letter) - ord("A") + 1
    return value


def _render_table(header: list[str], body: list[list[str]]) -> str:
    def row(values: list[str]) -> str:
        return "| " + " | ".join(value.strip() for value in values) + " |\n"

    return row(header) + row(["---"] * len(header)) + "".join(row(values) for values in body)


def _invalid(message: str) -> StageInputError:
    return StageInputError(message, stage="chunk", code="invalid_table_structure")


__all__ = ["project_table_record_groups"]
