"""Policy-based SourceChunk assembly for text and Markdown tables."""

from __future__ import annotations

from zleap.sag.exceptions import InvalidInputError
from zleap.sag.modules.load.chunking.base import BaseSourceChunkAssembler
from zleap.sag.modules.load.chunking.tokenizer import TokenizerTokenEstimator
from zleap.sag.modules.load.chunking.types import (
    BlockType,
    ChunkDraft,
    InputDocument,
    SectionDraft,
)
from zleap.sag.utils import get_logger

logger = get_logger("modules.load.chunking.assembler")


class PolicyBasedSourceChunkAssembler(BaseSourceChunkAssembler):
    """Greedily combine text while keeping every table self-contained."""

    def __init__(
        self,
        source_chunk_max_tokens: int,
        standalone_block_max_tokens: int = 600,
        heading_strict: bool = False,
    ) -> None:
        self.source_chunk_max_tokens = max(64, min(source_chunk_max_tokens, 1000))
        self.standalone_block_max_tokens = max(1, standalone_block_max_tokens)
        self.token_estimator = TokenizerTokenEstimator()
        self.heading_strict = heading_strict

    def assemble_chunks(
        self,
        doc: InputDocument,
        sections: list[SectionDraft],
    ) -> list[ChunkDraft]:
        _ = doc
        logger.info(
            "generic assembler 开始: sections=%d, max_tokens=%d, standalone_threshold=%d",
            len(sections),
            self.source_chunk_max_tokens,
            self.standalone_block_max_tokens,
        )
        chunks: list[ChunkDraft] = []
        current: list[SectionDraft] = []
        current_tokens = 0

        ordered_sections = sorted(sections, key=lambda item: item.order_index)
        index = 0
        while index < len(ordered_sections):
            section = ordered_sections[index]

            if self._is_table_section(section):
                if current:
                    chunks.append(self._build_chunk(current))
                    current = []
                    current_tokens = 0

                group_index = section.render_group_index
                table_group: list[SectionDraft] = []
                while index < len(ordered_sections):
                    candidate = ordered_sections[index]
                    if candidate.render_group_index != group_index or not self._is_table_section(
                        candidate
                    ):
                        break
                    table_group.append(candidate)
                    index += 1
                chunks.extend(self._build_table_chunks(table_group))
                continue

            section_tokens = self._section_tokens(section)

            # heading_strict 模式：遇到新标题强制断开
            if self.heading_strict and current and section.heading != current[0].heading:
                chunks.append(self._build_chunk(current))
                current = []
                current_tokens = 0

            # 大块（>standalone_block_max_tokens）独立成 chunk
            if section_tokens > self.standalone_block_max_tokens:
                if current:
                    chunks.append(self._build_chunk(current))
                    current = []
                    current_tokens = 0

                # 图片/代码/公式是原子语义块，过长也保持独立成块、不做内部拆分。
                if section.section_type in {
                    BlockType.IMAGE.value,
                    BlockType.CODE.value,
                    BlockType.FORMULA.value,
                }:
                    logger.info(
                        "%s Section 超过独立阈值，保持独立: order=%d, tokens=%d",
                        section.section_type,
                        section.order_index,
                        section_tokens,
                    )
                    chunks.append(self._build_chunk([section]))
                    index += 1
                    continue

                # 大块内部按 source_chunk_max_tokens 切分
                for unit in self._split_large_section(section):
                    chunks.append(self._build_chunk([unit]))
                index += 1
                continue

            # 小块贪婪聚合
            if not current:
                current = [section]
                current_tokens = section_tokens
            elif current_tokens + section_tokens <= self.source_chunk_max_tokens:
                current.append(section)
                current_tokens += section_tokens
            else:
                chunks.append(self._build_chunk(current))
                current = [section]
                current_tokens = section_tokens
            index += 1

        if current:
            chunks.append(self._build_chunk(current))

        for idx, chunk in enumerate(chunks):
            chunk.rank = idx
        mixed_chunks = sum(
            len(set(chunk.metadata.get("section_types", []))) > 1 for chunk in chunks
        )
        logger.info(
            "generic assembler 完成: sections=%d, chunks=%d, mixed_chunks=%d",
            len(sections),
            len(chunks),
            mixed_chunks,
        )
        return chunks

    @staticmethod
    def _is_table_section(section: SectionDraft) -> bool:
        return (
            section.section_type == BlockType.TABLE.value
            or section.metadata.get("assemble_policy") == "table_with_header"
        )

    def _build_table_chunks(self, sections: list[SectionDraft]) -> list[ChunkDraft]:
        if not sections:
            return []

        header = next(
            (section for section in sections if section.metadata.get("role") == "table_header"),
            sections[0],
        )
        rows = [section for section in sections if section is not header]
        if not rows:
            return [
                self._build_chunk(
                    [header],
                    metadata={
                        "assemble_policy": "table_with_header",
                        "table_block_id": header.metadata.get("block_id"),
                        "row_start": 0,
                        "row_end": 0,
                        "row_count": 0,
                        "header_repeated": False,
                        "oversized_row": self._sections_tokens([header])
                        > self.source_chunk_max_tokens,
                    },
                )
            ]

        units: list[tuple[list[SectionDraft], bool]] = []
        current_rows: list[SectionDraft] = []
        for row in rows:
            candidate = [header, *current_rows, row]
            if self._sections_tokens(candidate) <= self.source_chunk_max_tokens:
                current_rows.append(row)
                continue
            if current_rows:
                units.append(([header, *current_rows], False))
                current_rows = []
            oversized = self._sections_tokens([header, row]) > self.source_chunk_max_tokens
            if oversized:
                units.append(([header, row], True))
            else:
                current_rows = [row]

        if current_rows:
            units.append(([header, *current_rows], False))

        header_repeated = len(units) > 1
        chunks: list[ChunkDraft] = []
        for unit, oversized_row in units:
            unit_rows = [section for section in unit if section is not header]
            row_indices = [int(section.metadata.get("row_index", 0)) for section in unit_rows]
            chunks.append(
                self._build_chunk(
                    unit,
                    metadata={
                        "assemble_policy": "table_with_header",
                        "table_block_id": header.metadata.get("block_id"),
                        "row_start": min(row_indices, default=0),
                        "row_end": max(row_indices, default=0),
                        "row_count": len(unit_rows),
                        "header_repeated": header_repeated,
                        "oversized_row": oversized_row,
                    },
                )
            )
        return chunks

    def _split_large_section(self, section: SectionDraft) -> list[SectionDraft]:
        """大 section 按 token 上限切分为多个子 section。"""
        content = section.content.strip()
        if not content:
            return [section]

        # 简单按段落切分
        paragraphs = content.split("\n\n")
        units: list[SectionDraft] = []
        current_parts: list[str] = []
        current_tokens = 0

        for para in paragraphs:
            para_tokens = self.token_estimator.estimate_tokens(para)
            if not current_parts:
                current_parts = [para]
                current_tokens = para_tokens
            elif current_tokens + para_tokens <= self.source_chunk_max_tokens:
                current_parts.append(para)
                current_tokens += para_tokens
            else:
                units.append(self._clone_section(section, "\n\n".join(current_parts)))
                current_parts = [para]
                current_tokens = para_tokens

        if current_parts:
            units.append(self._clone_section(section, "\n\n".join(current_parts)))

        return units if units else [section]

    @staticmethod
    def _clone_section(original: SectionDraft, new_content: str) -> SectionDraft:
        """克隆 section 并替换 content。"""
        return SectionDraft(
            order_index=original.order_index,
            render_group_index=original.render_group_index,
            heading=original.heading,
            content=new_content,
            raw_content=new_content,
            section_type=original.section_type,
            metadata=original.metadata.copy(),
        )

    def _build_chunk(
        self,
        sections: list[SectionDraft],
        *,
        metadata: dict | None = None,
    ) -> ChunkDraft:
        if not sections:
            raise InvalidInputError("Cannot build chunk from empty sections")

        heading = ""
        for sec in sections:
            if sec.heading:
                heading = sec.heading
                break
        content = "".join(s.content for s in sections).strip()
        raw_content = "".join(s.raw_content for s in sections)
        section_order_indices = [s.order_index for s in sections]
        section_types = [s.section_type for s in sections]
        chunk_type = sections[0].section_type
        render_group_indices = sorted({s.render_group_index for s in sections})
        record_group_ids = {
            str(section.metadata["record_group_id"])
            for section in sections
            if "record_group_id" in section.metadata
        }
        if len(record_group_ids) > 1:
            raise InvalidInputError("Cannot build one chunk from multiple record groups")
        provenance = {
            key: sections[0].metadata[key]
            for key in (
                "record_group_id",
                "table_index",
                "cell_range",
                "identity_cells",
                "identity_value",
                "canonical_raw_content",
                "numeric_evidence",
                "sheet_name",
            )
            if key in sections[0].metadata
        }

        return ChunkDraft(
            rank=0,
            heading=heading,
            content=content if content else raw_content,
            raw_content=raw_content,
            chunk_type=chunk_type,
            section_order_indices=section_order_indices,
            metadata={
                "section_order_indices": section_order_indices,
                "section_types": section_types,
                "assembler": "generic",
                "render_group_index": render_group_indices[0],
                "render_group_indices": render_group_indices,
                "chunk_type": chunk_type,
                "keep_if_short": any(
                    bool(section.metadata.get("keep_if_short")) for section in sections
                ),
                **provenance,
                **(metadata or {}),
            },
        )

    def _section_tokens(self, section: SectionDraft) -> int:
        return self.token_estimator.estimate_tokens(section.content.strip())

    def _sections_tokens(self, sections: list[SectionDraft]) -> int:
        content = "".join(section.content for section in sections).strip()
        return self.token_estimator.estimate_tokens(content)


class MarkdownSourceChunkAssembler(PolicyBasedSourceChunkAssembler):
    """Markdown 使用的统一策略组装器。"""

    pass
