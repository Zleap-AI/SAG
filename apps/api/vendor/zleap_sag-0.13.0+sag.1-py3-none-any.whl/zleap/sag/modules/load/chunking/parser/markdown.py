"""
Markdown 输入标准化与结构解析。
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from pathlib import Path

from zleap.sag.modules.load.chunking.base import BaseBlockParser, BaseInputNormalizer
from zleap.sag.modules.load.chunking.parser.html_table import html_table_to_gfm
from zleap.sag.modules.load.chunking.types import BlockType, InputDocument, StructuredBlock
from zleap.sag.utils import normalize_heading_text


class MarkdownInputNormalizer(BaseInputNormalizer):
    """Markdown 输入标准化"""

    def normalize(self, content: str, source_path: Path | None = None) -> InputDocument:
        return InputDocument(
            content=content or "",
            source_path=source_path,
            is_markdown=True,
            metadata={},
        )


class MarkdownBlockParser(BaseBlockParser):
    """Recognize heading-scoped text and valid GitHub-style Markdown tables."""

    HEADING_PATTERN = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
    FENCE_PATTERN = re.compile(r"^[ \t]{0,3}(`{3,}|~{3,})(.*)$")
    TABLE_SEPARATOR_CELL_PATTERN = re.compile(r"^:?-{3,}:?$")
    BLANK_LINE_PATTERN = re.compile(r"\n[ \t]*\n")

    # 支持 ``` / ~~~ 围栏与 CommonMark 允许的 0-3 空格缩进；
    # \2 反向引用同一围栏串，避免 ``` 与 ~~~ 混用闭合。
    CODE_BLOCK_PATTERN = re.compile(
        r"(^[ \t]{0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?^[ \t]{0,3}\2[ \t]*\n?)",
        re.MULTILINE,
    )
    HTML_TABLE_BLOCK_PATTERN = re.compile(
        r"(?:(?<=\n)|\A)[ \t]*<table\b[\s\S]*?</table>[ \t]*(?=\n|$)",
        re.IGNORECASE | re.MULTILINE,
    )
    IMAGE_START_PATTERN = re.compile(r"!\[")
    # 公式块 pattern 与 formula_type 一一对应，供结构化识别与图片排除共用。
    FORMULA_BLOCK_PATTERNS: Sequence[tuple[re.Pattern[str], str]] = (
        (
            re.compile(
                r"(?:(?<=\n)|\A)[ \t]*\$\$[\s\S]*?\$\$[ \t]*(?=\n|$)",
                re.MULTILINE,
            ),
            "double_dollar",
        ),
        (
            re.compile(
                r"(?:(?<=\n)|\A)[ \t]*\\\[[\s\S]*?\\\][ \t]*(?=\n|$)",
                re.MULTILINE,
            ),
            "bracket_math",
        ),
        (
            re.compile(
                (
                    r"(?:(?<=\n)|\A)[ \t]*\\begin\{"
                    r"(equation\*?|align\*?|gather\*?|multline\*?)"
                    r"\}[\s\S]*?\\end\{\1\}[ \t]*(?=\n|$)"
                ),
                re.MULTILINE,
            ),
            "latex_environment",
        ),
    )

    def __init__(self, *, parse_images: bool = False) -> None:
        self.parse_images = parse_images

    def parse_blocks(self, doc: InputDocument) -> list[StructuredBlock]:
        """按源文档顺序输出不重叠的 TEXT、TABLE、CODE、FORMULA、IMAGE blocks。"""
        text = doc.content
        table_spans = self._table_spans(doc)
        occupied = [(start, end) for start, end, _ in table_spans]

        # 结构块按 table -> code -> html-table -> formula 顺序提取，
        # 每步用 occupied 区间互斥，保证同一文本只归一类块。
        # code 优先于 html-table：代码块内的 <table> 字符串不当作表格；
        # html-table 优先于 formula：单元格里的 $$ 不拆散表格。
        code_spans = self._code_spans(text, occupied)
        occupied.extend((start, end) for start, end, _ in code_spans)
        html_table_spans = self._html_table_spans(text, occupied)
        occupied.extend((start, end) for start, end, _ in html_table_spans)
        formula_spans = self._formula_spans(text, occupied)
        occupied.extend((start, end) for start, end, _ in formula_spans)

        image_spans: list[tuple[int, int, dict[str, object]]] = []
        if self.parse_images:
            # 图片语法不得在结构块（代码/公式/表格）内生效。
            image_spans = self._image_spans(text, occupied)

        image_occupied = [(start, end) for start, end, _ in image_spans]
        heading_occupied = self._merge_spans([*occupied, *image_occupied])
        headings = self._heading_positions(text, heading_occupied)

        structural_spans: list[tuple[int, int, BlockType, dict[str, object]]] = [
            (start, end, BlockType.TABLE, metadata) for start, end, metadata in table_spans
        ]
        structural_spans.extend(
            (start, end, BlockType.CODE, metadata) for start, end, metadata in code_spans
        )
        structural_spans.extend(
            (start, end, BlockType.TABLE, metadata) for start, end, metadata in html_table_spans
        )
        structural_spans.extend(
            (start, end, BlockType.FORMULA, metadata) for start, end, metadata in formula_spans
        )
        structural_spans.extend(
            (start, end, BlockType.IMAGE, metadata) for start, end, metadata in image_spans
        )
        structural_spans.sort(key=lambda item: (item[0], item[1]))

        blocks: list[StructuredBlock] = []
        cursor = 0
        counter = 0
        for start, end, block_type, metadata in structural_spans:
            if start < cursor:
                continue
            if start > cursor:
                text_blocks, counter = self._build_text_blocks(
                    text=text,
                    start=cursor,
                    end=start,
                    headings=headings,
                    counter=counter,
                )
                blocks.extend(text_blocks)

            blocks.append(
                StructuredBlock(
                    block_id=f"{block_type.value.lower()}-{counter}",
                    block_type=block_type,
                    # 内嵌 <table> 已转成 GFM，块内容用转换结果；
                    # start/end 仍指向原始 HTML 区间以保留溯源。
                    raw_content=str(metadata.pop("gfm_content", None) or text[start:end]),
                    heading=self._resolve_heading(headings, start),
                    start_index=start,
                    end_index=end,
                    metadata=metadata,
                )
            )
            counter += 1
            cursor = end

        if cursor < len(text):
            text_blocks, counter = self._build_text_blocks(
                text=text,
                start=cursor,
                end=len(text),
                headings=headings,
                counter=counter,
            )
            blocks.extend(text_blocks)
        return [b for b in blocks if b.raw_content != ""]

    def parse_heading_blocks(self, doc: InputDocument) -> list[StructuredBlock]:
        """Legacy heading-only view used by ``heading_strict`` compatibility mode."""
        headings = self._heading_positions(doc.content, [])
        blocks, _ = self._build_text_blocks(
            text=doc.content,
            start=0,
            end=len(doc.content),
            headings=headings,
            counter=0,
        )
        return [block for block in blocks if block.raw_content != ""]

    def _table_spans(self, doc: InputDocument) -> list[tuple[int, int, dict]]:
        lines = self._lines_with_offsets(doc.content)
        spans: list[tuple[int, int, dict]] = []
        fence_char = ""
        fence_length = 0
        index = 0

        while index < len(lines):
            _, _, raw_line = lines[index]
            line = self._without_line_ending(raw_line)
            fence = self._fence_marker(line)
            if fence_char:
                if (
                    fence
                    and fence[0] == fence_char
                    and fence[1] >= fence_length
                    and not fence[2].strip()
                ):
                    fence_char = ""
                    fence_length = 0
                index += 1
                continue
            if fence:
                fence_char, fence_length, _ = fence
                index += 1
                continue

            if index + 1 >= len(lines):
                break
            header_cells = self._split_table_cells(line)
            separator_cells = self._split_table_cells(
                self._without_line_ending(lines[index + 1][2])
            )
            if not self._is_valid_table_start(header_cells, separator_cells):
                index += 1
                continue

            assert header_cells is not None
            column_count = len(header_cells)
            leading_pipe_style = line.lstrip().startswith("|")
            next_index = index + 2
            row_count = 0
            malformed = False
            while next_index < len(lines):
                candidate = self._without_line_ending(lines[next_index][2])
                if (
                    not candidate.strip()
                    or self._fence_marker(candidate)
                    or self.HEADING_PATTERN.match(candidate)
                ):
                    break
                # 若下一行是另一张表(表头+分隔线),当前表在此结束,
                # 避免背靠背表格被合并成一张。
                if next_index + 1 < len(lines):
                    next_candidate = self._without_line_ending(lines[next_index + 1][2])
                    if self._is_valid_table_start(
                        self._split_table_cells(candidate),
                        self._split_table_cells(next_candidate),
                    ):
                        break
                cells = self._split_table_cells(candidate)
                if cells is None or len(cells) != column_count:
                    if "|" in candidate:
                        malformed = True
                        self._append_warning(
                            doc,
                            f"table_column_mismatch:{next_index + 1}",
                        )
                    break
                # 表头带前导管道时,数据行也应带前导管道,否则视为正文,
                # 避免含 "|" 的散文被误吞为表格行。
                if leading_pipe_style and not candidate.lstrip().startswith("|"):
                    break
                row_count += 1
                next_index += 1

            if malformed:
                index += 1
                continue

            start = lines[index][0]
            end = lines[next_index - 1][1]
            source_format = str(
                doc.metadata.get("original_format")
                or doc.metadata.get("source_format")
                or "markdown"
            )
            spans.append(
                (
                    start,
                    end,
                    {
                        "table_format": "markdown",
                        "header_line_count": 2,
                        "row_count": row_count,
                        "column_count": column_count,
                        "source_format": source_format,
                    },
                )
            )
            index = next_index

        return spans

    @staticmethod
    def _append_warning(doc: InputDocument, warning: str) -> None:
        warnings = doc.metadata.setdefault("parse_warnings", [])
        if isinstance(warnings, list) and warning not in warnings:
            warnings.append(warning)

    @classmethod
    def _is_valid_table_start(
        cls,
        header_cells: list[str] | None,
        separator_cells: list[str] | None,
    ) -> bool:
        if not header_cells or separator_cells is None:
            return False
        if len(header_cells) != len(separator_cells):
            return False
        return all(
            cls.TABLE_SEPARATOR_CELL_PATTERN.fullmatch(cell.strip()) for cell in separator_cells
        )

    @classmethod
    def _split_table_cells(cls, line: str) -> list[str] | None:
        stripped = line.strip()
        if not stripped:
            return None

        leading_pipe = stripped.startswith("|")
        trailing_pipe = cls._ends_with_unescaped_pipe(stripped)
        if leading_pipe:
            stripped = stripped[1:]
        if trailing_pipe and stripped:
            stripped = stripped[:-1]

        cells: list[str] = []
        current: list[str] = []
        separator_count = 0
        code_delimiter = 0
        index = 0
        while index < len(stripped):
            char = stripped[index]
            if char == "\\" and index + 1 < len(stripped):
                current.extend((char, stripped[index + 1]))
                index += 2
                continue
            if char == "`":
                run_end = index + 1
                while run_end < len(stripped) and stripped[run_end] == "`":
                    run_end += 1
                run_length = run_end - index
                if code_delimiter == 0:
                    code_delimiter = run_length
                elif code_delimiter == run_length:
                    code_delimiter = 0
                current.extend(stripped[index:run_end])
                index = run_end
                continue
            if char == "|" and code_delimiter == 0:
                cells.append("".join(current))
                current = []
                separator_count += 1
            else:
                current.append(char)
            index += 1
        cells.append("".join(current))

        if separator_count == 0 and not (leading_pipe and trailing_pipe):
            return None
        return cells

    @staticmethod
    def _ends_with_unescaped_pipe(value: str) -> bool:
        if not value.endswith("|"):
            return False
        backslashes = 0
        index = len(value) - 2
        while index >= 0 and value[index] == "\\":
            backslashes += 1
            index -= 1
        return backslashes % 2 == 0

    @classmethod
    def _fence_marker(cls, line: str) -> tuple[str, int, str] | None:
        match = cls.FENCE_PATTERN.match(line)
        if match is None:
            return None
        marker = match.group(1)
        return marker[0], len(marker), match.group(2)

    @staticmethod
    def _without_line_ending(line: str) -> str:
        return line.rstrip("\r\n")

    @staticmethod
    def _lines_with_offsets(text: str) -> list[tuple[int, int, str]]:
        result: list[tuple[int, int, str]] = []
        offset = 0
        for line in text.splitlines(keepends=True):
            end = offset + len(line)
            result.append((offset, end, line))
            offset = end
        return result

    def _heading_positions(
        self,
        text: str,
        occupied: list[tuple[int, int]] | None = None,
    ) -> list[tuple[int, str]]:
        headings: list[tuple[int, str]] = []
        for match in self.HEADING_PATTERN.finditer(text):
            if occupied and self._overlap(match.start(), match.end(), occupied):
                continue
            headings.append((match.start(), normalize_heading_text(match.group(2))))
        return headings

    @staticmethod
    def _merge_spans(
        spans: Sequence[tuple[int, int]],
    ) -> list[tuple[int, int]]:
        merged: list[tuple[int, int]] = []
        for start, end in sorted(spans):
            if end <= start:
                continue
            if merged and start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        return merged

    def _code_spans(
        self,
        text: str,
        occupied: Sequence[tuple[int, int]],
    ) -> list[tuple[int, int, dict[str, object]]]:
        """识别 fenced 代码块为 CODE 结构块（带 language）。"""
        spans: list[tuple[int, int, dict[str, object]]] = []
        for match in self.CODE_BLOCK_PATTERN.finditer(text):
            if self._overlap(match.start(), match.end(), occupied):
                continue
            spans.append(
                (
                    match.start(),
                    match.end(),
                    {"language": self._extract_code_language(match.group(0))},
                )
            )
        return spans

    def _formula_spans(
        self,
        text: str,
        occupied: Sequence[tuple[int, int]],
    ) -> list[tuple[int, int, dict[str, object]]]:
        """识别块级公式为 FORMULA 结构块（带 formula_type）。"""
        spans: list[tuple[int, int, dict[str, object]]] = []
        for pattern, formula_type in self.FORMULA_BLOCK_PATTERNS:
            for match in pattern.finditer(text):
                if self._overlap(match.start(), match.end(), occupied):
                    continue
                if not self._is_plausible_formula(match.group(0)):
                    continue
                spans.append(
                    (
                        match.start(),
                        match.end(),
                        {"formula_type": formula_type},
                    )
                )
        return spans

    @classmethod
    def _is_plausible_formula(cls, raw_formula: str) -> bool:
        """判定一段候选块级公式是否真的是公式。

        分隔符是惰性匹配的，正文里散落的 ``$$``（价格、shell ``$$``）会与后面
        另一处 ``$$`` 误配对，把中间整段正文吞成一个原子 FORMULA 块，连带吞掉
        其中的标题。真正的块级公式不跨空行、也不包含标题行，用这两条排除误配。
        """
        body = raw_formula.strip()
        if not body:
            return False
        if cls.BLANK_LINE_PATTERN.search(body):
            return False
        return not any(cls.HEADING_PATTERN.match(line) for line in body.splitlines())

    def _html_table_spans(
        self,
        text: str,
        occupied: Sequence[tuple[int, int]],
    ) -> list[tuple[int, int, dict[str, object]]]:
        """识别内嵌 `<table>`，转成 GFM 后交给既有行级表格切块。

        转换后与 `.html` 输入走同一条路径：同样的块形状、同样的行级
        reference_key，且天然受 `source_chunk_max_tokens` 约束——保留原始
        HTML 整块会绕过表格路径上唯一的尺寸约束。
        """
        spans: list[tuple[int, int, dict[str, object]]] = []
        for match in self.HTML_TABLE_BLOCK_PATTERN.finditer(text):
            if self._overlap(match.start(), match.end(), occupied):
                continue
            raw_table = match.group(0)
            if not self._has_balanced_table_tags(raw_table):
                # 开合标签不配平说明非贪婪匹配够到了另一张表的 </table>，
                # 中间整段正文会被吞成一个原子块，判定为误匹配。
                continue
            gfm = html_table_to_gfm(raw_table)
            if not gfm:
                continue
            rows = gfm.splitlines()
            spans.append(
                (
                    match.start(),
                    match.end(),
                    {
                        "table_format": "markdown",
                        "source_format": "html",
                        "converted_from": "html",
                        "html_source": raw_table,
                        "header_line_count": 2,
                        "row_count": max(0, len(rows) - 2),
                        "column_count": rows[0].count("|") - 1 if rows else 0,
                        "gfm_content": gfm,
                    },
                )
            )
        return spans

    @staticmethod
    def _has_balanced_table_tags(raw_table: str) -> bool:
        opens = len(re.findall(r"<table\b", raw_table, re.IGNORECASE))
        closes = len(re.findall(r"</table\s*>", raw_table, re.IGNORECASE))
        return opens == closes

    @staticmethod
    def _extract_code_language(raw_code_block: str) -> str:
        first_line = raw_code_block.splitlines()[0] if raw_code_block else ""
        match = MarkdownBlockParser.FENCE_PATTERN.match(first_line.strip())
        return (match.group(2).strip() if match else "") or ""

    def _image_spans(
        self,
        text: str,
        occupied: Sequence[tuple[int, int]],
    ) -> list[tuple[int, int, dict[str, object]]]:
        spans: list[tuple[int, int, dict[str, object]]] = []
        for match in self.IMAGE_START_PATTERN.finditer(text):
            parsed = self._parse_image(text, match.start())
            if parsed is None:
                continue
            start, end, alt_text, image_src, title, link = parsed
            if self._overlap(start, end, occupied):
                continue
            metadata: dict[str, object] = {
                "alt_text": alt_text.strip(),
                "image_src": image_src.strip(),
                "link": link.strip() if link else None,
            }
            if title is not None:
                metadata["title"] = title.strip()
            spans.append(
                (
                    start,
                    end,
                    metadata,
                )
            )
        return spans

    @classmethod
    def _parse_image(
        cls,
        text: str,
        image_start: int,
    ) -> tuple[int, int, str, str, str | None, str | None] | None:
        """Parse one inline image, including balanced destinations and an optional link."""
        if cls._is_escaped(text, image_start):
            return None

        alt_end = cls._closing_square_bracket(text, image_start + 1)
        if alt_end is None or alt_end + 1 >= len(text) or text[alt_end + 1] != "(":
            return None
        target = cls._parse_target(text, alt_end + 1)
        if target is None:
            return None

        image_end, image_src, title = target
        start = image_start
        end = image_end
        link: str | None = None

        # Linked image: [![alt](image "title")](target)
        if (
            image_start > 0
            and text[image_start - 1] == "["
            and not cls._is_escaped(text, image_start - 1)
            and image_end + 1 < len(text)
            and text[image_end] == "]"
            and text[image_end + 1] == "("
        ):
            link_target = cls._parse_target(text, image_end + 1)
            if link_target is not None:
                end, link, _ = link_target
                start = image_start - 1

        alt_text = text[image_start + 2 : alt_end]
        return start, end, alt_text, image_src, title, link

    @classmethod
    def _closing_square_bracket(cls, text: str, opening: int) -> int | None:
        depth = 1
        index = opening + 1
        while index < len(text):
            if text[index] == "\\" and index + 1 < len(text):
                index += 2
                continue
            if text[index] == "[":
                depth += 1
            elif text[index] == "]":
                depth -= 1
                if depth == 0:
                    return index
            index += 1
        return None

    @classmethod
    def _parse_target(cls, text: str, opening: int) -> tuple[int, str, str | None] | None:
        """Return ``(end, destination, title)`` for a Markdown ``(...)`` target."""
        index = opening + 1
        while index < len(text) and text[index] in " \t":
            index += 1

        if index < len(text) and text[index] == "<":
            destination_start = index + 1
            destination_end = cls._find_unescaped(text, destination_start, ">")
            if destination_end is None:
                return None
            destination = text[destination_start:destination_end]
            index = destination_end + 1
        else:
            destination_start = index
            depth = 0
            while index < len(text):
                char = text[index]
                if char == "\\" and index + 1 < len(text):
                    index += 2
                    continue
                if char == "(":
                    depth += 1
                elif char == ")":
                    if depth == 0:
                        break
                    depth -= 1
                elif char in " \t\r\n" and depth == 0:
                    break
                index += 1
            destination = text[destination_start:index]

        destination = cls._unescape_markdown(destination)
        while index < len(text) and text[index] in " \t\r\n":
            index += 1
        if index >= len(text):
            return None
        if text[index] == ")":
            return index + 1, destination, None

        title_result = cls._parse_title(text, index)
        if title_result is None:
            return None
        index, title = title_result
        while index < len(text) and text[index] in " \t\r\n":
            index += 1
        if index >= len(text) or text[index] != ")":
            return None
        return index + 1, destination, title

    @classmethod
    def _parse_title(cls, text: str, start: int) -> tuple[int, str] | None:
        delimiter = text[start]
        if delimiter in {'"', "'"}:
            end = cls._find_unescaped(text, start + 1, delimiter)
            if end is None:
                return None
            return end + 1, text[start + 1 : end]
        if delimiter != "(":
            return None

        depth = 1
        index = start + 1
        while index < len(text):
            if text[index] == "\\" and index + 1 < len(text):
                index += 2
                continue
            if text[index] == "(":
                depth += 1
            elif text[index] == ")":
                depth -= 1
                if depth == 0:
                    return index + 1, text[start + 1 : index]
            index += 1
        return None

    @staticmethod
    def _find_unescaped(text: str, start: int, needle: str) -> int | None:
        index = start
        while index < len(text):
            if text[index] == "\\" and index + 1 < len(text):
                index += 2
                continue
            if text[index] == needle:
                return index
            if text[index] in "\r\n":
                return None
            index += 1
        return None

    @staticmethod
    def _is_escaped(text: str, position: int) -> bool:
        backslashes = 0
        position -= 1
        while position >= 0 and text[position] == "\\":
            backslashes += 1
            position -= 1
        return backslashes % 2 == 1

    @staticmethod
    def _unescape_markdown(value: str) -> str:
        escapable = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
        result: list[str] = []
        index = 0
        while index < len(value):
            if value[index] == "\\" and index + 1 < len(value) and value[index + 1] in escapable:
                index += 1
            result.append(value[index])
            index += 1
        return "".join(result)

    @staticmethod
    def _overlap(start: int, end: int, occupied: Sequence[tuple[int, int]]) -> bool:
        return any(
            start < occupied_end and end > occupied_start
            for occupied_start, occupied_end in occupied
        )

    @staticmethod
    def _resolve_heading(headings: list[tuple[int, str]], position: int) -> str:
        if not headings:
            return ""
        candidate = ""
        for pos, title in headings:
            if pos <= position:
                candidate = title
            else:
                break
        return candidate

    def _build_text_blocks(
        self,
        text: str,
        start: int,
        end: int,
        headings: list[tuple[int, str]],
        counter: int,
    ) -> tuple[list[StructuredBlock], int]:
        """把文本段按标题边界进一步拆分，保证 Section 可拿到就近标题。"""
        if start >= end:
            return [], counter

        split_points = [pos for pos, _ in headings if start < pos < end]
        boundaries = [start, *split_points, end]
        blocks: list[StructuredBlock] = []

        for idx in range(len(boundaries) - 1):
            seg_start = boundaries[idx]
            seg_end = boundaries[idx + 1]
            raw = text[seg_start:seg_end]
            if raw == "":
                continue
            blocks.append(
                StructuredBlock(
                    block_id=f"text-{counter}",
                    block_type=BlockType.TEXT,
                    raw_content=raw,
                    heading=self._resolve_heading(headings, seg_start),
                    start_index=seg_start,
                    end_index=seg_end,
                )
            )
            counter += 1

        return blocks, counter
