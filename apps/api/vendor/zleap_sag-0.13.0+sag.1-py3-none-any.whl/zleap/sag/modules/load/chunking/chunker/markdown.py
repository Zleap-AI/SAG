"""Markdown Block -> Section 编排（纯文本简化版）。"""

from __future__ import annotations

from zleap.sag.modules.load.chunking.base import BaseArticleSectionBuilder
from zleap.sag.modules.load.chunking.chunker.code import MarkdownCodeChunker
from zleap.sag.modules.load.chunking.chunker.formula import MarkdownFormulaChunker
from zleap.sag.modules.load.chunking.chunker.image import MarkdownImageChunker
from zleap.sag.modules.load.chunking.chunker.router import BlockChunkerRouter
from zleap.sag.modules.load.chunking.chunker.table import MarkdownTableChunker
from zleap.sag.modules.load.chunking.chunker.text import MarkdownTextChunker
from zleap.sag.modules.load.chunking.types import (
    BlockType,
    InputDocument,
    SectionDraft,
    StructuredBlock,
)


class MarkdownArticleSectionBuilder(BaseArticleSectionBuilder):
    """纯文本 md：直接用 MarkdownTextChunker 处理所有 blocks。"""

    def __init__(
        self,
        section_max_tokens: int,
        router: BlockChunkerRouter | None = None,
    ) -> None:
        self.section_max_tokens = max(32, section_max_tokens)
        self.chunker = MarkdownTextChunker(
            section_max_tokens=self.section_max_tokens,
        )
        self.router = router or BlockChunkerRouter(
            chunker_by_type={
                BlockType.TEXT: self.chunker,
                BlockType.CODE: MarkdownCodeChunker(),
                BlockType.FORMULA: MarkdownFormulaChunker(),
                BlockType.TABLE: MarkdownTableChunker(),
                BlockType.IMAGE: MarkdownImageChunker(),
            },
            default_chunker=self.chunker,
        )

    async def build_sections(
        self,
        doc: InputDocument,
        blocks: list[StructuredBlock],
    ) -> list[SectionDraft]:
        _ = doc
        sections: list[SectionDraft] = []
        order_index = 0
        render_group_index = 0

        for block in blocks:
            render_group_index += 1
            block_sections = await self.router.resolve(block).build_sections(
                block=block,
                order_start=order_index,
                render_group_index=render_group_index,
            )
            sections.extend(block_sections)
            order_index += len(block_sections)

        sections = self._merge_whitespace_only_text_sections(sections)
        for idx, section in enumerate(sections):
            section.order_index = idx
        return sections

    @classmethod
    def _merge_whitespace_only_text_sections(
        cls,
        sections: list[SectionDraft],
    ) -> list[SectionDraft]:
        """把"仅空白的 TEXT section"吸附到相邻 TEXT section，避免产生无语义 section。

        空白不吸附进 TABLE section：表格是自包含块，其 raw_content 与
        metadata 里的 start_index/end_index 描述原始表格文本，追加空白会破坏
        偏移溯源的一致性。
        """
        if len(sections) <= 1:
            return sections

        merged: list[SectionDraft] = []
        leading_whitespace = ""

        for section in sections:
            if cls._is_whitespace_only_text_section(section):
                ws = section.raw_content if section.raw_content is not None else section.content
                if merged and cls._is_text_section(merged[-1]):
                    cls._append_trailing_whitespace(merged[-1], ws)
                else:
                    leading_whitespace += ws
                continue

            if leading_whitespace:
                if cls._is_text_section(section):
                    cls._prepend_leading_whitespace(section, leading_whitespace)
                leading_whitespace = ""
            merged.append(section)

        if leading_whitespace:
            if merged and cls._is_text_section(merged[-1]):
                cls._append_trailing_whitespace(merged[-1], leading_whitespace)
            elif not merged:
                return sections

        return merged

    @staticmethod
    def _is_text_section(section: SectionDraft) -> bool:
        return section.section_type == BlockType.TEXT.value

    @staticmethod
    def _is_whitespace_only_text_section(section: SectionDraft) -> bool:
        if section.section_type != BlockType.TEXT.value:
            return False
        raw = section.raw_content if section.raw_content is not None else section.content
        return raw.strip() == ""

    @staticmethod
    def _append_trailing_whitespace(section: SectionDraft, whitespace: str) -> None:
        if not whitespace:
            return
        section.raw_content = f"{section.raw_content}{whitespace}"
        if section.section_type == BlockType.TEXT.value:
            section.content = f"{section.content}{whitespace}"

    @staticmethod
    def _prepend_leading_whitespace(section: SectionDraft, whitespace: str) -> None:
        if not whitespace:
            return
        section.raw_content = f"{whitespace}{section.raw_content}"
        if section.section_type == BlockType.TEXT.value:
            section.content = f"{whitespace}{section.content}"
