"""Markdown 图片语义增强使用的内部运行时类型。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from pydantic import Field

from zleap.sag.validation import SagBaseModel as BaseModel


@dataclass(frozen=True, slots=True)
class LoadedImage:
    """单次语义增强使用的图片字节对象，不得持久化。"""

    data: bytes
    mime_type: str
    sha256: str
    width: int | None = None
    height: int | None = None


class ImageAnalysis(BaseModel):
    """旧版 ``response.analysis`` 返回数据的规范化结构。"""

    schema_version: Literal["image-analysis-v1"] = "image-analysis-v1"
    objects: tuple[str, ...] = ()
    scene: str = ""
    explain: dict[str, str] = Field(default_factory=dict)
    ocr_text: str = ""
    reasoning: str = ""


IMAGE_ANALYSIS_SCHEMA: dict[str, object] = {
    "type": "object",
    "properties": {
        "type": {"type": "string", "enum": ["图像", "image"]},
        "analysis": {
            "type": "object",
            "properties": {
                "objects": {"type": "array", "items": {"type": "string"}},
                "scene": {"type": "string"},
                "explain": {
                    "type": "object",
                    "additionalProperties": {"type": "string"},
                },
                "ocr_text": {"type": "string"},
                "reasoning": {"type": "string"},
            },
            "required": ["objects", "scene", "explain", "ocr_text", "reasoning"],
            "additionalProperties": False,
        },
    },
    "required": ["type", "analysis"],
    "additionalProperties": False,
}


__all__ = ["IMAGE_ANALYSIS_SCHEMA", "ImageAnalysis", "LoadedImage"]
