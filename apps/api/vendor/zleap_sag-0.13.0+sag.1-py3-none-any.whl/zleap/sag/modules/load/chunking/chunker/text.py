"""Markdown 文本块切分（带链接/公式/行内代码防切）。"""

from __future__ import annotations

import re

from zleap.sag.modules.load.chunking.chunker.base import BaseBlockChunker
from zleap.sag.modules.load.chunking.tokenizer import TokenizerTokenEstimator
from zleap.sag.modules.load.chunking.types import BlockType, SectionDraft, StructuredBlock


class MarkdownTextChunker(BaseBlockChunker):
    """TEXT block 切分器。

    切分时把链接、自动链接、块/行内公式、行内代码视为受保护片段，
    避免从这些强语义单元的中间切开。
    """

    PRIMARY_DELIMITERS = (
        "\r\n\r\n",
        "\n\n",
        "\r\n",
        "\n",
        "\r",
        "。",
        "！",
        "？",
        "!",
        "?",
        ". ",
    )
    SECONDARY_DELIMITERS = (
        "，",
        ",",
        "、",
        "；",
        ";",
    )
    LINK_PATTERN = re.compile(r"\[[^\]\n]*\]\([^)\n]*\)")
    AUTOLINK_PATTERN = re.compile(r"<(?:https?://|mailto:)[^>\n]+>")
    BLOCK_DOLLAR_MATH_PATTERN = re.compile(r"\$\$[\s\S]*?\$\$")
    BLOCK_BRACKET_MATH_PATTERN = re.compile(r"\\\[[\s\S]*?\\\]")
    LATEX_ENV_MATH_PATTERN = re.compile(
        r"\\begin\{(equation\*?|align\*?|gather\*?|multline\*?)\}[\s\S]*?\\end\{\1\}"
    )
    INLINE_PAREN_MATH_PATTERN = re.compile(r"\\\([^\n]*?\\\)")
    # 行内公式/行内代码的合理跨度上限：超长跨度更可能是文本里的孤立
    # $/反引号（价格、$VAR、误写），不应作为受保护片段阻断切分。
    MAX_INLINE_PROTECTED_LEN = 200

    def __init__(self, section_max_tokens: int) -> None:
        self.section_max_tokens = max(32, section_max_tokens)
        self.token_estimator = TokenizerTokenEstimator()

    async def build_sections(
        self,
        block: StructuredBlock,
        order_start: int,
        render_group_index: int,
    ) -> list[SectionDraft]:
        text_parts = self._split_text(block.raw_content)
        sections: list[SectionDraft] = []
        for idx, part in enumerate(text_parts):
            sections.append(
                SectionDraft(
                    order_index=order_start + idx,
                    render_group_index=render_group_index,
                    heading=block.heading,
                    content=part,
                    raw_content=part,
                    section_type=BlockType.TEXT.value,
                    metadata={
                        "block_type": BlockType.TEXT.value,
                        "render_format": "markdown_text",
                        "block_id": block.block_id,
                    },
                )
            )
        return sections

    def _split_text(self, text: str) -> list[str]:
        if text == "":
            return [""]
        first_pass = self._split_by_delimiters(text, self.PRIMARY_DELIMITERS)
        if not first_pass:
            first_pass = [text]

        result: list[str] = []
        for part in first_pass:
            tokens = self.token_estimator.estimate_tokens(part)
            if tokens <= self.section_max_tokens:
                result.append(part)
                continue

            second_pass = self._split_by_delimiters(part, self.SECONDARY_DELIMITERS)
            if len(second_pass) <= 1:
                result.extend(self._force_split(part))
                continue

            for frag in second_pass:
                frag_tokens = self.token_estimator.estimate_tokens(frag)
                if frag_tokens <= self.section_max_tokens:
                    result.append(frag)
                else:
                    result.extend(self._force_split(frag))
        return result

    def _split_by_delimiters(self, text: str, delimiters: tuple[str, ...]) -> list[str]:
        parts: list[str] = []
        protected_spans = self._find_protected_spans(text)
        start = 0
        idx = 0
        span_idx = 0
        while idx < len(text):
            while span_idx < len(protected_spans) and idx >= protected_spans[span_idx][1]:
                span_idx += 1

            next_span_start = len(text) + 1
            if span_idx < len(protected_spans):
                span_start, span_end = protected_spans[span_idx]
                next_span_start = span_start
                if span_start <= idx < span_end:
                    # 当前位于受保护片段内部：整体跳过，不在其中切分。
                    idx = span_end
                    continue

            matched = None
            for delimiter in delimiters:
                if text.startswith(delimiter, idx):
                    if idx + len(delimiter) > next_span_start:
                        continue
                    if delimiter == ". " and self._is_ordered_list_marker(text, idx):
                        continue
                    matched = delimiter
                    break

            if matched:
                end = idx + len(matched)
                parts.append(text[start:end])
                start = end
                idx = end
            else:
                idx += 1

        if start < len(text):
            parts.append(text[start:])
        normalized_parts = self._merge_whitespace_only_parts(parts if parts else [text])
        return normalized_parts if normalized_parts else [text]

    def _force_split(self, text: str) -> list[str]:
        chunks: list[str] = []
        current_pos = 0
        protected_spans = self._find_protected_spans(text)
        while current_pos < len(text):
            remaining = text[current_pos:]
            cut = self._find_prefix_len_by_tokens(remaining, self.section_max_tokens)
            if cut <= 0:
                cut = 1
            # 切点落在受保护片段内时，回退到片段末尾，保证不切开链接/公式/代码。
            cut = self._adjust_cut_for_protected_spans(
                absolute_cut=current_pos + cut,
                current_pos=current_pos,
                protected_spans=protected_spans,
            )
            chunks.append(remaining[:cut])
            current_pos += cut
        return chunks

    def _find_prefix_len_by_tokens(self, text: str, max_tokens: int) -> int:
        if not text:
            return 0
        low, high = 0, len(text)
        best = 0
        while low <= high:
            mid = (low + high) // 2
            prefix = text[:mid]
            tokens = self.token_estimator.estimate_tokens(prefix)
            if tokens <= max_tokens:
                best = mid
                low = mid + 1
            else:
                high = mid - 1
        return best

    @classmethod
    def _find_protected_spans(cls, text: str) -> list[tuple[int, int]]:
        """返回链接/公式/行内代码等不可切分区间的合并列表。

        所有片段统一受 ``MAX_INLINE_PROTECTED_LEN`` 约束：超长跨度更可能是
        正文里散落的 ``$``/``[``/反引号被误配对（价格、shell ``$$``、超长 URL），
        真把它当成不可切分区间会让整段正文突破 ``section_max_tokens``。
        """
        spans: list[tuple[int, int]] = []
        for pattern in (
            cls.LINK_PATTERN,
            cls.AUTOLINK_PATTERN,
            cls.BLOCK_DOLLAR_MATH_PATTERN,
            cls.BLOCK_BRACKET_MATH_PATTERN,
            cls.LATEX_ENV_MATH_PATTERN,
            cls.INLINE_PAREN_MATH_PATTERN,
        ):
            spans.extend(
                (m.start(), m.end())
                for m in pattern.finditer(text)
                if m.end() - m.start() <= cls.MAX_INLINE_PROTECTED_LEN
            )
        spans.extend(cls._find_inline_code_spans(text))
        spans.extend(cls._find_inline_dollar_math_spans(text))
        # 合并可能把背靠背的片段拼成超长区间，这里再兜一次上限。
        return [
            (start, end)
            for start, end in cls._merge_spans(spans)
            if end - start <= cls.MAX_INLINE_PROTECTED_LEN
        ]

    @classmethod
    def _find_inline_code_spans(cls, text: str) -> list[tuple[int, int]]:
        """识别成对的反引号行内代码区间。

        跨行或跨度超过 ``MAX_INLINE_PROTECTED_LEN`` 的反引号对视为普通文本，
        不做保护，避免孤立的单个反引号把整段文本变成一个不可切分区间。
        """
        spans: list[tuple[int, int]] = []
        idx = 0
        while idx < len(text):
            if text[idx] != "`":
                idx += 1
                continue

            tick_count = 1
            while idx + tick_count < len(text) and text[idx + tick_count] == "`":
                tick_count += 1

            fence = "`" * tick_count
            closing = text.find(fence, idx + tick_count)
            if closing == -1:
                idx += tick_count
                continue

            span_text = text[idx + tick_count : closing]
            if "\n" in span_text or closing - idx > cls.MAX_INLINE_PROTECTED_LEN:
                idx += tick_count
                continue

            spans.append((idx, closing + tick_count))
            idx = closing + tick_count
        return spans

    @classmethod
    def _find_inline_dollar_math_spans(cls, text: str) -> list[tuple[int, int]]:
        """识别行内 $...$ 公式区间（跳过转义 \\$ 与块公式起始）。

        跨度超过 ``MAX_INLINE_PROTECTED_LEN`` 的 $...$ 对视为普通文本
        （价格、$VAR 等误判），不做保护。
        """
        spans: list[tuple[int, int]] = []
        idx = 0
        while idx < len(text):
            if text[idx] != "$":
                idx += 1
                continue
            if (idx > 0 and text[idx - 1] == "\\") or (
                idx + 1 < len(text) and text[idx + 1] == "$"
            ):
                idx += 1
                continue

            end = idx + 1
            while end < len(text):
                if text[end] == "\n":
                    end = -1
                    break
                if (
                    text[end] == "$"
                    and text[end - 1] != "\\"
                    and not (end + 1 < len(text) and text[end + 1] == "$")
                ):
                    if end - idx <= cls.MAX_INLINE_PROTECTED_LEN:
                        spans.append((idx, end + 1))
                    idx = end + 1
                    break
                end += 1
            else:
                end = -1

            if end == -1:
                idx += 1
        return spans

    @staticmethod
    def _merge_spans(spans: list[tuple[int, int]]) -> list[tuple[int, int]]:
        """合并相邻/重叠区间，返回有序列表。"""
        if not spans:
            return []

        ordered = sorted(spans, key=lambda item: (item[0], item[1]))
        merged: list[tuple[int, int]] = [ordered[0]]
        for start, end in ordered[1:]:
            prev_start, prev_end = merged[-1]
            if start <= prev_end:
                merged[-1] = (prev_start, max(prev_end, end))
            else:
                merged.append((start, end))
        return merged

    @staticmethod
    def _adjust_cut_for_protected_spans(
        absolute_cut: int,
        current_pos: int,
        protected_spans: list[tuple[int, int]],
    ) -> int:
        """调整落在受保护片段内部的切点，且不放大分块尺寸。

        优先把切点**前移**到片段起点，让整个片段进入下一块——这样既不切开
        片段，也不会让当前块超过 ``section_max_tokens``。只有当片段恰好从块
        首开始（前移会切出空块）时才后退到片段末尾；此时的超额由
        ``MAX_INLINE_PROTECTED_LEN`` 兜住。
        """
        for span_start, span_end in protected_spans:
            if span_start < absolute_cut < span_end:
                if span_start > current_pos:
                    return span_start - current_pos
                return span_end - current_pos
        return max(1, absolute_cut - current_pos)

    @staticmethod
    def _is_ordered_list_marker(text: str, dot_pos: int) -> bool:
        """判断 dot_pos 处的 '. ' 是否是有序列表序号（如 '1. '）的一部分。

        行首可选空白 + 纯数字 + '. ' 视为列表标记，不作为分隔符切断。
        只向前扫描有限窗口（最长序号 + 缩进上限），避免超长单行的 O(n²) 退化。
        """
        if dot_pos == 0:
            return False
        # 有序列表序号最长约 6 位数字加最多 4 格缩进，扫描窗口上限设为 16。
        window_start = max(0, dot_pos - 16)
        nl = text.rfind("\n", window_start, dot_pos)
        line_start = nl + 1 if nl != -1 else (0 if dot_pos <= 16 else -1)
        if line_start == -1:
            return False
        segment = text[line_start:dot_pos]
        return segment.lstrip(" \t").isdigit()

    @staticmethod
    def _merge_whitespace_only_parts(parts: list[str]) -> list[str]:
        if len(parts) <= 1:
            return parts

        merged: list[str] = []
        leading_whitespace = ""
        for part in parts:
            if part.strip() == "":
                if merged:
                    merged[-1] += part
                else:
                    leading_whitespace += part
                continue

            if leading_whitespace:
                part = f"{leading_whitespace}{part}"
                leading_whitespace = ""
            merged.append(part)

        if leading_whitespace:
            if merged:
                merged[-1] += leading_whitespace
            else:
                merged.append(leading_whitespace)
        return merged
