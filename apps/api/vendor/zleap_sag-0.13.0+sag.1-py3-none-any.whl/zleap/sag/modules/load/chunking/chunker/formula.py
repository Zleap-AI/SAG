"""Markdown 公式块切分。"""

from __future__ import annotations

from zleap.sag.modules.load.chunking.chunker.base import BaseBlockChunker
from zleap.sag.modules.load.chunking.types import BlockType, SectionDraft, StructuredBlock


class MarkdownFormulaChunker(BaseBlockChunker):
    """FORMULA block 切分器：整块保留，不做内部切分。

    块级公式（$$...$$ / \\[...\\] / \\begin{equation}）是完整语义单元，
    从中间切开会破坏公式含义，因此始终产出单个 SectionDraft。
    """

    async def build_sections(
        self,
        block: StructuredBlock,
        order_start: int,
        render_group_index: int,
    ) -> list[SectionDraft]:
        return [
            SectionDraft(
                order_index=order_start,
                render_group_index=render_group_index,
                heading=block.heading,
                content=block.raw_content,
                raw_content=block.raw_content,
                section_type=BlockType.FORMULA.value,
                metadata={
                    "block_type": BlockType.FORMULA.value,
                    "render_format": "markdown_formula",
                    "block_id": block.block_id,
                    "formula_type": block.metadata.get("formula_type", ""),
                    "split_strategy": "single_formula_single_section",
                    "assemble_policy": "generic",
                    # 短公式不被 min_content_length 过滤（对齐 IMAGE 的原子块语义）。
                    "keep_if_short": True,
                },
            )
        ]
