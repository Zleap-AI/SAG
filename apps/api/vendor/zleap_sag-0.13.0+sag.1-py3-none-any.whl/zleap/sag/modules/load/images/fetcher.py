"""为 Markdown 图片语义增强提供受约束的图片加载。"""

from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
from time import perf_counter
from typing import TYPE_CHECKING
from urllib.parse import SplitResult, urlsplit, urlunsplit

from zleap.sag.modules.load.images.types import LoadedImage
from zleap.sag.pipeline.errors import ParseError
from zleap.sag.utils import get_logger

if TYPE_CHECKING:
    import aiohttp

logger = get_logger("load.images")

_MIME_BY_SUFFIX = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
}

_REMOTE_SCHEMES = frozenset({"http", "https"})
_DOWNLOAD_CHUNK_BYTES = 64 * 1024


class ImageLoadError(ParseError):
    """单张图片加载错误，由 BuiltinImageEnricher 统一捕获并降级。"""


def _unwrap(src: str) -> str:
    """剥离 Markdown 尖括号目标语法 ``<...>``。"""
    value = src.strip()
    return value[1:-1] if value.startswith("<") and value.endswith(">") else value


def sanitize_image_src(src: str) -> str:
    """清除远程图片引用中的凭据、查询参数和片段，供安全持久化。"""
    value = _unwrap(src)
    parsed = urlsplit(value)
    if parsed.scheme.lower() not in _REMOTE_SCHEMES:
        return value
    host = parsed.hostname or ""
    netloc = host
    try:
        port = parsed.port
    except ValueError:
        port = None
    if port is not None:
        netloc = f"{host}:{port}"
    return urlunsplit((parsed.scheme.lower(), netloc, parsed.path, "", ""))


class ImageFetcher:
    """在来源策略和字节上限约束下加载本地或内网图片。"""

    def __init__(
        self,
        *,
        max_bytes: int,
        fetch_timeout: int = 15,
        fetch_connect_timeout: int = 5,
    ) -> None:
        self.max_bytes = max_bytes
        self._fetch_timeout = fetch_timeout
        self._fetch_connect_timeout = fetch_connect_timeout
        self._session: aiohttp.ClientSession | None = None
        self._session_lock = asyncio.Lock()

    async def fetch(self, src: str, *, source_path: Path | None) -> LoadedImage:
        value = _unwrap(src)
        parsed = urlsplit(value)
        scheme = parsed.scheme.lower()
        if scheme in _REMOTE_SCHEMES:
            data, mime_type = await self._fetch_remote(parsed)
        elif scheme or parsed.netloc:
            raise ImageLoadError(
                "内置图片读取器不支持该图片来源协议",
                stage="parse",
                code="unsupported_image_source",
            )
        else:
            data, mime_type = await self._fetch_local(value, source_path)
        return LoadedImage(
            data=data,
            mime_type=mime_type,
            sha256=hashlib.sha256(data).hexdigest(),
        )

    async def _fetch_local(self, src: str, source_path: Path | None) -> tuple[bytes, str]:
        relative = Path(src)
        if relative.is_absolute():
            candidate = relative.resolve()
        else:
            if source_path is None:
                raise ImageLoadError(
                    "本地相对图片需要 Markdown 文件路径",
                    stage="parse",
                    code="image_base_path_required",
                )
            root = source_path.resolve().parent
            candidate = (root / relative).resolve()
            try:
                candidate.relative_to(root)
            except ValueError as exc:
                raise ImageLoadError(
                    "图片路径越过 Markdown 文件目录",
                    stage="parse",
                    code="image_path_outside_source",
                ) from exc
        mime_type = _MIME_BY_SUFFIX.get(candidate.suffix.lower())
        if mime_type is None:
            raise ImageLoadError(
                "不支持的本地图片格式",
                stage="parse",
                code="unsupported_image_mime",
            )
        try:
            stat = await asyncio.to_thread(candidate.stat)
            if not candidate.is_file():
                raise OSError("not a file")
            if stat.st_size <= 0:
                raise ImageLoadError("图片文件为空", stage="parse", code="empty_image")
            if stat.st_size > self.max_bytes:
                raise ImageLoadError(
                    "图片超过 VLM_MAX_IMAGE_BYTES",
                    stage="parse",
                    code="image_too_large",
                )
            data = await asyncio.to_thread(candidate.read_bytes)
            if len(data) > self.max_bytes:
                raise ImageLoadError(
                    "图片超过 VLM_MAX_IMAGE_BYTES",
                    stage="parse",
                    code="image_too_large",
                )
        except ImageLoadError:
            raise
        except OSError as exc:
            raise ImageLoadError(
                "本地图片读取失败",
                stage="parse",
                code="image_read_failed",
                cause_summary=type(exc).__name__,
            ) from exc
        return data, mime_type

    async def _fetch_remote(self, parsed: SplitResult) -> tuple[bytes, str]:
        try:
            host = parsed.hostname
        except ValueError as exc:
            raise ImageLoadError(
                "远程图片地址非法",
                stage="parse",
                code="image_fetch_failed",
            ) from exc
        if not host:
            raise ImageLoadError(
                "远程图片地址缺少主机名",
                stage="parse",
                code="image_fetch_failed",
            )
        # 抓取必须用原始 URL：签名类查询参数(如 AWS SigV4)去掉即失效。
        # 仅日志与持久化走 sanitize_image_src。
        return await self._download(urlunsplit(parsed))

    async def _download(self, url: str) -> tuple[bytes, str]:
        import aiohttp

        # 日志一律用清洗后的 URL：原始 URL 的 query 可能带签名/令牌。
        safe_url = sanitize_image_src(url)
        started_at = perf_counter()
        session = await self._ensure_session()
        try:
            # 公网图床/CDN 普遍用 302 跳转到实际存储，需跟随；限制跳数防跳转环。
            async with session.get(url, allow_redirects=True, max_redirects=5) as response:
                if response.status != 200:
                    logger.warning(
                        "远程图片请求失败: url=%s, status=%s",
                        safe_url,
                        response.status,
                    )
                    raise ImageLoadError(
                        "远程图片请求失败",
                        stage="parse",
                        code="image_fetch_failed",
                        cause_summary=f"status={response.status}",
                    )
                declared = response.content_length
                if declared is not None and declared > self.max_bytes:
                    raise ImageLoadError(
                        "图片超过 VLM_MAX_IMAGE_BYTES",
                        stage="parse",
                        code="image_too_large",
                    )
                buffer = bytearray()
                # Content-Length 可以谎报，按实际字节流二次设限。
                async for chunk in response.content.iter_chunked(_DOWNLOAD_CHUNK_BYTES):
                    buffer.extend(chunk)
                    if len(buffer) > self.max_bytes:
                        raise ImageLoadError(
                            "图片超过 VLM_MAX_IMAGE_BYTES",
                            stage="parse",
                            code="image_too_large",
                        )
                mime_type = (response.headers.get("Content-Type") or "").split(";")[0].strip()
        except ImageLoadError:
            raise
        # Python 3.11+ 下 asyncio.TimeoutError 即内置 TimeoutError；
        # aiohttp.ServerTimeoutError 也继承它，故必须先于 ClientError 捕获。
        except TimeoutError as exc:
            logger.warning(
                "远程图片请求超时: url=%s, error=%s",
                safe_url,
                type(exc).__name__,
            )
            raise ImageLoadError(
                "远程图片请求超时",
                stage="parse",
                code="image_fetch_timeout",
                cause_summary=type(exc).__name__,
            ) from exc
        except aiohttp.ClientError as exc:
            logger.warning(
                "远程图片请求失败: url=%s, error=%s",
                safe_url,
                type(exc).__name__,
            )
            raise ImageLoadError(
                "远程图片请求失败",
                stage="parse",
                code="image_fetch_failed",
                cause_summary=type(exc).__name__,
            ) from exc
        if not buffer:
            raise ImageLoadError("图片文件为空", stage="parse", code="empty_image")
        logger.info(
            "远程图片下载完成: url=%s, bytes=%d, content_type=%s, 耗时=%.3fs",
            safe_url,
            len(buffer),
            mime_type or "-",
            perf_counter() - started_at,
        )
        # 响应头可以撒谎，真实格式由 preprocess_image 的 Pillow 校验覆写。
        return bytes(buffer), mime_type or "application/octet-stream"

    async def _ensure_session(self) -> aiohttp.ClientSession:
        """懒建 session：必须在 running loop 内创建，并接入 aclose 关闭链路。"""
        if self._session is None:
            async with self._session_lock:
                if self._session is None:
                    import aiohttp

                    self._session = aiohttp.ClientSession(
                        timeout=aiohttp.ClientTimeout(
                            total=self._fetch_timeout,
                            connect=self._fetch_connect_timeout,
                        )
                    )
        return self._session

    async def aclose(self) -> None:
        """关闭远程抓取持有的 HTTP session；纯本地加载时无资源可关。"""
        session = self._session
        self._session = None
        if session is not None:
            await session.close()
