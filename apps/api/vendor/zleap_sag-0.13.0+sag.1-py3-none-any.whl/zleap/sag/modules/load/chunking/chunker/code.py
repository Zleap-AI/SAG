"""Markdown 代码块切分。"""

from __future__ import annotations

from zleap.sag.modules.load.chunking.chunker.base import BaseBlockChunker
from zleap.sag.modules.load.chunking.types import BlockType, SectionDraft, StructuredBlock


class MarkdownCodeChunker(BaseBlockChunker):
    """CODE block 切分器：整块保留，不做内部切分。

    代码块是强语义原子单元，切开会破坏可执行/可读语义，因此一个
    fenced 代码块始终产出单个 SectionDraft，并携带 language 元数据。
    """

    async def build_sections(
        self,
        block: StructuredBlock,
        order_start: int,
        render_group_index: int,
    ) -> list[SectionDraft]:
        return [
            SectionDraft(
                order_index=order_start,
                render_group_index=render_group_index,
                heading=block.heading,
                content=block.raw_content,
                raw_content=block.raw_content,
                section_type=BlockType.CODE.value,
                metadata={
                    "block_type": BlockType.CODE.value,
                    "render_format": "markdown_code",
                    "block_id": block.block_id,
                    "language": block.metadata.get("language", ""),
                    "split_strategy": "single_block_placeholder",
                    "assemble_policy": "generic",
                    # 短代码块不被 min_content_length 过滤（对齐 IMAGE 的原子块语义）。
                    "keep_if_short": True,
                },
            )
        ]
