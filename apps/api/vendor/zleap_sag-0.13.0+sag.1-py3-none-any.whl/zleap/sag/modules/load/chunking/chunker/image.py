"""IMAGE block 到可组装 ArticleSection 的纯转换。"""

from __future__ import annotations

from zleap.sag.modules.load.chunking.chunker.base import BaseBlockChunker
from zleap.sag.modules.load.chunking.types import BlockType, SectionDraft, StructuredBlock


class MarkdownImageChunker(BaseBlockChunker):
    """将已 enrichment 的图片映射为可与相邻文本组装的 Section。"""

    async def build_sections(
        self,
        block: StructuredBlock,
        order_start: int,
        render_group_index: int,
    ) -> list[SectionDraft]:
        enrichment = block.metadata.get("image_enrichment")
        enrichment_data = enrichment if isinstance(enrichment, dict) else {}
        semantic_text = str(enrichment_data.get("semantic_text") or "").strip()
        if not semantic_text:
            semantic_text = "[IMAGE]\n\nalt: 未提供\n内容: 未获取成功\n\n[/IMAGE]"

        metadata = dict(block.metadata)
        metadata.update(
            {
                "block_type": BlockType.IMAGE.value,
                "block_id": block.block_id,
                "render_format": "image_semantic_text",
                "keep_if_short": True,
            }
        )
        return [
            SectionDraft(
                order_index=order_start,
                render_group_index=render_group_index,
                heading=block.heading,
                content=semantic_text,
                raw_content=block.raw_content,
                section_type=BlockType.IMAGE.value,
                metadata=metadata,
            )
        ]
