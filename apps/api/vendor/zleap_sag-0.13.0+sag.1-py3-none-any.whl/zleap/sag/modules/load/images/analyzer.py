"""使用注入的 VLM 资源实现内置 Markdown 图片语义增强。"""

from __future__ import annotations

import asyncio
import hashlib
import json
from pathlib import Path
from typing import Any

from zleap.sag.config import ImageProcessingConfig
from zleap.sag.core.ai.image_messages import image_part_from_bytes, user_message_with_images
from zleap.sag.core.ai.models import LLMMessage, LLMRole
from zleap.sag.modules.load.images.fetcher import (
    ImageFetcher,
    ImageLoadError,
    sanitize_image_src,
)
from zleap.sag.modules.load.images.preprocessor import preprocess_image
from zleap.sag.modules.load.images.types import (
    IMAGE_ANALYSIS_SCHEMA,
    ImageAnalysis,
    LoadedImage,
)
from zleap.sag.pipeline.context import CancellationToken
from zleap.sag.pipeline.contracts import ParsedBlock
from zleap.sag.pipeline.errors import PipelineCancelledError
from zleap.sag.utils import get_logger

logger = get_logger("load.images")


class BuiltinImageEnricher:
    """加载、校验并分析图片，将结果安全写入 ParsedBlock。"""

    def __init__(
        self,
        *,
        vlm: Any,
        prompt_manager: Any,
        options: ImageProcessingConfig,
        max_image_bytes: int,
        detail: str | None,
        model_name: str | None = None,
        fetcher: ImageFetcher | None = None,
    ) -> None:
        self._vlm = vlm
        self._prompt = prompt_manager.render("image_analysis")
        self._options = options
        self._detail = detail
        self._fetcher = fetcher or ImageFetcher(
            max_bytes=max_image_bytes,
            fetch_timeout=options.fetch_timeout,
            fetch_connect_timeout=options.fetch_connect_timeout,
        )
        model = model_name or str(getattr(getattr(vlm, "config", None), "model", "unknown"))
        fingerprint_payload = json.dumps(
            {
                "model": model,
                "detail": detail,
                "prompt": self._prompt,
                "schema": IMAGE_ANALYSIS_SCHEMA,
            },
            ensure_ascii=False,
            sort_keys=True,
        ).encode("utf-8")
        self._fingerprint = hashlib.sha256(fingerprint_payload).hexdigest()

    @property
    def fingerprint(self) -> str:
        return self._fingerprint

    async def enrich_many(
        self,
        blocks: tuple[ParsedBlock, ...],
        *,
        source_path: Path | None,
        cancellation: CancellationToken,
    ) -> tuple[ParsedBlock, ...]:
        semaphore = asyncio.Semaphore(self._options.max_concurrency)
        fetch_tasks: dict[str, asyncio.Task[LoadedImage]] = {}
        analysis_tasks: dict[str, asyncio.Task[ImageAnalysis]] = {}
        task_lock = asyncio.Lock()

        async def fetch_once(src: str) -> LoadedImage:
            """按来源去重：同一 URL 在文档中重复出现时只抓取一次。"""
            async with task_lock:
                task = fetch_tasks.get(src)
                if task is None:
                    task = asyncio.create_task(self._fetcher.fetch(src, source_path=source_path))
                    fetch_tasks[src] = task
            return await task

        async def enrich(block: ParsedBlock) -> ParsedBlock:
            if block.block_type.lower() != "image":
                return block
            async with semaphore:
                self._raise_if_cancelled(cancellation)
                src = str(block.metadata.get("image_src") or "")
                alt_text = str(block.metadata.get("alt_text") or "")
                loaded: LoadedImage | None = None
                try:
                    loaded = await fetch_once(src)
                    loaded, skip_code = await preprocess_image(
                        loaded,
                        min_short_edge=self._options.min_short_edge,
                    )
                    self._raise_if_cancelled(cancellation)
                    if skip_code:
                        return self._updated_block(
                            block,
                            src=src,
                            alt_text=alt_text,
                            loaded=loaded,
                            status="skipped",
                            semantic_text=render_image_semantic(
                                alt_text, "超小图片，可忽略", (), success=False
                            ),
                            analysis=None,
                            error_code=skip_code,
                        )
                    async with task_lock:
                        task = analysis_tasks.get(loaded.sha256)
                        if task is None:
                            task = asyncio.create_task(self._analyze(loaded, alt_text))
                            analysis_tasks[loaded.sha256] = task
                    analysis = await task
                    return self._updated_block(
                        block,
                        src=src,
                        alt_text=alt_text,
                        loaded=loaded,
                        status="success",
                        semantic_text=render_analysis(alt_text, analysis),
                        analysis=analysis,
                        error_code=None,
                    )
                except PipelineCancelledError:
                    raise
                except Exception as exc:
                    error_code = str(getattr(exc, "code", "image_enrichment_failed"))
                    logger.warning(
                        "图片 enrichment 失败: src=%s, error_code=%s, error=%s",
                        sanitize_image_src(src),
                        error_code,
                        type(exc).__name__,
                    )
                    return self._updated_block(
                        block,
                        src=src,
                        alt_text=alt_text,
                        loaded=loaded,
                        status="failed",
                        semantic_text=render_image_semantic(
                            alt_text, "未获取成功", (), success=False
                        ),
                        analysis=None,
                        error_code=error_code,
                    )

        return tuple(await asyncio.gather(*(enrich(block) for block in blocks)))

    async def _analyze(self, loaded: LoadedImage, alt_text: str) -> ImageAnalysis:
        part = image_part_from_bytes(loaded.data, loaded.mime_type, self._detail)
        messages = [
            LLMMessage(role=LLMRole.SYSTEM, content=self._prompt),
            user_message_with_images(
                f"请分析这张图片。Markdown alt: {alt_text or '未提供'}",
                [part],
            ),
        ]
        response = await self._vlm.chat_with_schema(
            messages,
            response_schema=IMAGE_ANALYSIS_SCHEMA,
        )
        if not isinstance(response, dict):
            raise ImageLoadError(
                "VLM 图片分析响应必须是对象",
                stage="parse",
                code="invalid_image_analysis",
            )
        return ImageAnalysis.model_validate(response.get("analysis"))

    def _updated_block(
        self,
        block: ParsedBlock,
        *,
        src: str,
        alt_text: str,
        loaded: LoadedImage | None,
        status: str,
        semantic_text: str,
        analysis: ImageAnalysis | None,
        error_code: str | None,
    ) -> ParsedBlock:
        metadata = dict(block.metadata)
        metadata["image_src"] = sanitize_image_src(src)
        metadata["alt_text"] = alt_text
        # content 提供下游语义文本；metadata 保留完整结果，并桥接无 content 字段的
        # StructuredBlock。raw_content 始终保留原始 Markdown 图片语法。
        metadata["image_enrichment"] = {
            "status": status,
            "image_src": sanitize_image_src(src),
            "alt_text": alt_text,
            "image_width": loaded.width if loaded else None,
            "image_height": loaded.height if loaded else None,
            "image_sha256": loaded.sha256 if loaded else None,
            "semantic_text": semantic_text,
            "analysis": analysis.model_dump(mode="json") if analysis else None,
            "error_code": error_code,
            "analyzer_fingerprint": self.fingerprint,
        }
        return block.model_copy(update={"content": semantic_text, "metadata": metadata})

    @staticmethod
    def _raise_if_cancelled(cancellation: CancellationToken) -> None:
        if cancellation.is_cancelled:
            raise PipelineCancelledError("流水线已取消", stage="parse", code="pipeline_cancelled")

    async def aclose(self) -> None:
        await self._fetcher.aclose()


def render_analysis(alt_text: str, analysis: ImageAnalysis) -> str:
    content_lines: list[str] = []
    for value in (analysis.scene, analysis.reasoning):
        _append_unique(content_lines, value)
    for key, value in analysis.explain.items():
        _append_unique(content_lines, f"{key}：{value}" if key else value)
    if analysis.ocr_text.strip():
        _append_unique(content_lines, f"图中文字：{analysis.ocr_text.strip()}")
    return render_image_semantic(
        alt_text,
        "\n".join(content_lines),
        analysis.objects,
        success=True,
    )


def render_image_semantic(
    alt_text: str,
    content: str,
    scene_elements: tuple[str, ...],
    *,
    success: bool,
) -> str:
    lines = ["[IMAGE]", "", f"alt: {alt_text or '未提供'}"]
    if success:
        lines.extend(["", "内容:"])
        lines.extend(content.splitlines() if content else ["未获取成功"])
        if scene_elements:
            lines.extend(["", "场景元素:"])
            lines.extend(f"- {item}" for item in scene_elements)
    else:
        lines.append(f"内容: {content or '未获取成功'}")
    lines.extend(["", "[/IMAGE]"])
    return "\n".join(lines)


def _append_unique(lines: list[str], value: str) -> None:
    normalized = value.strip()
    if normalized and normalized not in lines:
        lines.append(normalized)
