"""
文档处理器

负责生成向量
"""

import time

from zleap.sag._safe_error import safe_error_type
from zleap.sag.exceptions import AIError, ConfigError
from zleap.sag.utils import estimate_tokens, get_logger

logger = get_logger("modules.load.processor")


def _log_embedding_failure(label: str, error: AIError) -> None:
    log = logger.warning if error.retryable else logger.error
    log("%s\n%s", label, error, extra={"error_type": safe_error_type(error)})


class DocumentProcessor:
    """文档处理器，负责向量生成"""

    def __init__(
        self,
        embedding_client=None,
    ) -> None:
        """
        初始化文档处理器

        Args:
            embedding_client: 当前 Engine 实例拥有的 Embedding 适配器
        """
        if embedding_client is None:
            raise ConfigError("DocumentProcessor 需要显式注入 embedding_client")
        self._embedding_client = embedding_client
        inner = getattr(embedding_client, "inner", embedding_client)
        config = getattr(inner, "_config", None)
        self.embedding_model_name = str(getattr(config, "model", "injected"))
        logger.info(
            "文档处理器初始化完成",
            extra={
                "embedding_model_name": self.embedding_model_name,
            },
        )

    async def generate_embedding(self, text: str) -> list[float]:
        """
        生成文本向量

        Args:
            text: 文本内容

        Returns:
            向量列表

        Raises:
            AIError: 向量生成失败
        """
        try:
            total_start = time.perf_counter()

            truncate_start = time.perf_counter()
            truncated_text = self._truncate_content(text, max_tokens=8000)
            truncate_time = time.perf_counter() - truncate_start

            logger.debug(f"生成向量，文本长度: {len(text)}字符")

            api_start = time.perf_counter()
            embedding = await self._embedding_client.generate(truncated_text)
            api_time = time.perf_counter() - api_start

            total_time = time.perf_counter() - total_start

            logger.info(
                f"向量生成耗时统计 - "
                f"总耗时: {total_time:.3f}s, "
                f"文本截断: {truncate_time:.3f}s ({truncate_time / total_time * 100:.1f}%), "
                f"API调用: {api_time:.3f}s ({api_time / total_time * 100:.1f}%), "
                f"向量维度: {len(embedding)}"
            )

            return embedding

        except AIError as e:
            _log_embedding_failure("向量生成失败", e)
            raise
        except Exception as e:
            logger.error("向量生成失败\n%s", e, extra={"error_type": safe_error_type(e)})
            raise AIError(f"向量生成失败：{e}", cause=e) from e

    async def generate_embeddings(self, texts: list[str]) -> list[list[float]]:
        """
        批量生成文本向量

        与逐条 generate_embedding + gather 相比，只发一次 embeddings.create 请求，
        省掉 N-1 次 HTTP 往返与对应的限流预算。截断与错误映射语义保持一致。

        Args:
            texts: 文本内容列表

        Returns:
            向量列表，顺序与入参一致

        Raises:
            AIError: 向量生成失败
        """
        if not texts:
            return []

        try:
            truncated = [self._truncate_content(text, max_tokens=8000) for text in texts]
            return await self._embedding_client.batch_generate(truncated)

        except AIError as e:
            _log_embedding_failure("批量向量生成失败", e)
            raise
        except Exception as e:
            logger.error("批量向量生成失败\n%s", e, extra={"error_type": safe_error_type(e)})
            raise AIError(f"批量向量生成失败：{e}", cause=e) from e

    def _truncate_content(self, content: str, max_tokens: int) -> str:
        """
        截断内容以适应 token 限制

        Args:
            content: 原始内容
            max_tokens: 最大 token 数

        Returns:
            截断后的内容
        """
        estimated_tokens = estimate_tokens(content)

        if estimated_tokens <= max_tokens:
            return content

        # 按比例截断，留 10% 余量
        ratio = max_tokens / estimated_tokens
        target_length = int(len(content) * ratio * 0.9)
        truncated = content[:target_length]

        logger.debug(
            f"内容截断: {len(content)}字符 -> {len(truncated)}字符 "
            f"({estimated_tokens} tokens -> ~{max_tokens} tokens)"
        )

        return truncated
