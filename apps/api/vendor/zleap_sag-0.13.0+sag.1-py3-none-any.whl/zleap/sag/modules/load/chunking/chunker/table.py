"""Header-aware Markdown table Block -> Section splitting."""

from __future__ import annotations

from zleap.sag.modules.load.chunking.chunker.base import BaseBlockChunker
from zleap.sag.modules.load.chunking.types import BlockType, SectionDraft, StructuredBlock


class MarkdownTableChunker(BaseBlockChunker):
    """Emit one reusable header Section followed by one Section per complete row."""

    async def build_sections(
        self,
        block: StructuredBlock,
        order_start: int,
        render_group_index: int,
    ) -> list[SectionDraft]:
        lines = block.raw_content.splitlines(keepends=True)
        if len(lines) < 2:
            return [self._raw_section(block, order_start, render_group_index)]

        column_count = int(block.metadata.get("column_count", 0) or 0)
        row_count = int(block.metadata.get("row_count", max(0, len(lines) - 2)) or 0)
        header_raw = "".join(lines[:2])
        header_end = block.start_index + len(header_raw)
        common = {
            **block.metadata,
            "block_type": BlockType.TABLE.value,
            "render_format": "markdown_table",
            "assemble_policy": "table_with_header",
            "block_id": block.block_id,
            "column_count": column_count,
            "table_row_count": row_count,
            "table_format": "markdown",
            "source_format": block.metadata.get("source_format", "markdown"),
        }
        sections = [
            SectionDraft(
                order_index=order_start,
                render_group_index=render_group_index,
                heading=block.heading,
                content=header_raw,
                raw_content=header_raw,
                section_type=BlockType.TABLE.value,
                metadata={
                    **common,
                    "role": "table_header",
                    "row_index": 0,
                    "start_index": block.start_index,
                    "end_index": header_end,
                    "reference_key": f"{block.block_id}:header",
                },
            )
        ]

        offset = header_end
        output_row_index = 1
        for row in lines[2:]:
            row_start = offset
            offset += len(row)
            if not row.strip():
                continue
            sections.append(
                SectionDraft(
                    order_index=order_start + output_row_index,
                    render_group_index=render_group_index,
                    heading=block.heading,
                    content=row,
                    raw_content=row,
                    section_type=BlockType.TABLE.value,
                    metadata={
                        **common,
                        "role": "table_row",
                        "row_index": output_row_index,
                        "start_index": row_start,
                        "end_index": offset,
                        "reference_key": f"{block.block_id}:row:{output_row_index}",
                    },
                )
            )
            output_row_index += 1
        return sections

    @staticmethod
    def _raw_section(
        block: StructuredBlock,
        order_start: int,
        render_group_index: int,
    ) -> SectionDraft:
        return SectionDraft(
            order_index=order_start,
            render_group_index=render_group_index,
            heading=block.heading,
            content=block.raw_content,
            raw_content=block.raw_content,
            section_type=BlockType.TABLE.value,
            metadata={
                **block.metadata,
                "block_type": BlockType.TABLE.value,
                "render_format": "markdown_table",
                "assemble_policy": "table_with_header",
                "role": "table_raw",
                "block_id": block.block_id,
                "start_index": block.start_index,
                "end_index": block.end_index,
                "reference_key": f"{block.block_id}:raw",
            },
        )
