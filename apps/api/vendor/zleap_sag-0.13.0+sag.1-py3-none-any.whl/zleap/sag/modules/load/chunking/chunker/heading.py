"""Markdown 标题严格切块服务。"""

from __future__ import annotations

from collections.abc import Sequence

from zleap.sag.modules.load.chunking.types import BlockType, ChunkDraft, StructuredBlock


class MarkdownHeadingStrictChunker:
    """每个非空 Markdown 标题 block 原样生成一个 chunk。

    该策略实现 SAG-Benchmark 的 ``heading_strict`` 语义：

    - 每遇到一个 Markdown 标题就开始新 chunk；
    - 连续同名标题也保持为不同 chunk；
    - 不做句子级或 token 级二次切分；
    - 保留标题行，并去掉 chunk 首尾空白。
    """

    def split_blocks(self, blocks: Sequence[StructuredBlock]) -> list[ChunkDraft]:
        chunks: list[ChunkDraft] = []
        for block_order, block in enumerate(blocks):
            enrichment = block.metadata.get("image_enrichment")
            enrichment_data = enrichment if isinstance(enrichment, dict) else {}
            is_image = block.block_type == BlockType.IMAGE
            content = (
                str(enrichment_data.get("semantic_text") or "").strip()
                if is_image
                else block.raw_content.strip()
            )
            if not content:
                continue
            chunks.append(
                ChunkDraft(
                    rank=len(chunks),
                    heading=block.heading,
                    content=content,
                    raw_content=block.raw_content.strip(),
                    chunk_type=block.block_type.value,
                    section_order_indices=[block_order],
                    metadata={
                        "chunk_strategy": "heading_strict",
                        "block_id": block.block_id,
                        "block_order": block_order,
                        "keep_if_short": is_image,
                        **dict(block.metadata),
                    },
                )
            )
        return chunks
