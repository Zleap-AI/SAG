"""在调用 VLM 前校验图片尺寸、内容和 MIME 类型。"""

from __future__ import annotations

import asyncio
import io
from dataclasses import replace

from zleap.sag.core.ai.image_messages import SUPPORTED_IMAGE_MIME_TYPES
from zleap.sag.modules.load.images.fetcher import ImageLoadError
from zleap.sag.modules.load.images.types import LoadedImage


async def preprocess_image(
    loaded: LoadedImage,
    *,
    min_short_edge: int,
) -> tuple[LoadedImage, str | None]:
    """读取真实尺寸和 MIME；图片过小时返回 ``tiny_image`` 并跳过 VLM。"""
    return await asyncio.to_thread(_preprocess_sync, loaded, min_short_edge)


def _preprocess_sync(loaded: LoadedImage, min_short_edge: int) -> tuple[LoadedImage, str | None]:
    try:
        from PIL import Image

        with Image.open(io.BytesIO(loaded.data)) as image:
            width, height = image.size
            mime_type = image.get_format_mimetype() or loaded.mime_type
            image.verify()
    except Exception as exc:
        raise ImageLoadError(
            "图片内容无效或已损坏",
            stage="parse",
            code="invalid_image",
            cause_summary=type(exc).__name__,
        ) from exc
    if mime_type not in SUPPORTED_IMAGE_MIME_TYPES:
        raise ImageLoadError(
            "图片内容格式不受支持",
            stage="parse",
            code="unsupported_image_mime",
        )
    enriched = replace(
        loaded,
        width=width,
        height=height,
        mime_type=mime_type,
    )
    return enriched, "tiny_image" if min(width, height) < min_short_edge else None
