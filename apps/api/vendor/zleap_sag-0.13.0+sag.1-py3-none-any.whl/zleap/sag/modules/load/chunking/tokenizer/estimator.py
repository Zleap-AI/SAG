"""Accurate token estimator backed by a local tokenizer.json file."""

from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import TYPE_CHECKING

from zleap.sag.exceptions import ConfigError, LoadError, ResourceNotFoundError
from zleap.sag.utils import get_logger

if TYPE_CHECKING:
    from tokenizers import Tokenizer

logger = get_logger("modules.load.chunking.tokenizer")

DEFAULT_TOKENIZER_JSON_PATH = Path(__file__).resolve().parent / "assets" / "tokenizer.json"
ENV_KEYS = (
    "DATAFLOW_CHUNKING_TOKENIZER_JSON",
    "DATAFLOW_TOKENIZER_JSON",
)


class TokenizerTokenEstimator:
    """Token estimator using HuggingFace `tokenizers` local JSON model."""

    _tokenizer_cache: dict[str, Tokenizer] = {}
    _lock = threading.Lock()

    def __init__(
        self,
        tokenizer_path: str | Path | None = None,
    ) -> None:
        self.tokenizer_path = self._resolve_tokenizer_path(tokenizer_path)
        self._tokenizer = self._load_tokenizer(self.tokenizer_path)

    def estimate_tokens(self, text: str) -> int:
        if not text:
            return 0
        try:
            encoded = self._tokenizer.encode(text)
            return len(encoded.ids)
        except Exception as exc:
            raise LoadError(f"Tokenizer encode 失败: {exc}", cause=exc) from exc

    @classmethod
    def _resolve_tokenizer_path(cls, tokenizer_path: str | Path | None) -> Path:
        if tokenizer_path is not None:
            return Path(tokenizer_path).expanduser().resolve()
        for key in ENV_KEYS:
            value = os.getenv(key)
            if value:
                return Path(value).expanduser().resolve()
        return DEFAULT_TOKENIZER_JSON_PATH

    @classmethod
    def _load_tokenizer(cls, tokenizer_path: Path) -> Tokenizer:
        key = str(tokenizer_path)
        with cls._lock:
            if key in cls._tokenizer_cache:
                return cls._tokenizer_cache[key]

            if not tokenizer_path.exists():
                raise ResourceNotFoundError(
                    f"Tokenizer 文件不存在: {tokenizer_path}. "
                    f"请放置 tokenizer.json 到该路径，或通过环境变量 "
                    f"{ENV_KEYS[0]}/{ENV_KEYS[1]} 指定路径。",
                    details={"path": str(tokenizer_path)},
                )
            try:
                from tokenizers import Tokenizer
            except ImportError as exc:
                raise ConfigError(
                    "缺少依赖 tokenizers。请先安装 `tokenizers` 后再执行切块。",
                    cause=exc,
                ) from exc

            try:
                tokenizer = Tokenizer.from_file(str(tokenizer_path))
            except Exception as exc:
                raise LoadError(
                    f"加载 tokenizer 失败: {tokenizer_path}, err={exc}", cause=exc
                ) from exc

            cls._tokenizer_cache[key] = tokenizer
            logger.info(f"已加载 tokenizer: {tokenizer_path}")
            return tokenizer
