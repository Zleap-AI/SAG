"""Route recognized block types to their section chunkers."""

from __future__ import annotations

from zleap.sag.modules.load.chunking.chunker.base import BaseBlockChunker
from zleap.sag.modules.load.chunking.types import BlockType, StructuredBlock
from zleap.sag.pipeline.errors import StageInputError


class BlockChunkerRouter:
    """Resolve one chunker for each ``StructuredBlock`` type."""

    def __init__(
        self,
        chunker_by_type: dict[BlockType, BaseBlockChunker],
        default_chunker: BaseBlockChunker | None = None,
    ) -> None:
        self.chunker_by_type = dict(chunker_by_type)
        self.default_chunker = default_chunker

    def resolve(self, block: StructuredBlock) -> BaseBlockChunker:
        chunker = self.chunker_by_type.get(block.block_type)
        if chunker is not None:
            return chunker
        if self.default_chunker is not None:
            return self.default_chunker
        raise StageInputError(
            f"未找到 block_type={block.block_type} 的 chunker",
            stage="chunk",
            code="unsupported_block_type",
        )
