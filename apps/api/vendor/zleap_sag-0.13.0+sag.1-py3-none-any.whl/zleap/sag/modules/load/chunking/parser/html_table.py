"""HTML `<table>` 解析与 GFM 渲染（`.html` 输入与 md 内嵌表格共用）。

同一段 `<table>` 无论来自 `.html` 文件还是 Markdown 内嵌，都经这里转成
GFM 表格，再走既有的行级表格切块，避免两条路径产出不同的块形状。

容错要求来自真实语料：`</td>` / `</tr>` 在 HTML5 里是可省略的，爬虫与
文档导出工具普遍省略；截断的页面还会留下未闭合的 `<table>`。这两种输入
都必须保住全部单元格文本，不能静默丢数据。
"""

from __future__ import annotations

from html.parser import HTMLParser

CELL_TAGS = frozenset({"td", "th"})
ROW_TAG = "tr"
TABLE_TAG = "table"
# 单元格内的块级标签渲染为软换行，避免 "<td>a<br>b</td>" 被粘成 "ab"。
CELL_SOFT_BREAK_TAGS = frozenset({"br", "p", "div", "li", "tr"})


class HtmlTableAccumulator:
    """累积一张 `<table>` 的行列文本，容忍缺失的结束标签。

    调用方在遇到表格相关标签时转发给本类；`rows()` 返回已累积的行，
    未闭合的单元格/行会在取值时兜底 flush，因此任何时刻取值都不丢文本。
    """

    def __init__(self) -> None:
        self._rows: list[list[str]] = []
        self._row: list[str] | None = None
        self._cell: str | None = None
        self.depth = 0

    @property
    def in_cell(self) -> bool:
        return self._cell is not None

    def open_table(self) -> None:
        self.depth += 1

    def close_table(self) -> bool:
        """闭合一层表格；返回 True 表示最外层表格已结束。"""
        if self.depth == 0:
            return False
        self.depth -= 1
        return self.depth == 0

    def start_row(self) -> None:
        # 上一行可能因缺失 </tr> 未结算，先 flush 再开新行。
        self.end_row()
        self._row = []

    def end_row(self) -> None:
        self.end_cell()
        if self._row:
            self._rows.append(self._row)
        self._row = None

    def start_cell(self) -> None:
        # 缺失 </td> 时上一个单元格尚未结算，先 flush 再开新格。
        self.end_cell()
        if self._row is None:
            # 缺失 <tr> 的畸形表格：补一行，避免单元格无处安放。
            self._row = []
        self._cell = ""

    def end_cell(self) -> None:
        if self._cell is None:
            return
        if self._row is None:
            self._row = []
        self._row.append(self._cell.strip())
        self._cell = None

    def add_text(self, data: str) -> None:
        if self._cell is not None:
            self._cell += data

    def add_soft_break(self) -> None:
        """单元格内的块级标签转成空格，保住词边界。"""
        if self._cell is not None and self._cell and not self._cell.endswith(" "):
            self._cell += " "

    def rows(self) -> list[list[str]]:
        """返回全部行；未闭合的单元格/行在此兜底结算。"""
        self.end_row()
        return self._rows


def render_gfm_table(rows: list[list[str]]) -> str:
    """把行列文本渲染为 GFM 表格，第一行作表头。

    列数按最宽行对齐，缺列补空，使输出必定能被 ``MarkdownBlockParser``
    的表格识别重新认出来（分隔行需与表头列数一致）。
    """
    if not rows:
        return ""
    col_count = max(len(row) for row in rows)
    if col_count == 0:
        return ""

    def row_line(cells: list[str]) -> str:
        padded = cells + [""] * (col_count - len(cells))
        escaped = [cell.replace("|", "\\|").replace("\n", " ").strip() for cell in padded]
        return "| " + " | ".join(escaped) + " |"

    lines = [row_line(rows[0])]
    lines.append("| " + " | ".join("---" for _ in range(col_count)) + " |")
    lines.extend(row_line(row) for row in rows[1:])
    return "\n" + "\n".join(lines) + "\n"


class _InlineTableParser(HTMLParser):
    """解析单段 `<table>…</table>` 文本，供 Markdown 内嵌表格复用。"""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.table = HtmlTableAccumulator()
        self.saw_table = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        _ = attrs
        if tag == TABLE_TAG:
            self.saw_table = True
            # 嵌套表格拍平进当前单元格，不另起状态。
            self.table.open_table()
            return
        if self.table.depth != 1:
            return
        if tag == ROW_TAG:
            self.table.start_row()
        elif tag in CELL_TAGS:
            self.table.start_cell()
        elif tag in CELL_SOFT_BREAK_TAGS:
            self.table.add_soft_break()

    def handle_endtag(self, tag: str) -> None:
        if tag == TABLE_TAG:
            self.table.close_table()
            return
        if self.table.depth != 1:
            return
        if tag in CELL_TAGS:
            self.table.end_cell()
        elif tag == ROW_TAG:
            self.table.end_row()

    def handle_data(self, data: str) -> None:
        self.table.add_text(data)


def html_table_to_gfm(raw_table: str) -> str | None:
    """把一段 `<table>` 文本转成 GFM 表格；无法识别为表格时返回 ``None``。"""
    parser = _InlineTableParser()
    parser.feed(raw_table)
    parser.close()
    if not parser.saw_table:
        return None
    rows = parser.table.rows()
    if not rows:
        return None
    return render_gfm_table(rows).strip("\n")
