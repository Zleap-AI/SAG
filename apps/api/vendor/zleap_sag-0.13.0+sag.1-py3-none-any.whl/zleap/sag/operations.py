"""Public durable mutation contracts.

These DTOs are provider-neutral and safe for host applications to persist, replay, and
map without importing SAG ORM models or repositories.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from enum import StrEnum

from pydantic import Field, field_validator, model_validator

from zleap.sag.exceptions import ValidationError as SagValidationError
from zleap.sag.pipeline.contracts import (
    ContractModel,
    JsonValue,
    SourceInput,
)
from zleap.sag.pipeline.options import (
    ChunkOptions,
    ExtractionOptions,
    IndexOptions,
    ParseOptions,
    ReplacePolicy,
)

_MAX_OPERATION_IDENTIFIER_CHARACTERS = 191
_MAX_FENCE_SCOPE_CHARACTERS = 512
_MAX_STORAGE_ID_CHARACTERS = 36
_MAX_DURABLE_REQUEST_BYTES = 32 * 1024 * 1024


class OperationType(StrEnum):
    PROCESS_SOURCE = "process_source"
    DELETE_SOURCE = "delete_source"
    DELETE_DATA_SOURCE = "delete_data_source"


class OperationStatus(StrEnum):
    ACCEPTED = "accepted"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class OperationCheckpoint(StrEnum):
    ACCEPTED = "accepted"
    PARSED = "parsed"
    CHUNKED = "chunked"
    INDEXED = "indexed"
    EXTRACT_PREPARED = "extract_prepared"
    EXTRACTED = "extracted"
    READY = "ready"
    DELETE_HIDDEN = "delete_hidden"
    VECTORS_DELETED = "vectors_deleted"
    RELATIONS_DELETED = "relations_deleted"


class OperationContext(ContractModel):
    operation_id: str
    idempotency_key: str
    request_digest: str
    fence_scope: str
    fence_token: int = Field(ge=1)
    owner_id: str
    lease_seconds: int = Field(default=300, ge=30, le=3600)
    deadline_at: datetime | None = None
    request_id: str | None = None
    trace_id: str | None = None

    @field_validator(
        "operation_id",
        "idempotency_key",
        "owner_id",
        "request_id",
        "trace_id",
    )
    @classmethod
    def _normalize_identifiers(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise SagValidationError("operation identifiers cannot be blank")
        if len(normalized) > _MAX_OPERATION_IDENTIFIER_CHARACTERS:
            raise SagValidationError(
                "operation identifiers cannot exceed "
                f"{_MAX_OPERATION_IDENTIFIER_CHARACTERS} characters"
            )
        return normalized

    @field_validator("fence_scope")
    @classmethod
    def _normalize_fence_scope(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise SagValidationError("fence_scope cannot be blank")
        if len(normalized) > _MAX_FENCE_SCOPE_CHARACTERS:
            raise SagValidationError(
                f"fence_scope cannot exceed {_MAX_FENCE_SCOPE_CHARACTERS} characters"
            )
        return normalized

    @field_validator("request_digest")
    @classmethod
    def _validate_digest(cls, value: str) -> str:
        normalized = value.strip().lower()
        if len(normalized) != 64 or any(ch not in "0123456789abcdef" for ch in normalized):
            raise SagValidationError("request_digest must be a SHA-256 hex digest")
        return normalized

    @field_validator("deadline_at")
    @classmethod
    def _normalize_deadline(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None or value.utcoffset() is None:
            raise SagValidationError("deadline_at must include a timezone")
        return value.astimezone(UTC)


class ProcessSourceRequest(ContractModel):
    context: OperationContext
    source: SourceInput
    parse_options: ParseOptions = Field(default_factory=ParseOptions)
    chunk_options: ChunkOptions = Field(default_factory=ChunkOptions)
    index_options: IndexOptions = Field(
        default_factory=lambda: IndexOptions(replace_policy=ReplacePolicy.REPLACE_CURRENT)
    )
    extraction_options: ExtractionOptions = Field(default_factory=ExtractionOptions)

    @model_validator(mode="after")
    def _require_durable_caller_owned_source(self) -> ProcessSourceRequest:
        descriptor = getattr(self.source, "descriptor", None)
        if descriptor is None or not descriptor.data_source_id or not descriptor.source_id:
            raise SagValidationError(
                "process_source requires descriptor.data_source_id and caller-owned source_id"
            )
        kind = getattr(self.source, "kind", None)
        if kind in {"file", "external"}:
            raise SagValidationError("process_source only accepts replayable inline source content")
        if kind == "article" and getattr(self.source, "content", None) is None:
            raise SagValidationError("process_source article input must carry inline content")
        if kind in {"conversation", "recording"} and not getattr(self.source, "units", ()):
            raise SagValidationError(f"process_source {kind} input must carry inline units")
        encoded_size = len(
            json.dumps(
                self.model_dump(mode="json"),
                ensure_ascii=False,
                separators=(",", ":"),
            ).encode("utf-8")
        )
        if encoded_size > _MAX_DURABLE_REQUEST_BYTES:
            raise SagValidationError(
                f"process_source request exceeds {_MAX_DURABLE_REQUEST_BYTES} bytes"
            )
        return self


class DeleteSourceRequest(ContractModel):
    context: OperationContext
    data_source_id: str
    source_id: str

    @field_validator("data_source_id", "source_id")
    @classmethod
    def _normalize_target(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise SagValidationError("delete target identifiers cannot be blank")
        if len(normalized) > _MAX_STORAGE_ID_CHARACTERS:
            raise SagValidationError(
                f"delete target identifiers cannot exceed {_MAX_STORAGE_ID_CHARACTERS} characters"
            )
        return normalized


class DeleteDataSourceRequest(ContractModel):
    context: OperationContext
    data_source_id: str

    @field_validator("data_source_id")
    @classmethod
    def _normalize_target(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise SagValidationError("delete target identifier cannot be blank")
        if len(normalized) > _MAX_STORAGE_ID_CHARACTERS:
            raise SagValidationError(
                f"delete target identifier cannot exceed {_MAX_STORAGE_ID_CHARACTERS} characters"
            )
        return normalized


class OperationResult(ContractModel):
    operation_id: str
    idempotency_key: str
    request_digest: str
    operation_type: OperationType
    data_source_id: str
    source_id: str | None = None
    status: OperationStatus
    checkpoint: OperationCheckpoint
    fence_scope: str
    fence_token: int = Field(ge=1)
    generation_id: str | None = None
    retryable: bool | None = None
    failure_code: str | None = None
    failure_message: str | None = None
    cleanup_pending: bool = False
    cleanup_error: str | None = None
    result: dict[str, JsonValue] | None = None
    extraction_progress: dict[str, JsonValue] | None = None
    attempts: int = Field(default=0, ge=0)
    created_at: datetime
    updated_at: datetime

    @property
    def terminal(self) -> bool:
        return self.status in {OperationStatus.SUCCEEDED, OperationStatus.FAILED}


__all__ = [
    "DeleteDataSourceRequest",
    "DeleteSourceRequest",
    "OperationCheckpoint",
    "OperationContext",
    "OperationResult",
    "OperationStatus",
    "OperationType",
    "ProcessSourceRequest",
]
