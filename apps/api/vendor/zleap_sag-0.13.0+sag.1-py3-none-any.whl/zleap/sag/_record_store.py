"""Instance-scoped implementation behind the public persisted-record API."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import and_, delete, exists, func, or_, select

from zleap.sag.db import (
    Article,
    ArticleSection,
    ChatConversation,
    ChatMessage,
    DataSource,
    Entity,
    EntityType,
    EventEntity,
    KBDocument,
    SAGSourceManifest,
    SourceChunk,
    SourceEvent,
)
from zleap.sag.exceptions import InvalidInputError
from zleap.sag.pipeline.contracts import EventDetail, EventEntityDetail, SourceType
from zleap.sag.records import (
    ChunkRecord,
    DeleteReport,
    EvidenceRecord,
    GraphAssociation,
    GraphEntity,
    GraphEvent,
    KnowledgeGraph,
    OutlineEntry,
    OutlinePage,
    SourceEventCount,
    SourceState,
)

_MAX_EVIDENCE_CHUNKS = 200
_MAX_EVENTS_PER_CHUNK = 200
_MAX_OUTLINE_PAGE_SIZE = 200
_MAX_GRAPH_SOURCES = 1_000
_MAX_GRAPH_EVENTS = 10_000
_MAX_GRAPH_ENTITIES = 10_000


def _aware_utc(value: datetime | None) -> datetime:
    if value is None:
        return datetime.now(UTC)
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def _public_source_type(value: str) -> SourceType:
    if value == "ARTICLE":
        return SourceType.ARTICLE
    if value == "CHAT":
        return SourceType.CHAT
    if value == "RECORDING":
        return SourceType.RECORDING
    return SourceType.TEXT


class KnowledgeRecordStore:
    def __init__(
        self,
        *,
        session_factory: Any,
        repositories: Any,
        data_source_id: str,
    ) -> None:
        self._session_factory = session_factory
        self._repositories = repositories
        self._data_source_id = data_source_id

    async def _source_manifest(self, session: Any, source_id: str) -> Any:
        return await session.get(SAGSourceManifest, (self._data_source_id, source_id))

    @staticmethod
    def _generation_clause(model: Any, manifest: Any) -> Any:
        if manifest is None:
            return model.generation_id.is_(None)
        if manifest.status == "ready" and manifest.active_generation_id is not None:
            return model.generation_id == manifest.active_generation_id
        return model.generation_id == "__sag_no_visible_generation__"

    async def _source_generation_predicate(
        self,
        session: Any,
        model: Any,
        source_ids: Sequence[str],
    ) -> Any:
        unique_source_ids = tuple(dict.fromkeys(source_ids))
        manifests = list(
            (
                await session.scalars(
                    select(SAGSourceManifest).where(
                        SAGSourceManifest.data_source_id == self._data_source_id,
                        SAGSourceManifest.source_id.in_(unique_source_ids),
                    )
                )
            ).all()
        )
        manifest_by_source = {manifest.source_id: manifest for manifest in manifests}
        branches: list[Any] = []
        for source_id in unique_source_ids:
            manifest = manifest_by_source.get(source_id)
            branches.append(
                and_(
                    model.source_id == source_id,
                    self._generation_clause(model, manifest),
                )
            )
        return or_(*branches) if branches else model.source_id == "__sag_no_source__"

    async def source_state(self, source_id: str) -> SourceState | None:
        async with self._session_factory() as session:
            manifest = await self._source_manifest(session, source_id)
            if manifest is not None and manifest.status != "ready":
                return None
            carrier = await session.get(Article, source_id)
            physical_type = "ARTICLE"
            if carrier is None:
                carrier = await session.get(ChatConversation, source_id)
                physical_type = "CHAT"
            if carrier is None or carrier.data_source_id != self._data_source_id:
                return None
            pipeline = (carrier.extra_data or {}).get("sag_pipeline") or {}
            chunk_generation = self._generation_clause(SourceChunk, manifest)
            event_generation = self._generation_clause(SourceEvent, manifest)
            chunk_count = int(
                await session.scalar(
                    select(func.count(SourceChunk.id)).where(
                        SourceChunk.data_source_id == self._data_source_id,
                        SourceChunk.source_id == source_id,
                        chunk_generation,
                    )
                )
                or 0
            )
            event_count = int(
                await session.scalar(
                    select(func.count(SourceEvent.id)).where(
                        SourceEvent.data_source_id == self._data_source_id,
                        SourceEvent.source_id == source_id,
                        event_generation,
                        SourceEvent.not_deleted(),
                    )
                )
                or 0
            )
            return SourceState(
                data_source_id=self._data_source_id,
                source_id=source_id,
                source_type=_public_source_type(physical_type),
                source_version=(
                    manifest.source_version
                    if manifest is not None
                    else pipeline.get("source_version")
                ),
                chunk_version=(
                    manifest.chunk_version
                    if manifest is not None
                    else pipeline.get("chunk_version")
                ),
                status=(
                    "ready"
                    if manifest is not None
                    else str(getattr(carrier, "status", None) or carrier.parse_status or "")
                ),
                chunk_count=chunk_count,
                event_count=event_count,
            )

    async def read_chunk(self, source_id: str, chunk_id: str) -> ChunkRecord | None:
        async with self._session_factory() as session:
            manifest = await self._source_manifest(session, source_id)
            statement = select(SourceChunk).where(
                SourceChunk.data_source_id == self._data_source_id,
                SourceChunk.source_id == source_id,
                SourceChunk.id == chunk_id,
                self._generation_clause(SourceChunk, manifest),
            )
            row = (await session.scalars(statement)).first()
        if row is None or not (row.content or "").strip():
            return None
        return self._chunk_record(row)

    async def read_evidence(
        self,
        source_id: str,
        chunk_ids: Sequence[str],
        *,
        max_events_per_chunk: int = 50,
    ) -> tuple[EvidenceRecord, ...]:
        unique_chunk_ids = tuple(dict.fromkeys(chunk_ids))
        if not unique_chunk_ids:
            return ()
        if len(unique_chunk_ids) > _MAX_EVIDENCE_CHUNKS:
            raise InvalidInputError(f"chunk_ids exceeds maximum {_MAX_EVIDENCE_CHUNKS}")
        if not 1 <= max_events_per_chunk <= _MAX_EVENTS_PER_CHUNK:
            raise InvalidInputError(
                f"max_events_per_chunk must be between 1 and {_MAX_EVENTS_PER_CHUNK}"
            )

        async with self._session_factory() as session:
            manifest = await self._source_manifest(session, source_id)
            chunk_generation = self._generation_clause(SourceChunk, manifest)
            event_generation = self._generation_clause(SourceEvent, manifest)
            chunks = list(
                (
                    await session.scalars(
                        select(SourceChunk)
                        .where(
                            SourceChunk.data_source_id == self._data_source_id,
                            SourceChunk.source_id == source_id,
                            SourceChunk.id.in_(unique_chunk_ids),
                            chunk_generation,
                        )
                        .order_by(SourceChunk.rank, SourceChunk.id)
                    )
                ).all()
            )
            events = list(
                (
                    await session.scalars(
                        select(SourceEvent)
                        .where(
                            SourceEvent.data_source_id == self._data_source_id,
                            SourceEvent.source_id == source_id,
                            SourceEvent.chunk_id.in_(unique_chunk_ids),
                            SourceEvent.not_deleted(),
                            event_generation,
                        )
                        .order_by(SourceEvent.chunk_id, SourceEvent.level, SourceEvent.rank)
                    )
                ).all()
            )
            event_ids = tuple(row.id for row in events)
            association_rows = (
                (
                    await session.execute(
                        select(EventEntity, Entity)
                        .join(Entity, Entity.id == EventEntity.entity_id)
                        .where(
                            EventEntity.event_id.in_(event_ids),
                            Entity.data_source_id == self._data_source_id,
                        )
                        .order_by(EventEntity.event_id, Entity.name, Entity.id)
                    )
                ).all()
                if event_ids
                else []
            )

        entities_by_event: dict[str, list[EventEntityDetail]] = {}
        for association, entity in association_rows:
            entities_by_event.setdefault(association.event_id, []).append(
                EventEntityDetail(
                    id=entity.id,
                    type=entity.type,
                    name=entity.name,
                    description=entity.description or "",
                    weight=float(association.weight or 1.0),
                    metadata=dict(association.extra_data or {}),
                )
            )
        events_by_chunk: dict[str, list[EventDetail]] = {}
        for row in events:
            if row.chunk_id is None:
                continue
            bucket = events_by_chunk.setdefault(row.chunk_id, [])
            if len(bucket) >= max_events_per_chunk:
                continue
            bucket.append(self._event_detail(row, tuple(entities_by_event.get(row.id, ()))))

        return tuple(
            EvidenceRecord(
                chunk=self._chunk_record(chunk),
                events=tuple(events_by_chunk.get(chunk.id, ())),
            )
            for chunk in chunks
            if (chunk.content or "").strip()
        )

    async def read_outline(self, source_id: str, *, offset: int, limit: int) -> OutlinePage:
        if offset < 0:
            raise InvalidInputError("offset must not be negative")
        if not 1 <= limit <= _MAX_OUTLINE_PAGE_SIZE:
            raise InvalidInputError(f"limit must be between 1 and {_MAX_OUTLINE_PAGE_SIZE}")
        base = [
            SourceEvent.data_source_id == self._data_source_id,
            SourceEvent.source_id == source_id,
            SourceEvent.not_deleted(),
        ]
        async with self._session_factory() as session:
            manifest = await self._source_manifest(session, source_id)
            base.append(self._generation_clause(SourceEvent, manifest))
            top_count = int(
                await session.scalar(
                    select(func.count(SourceEvent.id)).where(*base, SourceEvent.level == 0)
                )
                or 0
            )
            top_level_only = top_count > 0
            total = top_count or int(
                await session.scalar(select(func.count(SourceEvent.id)).where(*base)) or 0
            )
            statement = select(SourceEvent).where(*base)
            if top_level_only:
                statement = statement.where(SourceEvent.level == 0)
            rows = list(
                (
                    await session.scalars(
                        statement.order_by(SourceEvent.rank, SourceEvent.id)
                        .offset(offset)
                        .limit(limit)
                    )
                ).all()
            )
        entries = tuple(
            OutlineEntry(
                title=row.title.strip(),
                summary=(row.summary or row.content).strip(),
                chunk_id=row.chunk_id,
            )
            for row in rows
            if row.title.strip() and (row.summary or row.content).strip()
        )
        return OutlinePage(entries=entries, total=total, offset=offset, limit=limit)

    async def read_graph(
        self,
        source_ids: Sequence[str],
        *,
        event_limit: int,
        entity_limit: int,
    ) -> KnowledgeGraph:
        unique_source_ids = tuple(dict.fromkeys(source_ids))
        if not unique_source_ids:
            return KnowledgeGraph()
        if len(unique_source_ids) > _MAX_GRAPH_SOURCES:
            raise InvalidInputError(f"source_ids exceeds maximum {_MAX_GRAPH_SOURCES}")
        if not 1 <= event_limit <= _MAX_GRAPH_EVENTS:
            raise InvalidInputError(f"event_limit must be between 1 and {_MAX_GRAPH_EVENTS}")
        if not 1 <= entity_limit <= _MAX_GRAPH_ENTITIES:
            raise InvalidInputError(f"entity_limit must be between 1 and {_MAX_GRAPH_ENTITIES}")
        async with self._session_factory() as session:
            generation_scope = await self._source_generation_predicate(
                session, SourceEvent, unique_source_ids
            )
            scope = (
                SourceEvent.data_source_id == self._data_source_id,
                generation_scope,
                SourceEvent.not_deleted(),
            )
            count_rows = (
                await session.execute(
                    select(SourceEvent.source_id, func.count(SourceEvent.id))
                    .where(*scope)
                    .group_by(SourceEvent.source_id)
                )
            ).all()
            total_events = sum(int(row[1] or 0) for row in count_rows)
            total_entities = int(
                await session.scalar(
                    select(func.count(func.distinct(EventEntity.entity_id)))
                    .join(SourceEvent, SourceEvent.id == EventEntity.event_id)
                    .join(Entity, Entity.id == EventEntity.entity_id)
                    .where(*scope, Entity.data_source_id == self._data_source_id)
                )
                or 0
            )
            event_rows = list(
                (
                    await session.scalars(
                        select(SourceEvent)
                        .where(*scope)
                        .order_by(SourceEvent.source_id, SourceEvent.rank, SourceEvent.id)
                        .limit(event_limit)
                    )
                ).all()
            )
            event_ids = tuple(row.id for row in event_rows)
            association_rows = (
                (
                    await session.execute(
                        select(EventEntity, Entity)
                        .join(Entity, Entity.id == EventEntity.entity_id)
                        .where(
                            EventEntity.event_id.in_(event_ids),
                            Entity.data_source_id == self._data_source_id,
                        )
                        .order_by(EventEntity.weight.desc(), EventEntity.id)
                    )
                ).all()
                if event_ids
                else []
            )

        heat: dict[str, int] = {}
        entity_by_id: dict[str, Any] = {}
        for _association, entity in association_rows:
            heat[entity.id] = heat.get(entity.id, 0) + 1
            entity_by_id[entity.id] = entity
        selected_ids = tuple(
            sorted(heat, key=lambda entity_id: (-heat[entity_id], entity_id))[:entity_limit]
        )
        selected = set(selected_ids)
        return KnowledgeGraph(
            events=tuple(
                GraphEvent(
                    id=row.id,
                    source_id=row.source_id,
                    title=row.title,
                    summary=row.summary or "",
                    category=row.category or "",
                    rank=max(row.rank, 0),
                    parent_id=row.parent_id,
                    chunk_id=row.chunk_id,
                    start_time=_aware_utc(row.start_time) if row.start_time else None,
                )
                for row in event_rows
            ),
            entities=tuple(
                GraphEntity(
                    id=entity_id,
                    name=entity_by_id[entity_id].name,
                    type=entity_by_id[entity_id].type,
                    description=entity_by_id[entity_id].description or "",
                    heat=heat[entity_id],
                )
                for entity_id in selected_ids
            ),
            associations=tuple(
                GraphAssociation(
                    event_id=association.event_id,
                    entity_id=association.entity_id,
                    weight=float(association.weight or 1.0),
                    description=association.description or "",
                )
                for association, _entity in association_rows
                if association.entity_id in selected
            ),
            source_counts=tuple(
                SourceEventCount(source_id=str(source_id), event_count=int(count or 0))
                for source_id, count in count_rows
            ),
            total_events=total_events,
            total_entities=total_entities,
        )

    async def delete_source(self, source_id: str) -> DeleteReport:
        async with self._session_factory() as session:
            article = await session.get(Article, source_id)
            conversation = await session.get(ChatConversation, source_id)
            carrier = article or conversation
            if carrier is None or carrier.data_source_id != self._data_source_id:
                return DeleteReport(
                    target="source",
                    data_source_id=self._data_source_id,
                    source_id=source_id,
                    existed=False,
                )
            chunk_ids = tuple(
                (
                    await session.scalars(
                        select(SourceChunk.id).where(
                            SourceChunk.data_source_id == self._data_source_id,
                            SourceChunk.source_id == source_id,
                        )
                    )
                ).all()
            )
            event_ids = tuple(
                (
                    await session.scalars(
                        select(SourceEvent.id).where(
                            SourceEvent.data_source_id == self._data_source_id,
                            SourceEvent.source_id == source_id,
                        )
                    )
                ).all()
            )
            association_rows = (
                (
                    await session.execute(
                        select(EventEntity.id, EventEntity.entity_id).where(
                            EventEntity.event_id.in_(event_ids)
                        )
                    )
                ).all()
                if event_ids
                else []
            )
            relation_ids = tuple(str(row[0]) for row in association_rows)
            candidate_entity_ids = tuple(dict.fromkeys(str(row[1]) for row in association_rows))

            if event_ids:
                await session.execute(
                    delete(EventEntity).where(EventEntity.event_id.in_(event_ids))
                )
                await session.execute(delete(SourceEvent).where(SourceEvent.id.in_(event_ids)))
            if chunk_ids:
                await session.execute(delete(SourceChunk).where(SourceChunk.id.in_(chunk_ids)))
            if article is not None:
                await session.execute(
                    delete(ArticleSection).where(ArticleSection.article_id == source_id)
                )
                await session.delete(article)
            else:
                await session.execute(
                    delete(ChatMessage).where(ChatMessage.conversation_id == source_id)
                )
                await session.delete(conversation)

            orphan_entity_ids: tuple[str, ...] = ()
            if candidate_entity_ids:
                orphan_entity_ids = tuple(
                    (
                        await session.scalars(
                            select(Entity.id).where(
                                Entity.data_source_id == self._data_source_id,
                                Entity.id.in_(candidate_entity_ids),
                                ~exists(
                                    select(EventEntity.id).where(EventEntity.entity_id == Entity.id)
                                ),
                            )
                        )
                    ).all()
                )
                if orphan_entity_ids:
                    await session.execute(delete(Entity).where(Entity.id.in_(orphan_entity_ids)))
            await session.commit()

        failed = await self._delete_vectors(
            (
                (self._repositories.source_chunks, chunk_ids),
                (self._repositories.events, event_ids),
                (self._repositories.event_entities, relation_ids),
                (self._repositories.entities, orphan_entity_ids),
            )
        )
        return DeleteReport(
            target="source",
            data_source_id=self._data_source_id,
            source_id=source_id,
            existed=True,
            deleted_chunks=len(chunk_ids),
            deleted_events=len(event_ids),
            deleted_entities=len(orphan_entity_ids),
            failed_vector_ids=failed,
        )

    async def delete_data_source(self) -> DeleteReport:
        async with self._session_factory() as session:
            data_source = await session.get(DataSource, self._data_source_id)
            if data_source is None:
                return DeleteReport(
                    target="data_source",
                    data_source_id=self._data_source_id,
                    existed=False,
                )
            chunk_ids = tuple(
                (
                    await session.scalars(
                        select(SourceChunk.id).where(
                            SourceChunk.data_source_id == self._data_source_id
                        )
                    )
                ).all()
            )
            event_ids = tuple(
                (
                    await session.scalars(
                        select(SourceEvent.id).where(
                            SourceEvent.data_source_id == self._data_source_id
                        )
                    )
                ).all()
            )
            relation_ids = tuple(
                (
                    await session.scalars(
                        select(EventEntity.id).where(EventEntity.event_id.in_(event_ids))
                    )
                ).all()
                if event_ids
                else ()
            )
            entity_ids = tuple(
                (
                    await session.scalars(
                        select(Entity.id).where(Entity.data_source_id == self._data_source_id)
                    )
                ).all()
            )
            if event_ids:
                await session.execute(
                    delete(EventEntity).where(EventEntity.event_id.in_(event_ids))
                )
                await session.execute(delete(SourceEvent).where(SourceEvent.id.in_(event_ids)))
            if chunk_ids:
                await session.execute(delete(SourceChunk).where(SourceChunk.id.in_(chunk_ids)))
            await session.execute(
                delete(Article).where(Article.data_source_id == self._data_source_id)
            )
            await session.execute(
                delete(ChatConversation).where(
                    ChatConversation.data_source_id == self._data_source_id
                )
            )
            if entity_ids:
                await session.execute(delete(Entity).where(Entity.id.in_(entity_ids)))
            await session.execute(
                delete(EntityType).where(EntityType.data_source_id == self._data_source_id)
            )
            await session.execute(
                delete(KBDocument).where(KBDocument.data_source_id == self._data_source_id)
            )
            await session.delete(data_source)
            await session.commit()

        failed = await self._delete_vectors(
            (
                (self._repositories.source_chunks, chunk_ids),
                (self._repositories.events, event_ids),
                (self._repositories.event_entities, relation_ids),
                (self._repositories.entities, entity_ids),
            )
        )
        return DeleteReport(
            target="data_source",
            data_source_id=self._data_source_id,
            existed=True,
            deleted_chunks=len(chunk_ids),
            deleted_events=len(event_ids),
            deleted_entities=len(entity_ids),
            failed_vector_ids=failed,
        )

    async def _delete_vectors(
        self,
        groups: Sequence[tuple[Any, Sequence[str]]],
    ) -> tuple[str, ...]:
        failed: list[str] = []
        for repository, ids in groups:
            unique_ids = tuple(dict.fromkeys(ids))
            if not unique_ids:
                continue
            try:
                result = await repository.vector_store.delete(repository.INDEX_NAME, unique_ids)
            except Exception:
                failed.extend(unique_ids)
                continue
            failed.extend(str(item.id) for item in result.failed_items)
        return tuple(dict.fromkeys(failed))

    def _chunk_record(self, row: Any) -> ChunkRecord:
        return ChunkRecord(
            id=row.id,
            data_source_id=row.data_source_id,
            source_id=row.source_id,
            source_type=_public_source_type(row.source_type),
            heading=(row.heading or "").strip() or None,
            content=(row.content or "").strip(),
            rank=max(row.rank, 0),
        )

    def _event_detail(
        self,
        row: Any,
        entities: tuple[EventEntityDetail, ...],
    ) -> EventDetail:
        return EventDetail(
            id=row.id,
            data_source_id=row.data_source_id,
            source_type=_public_source_type(row.source_type),
            source_id=row.source_id,
            chunk_id=row.chunk_id,
            parent_id=row.parent_id,
            level=max(row.level, 0),
            rank=max(row.rank, 0),
            title=row.title,
            summary=row.summary,
            content=row.content,
            category=row.category,
            event_type=row.type,
            keywords=row.keywords,
            priority=row.priority,
            status=row.status,
            start_time=_aware_utc(row.start_time) if row.start_time else None,
            end_time=_aware_utc(row.end_time) if row.end_time else None,
            references=row.references,
            entities=entities,
            created_time=_aware_utc(row.created_time),
            updated_time=_aware_utc(row.updated_time),
        )
