"""启动前模型访问探测(fail-fast)。

引擎的写入与检索都依赖 Embedding 端点;凭证失效若拖到首次查询才暴露,
表现为难以定位的检索失败。上层在打开引擎网关时调用一次本探测,
用最小输入验证端点、凭证与向量维度,失败立即抛出明确异常。
"""

from __future__ import annotations

from zleap.sag.config import EngineConfig
from zleap.sag.core.ai.embedding import EmbeddingClient

_PROBE_INPUT = "zleap"
_PROBE_TIMEOUT_SECONDS = 30


async def verify_model_access(config: EngineConfig) -> None:
    """用一条最小输入探测 Embedding 端点。

    Raises:
        AIAuthError: 凭证无效或无权限(401/403),重试不会恢复
        AIError: 端点不可用、模型名错误或响应异常
    """
    embedding = config.embedding
    client = EmbeddingClient(
        model=embedding.model,
        api_key=embedding.api_key or config.llm.api_key,
        base_url=embedding.base_url,
        schema_dimensions=embedding.schema_dimensions,
        request_dimensions=embedding.request_dimensions,
        max_tokens=embedding.max_tokens,
        timeout=min(embedding.timeout, _PROBE_TIMEOUT_SECONDS),
        max_retries=1,
    )
    try:
        await client.generate(_PROBE_INPUT)
    finally:
        await client.close()


__all__ = ["verify_model_access"]
