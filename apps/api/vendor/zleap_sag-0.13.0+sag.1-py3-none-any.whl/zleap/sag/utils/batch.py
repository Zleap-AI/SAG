"""Embedding generation and provider-neutral vector batch helpers."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable, Sequence
from typing import Any, TypeVar

from zleap.sag._safe_error import safe_error_type
from zleap.sag.exceptions import AIError, InvalidInputError, StateError
from zleap.sag.utils.logger import get_logger
from zleap.sag.utils.retry import is_retryable_error

T = TypeVar("T")
R = TypeVar("R")


async def run_batches(
    batches: Sequence[Sequence[T]],
    worker: Callable[[int, Sequence[T]], Awaitable[R]],
    *,
    concurrency: int,
) -> list[R]:
    """Run one worker per batch with bounded concurrency, results in batch order.

    ``concurrency=1`` preserves the historical strictly-sequential behaviour.
    The bound must not exceed the engine's governor limit for the resource the
    worker consumes: a wider bound only parks the extra workers on the governor
    semaphore, where waiting past the acquire timeout is misclassified as
    resource exhaustion. Workers own their error handling; an escaped exception
    cancels the remaining workers and propagates.
    """

    if concurrency < 1:
        raise InvalidInputError("concurrency must be positive")
    if not batches:
        return []
    if concurrency == 1 or len(batches) == 1:
        return [await worker(index, batch) for index, batch in enumerate(batches)]

    gate = asyncio.Semaphore(concurrency)

    async def _guarded(index: int, batch: Sequence[T]) -> R:
        async with gate:
            return await worker(index, batch)

    async with asyncio.TaskGroup() as group:
        tasks = [group.create_task(_guarded(index, batch)) for index, batch in enumerate(batches)]
    return [task.result() for task in tasks]


def split_batches(items: Sequence[T], batch_size: int) -> list[Sequence[T]]:
    """Split items into contiguous batches preserving order."""

    if batch_size < 1:
        raise InvalidInputError("batch_size must be positive")
    return [items[start : start + batch_size] for start in range(0, len(items), batch_size)]


class BatchProcessor:
    def __init__(
        self,
        batch_size: int = 10,
        logger_name: str | None = None,
        *,
        concurrency: int = 1,
    ) -> None:
        if concurrency < 1:
            raise InvalidInputError("concurrency must be positive")
        self.batch_size = batch_size
        self.concurrency = concurrency
        self.logger = get_logger(logger_name or "utils.batch")


class EmbeddingBatchProcessor(BatchProcessor):
    async def process(
        self,
        items: list[T],
        text_extractor: Callable[[T], str],
        embedding_client: Any,
        on_success: Callable[[T, list[float]], Any] | None = None,
    ) -> dict[str, Any]:
        start_time = time.perf_counter()

        async def _embed_batch(_index: int, batch: Sequence[T]) -> tuple[list[Any], int]:
            results: list[Any] = []
            failed = 0
            try:
                vectors = await embedding_client.batch_generate(
                    [text_extractor(item) for item in batch]
                )
                if len(vectors) != len(batch):
                    raise StateError(
                        "batch_generate returned mismatched vector count: "
                        f"expected={len(batch)}, actual={len(vectors)}"
                    )
                if on_success:
                    results.extend(
                        on_success(item, vector)
                        for item, vector in zip(batch, vectors, strict=True)
                    )
            except AIError:
                # Provider-wide failures (especially auth) must not fan out into N requests.
                raise
            except Exception as exc:  # noqa: BLE001 - custom clients may need per-item isolation
                self.logger.warning(
                    "批量生成向量失败，降级重试",
                    extra={"error_type": safe_error_type(exc)},
                )
                for item in batch:
                    try:
                        vector = await embedding_client.generate(text_extractor(item))
                        if on_success:
                            results.append(on_success(item, vector))
                    except AIError:
                        raise
                    except Exception as retry_exc:  # noqa: BLE001
                        failed += 1
                        self.logger.error(
                            "单条生成向量失败",
                            extra={"error_type": safe_error_type(retry_exc)},
                        )
            return results, failed

        batch_results = await run_batches(
            split_batches(items, self.batch_size),
            _embed_batch,
            concurrency=self.concurrency,
        )
        results = [item for batch_result, _failed in batch_results for item in batch_result]
        failed_count = sum(failed for _results, failed in batch_results)
        return {
            "total": len(items),
            "success": len(results),
            "failed": failed_count,
            "results": results,
            "time": f"{time.perf_counter() - start_time:.2f}s",
        }


class VectorBulkUpsertProcessor(BatchProcessor):
    async def process(
        self,
        documents: list[dict[str, Any]],
        repository: Any,
        collection: str,
    ) -> dict[str, Any]:
        from zleap.sag.exceptions import VectorSyncError

        start_time = time.perf_counter()

        async def _upsert_batch(
            _index: int, batch: Sequence[dict[str, Any]]
        ) -> tuple[int, int, list[str]]:
            indexed = 0
            failed = 0
            failed_ids: list[str] = []
            try:
                result = await repository.upsert_documents(collection, list(batch))
                indexed += result.success_count
                retry_ids = {item.id for item in result.failed_items}
            except Exception as exc:  # noqa: BLE001 - entire batch falls back per item
                self.logger.error(
                    "批量向量写入失败，降级重试",
                    extra={"error_type": safe_error_type(exc)},
                )
                retry_ids = {str(document.get("id") or "") for document in batch}

            for document in batch:
                doc_id = str(document.get("id") or "")
                if doc_id not in retry_ids:
                    continue
                try:
                    await repository.index_document(collection, doc_id, document)
                    indexed += 1
                except Exception as retry_exc:  # noqa: BLE001
                    failed += 1
                    failed_ids.append(doc_id)
                    log = (
                        self.logger.warning if is_retryable_error(retry_exc) else self.logger.error
                    )
                    log(
                        "向量写入重试失败",
                        extra={"error_type": safe_error_type(retry_exc)},
                    )
            return indexed, failed, failed_ids

        batch_results = await run_batches(
            split_batches(documents, self.batch_size),
            _upsert_batch,
            concurrency=self.concurrency,
        )
        indexed = sum(item[0] for item in batch_results)
        failed = sum(item[1] for item in batch_results)
        failed_ids = [doc_id for item in batch_results for doc_id in item[2]]
        if failed_ids:
            raise VectorSyncError(
                provider=repository.vector_store.provider,
                collection=collection,
                failed_ids=failed_ids,
            )
        return {
            "total": len(documents),
            "indexed": indexed,
            "failed": failed,
            "time": f"{time.perf_counter() - start_time:.2f}s",
        }


async def batch_generate_embeddings(
    items: list[T],
    text_extractor: Callable[[T], str],
    embedding_client: Any,
    batch_size: int = 10,
    on_success: Callable[[T, list[float]], Any] | None = None,
    *,
    concurrency: int = 1,
) -> dict[str, Any]:
    processor = EmbeddingBatchProcessor(batch_size=batch_size, concurrency=concurrency)
    return await processor.process(items, text_extractor, embedding_client, on_success)


async def batch_upsert_vectors(
    documents: list[dict[str, Any]],
    repository: Any,
    collection: str,
    batch_size: int = 50,
    *,
    concurrency: int = 1,
) -> dict[str, Any]:
    processor = VectorBulkUpsertProcessor(batch_size=batch_size, concurrency=concurrency)
    return await processor.process(documents, repository, collection)
