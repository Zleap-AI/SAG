"""SQL-backed durable operation, fence, and manifest coordination."""

from __future__ import annotations

import asyncio
import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import and_, or_, select, update
from sqlalchemy.exc import IntegrityError

from zleap.sag._extraction_progress import extraction_progress_summary
from zleap.sag.db import (
    SAGDataSourceManifest,
    SAGFence,
    SAGOperation,
    SAGSourceManifest,
)
from zleap.sag.db.clock import database_utcnow
from zleap.sag.exceptions import (
    InvalidInputError,
    OperationConflictError,
    ResourceBusyError,
    StaleFenceError,
)
from zleap.sag.operations import (
    DeleteDataSourceRequest,
    DeleteSourceRequest,
    OperationCheckpoint,
    OperationResult,
    OperationStatus,
    OperationType,
    ProcessSourceRequest,
)


def _aware(value: datetime) -> datetime:
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


def _semantic_payload(request: Any) -> dict[str, Any]:
    payload = request.model_dump(mode="json")
    context = dict(payload["context"])
    for key in ("owner_id", "lease_seconds", "deadline_at", "request_id", "trace_id"):
        context.pop(key, None)
    payload["context"] = context
    return payload


def _payload_digest(request: Any) -> str:
    encoded = json.dumps(
        _semantic_payload(request),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _generation_id(request: ProcessSourceRequest) -> str:
    descriptor = request.source.descriptor
    assert descriptor is not None and descriptor.data_source_id and descriptor.source_id
    return str(
        uuid.uuid5(
            uuid.NAMESPACE_URL,
            ":".join(
                (
                    "zleap-sag-generation",
                    descriptor.data_source_id,
                    descriptor.source_id,
                    request.context.operation_id,
                    request.context.request_digest,
                )
            ),
        )
    )


@dataclass(frozen=True, slots=True)
class OperationExecution:
    state: OperationResult
    request_payload: dict[str, Any]
    work_payload: dict[str, Any]
    owner_id: str | None
    lease_expires_at: datetime | None


@dataclass(frozen=True, slots=True)
class DeleteBatch:
    chunk_ids: tuple[str, ...] = ()
    event_ids: tuple[str, ...] = ()
    association_ids: tuple[str, ...] = ()
    entity_ids: tuple[str, ...] = ()

    @property
    def empty(self) -> bool:
        return not (self.chunk_ids or self.event_ids or self.association_ids or self.entity_ids)


_DELETE_BATCH_SIZE = 500


class OperationStore:
    def __init__(self, session_factory: Any, data_source_id: str) -> None:
        self._session_factory = session_factory
        self._data_source_id = data_source_id
        self._chunk_checkpoint_lock = asyncio.Lock()

    async def _get_scoped_operation(
        self,
        session: Any,
        operation_id: str,
        *,
        for_update: bool = False,
    ) -> SAGOperation | None:
        """Load an operation only inside this store's namespace.

        Operation identifiers are globally unique for replay detection, but they are
        not authorization capabilities.  Every runtime read or mutation through a
        namespace-bound store must therefore include ``data_source_id`` explicitly.
        """

        statement = select(SAGOperation).where(
            SAGOperation.operation_id == operation_id,
            SAGOperation.data_source_id == self._data_source_id,
        )
        if for_update:
            statement = statement.with_for_update()
        return (await session.scalars(statement)).first()

    async def begin_process(self, request: ProcessSourceRequest) -> OperationResult:
        descriptor = request.source.descriptor
        assert descriptor is not None and descriptor.source_id is not None
        if descriptor.data_source_id != self._data_source_id:
            raise OperationConflictError("process_source data_source_id does not match engine")

        return await self._begin(
            request,
            operation_type=OperationType.PROCESS_SOURCE,
            source_id=descriptor.source_id,
            generation_id=_generation_id(request),
        )

    async def begin_delete_source(self, request: DeleteSourceRequest) -> OperationResult:
        if request.data_source_id != self._data_source_id:
            raise OperationConflictError("delete_source data_source_id does not match engine")
        return await self._begin(
            request,
            operation_type=OperationType.DELETE_SOURCE,
            source_id=request.source_id,
            generation_id=None,
        )

    async def begin_delete_data_source(self, request: DeleteDataSourceRequest) -> OperationResult:
        if request.data_source_id != self._data_source_id:
            raise OperationConflictError("delete_data_source target does not match engine")
        return await self._begin(
            request,
            operation_type=OperationType.DELETE_DATA_SOURCE,
            source_id=None,
            generation_id=None,
        )

    async def _begin(
        self,
        request: Any,
        *,
        operation_type: OperationType,
        source_id: str | None,
        generation_id: str | None,
    ) -> OperationResult:
        if request.context.fence_scope != self._data_source_id:
            raise OperationConflictError(
                "fence_scope must equal data_source_id so source writes and namespace "
                "deletion share one durable ordering boundary"
            )
        payload = request.model_dump(mode="json")
        payload_digest = _payload_digest(request)
        try:
            async with self._session_factory() as session:
                existing = await session.get(SAGOperation, request.context.operation_id)
                if existing is not None:
                    await self._validate_existing(
                        session,
                        existing,
                        request,
                        payload_digest,
                        operation_type=operation_type,
                        source_id=source_id,
                    )
                    return self._public(existing)

                duplicate = (
                    await session.scalars(
                        select(SAGOperation).where(
                            SAGOperation.data_source_id == self._data_source_id,
                            SAGOperation.idempotency_key == request.context.idempotency_key,
                        )
                    )
                ).first()
                if duplicate is not None:
                    if duplicate.operation_id == request.context.operation_id:
                        await self._validate_existing(
                            session,
                            duplicate,
                            request,
                            payload_digest,
                            operation_type=operation_type,
                            source_id=source_id,
                        )
                        return self._public(duplicate)
                    raise OperationConflictError(
                        "idempotency_key already belongs to another operation"
                    )

                await self._accept_fence(session, request)
                now = await database_utcnow(session)
                row = SAGOperation(
                    operation_id=request.context.operation_id,
                    data_source_id=self._data_source_id,
                    source_id=source_id,
                    operation_type=operation_type.value,
                    idempotency_key=request.context.idempotency_key,
                    request_digest=request.context.request_digest,
                    payload_digest=payload_digest,
                    fence_scope=request.context.fence_scope,
                    fence_token=request.context.fence_token,
                    status=OperationStatus.ACCEPTED.value,
                    checkpoint=OperationCheckpoint.ACCEPTED.value,
                    generation_id=generation_id,
                    request_payload=payload,
                    work_payload={},
                    created_time=now,
                    updated_time=now,
                )
                session.add(row)
                manifest = await session.get(SAGDataSourceManifest, self._data_source_id)
                if manifest is None:
                    session.add(
                        SAGDataSourceManifest(
                            data_source_id=self._data_source_id,
                            revision=0,
                            active=True,
                            created_time=now,
                            updated_time=now,
                        )
                    )
                result = self._public(row)
                await session.commit()
                return result
        except IntegrityError as exc:
            # A concurrent insert must resolve to the exact same immutable command.
            async with self._session_factory() as session:
                existing = await session.get(SAGOperation, request.context.operation_id)
                if existing is not None:
                    await self._validate_existing(
                        session,
                        existing,
                        request,
                        payload_digest,
                        operation_type=operation_type,
                        source_id=source_id,
                    )
                    return self._public(existing)
            raise OperationConflictError("concurrent operation identity conflict") from exc

    async def _validate_existing(
        self,
        session: Any,
        row: SAGOperation,
        request: Any,
        payload_digest: str,
        *,
        operation_type: OperationType,
        source_id: str | None,
    ) -> None:
        context = request.context
        expected = (
            row.data_source_id == self._data_source_id
            and row.operation_type == operation_type.value
            and row.source_id == source_id
            and row.idempotency_key == context.idempotency_key
            and row.request_digest == context.request_digest
            and row.payload_digest == payload_digest
            and row.fence_scope == context.fence_scope
            and row.fence_token == context.fence_token
        )
        if not expected:
            raise OperationConflictError("operation_id replay does not match durable command")
        fence = await session.get(SAGFence, context.fence_scope)
        if fence is not None and fence.fence_token > context.fence_token:
            raise StaleFenceError(
                f"fence token {context.fence_token} is stale; current={fence.fence_token}"
            )
        if fence is not None and (
            fence.fence_token != context.fence_token or fence.operation_id != context.operation_id
        ):
            raise OperationConflictError("fence token is owned by another operation")

    async def _accept_fence(self, session: Any, request: Any) -> None:
        context = request.context
        fence = (
            await session.scalars(
                select(SAGFence)
                .where(SAGFence.fence_scope == context.fence_scope)
                .with_for_update()
            )
        ).first()
        now = await database_utcnow(session)
        if fence is None:
            session.add(
                SAGFence(
                    fence_scope=context.fence_scope,
                    fence_token=context.fence_token,
                    operation_id=context.operation_id,
                    updated_time=now,
                )
            )
            return
        if context.fence_token < fence.fence_token:
            raise StaleFenceError(
                f"fence token {context.fence_token} is stale; current={fence.fence_token}"
            )
        if context.fence_token == fence.fence_token:
            if context.operation_id != fence.operation_id:
                raise OperationConflictError("fence token is already owned by another operation")
            return

        prior = await self._get_scoped_operation(session, fence.operation_id)
        if (
            prior is not None
            and prior.status == OperationStatus.RUNNING.value
            and prior.lease_expires_at is not None
            and prior.lease_expires_at > now
        ):
            raise ResourceBusyError(
                "previous fenced operation still owns an active execution lease"
            )
        if prior is not None and prior.status != OperationStatus.SUCCEEDED.value:
            # A higher namespace fence permanently prevents exact continuation of
            # the older mutation.  Persist that fact so its invisible generation
            # becomes eligible for deterministic reconciliation.
            prior.status = OperationStatus.FAILED.value
            prior.error_code = "stale_fence"
            prior.error_message = "operation was superseded by a higher namespace fence"
            prior.retryable = False
            prior.owner_id = None
            prior.lease_expires_at = None
            prior.updated_time = now
        fence.fence_token = context.fence_token
        fence.operation_id = context.operation_id
        fence.updated_time = now

    async def claim(self, request: Any) -> OperationExecution | None:
        context = request.context
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(session, context.operation_id)
            if row is None:
                return None
            await self._assert_fence(session, row, lock=True)
            if row.status == OperationStatus.SUCCEEDED.value:
                return None
            if row.status == OperationStatus.FAILED.value and not row.retryable:
                return None

            now = await database_utcnow(session)
            if context.deadline_at is not None and context.deadline_at <= _aware(now):
                row.status = OperationStatus.FAILED.value
                row.error_code = "deadline_exceeded"
                row.error_message = "operation deadline elapsed before claim"
                # A deadline belongs to one delivery attempt, not to the immutable
                # command.  Exact replay may supply a later deadline and continue
                # from the last durable checkpoint.
                row.retryable = True
                row.owner_id = None
                row.lease_expires_at = None
                row.updated_time = now
                await session.commit()
                return None
            eligible = or_(
                SAGOperation.status == OperationStatus.ACCEPTED.value,
                and_(
                    SAGOperation.status == OperationStatus.FAILED.value,
                    SAGOperation.retryable.is_(True),
                ),
                and_(
                    SAGOperation.status == OperationStatus.RUNNING.value,
                    or_(
                        SAGOperation.lease_expires_at.is_(None),
                        SAGOperation.lease_expires_at <= now,
                    ),
                ),
            )
            claimed = await session.execute(
                update(SAGOperation)
                .where(
                    SAGOperation.operation_id == context.operation_id,
                    SAGOperation.data_source_id == self._data_source_id,
                    eligible,
                )
                .values(
                    status=OperationStatus.RUNNING.value,
                    owner_id=context.owner_id,
                    heartbeat_at=now,
                    lease_expires_at=now + timedelta(seconds=context.lease_seconds),
                    attempts=SAGOperation.attempts + 1,
                    error_code=None,
                    error_message=None,
                    retryable=None,
                    updated_time=now,
                )
            )
            if claimed.rowcount != 1:
                await session.rollback()
                return None
            await session.commit()
            row = await self._get_scoped_operation(session, context.operation_id)
            if row is None:  # pragma: no cover - protected by the successful update
                raise OperationConflictError("claimed operation disappeared")
            return self._execution(row)

    async def heartbeat(self, request: Any) -> OperationResult:
        context = request.context
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            if row.status in {
                OperationStatus.SUCCEEDED.value,
                OperationStatus.FAILED.value,
            }:
                return self._public(row)
            await self._assert_owner_and_fence(session, row, context.owner_id)
            now = await database_utcnow(session)
            heartbeat = await session.execute(
                update(SAGOperation)
                .where(
                    SAGOperation.operation_id == context.operation_id,
                    SAGOperation.data_source_id == self._data_source_id,
                    SAGOperation.status == OperationStatus.RUNNING.value,
                    SAGOperation.owner_id == context.owner_id,
                    SAGOperation.fence_scope == context.fence_scope,
                    SAGOperation.fence_token == context.fence_token,
                )
                .values(
                    heartbeat_at=now,
                    lease_expires_at=now + timedelta(seconds=context.lease_seconds),
                    updated_time=now,
                )
            )
            if heartbeat.rowcount != 1:
                # SQLite ignores SELECT ... FOR UPDATE. A terminal write may win
                # after the stale read/assert above; never let this heartbeat
                # overwrite the immutable terminal timestamp or restore a lease.
                await session.rollback()
                current = await self._get_scoped_operation(session, context.operation_id)
                if current is not None and current.status in {
                    OperationStatus.SUCCEEDED.value,
                    OperationStatus.FAILED.value,
                }:
                    return self._public(current)
                raise ResourceBusyError("operation execution lease changed before heartbeat")
            await session.commit()
            current = await self._get_scoped_operation(session, context.operation_id)
            if current is None:  # pragma: no cover - protected by the successful update
                raise OperationConflictError("operation disappeared after heartbeat")
            return self._public(current)

    async def save_chunk_checkpoint(
        self,
        request: ProcessSourceRequest,
        *,
        execution_attempt: int,
        fingerprint: str,
        chunk_ids: tuple[str, ...],
        chunk_id: str | None = None,
        outcome: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Merge one durable outcome into the current JSON under the execution lease."""
        context = request.context
        async with self._chunk_checkpoint_lock, self._session_factory() as session:
            row = await self._get_scoped_operation(session, context.operation_id, for_update=True)
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            if (
                row.checkpoint != OperationCheckpoint.INDEXED.value
                or row.attempts != execution_attempt
            ):
                raise OperationConflictError("extraction checkpoint execution has changed")
            work = dict(row.work_payload or {})
            progress = work.get("extraction_progress")
            if progress is None:
                progress = {
                    "version": 1,
                    "fingerprint": fingerprint,
                    "created_at": (await database_utcnow(session)).isoformat(),
                    "target_chunk_ids": list(chunk_ids),
                    "chunks": {},
                    "token_usage": {
                        "prompt_tokens": 0,
                        "completion_tokens": 0,
                        "total_tokens": 0,
                        "reported_calls": 0,
                        "unknown_calls": 0,
                        "complete": True,
                    },
                }
            elif (
                progress.get("version") != 1
                or progress.get("fingerprint") != fingerprint
                or progress.get("target_chunk_ids") != list(chunk_ids)
            ):
                raise OperationConflictError("extraction checkpoint input or configuration changed")
            records = dict(progress["chunks"])
            if chunk_id is None and outcome is None and execution_attempt > 1:
                # An earlier process may have died after a provider billed a
                # request but before its usage could be checkpointed.
                progress = {
                    **progress,
                    "token_usage": {**progress["token_usage"], "complete": False},
                }
            if chunk_id is None and outcome is not None:
                usage = dict(progress["token_usage"])
                if "usage" in outcome:
                    reported = outcome["usage"]
                    if reported is None:
                        usage["unknown_calls"] += 1
                        usage["complete"] = False
                    else:
                        for field in ("prompt_tokens", "completion_tokens", "total_tokens"):
                            usage[field] += int(reported[field])
                        usage["reported_calls"] += 1
                if outcome.get("usage_incomplete"):
                    usage["complete"] = False
                progress = {**progress, "token_usage": usage}
            if chunk_id is not None:
                if chunk_id not in chunk_ids or outcome is None:
                    raise OperationConflictError("invalid chunk checkpoint identity")
                # Successful outcomes are immutable during exact replay, including
                # valid empty results. This also makes duplicate completion safe.
                if records.get(chunk_id, {}).get("status") != "succeeded":
                    records[chunk_id] = outcome
            progress = {**progress, "chunks": records}
            work["extraction_progress"] = progress
            now = await database_utcnow(session)
            written = await session.execute(
                update(SAGOperation)
                .where(
                    SAGOperation.operation_id == row.operation_id,
                    SAGOperation.data_source_id == self._data_source_id,
                    SAGOperation.status == OperationStatus.RUNNING.value,
                    SAGOperation.checkpoint == OperationCheckpoint.INDEXED.value,
                    SAGOperation.owner_id == context.owner_id,
                    SAGOperation.attempts == execution_attempt,
                    SAGOperation.fence_token == context.fence_token,
                    SAGOperation.lease_expires_at > now,
                )
                .values(work_payload=work, updated_time=now)
            )
            if written.rowcount != 1:
                raise ResourceBusyError("operation execution changed before chunk checkpoint")
            await session.commit()
            return progress

    async def checkpoint(
        self,
        request: Any,
        checkpoint: OperationCheckpoint,
        work_payload: dict[str, Any],
    ) -> OperationResult:
        context = request.context
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            now = await database_utcnow(session)
            row.status = OperationStatus.RUNNING.value
            row.checkpoint = checkpoint.value
            row.work_payload = work_payload
            row.heartbeat_at = now
            row.lease_expires_at = now + timedelta(seconds=context.lease_seconds)
            row.updated_time = now
            result = self._public(row)
            await session.commit()
            return result

    async def complete_process(
        self,
        request: ProcessSourceRequest,
        *,
        work_payload: dict[str, Any],
        result_payload: dict[str, Any],
        source_version: str,
        chunk_version: str,
        extract_version: str,
        chunk_count: int,
        event_count: int,
    ) -> OperationResult:
        descriptor = request.source.descriptor
        assert descriptor is not None and descriptor.source_id is not None
        context = request.context
        source_type = getattr(descriptor.source_type, "value", descriptor.source_type)
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            now = await database_utcnow(session)
            source_manifest = await session.get(
                SAGSourceManifest,
                (self._data_source_id, descriptor.source_id),
            )
            if source_manifest is None:
                source_manifest = SAGSourceManifest(
                    data_source_id=self._data_source_id,
                    source_id=descriptor.source_id,
                    source_type=str(source_type),
                    active_generation_id=row.generation_id,
                    operation_id=row.operation_id,
                    fence_scope=row.fence_scope,
                    fence_token=row.fence_token,
                    status="ready",
                    source_version=source_version,
                    chunk_version=chunk_version,
                    extract_version=extract_version,
                    chunk_count=chunk_count,
                    event_count=event_count,
                    revision=1,
                    pending_cleanup_generations=[],
                    cleanup_required=False,
                    created_time=now,
                    updated_time=now,
                )
                session.add(source_manifest)
            else:
                previous_generation = source_manifest.active_generation_id
                pending_cleanup = list(source_manifest.pending_cleanup_generations or [])
                if (
                    previous_generation is not None
                    and previous_generation != row.generation_id
                    and previous_generation not in pending_cleanup
                ):
                    pending_cleanup.append(previous_generation)
                source_manifest.source_type = str(source_type)
                source_manifest.active_generation_id = row.generation_id
                source_manifest.operation_id = row.operation_id
                source_manifest.fence_scope = row.fence_scope
                source_manifest.fence_token = row.fence_token
                source_manifest.status = "ready"
                source_manifest.source_version = source_version
                source_manifest.chunk_version = chunk_version
                source_manifest.extract_version = extract_version
                source_manifest.chunk_count = chunk_count
                source_manifest.event_count = event_count
                source_manifest.revision = int(source_manifest.revision or 0) + 1
                source_manifest.pending_cleanup_generations = pending_cleanup
                source_manifest.cleanup_required = bool(pending_cleanup)
                source_manifest.cleanup_error = None
                source_manifest.deleted_time = None
                source_manifest.updated_time = now

            data_manifest = await session.get(SAGDataSourceManifest, self._data_source_id)
            if data_manifest is None:
                data_manifest = SAGDataSourceManifest(
                    data_source_id=self._data_source_id,
                    revision=1,
                    active=True,
                    created_time=now,
                    updated_time=now,
                )
                session.add(data_manifest)
            else:
                data_manifest.revision = int(data_manifest.revision or 0) + 1
                data_manifest.active = True
                data_manifest.deleted_time = None
                data_manifest.updated_time = now

            row.status = OperationStatus.SUCCEEDED.value
            row.checkpoint = OperationCheckpoint.READY.value
            row.result_payload = result_payload
            row.request_payload = {
                "terminal": True,
                "request_digest": row.request_digest,
                "payload_digest": row.payload_digest,
            }
            row.work_payload = None
            row.retryable = None
            row.error_code = None
            row.error_message = None
            row.owner_id = None
            row.heartbeat_at = now
            row.lease_expires_at = None
            row.updated_time = now
            result = self._public(row)
            await session.commit()
            return result

    async def prepare_delete(
        self,
        request: DeleteSourceRequest | DeleteDataSourceRequest,
    ) -> OperationResult:
        """Hide the target and initialize bounded, resumable delete progress."""
        from sqlalchemy import select

        from zleap.sag.db import (
            Article,
            ChatConversation,
            DataSource,
        )

        context = request.context
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            if row.checkpoint != OperationCheckpoint.ACCEPTED.value:
                return self._public(row)

            now = await database_utcnow(session)
            source_id = getattr(request, "source_id", None)
            if source_id is None:
                data_source = await session.get(DataSource, self._data_source_id)
                existed = data_source is not None
                data_manifest = await session.get(SAGDataSourceManifest, self._data_source_id)
                if data_manifest is None:
                    data_manifest = SAGDataSourceManifest(
                        data_source_id=self._data_source_id,
                        revision=1,
                        active=False,
                        deleted_time=now,
                        created_time=now,
                        updated_time=now,
                    )
                    session.add(data_manifest)
                else:
                    data_manifest.active = False
                    data_manifest.revision = int(data_manifest.revision or 0) + 1
                    data_manifest.deleted_time = now
                    data_manifest.updated_time = now
                await session.execute(
                    update(SAGSourceManifest)
                    .where(SAGSourceManifest.data_source_id == self._data_source_id)
                    .values(status="deleting", updated_time=now)
                )
            else:
                article = (
                    await session.scalars(
                        select(Article).where(
                            Article.id == source_id,
                            Article.data_source_id == self._data_source_id,
                        )
                    )
                ).first()
                conversation = (
                    await session.scalars(
                        select(ChatConversation).where(
                            ChatConversation.id == source_id,
                            ChatConversation.data_source_id == self._data_source_id,
                        )
                    )
                ).first()
                manifest = await session.get(SAGSourceManifest, (self._data_source_id, source_id))
                existed = article is not None or conversation is not None or manifest is not None
                source_type = (
                    manifest.source_type
                    if manifest is not None
                    else "article"
                    if article is not None
                    else "chat"
                    if conversation is not None
                    else "unknown"
                )
                if manifest is None:
                    manifest = SAGSourceManifest(
                        data_source_id=self._data_source_id,
                        source_id=source_id,
                        source_type=source_type,
                        operation_id=row.operation_id,
                        fence_scope=row.fence_scope,
                        fence_token=row.fence_token,
                        status="deleting",
                        revision=1,
                        pending_cleanup_generations=[],
                        cleanup_required=False,
                        created_time=now,
                        updated_time=now,
                    )
                    session.add(manifest)
                else:
                    manifest.operation_id = row.operation_id
                    manifest.fence_scope = row.fence_scope
                    manifest.fence_token = row.fence_token
                    manifest.status = "deleting"
                    manifest.revision = int(manifest.revision or 0) + 1
                    manifest.updated_time = now
                data_manifest = await session.get(SAGDataSourceManifest, self._data_source_id)
                if data_manifest is None:
                    session.add(
                        SAGDataSourceManifest(
                            data_source_id=self._data_source_id,
                            revision=1,
                            active=True,
                            created_time=now,
                            updated_time=now,
                        )
                    )
                else:
                    data_manifest.revision = int(data_manifest.revision or 0) + 1
                    data_manifest.updated_time = now

            work = {
                "existed": existed,
                "deleted_chunks": 0,
                "deleted_events": 0,
                "deleted_associations": 0,
                "deleted_entities": 0,
            }
            row.checkpoint = OperationCheckpoint.DELETE_HIDDEN.value
            row.work_payload = work
            row.updated_time = now
            row.heartbeat_at = now
            row.lease_expires_at = now + timedelta(seconds=context.lease_seconds)
            result = self._public(row)
            await session.commit()
            return result

    async def next_delete_batch(
        self,
        request: DeleteSourceRequest | DeleteDataSourceRequest,
        *,
        limit: int | None = None,
    ) -> DeleteBatch:
        """Return one deterministic physical batch without loading the full namespace."""

        from sqlalchemy import exists, select

        from zleap.sag.db import Entity, EventEntity, SourceChunk, SourceEvent

        batch_limit = _DELETE_BATCH_SIZE if limit is None else limit
        if not 1 <= batch_limit <= _DELETE_BATCH_SIZE:
            raise InvalidInputError(
                f"delete batch limit must be between 1 and {_DELETE_BATCH_SIZE}"
            )
        context = request.context
        source_id = getattr(request, "source_id", None)
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            if row.checkpoint != OperationCheckpoint.DELETE_HIDDEN.value:
                return DeleteBatch()

            event_scope = [SourceEvent.data_source_id == self._data_source_id]
            chunk_scope = [SourceChunk.data_source_id == self._data_source_id]
            if source_id is not None:
                event_scope.append(SourceEvent.source_id == source_id)
                chunk_scope.append(SourceChunk.source_id == source_id)

            association_ids = tuple(
                str(item)
                for item in (
                    await session.scalars(
                        select(EventEntity.id)
                        .join(SourceEvent, SourceEvent.id == EventEntity.event_id)
                        .where(*event_scope)
                        .order_by(EventEntity.id)
                        .limit(batch_limit)
                    )
                ).all()
            )
            event_ids = tuple(
                str(item)
                for item in (
                    await session.scalars(
                        select(SourceEvent.id)
                        .where(
                            *event_scope,
                            ~exists(
                                select(EventEntity.id).where(EventEntity.event_id == SourceEvent.id)
                            ),
                        )
                        .order_by(SourceEvent.id)
                        .limit(batch_limit)
                    )
                ).all()
            )
            chunk_ids = tuple(
                str(item)
                for item in (
                    await session.scalars(
                        select(SourceChunk.id)
                        .where(*chunk_scope)
                        .order_by(SourceChunk.id)
                        .limit(batch_limit)
                    )
                ).all()
            )
            entity_ids = tuple(
                str(item)
                for item in (
                    await session.scalars(
                        select(Entity.id)
                        .where(
                            Entity.data_source_id == self._data_source_id,
                            ~exists(
                                select(EventEntity.id).where(EventEntity.entity_id == Entity.id)
                            ),
                        )
                        .order_by(Entity.id)
                        .limit(batch_limit)
                    )
                ).all()
            )
            return DeleteBatch(
                chunk_ids=chunk_ids,
                event_ids=event_ids,
                association_ids=association_ids,
                entity_ids=entity_ids,
            )

    async def apply_delete_batch(
        self,
        request: DeleteSourceRequest | DeleteDataSourceRequest,
        batch: DeleteBatch,
    ) -> OperationResult:
        """Delete one already-vector-cleaned batch and atomically persist its counts."""

        from sqlalchemy import delete, exists, select

        from zleap.sag.db import Entity, EventEntity, SourceChunk, SourceEvent

        context = request.context
        source_id = getattr(request, "source_id", None)
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            if row.checkpoint != OperationCheckpoint.DELETE_HIDDEN.value:
                return self._public(row)

            event_scope = [SourceEvent.data_source_id == self._data_source_id]
            chunk_scope = [SourceChunk.data_source_id == self._data_source_id]
            if source_id is not None:
                event_scope.append(SourceEvent.source_id == source_id)
                chunk_scope.append(SourceChunk.source_id == source_id)
            scoped_event_ids = select(SourceEvent.id).where(*event_scope)

            deleted_associations = 0
            if batch.association_ids:
                result = await session.execute(
                    delete(EventEntity).where(
                        EventEntity.id.in_(batch.association_ids),
                        EventEntity.event_id.in_(scoped_event_ids),
                    )
                )
                deleted_associations = max(int(result.rowcount or 0), 0)
            deleted_events = 0
            if batch.event_ids:
                result = await session.execute(
                    delete(SourceEvent).where(
                        SourceEvent.id.in_(batch.event_ids),
                        *event_scope,
                        ~exists(
                            select(EventEntity.id).where(EventEntity.event_id == SourceEvent.id)
                        ),
                    )
                )
                deleted_events = max(int(result.rowcount or 0), 0)
            deleted_chunks = 0
            if batch.chunk_ids:
                result = await session.execute(
                    delete(SourceChunk).where(
                        SourceChunk.id.in_(batch.chunk_ids),
                        *chunk_scope,
                    )
                )
                deleted_chunks = max(int(result.rowcount or 0), 0)
            deleted_entities = 0
            if batch.entity_ids:
                result = await session.execute(
                    delete(Entity).where(
                        Entity.id.in_(batch.entity_ids),
                        Entity.data_source_id == self._data_source_id,
                        ~exists(select(EventEntity.id).where(EventEntity.entity_id == Entity.id)),
                    )
                )
                deleted_entities = max(int(result.rowcount or 0), 0)

            work = dict(row.work_payload or {})
            work["deleted_chunks"] = int(work.get("deleted_chunks") or 0) + deleted_chunks
            work["deleted_events"] = int(work.get("deleted_events") or 0) + deleted_events
            work["deleted_associations"] = (
                int(work.get("deleted_associations") or 0) + deleted_associations
            )
            work["deleted_entities"] = int(work.get("deleted_entities") or 0) + deleted_entities
            now = await database_utcnow(session)
            row.work_payload = work
            row.updated_time = now
            row.heartbeat_at = now
            row.lease_expires_at = now + timedelta(seconds=context.lease_seconds)
            result = self._public(row)
            await session.commit()
            return result

    async def mark_delete_vectors_complete(
        self,
        request: DeleteSourceRequest | DeleteDataSourceRequest,
    ) -> OperationResult:
        context = request.context
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            if row.checkpoint == OperationCheckpoint.DELETE_HIDDEN.value:
                now = await database_utcnow(session)
                row.checkpoint = OperationCheckpoint.VECTORS_DELETED.value
                row.updated_time = now
                row.heartbeat_at = now
                row.lease_expires_at = now + timedelta(seconds=context.lease_seconds)
            result = self._public(row)
            await session.commit()
            return result

    async def delete_relations(
        self,
        request: DeleteSourceRequest | DeleteDataSourceRequest,
    ) -> OperationResult:
        """Delete parent relations after all bounded vector/child batches are gone."""
        from sqlalchemy import delete, select

        from zleap.sag.db import (
            Article,
            ArticleSection,
            ChatConversation,
            ChatMessage,
            DataSource,
            Entity,
            EntityType,
            KBDocument,
        )

        context = request.context
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            if row.checkpoint == OperationCheckpoint.RELATIONS_DELETED.value:
                return self._public(row)
            if row.checkpoint != OperationCheckpoint.VECTORS_DELETED.value:
                raise OperationConflictError("delete relation stage is out of order")
            work = dict(row.work_payload or {})

            if isinstance(request, DeleteSourceRequest):
                source_id = request.source_id
                article_exists = await session.scalar(
                    select(Article.id).where(
                        Article.id == source_id,
                        Article.data_source_id == self._data_source_id,
                    )
                )
                conversation_exists = await session.scalar(
                    select(ChatConversation.id).where(
                        ChatConversation.id == source_id,
                        ChatConversation.data_source_id == self._data_source_id,
                    )
                )
                if article_exists is not None:
                    await session.execute(
                        delete(ArticleSection).where(ArticleSection.article_id == source_id)
                    )
                    await session.execute(
                        delete(Article).where(
                            Article.id == source_id,
                            Article.data_source_id == self._data_source_id,
                        )
                    )
                if conversation_exists is not None:
                    await session.execute(
                        delete(ChatMessage).where(ChatMessage.conversation_id == source_id)
                    )
                    await session.execute(
                        delete(ChatConversation).where(
                            ChatConversation.id == source_id,
                            ChatConversation.data_source_id == self._data_source_id,
                        )
                    )
            else:
                await session.execute(
                    delete(Entity).where(Entity.data_source_id == self._data_source_id)
                )
                await session.execute(
                    delete(EntityType).where(EntityType.data_source_id == self._data_source_id)
                )
                await session.execute(
                    delete(KBDocument).where(KBDocument.data_source_id == self._data_source_id)
                )
                await session.execute(
                    delete(Article).where(Article.data_source_id == self._data_source_id)
                )
                await session.execute(
                    delete(ChatConversation).where(
                        ChatConversation.data_source_id == self._data_source_id
                    )
                )
                await session.execute(
                    delete(DataSource).where(DataSource.id == self._data_source_id)
                )

            now = await database_utcnow(session)
            row.checkpoint = OperationCheckpoint.RELATIONS_DELETED.value
            row.work_payload = work
            row.updated_time = now
            row.heartbeat_at = now
            row.lease_expires_at = now + timedelta(seconds=context.lease_seconds)
            result = self._public(row)
            await session.commit()
            return result

    async def complete_delete(
        self,
        request: DeleteSourceRequest | DeleteDataSourceRequest,
    ) -> OperationResult:
        context = request.context
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(
                session,
                context.operation_id,
                for_update=True,
            )
            if row is None:
                raise OperationConflictError("operation does not exist")
            await self._assert_owner_and_fence(session, row, context.owner_id)
            if row.checkpoint != OperationCheckpoint.RELATIONS_DELETED.value:
                raise OperationConflictError("delete completion is out of order")
            work = dict(row.work_payload or {})
            now = await database_utcnow(session)
            if isinstance(request, DeleteSourceRequest):
                manifest = await session.get(
                    SAGSourceManifest,
                    (self._data_source_id, request.source_id),
                )
                if manifest is not None:
                    manifest.status = "deleted"
                    manifest.active_generation_id = None
                    manifest.pending_cleanup_generations = []
                    manifest.cleanup_required = False
                    manifest.cleanup_error = None
                    manifest.deleted_time = now
                    manifest.updated_time = now
            else:
                await session.execute(
                    update(SAGSourceManifest)
                    .where(SAGSourceManifest.data_source_id == self._data_source_id)
                    .values(
                        status="deleted",
                        active_generation_id=None,
                        pending_cleanup_generations=[],
                        cleanup_required=False,
                        cleanup_error=None,
                        deleted_time=now,
                        updated_time=now,
                    )
                )

            result_payload = {
                "target": ("source" if isinstance(request, DeleteSourceRequest) else "data_source"),
                "existed": bool(work.get("existed")),
                "deleted_chunks": int(work.get("deleted_chunks") or 0),
                "deleted_events": int(work.get("deleted_events") or 0),
                "deleted_entities": int(work.get("deleted_entities") or 0),
            }
            row.status = OperationStatus.SUCCEEDED.value
            row.checkpoint = OperationCheckpoint.READY.value
            row.result_payload = result_payload
            row.request_payload = {
                "terminal": True,
                "request_digest": row.request_digest,
                "payload_digest": row.payload_digest,
            }
            row.work_payload = None
            row.retryable = None
            row.error_code = None
            row.error_message = None
            row.owner_id = None
            row.heartbeat_at = now
            row.lease_expires_at = None
            row.updated_time = now
            result = self._public(row)
            await session.commit()
            return result

    async def fail(
        self,
        operation_id: str,
        *,
        code: str,
        message: str,
        retryable: bool,
        owner_id: str | None = None,
        execution_attempt: int | None = None,
    ) -> OperationResult:
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(session, operation_id, for_update=True)
            if row is None:
                raise OperationConflictError("operation does not exist")
            if row.status == OperationStatus.SUCCEEDED.value:
                return self._public(row)
            if execution_attempt is not None and row.attempts != execution_attempt:
                raise ResourceBusyError("operation execution attempt has changed")
            if owner_id is not None and row.owner_id not in (None, owner_id):
                raise ResourceBusyError("operation execution lease is owned by another worker")
            now = await database_utcnow(session)
            row.status = OperationStatus.FAILED.value
            row.error_code = code
            row.error_message = message[:20_000]
            row.retryable = retryable
            if (row.work_payload or {}).get("extraction_progress"):
                work = dict(row.work_payload or {})
                progress = dict(work["extraction_progress"])
                progress["token_usage"] = {**progress["token_usage"], "complete": False}
                work["extraction_progress"] = progress
                row.work_payload = work
                # Keep small operational progress after terminal generation
                # cleanup scrubs the resumable event payloads.
                row.result_payload = {
                    "extraction_progress": extraction_progress_summary(progress, row.operation_id)
                }
            row.cleanup_error = None
            row.owner_id = None
            row.heartbeat_at = now
            row.lease_expires_at = None
            row.updated_time = now
            if not retryable:
                row.request_payload = {
                    "terminal": True,
                    "request_digest": row.request_digest,
                    "payload_digest": row.payload_digest,
                }
                # A failed process may already own an invisible generation.  Keep
                # its internal payload until generation cleanup succeeds; the
                # reconciliation path scrubs it afterwards.
                if row.operation_type != OperationType.PROCESS_SOURCE.value:
                    row.work_payload = None
                    row.cleanup_completed_at = now
            result = self._public(row)
            await session.commit()
            return result

    async def get(self, operation_id: str, *, expire_stale: bool = True) -> OperationResult | None:
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(session, operation_id, for_update=True)
            if row is None:
                return None
            now = await database_utcnow(session)
            if (
                expire_stale
                and row.status == OperationStatus.RUNNING.value
                and row.lease_expires_at is not None
                and row.lease_expires_at <= now
            ):
                row.status = OperationStatus.FAILED.value
                row.error_code = "execution_failed"
                row.error_message = "execution lease expired; exact replay is required"
                row.retryable = True
                row.owner_id = None
                row.lease_expires_at = None
                row.updated_time = now
                result = self._public(row)
                await session.commit()
                return result
            return self._public(row)

    async def execution(self, operation_id: str) -> OperationExecution | None:
        async with self._session_factory() as session:
            row = await self._get_scoped_operation(session, operation_id)
            return self._execution(row) if row is not None else None

    async def _assert_fence(self, session: Any, row: SAGOperation, *, lock: bool = False) -> None:
        if row.data_source_id != self._data_source_id:
            raise OperationConflictError("operation does not belong to this data source")
        if lock:
            fence = (
                await session.scalars(
                    select(SAGFence)
                    .where(SAGFence.fence_scope == row.fence_scope)
                    .with_for_update()
                )
            ).first()
        else:
            fence = await session.get(SAGFence, row.fence_scope)
        if fence is None:
            raise StaleFenceError("operation fence no longer exists")
        if fence.fence_token > row.fence_token:
            raise StaleFenceError(
                f"operation fence is stale; current={fence.fence_token} operation={row.fence_token}"
            )
        if fence.fence_token != row.fence_token or fence.operation_id != row.operation_id:
            raise OperationConflictError("operation does not own its fence token")

    async def _assert_owner_and_fence(self, session: Any, row: SAGOperation, owner_id: str) -> None:
        await self._assert_fence(session, row)
        if row.status != OperationStatus.RUNNING.value or row.owner_id != owner_id:
            raise ResourceBusyError("operation execution lease is not owned by this worker")
        if row.lease_expires_at is not None and row.lease_expires_at <= await database_utcnow(
            session
        ):
            raise ResourceBusyError("operation execution lease expired")

    def _execution(self, row: SAGOperation) -> OperationExecution:
        return OperationExecution(
            state=self._public(row),
            request_payload=dict(row.request_payload or {}),
            work_payload=dict(row.work_payload or {}),
            owner_id=row.owner_id,
            lease_expires_at=_aware(row.lease_expires_at) if row.lease_expires_at else None,
        )

    def _public(self, row: SAGOperation) -> OperationResult:
        if row.data_source_id != self._data_source_id:
            raise OperationConflictError("operation does not belong to this data source")
        return OperationResult(
            operation_id=row.operation_id,
            idempotency_key=row.idempotency_key,
            request_digest=row.request_digest,
            operation_type=OperationType(row.operation_type),
            data_source_id=row.data_source_id,
            source_id=row.source_id,
            status=OperationStatus(row.status),
            checkpoint=OperationCheckpoint(row.checkpoint),
            fence_scope=row.fence_scope,
            fence_token=row.fence_token,
            generation_id=row.generation_id,
            retryable=row.retryable,
            failure_code=row.error_code,
            failure_message=row.error_message,
            cleanup_pending=bool(
                row.operation_type == OperationType.PROCESS_SOURCE.value
                and row.status == OperationStatus.FAILED.value
                and row.retryable is False
                and row.cleanup_completed_at is None
            ),
            cleanup_error=row.cleanup_error,
            result=(
                dict(row.result_payload)
                if row.status == OperationStatus.SUCCEEDED.value and row.result_payload is not None
                else None
            ),
            extraction_progress=(
                extraction_progress_summary(
                    row.work_payload["extraction_progress"], row.operation_id
                )
                if row.work_payload and row.work_payload.get("extraction_progress")
                else (row.result_payload or {}).get("extraction_progress")
            ),
            attempts=int(row.attempts or 0),
            created_at=_aware(row.created_time),
            updated_at=_aware(row.updated_time),
        )


__all__ = ["OperationExecution", "OperationStore"]
