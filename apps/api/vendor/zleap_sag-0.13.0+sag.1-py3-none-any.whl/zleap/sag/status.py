"""Public production capability, schema, and health contracts."""

from __future__ import annotations

from enum import StrEnum
from typing import Literal

from pydantic import Field

from zleap.sag.pipeline.contracts import ContractModel


class SchemaState(StrEnum):
    READY = "ready"
    MISSING = "missing"
    MISMATCH = "mismatch"


class SchemaStatus(ContractModel):
    state: SchemaState
    storage_mode: Literal["normal", "lite"]
    expected_version: int = Field(ge=1)
    actual_version: int | None = Field(default=None, ge=1)
    missing_relation_tables: tuple[str, ...] = ()
    relation_diffs: tuple[str, ...] = ()
    vector_objects: tuple[str, ...] = ()
    missing_vector_objects: tuple[str, ...] = ()

    @property
    def ready(self) -> bool:
        return self.state == SchemaState.READY


class EngineCapabilities(ContractModel):
    strict_processing: bool
    caller_owned_ids: bool
    operation_replay: bool
    durable_operation_status: bool
    scoped_fencing: bool
    multi_namespace_search: bool
    search_pagination: bool
    document_delete: bool
    namespace_delete: bool
    outline_read: bool
    evidence_read: bool
    graph_read: bool
    bounded_maintenance: bool
    write_concurrency_scope: Literal["namespace"] = "namespace"


class EngineHealthState(StrEnum):
    AVAILABLE = "available"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"


class EngineHealthIssueCode(StrEnum):
    NOT_STARTED = "not_started"
    SCHEMA_MISMATCH = "schema_mismatch"
    DEPENDENCY_UNAVAILABLE = "dependency_unavailable"
    CLEANUP_PENDING = "cleanup_pending"


class EngineHealthIssue(ContractModel):
    code: EngineHealthIssueCode
    message: str


class EngineHealth(ContractModel):
    state: EngineHealthState
    issues: tuple[EngineHealthIssue, ...] = ()
    storage_schema: SchemaStatus | None = None
    pending_cleanup_sources: int = Field(default=0, ge=0)
    pending_cleanup_operations: int = Field(default=0, ge=0)
    expired_search_sessions: int = Field(default=0, ge=0)
    stale_operations: int = Field(default=0, ge=0)
    runtime: dict[str, dict[str, int]] = Field(default_factory=dict)


__all__ = [
    "EngineCapabilities",
    "EngineHealth",
    "EngineHealthIssue",
    "EngineHealthIssueCode",
    "EngineHealthState",
    "SchemaState",
    "SchemaStatus",
]
