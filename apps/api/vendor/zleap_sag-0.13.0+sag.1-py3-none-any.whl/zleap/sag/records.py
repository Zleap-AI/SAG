"""Portable read and maintenance contracts for persisted SAG knowledge."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import Field

from zleap.sag.pipeline.contracts import ContractModel, EventDetail, SourceType


class SourceState(ContractModel):
    data_source_id: str
    source_id: str
    source_type: SourceType
    source_version: str | None = None
    chunk_version: str | None = None
    status: str
    chunk_count: int = Field(ge=0)
    event_count: int = Field(ge=0)


class ChunkRecord(ContractModel):
    id: str
    data_source_id: str
    source_id: str
    source_type: SourceType
    heading: str | None = None
    content: str
    rank: int = Field(ge=0)


class EvidenceRecord(ContractModel):
    chunk: ChunkRecord
    events: tuple[EventDetail, ...] = ()


class OutlineEntry(ContractModel):
    title: str
    summary: str
    chunk_id: str | None = None


class OutlinePage(ContractModel):
    entries: tuple[OutlineEntry, ...]
    total: int = Field(ge=0)
    offset: int = Field(ge=0)
    limit: int = Field(ge=1)

    @property
    def has_more(self) -> bool:
        return self.offset + len(self.entries) < self.total


class GraphEvent(ContractModel):
    id: str
    source_id: str
    title: str
    summary: str = ""
    category: str = ""
    rank: int = Field(default=0, ge=0)
    parent_id: str | None = None
    chunk_id: str | None = None
    start_time: datetime | None = None


class GraphEntity(ContractModel):
    id: str
    name: str
    type: str
    description: str = ""
    heat: int = Field(default=0, ge=0)


class GraphAssociation(ContractModel):
    event_id: str
    entity_id: str
    weight: float = 1.0
    description: str = ""


class SourceEventCount(ContractModel):
    source_id: str
    event_count: int = Field(ge=0)


class KnowledgeGraph(ContractModel):
    events: tuple[GraphEvent, ...] = ()
    entities: tuple[GraphEntity, ...] = ()
    associations: tuple[GraphAssociation, ...] = ()
    source_counts: tuple[SourceEventCount, ...] = ()
    total_events: int = Field(default=0, ge=0)
    total_entities: int = Field(default=0, ge=0)


class DeleteReport(ContractModel):
    target: Literal["source", "data_source"]
    data_source_id: str
    source_id: str | None = None
    existed: bool
    deleted_chunks: int = Field(default=0, ge=0)
    deleted_events: int = Field(default=0, ge=0)
    deleted_entities: int = Field(default=0, ge=0)
    failed_vector_ids: tuple[str, ...] = ()

    @property
    def complete(self) -> bool:
        return not self.failed_vector_ids


__all__ = [
    "ChunkRecord",
    "DeleteReport",
    "EvidenceRecord",
    "GraphAssociation",
    "GraphEntity",
    "GraphEvent",
    "KnowledgeGraph",
    "OutlineEntry",
    "OutlinePage",
    "SourceEventCount",
    "SourceState",
]
