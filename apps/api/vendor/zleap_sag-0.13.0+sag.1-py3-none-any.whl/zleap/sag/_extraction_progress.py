"""JSON contract for task-local extraction checkpoints (no schema migration)."""

from collections.abc import Awaitable, Callable
from typing import Any

from zleap.sag.exceptions import ExtractError


class ExtractionCheckpointWriteError(ExtractError):
    def __init__(self) -> None:
        super().__init__(
            "Chunk checkpoint write failed",
            code="extraction_checkpoint_write_failed",
            retryable=True,
        )


ChunkCheckpointWriter = Callable[
    [str, tuple[str, ...], str | None, dict[str, Any] | None], Awaitable[dict[str, Any]]
]


def extraction_progress_summary(progress: dict[str, Any], operation_id: str) -> dict[str, Any]:
    targets = progress["target_chunk_ids"]
    records = progress["chunks"]
    succeeded = [key for key in targets if records.get(key, {}).get("status") == "succeeded"]
    failed = [key for key in targets if records.get(key, {}).get("status") == "failed"]
    pending = [key for key in targets if key not in records]
    return {
        "resume_token": operation_id,
        "chunk_total": len(targets),
        "chunk_succeeded": len(succeeded),
        "chunk_failed": len(failed),
        "chunk_pending": len(pending),
        "succeeded_chunk_ids": succeeded,
        "failed_chunk_ids": failed,
        "pending_chunk_ids": pending,
        "retryable_chunk_ids": [key for key in failed if records[key]["failure"]["retryable"]],
        "generation_attempts": sum(record.get("attempts", 0) for record in records.values()),
        "token_usage": progress.get("token_usage"),
    }
