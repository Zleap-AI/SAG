"""注入式配置对象。

设计目标:把"配置从外部注入"作为唯一来源，避免进程环境或
全局 Settings 单例造成跨 Engine 实例污染。
"""

from __future__ import annotations

from typing import Annotated, Any, Literal

from pydantic import ConfigDict, Field, field_validator, model_validator

from zleap.sag.exceptions import ValidationError as SagValidationError
from zleap.sag.guard.policy import GuardPolicy
from zleap.sag.guard.ports import ContentGuard
from zleap.sag.validation import SagBaseModel as BaseModel


class PostgresTLSConfig(BaseModel):
    """PostgreSQL transport security owned by one SQL runtime."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    mode: Literal["require", "verify-ca", "verify-full"] = "verify-full"
    ca_file: str | None = None
    client_cert_file: str | None = None
    client_key_file: str | None = None

    @model_validator(mode="after")
    def _validate_client_identity(self) -> PostgresTLSConfig:
        if (self.client_cert_file is None) != (self.client_key_file is None):
            raise SagValidationError(
                "PostgreSQL client certificate and key must be configured together"
            )
        for field_name in ("ca_file", "client_cert_file", "client_key_file"):
            value = getattr(self, field_name)
            if value is not None and (not value or value != value.strip()):
                raise SagValidationError(f"{field_name} must be normalized non-empty text")
        return self


class RelationalConfig(BaseModel):
    """关系库连接配置(可切换方言)。

    - ``provider="mysql"``:host/port/user/password/database
    - ``provider="postgres"``:同上(asyncpg)
    - ``provider="sqlite"``:仅需 ``path``(文件路径),其余忽略
    """

    provider: Literal["mysql", "postgres", "sqlite", "oceanbase"] = "mysql"
    host: str = "localhost"
    port: int = 3306
    user: str = "sag2"
    password: str = Field(default="sag2", repr=False)
    database: str = "sag2"
    path: str = ""  # sqlite 文件路径
    pool_size: int = Field(default=5, ge=1, le=100)
    max_overflow: int = Field(default=5, ge=0, le=200)
    pool_recycle: int = 3600
    connect_timeout: float = Field(default=10.0, gt=0, le=300)
    command_timeout: float = Field(default=30.0, gt=0, le=1_800)
    pool_timeout: float = Field(default=30.0, gt=0, le=300)
    tls: PostgresTLSConfig | None = None

    @model_validator(mode="before")
    @classmethod
    def _provider_default_port(cls, value: Any) -> Any:
        """未显式给端口时，按关系库方言选择常用默认值。"""
        if not isinstance(value, dict) or "port" in value:
            return value
        data = dict(value)
        provider = str(data.get("provider") or "mysql").lower()
        data["port"] = {
            "postgres": 5432,
            "oceanbase": 2881,
        }.get(provider, 3306)
        return data

    @model_validator(mode="after")
    def _validate_tls_provider(self) -> RelationalConfig:
        if self.tls is not None and self.provider != "postgres":
            raise SagValidationError("relational TLS configuration currently requires PostgreSQL")
        return self


class _ElasticsearchConnectionConfig(BaseModel):
    """Shared Elasticsearch connection fields for the typed vector configuration."""

    hosts: list[str] = Field(default_factory=lambda: ["http://localhost:9200"])
    username: str | None = None
    password: str | None = Field(default=None, repr=False)
    timeout: int = Field(default=30, ge=1, le=300)
    max_connections: int = Field(default=10, ge=1, le=200)
    max_retries: int = Field(default=3, ge=0, le=10)
    verify_certs: bool = False
    ca_certs: str | None = None
    client_cert: str | None = None
    client_key: str | None = Field(default=None, repr=False)

    @model_validator(mode="after")
    def _validate_tls(self) -> _ElasticsearchConnectionConfig:
        if (self.client_cert is None) != (self.client_key is None):
            raise SagValidationError(
                "Elasticsearch client certificate and key must be configured together"
            )
        if self.ca_certs is not None and not self.verify_certs:
            raise SagValidationError("Elasticsearch ca_certs requires verify_certs=true")
        return self


class PostgresConnectionConfig(BaseModel):
    """pgvector 专属 PostgreSQL 连接；不从关系库配置推导。"""

    provider: Literal["postgres"] = "postgres"
    host: str = "localhost"
    port: int = 5432
    user: str
    password: str = Field(repr=False)
    database: str
    pool_size: int = Field(default=5, ge=1, le=100)
    max_overflow: int = Field(default=5, ge=0, le=200)
    pool_recycle: int = 3600
    connect_timeout: float = Field(default=10.0, gt=0, le=300)
    command_timeout: float = Field(default=30.0, gt=0, le=1_800)
    pool_timeout: float = Field(default=30.0, gt=0, le=300)
    tls: PostgresTLSConfig | None = None


class OceanBaseConnectionConfig(BaseModel):
    """OceanBase Vector 专属连接；不从关系库配置推导。"""

    provider: Literal["oceanbase"] = "oceanbase"
    host: str = "localhost"
    port: int = 2881
    user: str
    password: str = Field(repr=False)
    database: str
    pool_size: int = Field(default=5, ge=1, le=100)
    max_overflow: int = Field(default=5, ge=0, le=200)
    pool_recycle: int = 3600


class LanceDBVectorConfig(BaseModel):
    """本地 LanceDB 向量存储配置。"""

    provider: Literal["lancedb"] = "lancedb"
    path: str = ""


class ElasticsearchVectorConfig(_ElasticsearchConnectionConfig):
    """Elasticsearch 向量存储配置。"""

    provider: Literal["elasticsearch"] = "elasticsearch"


class PgVectorConfig(BaseModel):
    """pgvector 向量存储配置。"""

    provider: Literal["pgvector"] = "pgvector"
    connection: PostgresConnectionConfig


class ParadeDBVectorConfig(BaseModel):
    """ParadeDB 向量存储配置(单库:pgvector 向量 + pg_search 真 BM25)。

    需要目标库已装 ``vector`` 与 ``pg_search`` 扩展;镜像见 docker-compose 的
    ``paradedb`` 服务。相对 PgVectorConfig 的差别只在词法检索能力,连接形状相同。
    """

    provider: Literal["paradedb"] = "paradedb"
    connection: PostgresConnectionConfig


class OceanBaseVectorConfig(BaseModel):
    """OceanBase Vector 向量存储配置。"""

    provider: Literal["oceanbase"] = "oceanbase"
    connection: OceanBaseConnectionConfig


VectorConfig = Annotated[
    LanceDBVectorConfig
    | ElasticsearchVectorConfig
    | PgVectorConfig
    | ParadeDBVectorConfig
    | OceanBaseVectorConfig,
    Field(discriminator="provider"),
]


class LLMConfig(BaseModel):
    """LLM(OpenAI 兼容)配置。"""

    api_key: str = Field(repr=False)
    model: str
    provider: Literal["openai", "litellm"] = "openai"
    base_url: str | None = None
    temperature: float = 0.7
    max_tokens: int = 30000
    timeout: int = 300
    max_retries: int = 5
    enable_think: bool = False
    # 结构化输出模式开关：json_schema(默认,向后兼容) | json_object | prompt_only 或注册扩展名。
    # 用 str + validator（而非 Literal）以便自定义注册模式也能经 env 配置。
    structured_output_mode: str = "json_schema"
    data_inspection: bool = True
    top_p: float = Field(default=1.0, ge=0.0, le=1.0)
    frequency_penalty: float = Field(default=0.0, ge=-2.0, le=2.0)
    presence_penalty: float = Field(default=0.0, ge=-2.0, le=2.0)

    @field_validator("structured_output_mode")
    @classmethod
    def _validate_structured_output_mode(cls, v: object) -> str:
        """校验结构化输出模式；非法值报错并列出可选值。"""
        if not isinstance(v, str):
            v = str(v)
        normalized = v.lower()
        # 惰性 import，避免 config ↔ core.ai.structured 循环
        from zleap.sag.core.ai.structured import available_modes

        if normalized not in available_modes():
            raise SagValidationError(
                f"structured_output_mode 必须是: {', '.join(available_modes())}"
            )
        return normalized


DEFAULT_EMBEDDING_MAX_TOKENS = 512


class VLMConfig(BaseModel):
    """多模态大模型(OpenAI 兼容)配置(可选)。

    与 ``LLMConfig`` 完全独立:模型名、温度、超时互不影响;仅 ``api_key``/``base_url``
    留空时回退到 LLM 的对应值(同一网关最常见)。``model`` **不回退** —— 否则未配 VLM
    时会静默拿文本模型去跑图片请求,返回与根因无关的 400。
    """

    model: str
    api_key: str | None = None
    base_url: str | None = None
    # 视觉任务比对话更需要确定性,默认温度低于 LLM
    temperature: float = 0.3
    max_tokens: int = 8000
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    # 图片首字延迟远高于纯文本
    timeout: int = 600
    max_retries: int = 3
    # OpenAI 兼容服务不一定实现 detail；默认不发送，只有显式配置时才携带。
    detail: Literal["low", "high", "auto"] | None = None
    max_image_bytes: int = 10 * 1024 * 1024
    structured_output_mode: str = "json_schema"

    @field_validator("structured_output_mode")
    @classmethod
    def _validate_structured_output_mode(cls, v: object) -> str:
        """与 LLMConfig 共用结构化输出注册表；非法值报错并列出可选值。"""
        if not isinstance(v, str):
            v = str(v)
        normalized = v.lower()
        from zleap.sag.core.ai.structured import available_modes

        if normalized not in available_modes():
            raise SagValidationError(
                f"structured_output_mode 必须是: {', '.join(available_modes())}"
            )
        return normalized


class ImageProcessingConfig(BaseModel):
    """Markdown 图片 enrichment 的可调运行参数。

    是否启用图片处理只由 ``EngineConfig.vlm`` 决定；本配置不承担功能开关。
    单图字节上限复用 ``VLMConfig.max_image_bytes``，避免出现两套同义配置。

    远程 http(s) 图片按 ``fetch_timeout`` / ``fetch_connect_timeout`` 限时抓取；
    本地相对路径始终受 Markdown 目录边界约束。
    """

    max_concurrency: int = Field(default=4, ge=1, le=32)
    min_short_edge: int = Field(default=32, ge=1)
    fetch_timeout: int = Field(default=15, ge=1, le=300)
    fetch_connect_timeout: int = Field(default=5, ge=1, le=60)


class EmbeddingConfig(BaseModel):
    """Embedding 配置;api_key/base_url 留空时回退到 LLM 的对应值。"""

    model_config = ConfigDict(extra="forbid")

    model: str
    schema_dimensions: int | None = Field(default=None, ge=1)
    request_dimensions: int | None = Field(default=None, ge=1)
    max_tokens: int = DEFAULT_EMBEDDING_MAX_TOKENS
    api_key: str | None = Field(default=None, repr=False)
    base_url: str | None = None
    timeout: int = 60
    max_retries: int = 3


class RerankConfig(BaseModel):
    """Rerank 配置(可选)。"""

    model: str
    api_key: str | None = Field(default=None, repr=False)
    base_url: str | None = None
    endpoint: str = "/rerank"
    # 不设超时会落到 aiohttp 默认的 300s，网关卡住时单次检索会挂五分钟
    timeout: int = Field(default=30, ge=1)


class EntityTypeConfig(BaseModel):
    """自定义实体类型(schema 初始化时幂等播种;按 type 名跳过已存在的,只加新的)。

    抽取阶段只保留"已定义类型"内的实体;声明领域类型可让 LLM 抽出并保留这些实体。
    ``type`` 用小写标识(对齐抽取 prompt 约定),如 ``"contract"`` / ``"invoice"``。
    """

    type: str
    name: str | None = None  # 显示名;缺省用 type 首字母大写
    description: str = ""


class GuardConfig(BaseModel):
    """内容过滤(违禁词)插件配置。"""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    enabled: bool = True
    provider: str | ContentGuard = "toolgood"
    words_file: str | None = None
    policy: GuardPolicy = Field(default_factory=GuardPolicy)
    options: dict[str, Any] = Field(default_factory=dict)


class RuntimeLimits(BaseModel):
    """单个 Engine 实例的有界并发和背压配置。

    这些限制只控制当前进程中的一个 Engine；生产总并发由
    ``实例数 × RuntimeLimits`` 明确计算，避免把分布式限流伪装成包内全局锁。
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    mutation_concurrency: int = Field(default=4, ge=1, le=256)
    search_concurrency: int = Field(default=32, ge=1, le=1024)
    llm_concurrency: int = Field(default=8, ge=1, le=256)
    embedding_concurrency: int = Field(default=8, ge=1, le=256)
    rerank_concurrency: int = Field(default=4, ge=1, le=256)
    vector_write_concurrency: int = Field(default=8, ge=1, le=256)
    acquire_timeout_seconds: float = Field(default=30.0, gt=0.0, le=600.0)


class EngineConfig(BaseModel):
    """引擎总配置(注入式)。

    用法::

        # 零基础设施:本地 SQLite + LanceDB,落盘 ./.zleap/,无需任何服务
        config = EngineConfig(
            storage_mode="normal",
            llm=LLMConfig(api_key="...", model="qwen3.6-flash", base_url="https://.../v1"),
            embedding=EmbeddingConfig(model="bge-large-en-v1.5", base_url="https://.../v1", api_key="..."),
        )

        # 生产:切 MySQL + Elasticsearch(需 pip install "zleap-sag[mysql,es]")
        config = EngineConfig(
            storage_mode="normal",
            relational=RelationalConfig(
                provider="mysql", user="sag2", password="...", database="sag2"
            ),
            vector=ElasticsearchVectorConfig(hosts=["http://localhost:9200"]),
            llm=LLMConfig(api_key="...", model="qwen3.6-flash", base_url="https://.../v1"),
            embedding=EmbeddingConfig(model="bge-large-en-v1.5", base_url="https://.../v1", api_key="..."),
        )
    """

    model_config = ConfigDict(extra="forbid")

    # storage_mode 是物理 schema 合同，不是运行时功能开关；不提供旧值映射。
    storage_mode: Literal["normal", "lite"]
    # 关系库:留空则默认本地 SQLite(零基础设施)。
    relational: RelationalConfig | None = None
    # 向量库拥有完整独立配置；留空时由 data_dir 派生本地 LanceDB。
    vector: VectorConfig | None = None
    # 本地数据目录:storage_mode 只选 schema，不自动改写该路径。
    data_dir: str = "./.zleap"
    llm: LLMConfig
    embedding: EmbeddingConfig
    rerank: RerankConfig | None = None
    # 多模态模型(可选):留空表示未启用多模态能力,ResourceContainer.vlm 为 None。
    vlm: VLMConfig | None = None
    image_processing: ImageProcessingConfig = Field(default_factory=ImageProcessingConfig)
    guard: GuardConfig | None = None
    # 自定义实体类型:schema 初始化时幂等追加(已存在跳过)。传字符串或 EntityTypeConfig 均可。
    entity_types: list[EntityTypeConfig] | None = None
    # 实体类型播种模式:
    # - "append"(默认):保留库中已有全局类型,逐个追加新类型(只加新的);
    # - "replace":先清空 scope="global" 的全部实体类型,再按 entity_types 精确播种。
    #   用于复现外部基准(如 SAG-Benchmark)需要与目标 entity_types 集合完全一致的场景。
    entity_types_mode: Literal["append", "replace"] = "append"

    language: Literal["zh", "en"] = "en"
    benchmark: bool = False
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    runtime_limits: RuntimeLimits = Field(default_factory=RuntimeLimits)

    @field_validator("entity_types", mode="before")
    @classmethod
    def _coerce_entity_types(cls, v: object) -> object:
        """允许 ``entity_types=["contract", ...]``(字符串)或 EntityTypeConfig 对象混用。"""
        if not isinstance(v, list | tuple):
            return v
        return [EntityTypeConfig(type=x) if isinstance(x, str) else x for x in v]

    @model_validator(mode="after")
    def _derive_relational(self) -> EngineConfig:
        """relational 未给时，使用 data_dir 下的 SQLite。"""
        if self.relational is None:
            from pathlib import Path

            self.relational = RelationalConfig(
                provider="sqlite",
                path=str(Path(self.data_dir) / "sag.db"),
            )
        return self

    @model_validator(mode="after")
    def _derive_vector(self) -> EngineConfig:
        """向量配置留空时使用 data_dir/lancedb；显式空 path 也只在此处派生。"""
        from pathlib import Path

        if self.vector is None:
            self.vector = LanceDBVectorConfig(path=str(Path(self.data_dir) / "lancedb"))
        elif isinstance(self.vector, LanceDBVectorConfig) and not self.vector.path:
            self.vector = self.vector.model_copy(
                update={"path": str(Path(self.data_dir) / "lancedb")}
            )
        return self

    @model_validator(mode="after")
    def _fallback_embedding_to_llm(self) -> EngineConfig:
        """Embedding 未单独配 api_key/base_url 时,回退复用 LLM 的对应值(同一网关最常见)。"""
        updates: dict[str, str | None] = {}
        if self.embedding.api_key is None:
            updates["api_key"] = self.llm.api_key
        if self.embedding.base_url is None:
            updates["base_url"] = self.llm.base_url
        if updates:
            self.embedding = self.embedding.model_copy(update=updates)
        return self

    @model_validator(mode="after")
    def _fallback_rerank_credentials(self) -> EngineConfig:
        """Rerank 显式开启后只复用本 Engine 的 Embedding/LLM 凭据。"""
        if self.rerank is None:
            return self
        updates: dict[str, str | None] = {}
        if self.rerank.api_key is None:
            updates["api_key"] = self.embedding.api_key or self.llm.api_key
        if self.rerank.base_url is None:
            updates["base_url"] = self.embedding.base_url or self.llm.base_url
        if updates:
            self.rerank = self.rerank.model_copy(update=updates)
        if not self.rerank.base_url:
            from zleap.sag.exceptions import ConfigError

            raise ConfigError("启用 rerank 时必须配置 rerank.base_url 或 embedding.base_url")
        return self

    @model_validator(mode="after")
    def _fallback_vlm_to_llm(self) -> EngineConfig:
        """VLM 未单独配 api_key/base_url 时,回退复用 LLM 的对应值(同一网关最常见)。

        注意只回退凭据,不回退 ``model``:后者缺失应在构造 VLMConfig 时就报错。
        """
        if self.vlm is None:
            return self
        if self.vlm.api_key is None:
            self.vlm.api_key = self.llm.api_key
        if self.vlm.base_url is None:
            self.vlm.base_url = self.llm.base_url
        return self

    @model_validator(mode="after")
    def _validate_backend_coherence(self) -> EngineConfig:
        """只校验向量侧自身配置，不限制关系库与向量库的组合。"""
        from zleap.sag.exceptions import ConfigError

        if isinstance(self.vector, ElasticsearchVectorConfig) and not self.vector.hosts:
            raise ConfigError(
                "vector.provider='elasticsearch' 需要 hosts；请配置 "
                "ElasticsearchVectorConfig(hosts=['http://localhost:9200'])。"
            )
        return self

    @classmethod
    def from_env(cls, env_file: str | None = None) -> EngineConfig:
        """从环境变量加载配置(标准/扁平命名,无前缀)。

        密钥与端点沿用生态通用命名(OpenAI SDK 同款),存储用自描述扁平名。零基础设施最小集::

            OPENAI_API_KEY=sk-...
            OPENAI_BASE_URL=https://your-gateway/v1     # 可选(默认 OpenAI 官方)
            LLM_MODEL=qwen3.6-flash
            EMBEDDING_MODEL=bge-large-en-v1.5

        切生产后端(示例:MySQL + Elasticsearch)::

            RELATIONAL_PROVIDER=mysql  DB_HOST=localhost DB_USER=sag2 DB_PASSWORD=... DB_NAME=sag2
            VECTOR_PROVIDER=es         ES_HOSTS=http://localhost:9200

        完整变量见仓库 ``.env.example`` 与 README。Embedding 未单独配 KEY/URL 时回退 OPENAI_*。

        Args:
            env_file: 可选 ``.env`` 文件路径(``KEY=VALUE`` 行;os.environ 优先于文件)。
        """
        import os

        env: dict[str, str] = {}
        if env_file:
            env.update(_parse_env_file(env_file))
        env.update(os.environ)

        def _req(*keys: str) -> str:
            for k in keys:
                if env.get(k):
                    return env[k]
            from zleap.sag.exceptions import ConfigError

            raise ConfigError(
                f"from_env 缺少必填环境变量 {' / '.join(keys)};最小集见 .env.example。"
            )

        def _opt(*keys: str) -> str | None:
            for k in keys:
                if env.get(k):
                    return env[k]
            return None

        def _int(*keys: str) -> int | None:
            v = _opt(*keys)
            return int(v) if v is not None else None

        def _float(*keys: str) -> float | None:
            v = _opt(*keys)
            return float(v) if v is not None else None

        # ── LLM / Embedding(标准命名)──
        llm_kwargs: dict[str, object] = {
            "api_key": _req("OPENAI_API_KEY"),
            "model": _req("LLM_MODEL"),
            "base_url": _opt("OPENAI_BASE_URL"),
        }
        if (t := _float("LLM_TEMPERATURE")) is not None:
            llm_kwargs["temperature"] = t
        if (mt := _int("LLM_MAX_TOKENS")) is not None:
            llm_kwargs["max_tokens"] = mt
        if (to := _int("LLM_TIMEOUT")) is not None:
            llm_kwargs["timeout"] = to
        if (structured_output := _opt("LLM_STRUCTURED_OUTPUT_MODE")) is not None:
            llm_kwargs["structured_output_mode"] = structured_output
        llm = LLMConfig(**llm_kwargs)  # type: ignore[arg-type]

        if "EMBEDDING_DIMENSIONS" in env:
            from zleap.sag.exceptions import ConfigError

            raise ConfigError(
                "EMBEDDING_DIMENSIONS 已移除，请分别配置 "
                "EMBEDDING_SCHEMA_DIMENSIONS 和 EMBEDDING_REQUEST_DIMENSIONS"
            )

        emb_kwargs: dict[str, object] = {
            "model": _req("EMBEDDING_MODEL"),
            "api_key": _opt("EMBEDDING_API_KEY"),  # None → validator 回退 OPENAI_API_KEY
            "base_url": _opt("EMBEDDING_BASE_URL"),
        }
        # 两项独立；未设置或空字符串/none/null 均为 None。
        for key in ("schema_dimensions", "request_dimensions"):
            env_key = f"EMBEDDING_{key.upper()}"
            if env_key in env:
                raw = env[env_key].strip()
                emb_kwargs[key] = None if raw.lower() in {"", "none", "null"} else int(raw)
        if (emtk := _int("EMBEDDING_MAX_TOKENS")) is not None:
            emb_kwargs["max_tokens"] = emtk
        if (eto := _int("EMBEDDING_TIMEOUT")) is not None:
            emb_kwargs["timeout"] = eto
        if (emr := _int("EMBEDDING_MAX_RETRIES")) is not None:
            emb_kwargs["max_retries"] = emr
        embedding = EmbeddingConfig(**emb_kwargs)  # type: ignore[arg-type]

        rerank = None
        if env.get("RERANK_MODEL"):
            rerank = RerankConfig(
                model=env["RERANK_MODEL"],
                api_key=_opt("RERANK_API_KEY"),
                base_url=_opt("RERANK_BASE_URL"),
            )

        # ── VLM(多模态,可选):未配 VLM_MODEL 则整体为 None,行为与不启用一致 ──
        vlm = None
        if env.get("VLM_MODEL"):
            vlm_kwargs: dict[str, object] = {
                "model": env["VLM_MODEL"],
                "api_key": _opt("VLM_API_KEY"),  # None → validator 回退 OPENAI_API_KEY
                "base_url": _opt("VLM_BASE_URL"),
            }
            if (vt := _float("VLM_TEMPERATURE")) is not None:
                vlm_kwargs["temperature"] = vt
            if (vmt := _int("VLM_MAX_TOKENS")) is not None:
                vlm_kwargs["max_tokens"] = vmt
            if (vtp := _float("VLM_TOP_P")) is not None:
                vlm_kwargs["top_p"] = vtp
            if (vfp := _float("VLM_FREQUENCY_PENALTY")) is not None:
                vlm_kwargs["frequency_penalty"] = vfp
            if (vpp := _float("VLM_PRESENCE_PENALTY")) is not None:
                vlm_kwargs["presence_penalty"] = vpp
            if (vto := _int("VLM_TIMEOUT")) is not None:
                vlm_kwargs["timeout"] = vto
            if (vmr := _int("VLM_MAX_RETRIES")) is not None:
                vlm_kwargs["max_retries"] = vmr
            if (vd := _opt("VLM_DETAIL")) is not None:
                vlm_kwargs["detail"] = vd
            if (vmib := _int("VLM_MAX_IMAGE_BYTES")) is not None:
                vlm_kwargs["max_image_bytes"] = vmib
            if (vso := _opt("VLM_STRUCTURED_OUTPUT_MODE")) is not None:
                vlm_kwargs["structured_output_mode"] = vso
            vlm = VLMConfig(**vlm_kwargs)  # type: ignore[arg-type]

        image_kwargs: dict[str, object] = {}
        if (imc := _int("IMAGE_MAX_CONCURRENCY")) is not None:
            image_kwargs["max_concurrency"] = imc
        if (imse := _int("IMAGE_MIN_SHORT_EDGE")) is not None:
            image_kwargs["min_short_edge"] = imse
        if (ift := _int("IMAGE_FETCH_TIMEOUT")) is not None:
            image_kwargs["fetch_timeout"] = ift
        if (ict := _int("IMAGE_FETCH_CONNECT_TIMEOUT")) is not None:
            image_kwargs["fetch_connect_timeout"] = ict
        image_processing = ImageProcessingConfig(**image_kwargs)  # type: ignore[arg-type]

        # ── 存储选型 ──
        storage_mode = _req("SAG_STORAGE_MODE", "STORAGE_MODE").lower()
        vector_provider = (_opt("SAG_VECTOR_PROVIDER", "VECTOR_PROVIDER") or "lancedb").lower()
        rel_provider = (_opt("SAG_RELATIONAL_PROVIDER", "RELATIONAL_PROVIDER") or "sqlite").lower()
        if rel_provider == "postgresql":
            rel_provider = "postgres"
        data_dir = _opt("SAG_DATA_DIR", "DATA_DIR") or "./.zleap"

        relational: RelationalConfig | None = None
        if rel_provider != "sqlite":  # sqlite 交给 _derive_relational 用 data_dir 派生
            relational_tls = None
            if rel_provider == "postgres" and (
                tls_mode := _opt("SAG_RELATIONAL_TLS_MODE", "DB_TLS_MODE")
            ):
                relational_tls = PostgresTLSConfig(
                    mode=tls_mode,  # type: ignore[arg-type]
                    ca_file=_opt("SAG_RELATIONAL_TLS_CA_FILE", "DB_TLS_CA_FILE"),
                    client_cert_file=_opt(
                        "SAG_RELATIONAL_TLS_CLIENT_CERT_FILE",
                        "DB_TLS_CLIENT_CERT_FILE",
                    ),
                    client_key_file=_opt(
                        "SAG_RELATIONAL_TLS_CLIENT_KEY_FILE",
                        "DB_TLS_CLIENT_KEY_FILE",
                    ),
                )
            relational_max_overflow = _int("SAG_RELATIONAL_MAX_OVERFLOW", "DB_MAX_OVERFLOW")
            relational = RelationalConfig(
                provider=rel_provider,  # type: ignore[arg-type]
                host=_opt("SAG_RELATIONAL_HOST", "DB_HOST") or "localhost",
                port=_int("SAG_RELATIONAL_PORT", "DB_PORT")
                or {"postgres": 5432, "oceanbase": 2881}.get(rel_provider, 3306),
                user=_opt("SAG_RELATIONAL_USER", "DB_USER") or "sag2",
                password=_opt("SAG_RELATIONAL_PASSWORD", "DB_PASSWORD") or "sag2",
                database=_opt("SAG_RELATIONAL_DATABASE", "DB_NAME") or "sag2",
                pool_size=_int("SAG_RELATIONAL_POOL_SIZE", "DB_POOL_SIZE") or 5,
                max_overflow=(5 if relational_max_overflow is None else relational_max_overflow),
                pool_recycle=_int("SAG_RELATIONAL_POOL_RECYCLE", "DB_POOL_RECYCLE") or 3600,
                connect_timeout=(
                    _float("SAG_RELATIONAL_CONNECT_TIMEOUT", "DB_CONNECT_TIMEOUT") or 10.0
                ),
                command_timeout=(
                    _float("SAG_RELATIONAL_COMMAND_TIMEOUT", "DB_COMMAND_TIMEOUT") or 30.0
                ),
                pool_timeout=(_float("SAG_RELATIONAL_POOL_TIMEOUT", "DB_POOL_TIMEOUT") or 30.0),
                tls=relational_tls,
            )

        vector: VectorConfig
        if vector_provider == "lancedb":
            from pathlib import Path

            vector = LanceDBVectorConfig(
                path=_opt("SAG_VECTOR_LANCEDB_PATH", "LANCEDB_PATH")
                or str(Path(data_dir) / "lancedb")
            )
        elif vector_provider in ("es", "elasticsearch"):
            elasticsearch_max_retries = _int("SAG_VECTOR_ES_MAX_RETRIES", "ES_MAX_RETRIES")
            vector = ElasticsearchVectorConfig(
                hosts=_parse_hosts(_req("SAG_VECTOR_ES_HOSTS", "ES_HOSTS")),
                username=_opt("SAG_VECTOR_ES_USERNAME", "ES_USERNAME"),
                password=_opt("SAG_VECTOR_ES_PASSWORD", "ES_PASSWORD", "ELASTIC_PASSWORD"),
                timeout=_int("SAG_VECTOR_ES_TIMEOUT", "ES_TIMEOUT") or 30,
                max_connections=_int("SAG_VECTOR_ES_MAX_CONNECTIONS", "ES_MAX_CONNECTIONS") or 10,
                max_retries=(3 if elasticsearch_max_retries is None else elasticsearch_max_retries),
                verify_certs=(
                    _opt("SAG_VECTOR_ES_VERIFY_CERTS", "ES_VERIFY_CERTS") or "false"
                ).lower()
                == "true",
                ca_certs=_opt("SAG_VECTOR_ES_CA_CERTS", "ES_CA_CERTS"),
                client_cert=_opt("SAG_VECTOR_ES_CLIENT_CERT", "ES_CLIENT_CERT"),
                client_key=_opt("SAG_VECTOR_ES_CLIENT_KEY", "ES_CLIENT_KEY"),
            )
        elif vector_provider == "pgvector":
            vector_tls = None
            if tls_mode := _opt("SAG_VECTOR_PG_TLS_MODE", "PGVECTOR_TLS_MODE"):
                vector_tls = PostgresTLSConfig(
                    mode=tls_mode,  # type: ignore[arg-type]
                    ca_file=_opt("SAG_VECTOR_PG_TLS_CA_FILE", "PGVECTOR_TLS_CA_FILE"),
                    client_cert_file=_opt(
                        "SAG_VECTOR_PG_TLS_CLIENT_CERT_FILE",
                        "PGVECTOR_TLS_CLIENT_CERT_FILE",
                    ),
                    client_key_file=_opt(
                        "SAG_VECTOR_PG_TLS_CLIENT_KEY_FILE",
                        "PGVECTOR_TLS_CLIENT_KEY_FILE",
                    ),
                )
            vector = PgVectorConfig(
                connection=PostgresConnectionConfig(
                    host=_req("SAG_VECTOR_PG_HOST", "PGVECTOR_HOST"),
                    port=_int("SAG_VECTOR_PG_PORT", "PGVECTOR_PORT") or 5432,
                    user=_req("SAG_VECTOR_PG_USER", "PGVECTOR_USER"),
                    password=_req("SAG_VECTOR_PG_PASSWORD", "PGVECTOR_PASSWORD"),
                    database=_req("SAG_VECTOR_PG_DATABASE", "PGVECTOR_DATABASE"),
                    pool_size=_int(
                        "SAG_VECTOR_PG_POOL_SIZE",
                        "PGVECTOR_POOL_SIZE",
                        "PGVECTOR_MIN_CONNECTION",
                    )
                    or 5,
                    max_overflow=_int("SAG_VECTOR_PG_MAX_OVERFLOW", "PGVECTOR_MAX_OVERFLOW") or 5,
                    pool_recycle=_int("SAG_VECTOR_PG_POOL_RECYCLE", "PGVECTOR_POOL_RECYCLE")
                    or 3600,
                    tls=vector_tls,
                )
            )
        elif vector_provider == "paradedb":
            vector = ParadeDBVectorConfig(
                connection=PostgresConnectionConfig(
                    host=_req("SAG_VECTOR_PARADEDB_HOST", "PARADEDB_HOST"),
                    port=_int("SAG_VECTOR_PARADEDB_PORT", "PARADEDB_PORT") or 5432,
                    user=_req("SAG_VECTOR_PARADEDB_USER", "PARADEDB_USER"),
                    password=_req("SAG_VECTOR_PARADEDB_PASSWORD", "PARADEDB_PASSWORD"),
                    database=_req("SAG_VECTOR_PARADEDB_DATABASE", "PARADEDB_DATABASE"),
                    pool_size=_int("SAG_VECTOR_PARADEDB_POOL_SIZE", "PARADEDB_POOL_SIZE") or 5,
                    max_overflow=_int("SAG_VECTOR_PARADEDB_MAX_OVERFLOW", "PARADEDB_MAX_OVERFLOW")
                    or 5,
                    pool_recycle=_int("SAG_VECTOR_PARADEDB_POOL_RECYCLE", "PARADEDB_POOL_RECYCLE")
                    or 3600,
                )
            )
        elif vector_provider == "oceanbase":
            vector = OceanBaseVectorConfig(
                connection=OceanBaseConnectionConfig(
                    host=_req("SAG_VECTOR_OB_HOST", "OCEANBASE_VECTOR_HOST"),
                    port=_int("SAG_VECTOR_OB_PORT", "OCEANBASE_VECTOR_PORT") or 2881,
                    user=_req("SAG_VECTOR_OB_USER", "OCEANBASE_VECTOR_USER"),
                    password=_req("SAG_VECTOR_OB_PASSWORD", "OCEANBASE_VECTOR_PASSWORD"),
                    database=_req("SAG_VECTOR_OB_DATABASE", "OCEANBASE_VECTOR_DATABASE"),
                    pool_size=_int("SAG_VECTOR_OB_POOL_SIZE", "OCEANBASE_VECTOR_POOL_SIZE") or 5,
                    max_overflow=_int(
                        "SAG_VECTOR_OB_MAX_OVERFLOW",
                        "OCEANBASE_VECTOR_MAX_OVERFLOW",
                    )
                    or 5,
                    pool_recycle=_int("SAG_VECTOR_OB_POOL_RECYCLE", "OCEANBASE_VECTOR_POOL_RECYCLE")
                    or 3600,
                )
            )
        else:
            from zleap.sag.exceptions import ConfigError

            raise ConfigError(f"VECTOR_PROVIDER={vector_provider!r} 不受支持")

        # guard 刻意不从环境变量读取:它直接注入 SearchAdapter 装饰器,vendor 侧没有
        # 读取方,走 env 只会重新引入跨实例污染。启用方式只有显式 EngineConfig(guard=...)。
        return cls(
            storage_mode=storage_mode,  # type: ignore[arg-type]
            relational=relational,
            vector=vector,
            data_dir=data_dir,
            llm=llm,
            embedding=embedding,
            rerank=rerank,
            vlm=vlm,
            image_processing=image_processing,
            language=(_opt("LANGUAGE") or "en"),  # type: ignore[arg-type]
            log_level=(_opt("LOG_LEVEL") or "INFO"),  # type: ignore[arg-type]
        )


def _parse_env_file(path: str) -> dict[str, str]:
    """极简 .env 解析:``KEY=VALUE`` 行,跳过空行/``#`` 注释,去除包裹引号(无新依赖)。"""
    from pathlib import Path

    out: dict[str, str] = {}
    text = Path(path).read_text(encoding="utf-8")
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            out[key] = value
    return out


def _parse_hosts(value: str) -> list[str]:
    """ES_HOSTS 解析:JSON 数组 / 逗号分隔 / 单 URL 均可。"""
    value = value.strip()
    if value.startswith("["):
        import json

        try:
            parsed = json.loads(value)
            if isinstance(parsed, list):
                return [str(h) for h in parsed]
        except ValueError:
            pass
    return [h.strip() for h in value.split(",") if h.strip()]
