"""
pipeline 异常定义

所有自定义异常都继承自 :class:`SagError`,并统一携带机器可读字段:
``code``(稳定错误码)、``operation``/``stage``(出错阶段)、``retryable``(是否可重试)、
``provider``(出错的 provider)、``item_id``(出错对象)、``details``(结构化上下文)、
``cause``(底层原始异常)。

子类通过类属性 ``_code`` / ``_retryable`` / ``_operation`` / ``_stage`` 声明默认值,
实例构造时可逐字段覆盖;因此现有 ``raise XXX("msg")`` 调用点零改动即获得结构化字段。
"""

from __future__ import annotations

from enum import StrEnum
from typing import Any


class ErrorCode(StrEnum):
    """稳定错误码。值即公开契约,按 ``<domain>.<sub>`` 命名空间化。

    新增错误码 = 新增成员;也可用任意字符串做一次性扩展,避免枚举膨胀。
    """

    UNEXPECTED = "sag.unexpected"
    CONFIG = "sag.config"
    STATE = "sag.state"
    STORAGE = "sag.storage"
    STORAGE_MODE = "sag.storage.mode"
    STORAGE_SCHEMA = "sag.storage.schema"
    STORAGE_INIT = "sag.storage.init"
    VECTOR_SYNC = "sag.storage.vector_sync"
    DATABASE = "sag.storage.database"
    CACHE = "sag.storage.cache"
    AI = "sag.ai"
    AI_INVALID_REQUEST = "sag.ai.invalid_request"
    AI_TRANSIENT = "sag.ai.transient"
    LLM = "sag.ai.llm"
    LLM_TIMEOUT = "sag.ai.llm.timeout"
    LLM_RATE_LIMIT = "sag.ai.llm.rate_limit"
    LLM_TRANSIENT = "sag.ai.llm.transient"
    EMBEDDING = "sag.ai.embedding"
    RERANK = "sag.ai.rerank"
    VALIDATION = "sag.validation"
    LOAD = "sag.load"
    ENTITY = "sag.entity"
    EXTRACT = "sag.extract"
    EXTRACTION_VALIDATION = "sag.extract.validation"
    SEARCH = "sag.search"
    PROMPT = "sag.prompt"
    ADAPTER_CAPABILITY = "sag.adapter.capability"


def _summarize(cause: BaseException | None) -> dict[str, Any] | None:
    """把 cause 收敛为可 JSON 序列化的摘要,避免泄漏原始栈/敏感体。"""
    if cause is None:
        return None
    cause_type = type(cause)
    if cause_type.__module__.startswith(("pydantic", "pydantic_settings")):
        message = "Validation failed"
    else:
        message = str(cause)
    return {"type": cause_type.__name__, "message": message}


class SagError(Exception):
    """结构化错误基类。所有公开异常继承自此。

    元数据在类级别声明,实例级别可覆盖;调用点可零改动获得结构化字段。
    """

    _code: str = "sag.error"
    _retryable: bool = False
    _operation: str | None = None
    _stage: str | None = None

    def __init__(
        self,
        message: str = "",
        *,
        code: str | None = None,
        operation: str | None = None,
        stage: str | None = None,
        retryable: bool | None = None,
        provider: str | None = None,
        item_id: str | None = None,
        details: dict[str, Any] | None = None,
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = self._code if code is None else code
        self.operation = self._operation if operation is None else operation
        self.stage = self._stage if stage is None else stage
        self.retryable = self._retryable if retryable is None else retryable
        self.provider = provider
        self.item_id = item_id
        self.details: dict[str, Any] = dict(details or {})
        self.cause = cause
        if cause is not None:
            self.__cause__ = cause

    def __str__(self) -> str:
        return f"[{self.code}] {self.message}" if self.message else f"[{self.code}]"

    def to_dict(self) -> dict[str, Any]:
        """稳定 JSON 序列化形态,用于日志/监控/API 返回。"""
        return {
            "type": type(self).__name__,
            "code": self.code,
            "operation": self.operation,
            "stage": self.stage,
            "retryable": self.retryable,
            "provider": self.provider,
            "item_id": self.item_id,
            "message": self.message,
            "details": self.details,
            "cause": _summarize(self.cause),
        }

    @classmethod
    def wrap(
        cls,
        exc: BaseException,
        *,
        code: str = ErrorCode.UNEXPECTED,
        operation: str | None = None,
        stage: str | None = None,
        retryable: bool = False,
        provider: str | None = None,
        item_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> SagError:
        """把非 SagError 异常归一化为结构化 SagError(用于边界兜底)。

        若已是 SagError 则原样返回,保证幂等。
        """
        if isinstance(exc, SagError):
            return exc
        return cls(
            str(exc),
            code=code,
            operation=operation,
            stage=stage,
            retryable=retryable,
            provider=provider,
            item_id=item_id,
            details=details,
            cause=exc,
        )


class ConfigError(SagError):
    """配置错误异常"""

    _code = ErrorCode.CONFIG


class StateError(SagError):
    """当前生命周期或组件状态不允许执行该操作。"""

    _code = ErrorCode.STATE


class StorageError(SagError):
    """存储层异常"""

    _code = ErrorCode.STORAGE


class StorageModeError(StorageError):
    """存储模式识别或匹配失败。"""

    _code = ErrorCode.STORAGE_MODE


class StorageModeMismatchError(StorageModeError):
    """配置的 storage_mode 与既有存储模式不一致。"""


class StorageLayoutConflictError(StorageModeError):
    """同一存储中同时出现 normal/lite 互斥结构。"""


class StorageModeUndeterminedError(StorageModeError):
    """非空存储缺少足以唯一判定模式的结构信号。"""


class StorageSchemaMismatchError(StorageError):
    """已有对象与当前模式的 schema 合同不一致。"""

    _code = ErrorCode.STORAGE_SCHEMA

    def __init__(self, message: str, *, diffs: list[str] | None = None) -> None:
        self.diffs = diffs or []
        detail = f"{message}: " + "; ".join(self.diffs) if self.diffs else message
        super().__init__(detail, details={"diffs": self.diffs})


class StorageInitializationRequiredError(StorageError):
    """服务端存储缺少完整对象，需要显式初始化。"""

    _code = ErrorCode.STORAGE_INIT

    def __init__(self, message: str, *, missing_objects: list[str] | None = None) -> None:
        self.missing_objects = missing_objects or []
        detail = (
            f"{message}: {', '.join(self.missing_objects)}" if self.missing_objects else message
        )
        super().__init__(detail, details={"missing_objects": self.missing_objects})


class StorageInitializationError(StorageError):
    """创建当前模式缺失的完整对象失败。"""


class VectorSyncError(StorageError):
    """向量同步存在失败项；调用方负责按阶段一致性策略补偿或报告。"""

    _code = ErrorCode.VECTOR_SYNC

    def __init__(
        self,
        *,
        provider: str,
        collection: str,
        failed_ids: list[str] | tuple[str, ...],
        reason: str | None = None,
        compensation_complete: bool | None = None,
    ) -> None:
        self.collection = collection
        self.failed_ids = tuple(dict.fromkeys(str(item) for item in failed_ids))
        self.compensation_complete = compensation_complete
        detail = (
            f"向量同步失败 provider={provider} collection={collection} "
            f"failed_ids={list(self.failed_ids)}"
        )
        if reason:
            detail = f"{detail}: {reason}"
        super().__init__(
            detail,
            provider=provider,
            details={"collection": collection, "failed_ids": list(self.failed_ids)},
        )


class DatabaseError(StorageError):
    """数据库异常"""

    _code = ErrorCode.DATABASE


class CacheError(StorageError):
    """缓存异常"""

    _code = ErrorCode.CACHE


class LLMError(SagError):
    """LLM调用异常"""

    _code = ErrorCode.LLM


class LLMStructuredOutputError(LLMError):
    """The provider returned content that violates the requested JSON contract.

    This is a model-content error rather than a transport failure. The bounded
    fields let application code repair or fall back without logging model output.
    """

    def __init__(
        self,
        *,
        code: str,
        path: str = "$",
        expected: object = None,
        actual: object = None,
    ) -> None:
        self.path = path
        self.expected = expected
        self.actual = actual
        detail = f"响应不符合Schema: code={code}, path={path}"
        if expected is not None:
            detail += f", expected={expected!r}"
        if actual is not None:
            detail += f", actual={actual!r}"
        super().__init__(detail, code=code)


class LLMTimeoutError(LLMError):
    """LLM调用超时异常"""

    _code = ErrorCode.LLM_TIMEOUT
    _retryable = True


class LLMRateLimitError(LLMError):
    """LLM速率限制异常"""

    _code = ErrorCode.LLM_RATE_LIMIT
    _retryable = True


class LLMTransientError(LLMError):
    """LLM provider 的连接错误或临时服务错误。"""

    _code = ErrorCode.LLM_TRANSIENT
    _retryable = True


class LLMAuthError(LLMError):
    """LLM认证/权限异常（401/403）

    凭证无效或无权限属于配置错误，重试不会恢复；重试层必须立即放弃。
    """

    pass


class LLMInvalidRequestError(LLMError):
    """LLM请求本身不可恢复（400/404/422）

    错误的模型名、无效参数或超限输入不会因重试而变对；重试只会把同一个
    坏请求反复打到服务端。重试层必须立即放弃。
    """

    pass


class LLMContentPolicyError(LLMInvalidRequestError):
    """The provider rejected input or output under its content policy."""


class LLMContextLengthError(LLMInvalidRequestError):
    """The complete structured request exceeds the provider context window."""


class LLMConfigurationError(LLMInvalidRequestError):
    """The selected model or request parameters are not supported."""


class LLMRetryExhaustedError(LLMError):
    """A transient model call stayed unavailable after bounded transport retries."""

    def __init__(self, *, attempts: int, last_error_type: str) -> None:
        self.attempts = attempts
        self.last_error_type = last_error_type
        super().__init__(f"LLM调用失败，传输重试耗尽: attempts={attempts}")


class AIError(SagError):
    """AI相关异常（包括LLM和Embedding）"""

    _code = ErrorCode.AI


class AIAuthError(AIError):
    """AI认证/权限异常（401/403，Embedding/Rerank 路径）

    与 LLMAuthError 语义一致；单独建类是因为 Embedding 路径的调用方捕获 AIError。
    """

    pass


class AIInvalidRequestError(AIError):
    """Embedding/Rerank 请求不可恢复（400/404/422）。"""

    _code = ErrorCode.AI_INVALID_REQUEST


class AITransientError(AIError):
    """Embedding/Rerank provider 的限流、超时或临时服务错误。"""

    _code = ErrorCode.AI_TRANSIENT
    _retryable = True


class ValidationError(SagError, ValueError):
    """数据验证异常。

    ``ValueError`` 兼容性是有意保留的：Pydantic 会收集 validator 中抛出的
    ValueError 子类并继续聚合字段错误，随后由 SagBaseModel 边界转换为
    结构化 SagValidationError。
    """

    _code = ErrorCode.VALIDATION

    def __str__(self) -> str:
        base = super().__str__()
        display = {
            (
                ".".join(str(part) for part in error.get("loc", ())),
                str(error.get("type") or "validation_error"),
            )
            for error in self.details.get("errors", ())
        }
        details = [f"{location}: {error_type}" for location, error_type in sorted(display)]
        return f"{base} ({'; '.join(details)})" if details else base


class LoadError(SagError):
    """文档加载异常"""

    _code = ErrorCode.LOAD
    _operation = "ingest"


class EntityError(SagError):
    """实体处理异常"""

    _code = ErrorCode.ENTITY


class ExtractError(SagError):
    """事项提取异常"""

    _code = ErrorCode.EXTRACT
    _operation = "extract"


class ExtractRollbackError(ExtractError):
    """An extraction write failed after compensation was attempted."""

    def __init__(
        self,
        *,
        compensation_complete: bool,
        provider: str | None = None,
    ) -> None:
        self.compensation_complete = compensation_complete
        self.provider = provider
        super().__init__(
            "Extract 关系与向量变更已全部回滚"
            if compensation_complete
            else "Extract 关系/向量补偿回滚不完整"
        )


class SearchError(SagError):
    """检索异常"""

    _code = ErrorCode.SEARCH
    _operation = "search"


class CursorInvalidError(SearchError):
    """Cursor is malformed, forged, or no longer bound to a search session."""


class CursorExpiredError(SearchError):
    """The server-side stable search snapshot has expired."""


class SearchSessionTooLargeError(SearchError):
    """A requested stable snapshot exceeds the configured persistence bound."""


class PromptError(SagError):
    """提示词异常"""

    _code = ErrorCode.PROMPT


# ============ 可重试异常 ============


class RetryableError(SagError):
    """可重试异常基类（临时性错误，重试可能成功）"""

    _retryable = True


class NetworkError(RetryableError):
    """网络错误（连接超时、网络中断等）"""

    _code = "sag.network"


class ResourceBusyError(RetryableError):
    """资源繁忙错误（数据库锁、并发冲突等）"""

    _code = "sag.resource_busy"


class ServiceUnavailableError(RetryableError):
    """服务不可用错误（外部服务暂时不可用）"""

    _code = "sag.service_unavailable"


# ============ 不可重试异常 ============


class NonRetryableError(SagError):
    """不可重试异常基类（永久性错误，重试无意义）"""

    _retryable = False


class InvalidInputError(NonRetryableError):
    """无效输入错误（数据格式错误、参数非法等）"""

    _code = "sag.invalid_input"


class ResourceNotFoundError(NonRetryableError):
    """资源不存在错误（文件不存在、记录不存在等）"""

    _code = "sag.resource_not_found"


class PermissionError(NonRetryableError):
    """权限错误（访问被拒绝、认证失败等）"""

    _code = "sag.permission"


class OperationConflictError(NonRetryableError):
    """Operation identity, idempotency key, or payload conflicts with durable state."""


class StaleFenceError(NonRetryableError):
    """A mutation carries a fence token older than the accepted scope high-water mark."""


class OperationDeadlineExceededError(SagError):
    """A durable mutation reached a safe stage boundary after its call deadline."""
