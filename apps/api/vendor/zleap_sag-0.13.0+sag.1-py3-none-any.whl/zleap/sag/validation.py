"""Pydantic boundary that exposes SAG-native structured validation errors."""

from __future__ import annotations

from typing import Any, NoReturn, Self

from pydantic import BaseModel
from pydantic import ValidationError as PydanticValidationError
from pydantic_settings import BaseSettings, SettingsError

from zleap.sag.exceptions import ConfigError, InvalidInputError, SagError
from zleap.sag.exceptions import ValidationError as SagValidationError


def _sanitized_errors(exc: PydanticValidationError) -> list[dict[str, Any]]:
    """Return stable validation metadata without echoing caller-provided values."""
    return [
        {
            "type": error["type"],
            "loc": list(error["loc"]),
            "msg": "Input validation failed",
        }
        for error in exc.errors(
            include_url=False,
            include_context=False,
            include_input=False,
        )
    ]


class _SagValidationBoundary:
    """Shared Pydantic-to-SAG exception translation for models and settings."""

    def __init__(self, /, *args: Any, **data: Any) -> None:
        if args:
            raise InvalidInputError(
                f"{type(self).__name__} only accepts keyword arguments",
                details={"positional_argument_count": len(args)},
            )
        try:
            parent: Any = super()
            parent.__init__(**data)
        except SagError:
            raise
        except SettingsError as exc:
            raise ConfigError(
                f"{type(self).__name__} settings could not be loaded",
                details={"model": type(self).__name__, "error_type": type(exc).__name__},
                cause=exc,
            ) from exc
        except PydanticValidationError as exc:
            self._raise_sag_validation_error(exc)

    def __setattr__(self, name: str, value: Any) -> None:
        try:
            parent: Any = super()
            parent.__setattr__(name, value)
        except SagError:
            raise
        except PydanticValidationError as exc:
            self._raise_sag_validation_error(exc)

    def __delattr__(self, name: str) -> None:
        try:
            parent: Any = super()
            parent.__delattr__(name)
        except SagError:
            raise
        except PydanticValidationError as exc:
            self._raise_sag_validation_error(exc)

    @classmethod
    def model_validate(cls, obj: Any, **kwargs: Any) -> Self:
        try:
            parent: Any = super()
            return parent.model_validate(obj, **kwargs)
        except SagError:
            raise
        except PydanticValidationError as exc:
            cls._raise_sag_validation_error(exc)

    @classmethod
    def model_validate_json(cls, json_data: str | bytes | bytearray, **kwargs: Any) -> Self:
        try:
            parent: Any = super()
            return parent.model_validate_json(json_data, **kwargs)
        except SagError:
            raise
        except PydanticValidationError as exc:
            cls._raise_sag_validation_error(exc)

    @classmethod
    def model_validate_strings(cls, obj: Any, **kwargs: Any) -> Self:
        try:
            parent: Any = super()
            return parent.model_validate_strings(obj, **kwargs)
        except SagError:
            raise
        except PydanticValidationError as exc:
            cls._raise_sag_validation_error(exc)

    @classmethod
    def _raise_sag_validation_error(cls, exc: PydanticValidationError) -> NoReturn:
        # ``model_validate`` may route through this mixin's ``__init__``. Because
        # SAG validation errors also inherit ValueError for validator compatibility,
        # Pydantic can wrap the already-sanitized error once more at the model root.
        # Preserve the first translation so field locations and error types survive.
        for raw_error in exc.errors(include_url=False, include_input=False):
            nested = (raw_error.get("ctx") or {}).get("error")
            if isinstance(nested, SagError) and nested.details.get("errors"):
                raise nested
        errors = _sanitized_errors(exc)
        if issubclass(cls, BaseSettings):
            for item in errors:
                item["loc"] = [
                    part.upper() if isinstance(part, str) else part for part in item["loc"]
                ]
        raise SagValidationError(
            f"{cls.__name__} validation failed",
            details={"model": cls.__name__, "errors": errors},
            cause=exc,
        ) from exc


class SagBaseModel(_SagValidationBoundary, BaseModel):
    """BaseModel whose public validation failures always derive from SagError."""


class SagBaseSettings(_SagValidationBoundary, BaseSettings):
    """BaseSettings whose public validation failures always derive from SagError."""
