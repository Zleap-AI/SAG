"""Public bounded maintenance contracts.

Maintenance repairs only SAG-owned derived state.  It never changes caller-owned
documents, permissions, fences, or durable operation identities.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from zleap.sag.pipeline.contracts import ContractModel


class MaintenancePolicy(ContractModel):
    """One bounded pass; callers repeat while ``has_more`` is true."""

    cleanup_source_limit: int = Field(default=50, ge=1, le=500)
    expired_search_session_limit: int = Field(default=500, ge=1, le=5_000)
    stale_operation_limit: int = Field(default=500, ge=1, le=5_000)
    terminal_operation_retention_days: int = Field(default=30, ge=1, le=3_650)
    terminal_operation_limit: int = Field(default=500, ge=1, le=5_000)


class MaintenanceResult(ContractModel):
    completed_at: datetime
    cleanup_sources_selected: int = Field(ge=0)
    cleanup_sources_completed: int = Field(ge=0)
    cleanup_sources_pending: int = Field(ge=0)
    expired_search_sessions_deleted: int = Field(ge=0)
    stale_operations_released: int = Field(ge=0)
    terminal_operations_deleted: int = Field(ge=0)
    has_more: bool


__all__ = ["MaintenancePolicy", "MaintenanceResult"]
