"""Instance-scoped runtime admission control.

The governor bounds expensive work before it reaches model or storage providers.  It is
deliberately local to one :class:`DataEngine`; deployment-level concurrency remains an
explicit function of process count and these limits.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from enum import StrEnum

from zleap.sag.config import RuntimeLimits
from zleap.sag.exceptions import ResourceBusyError


class RuntimeResource(StrEnum):
    MUTATION = "mutation"
    SEARCH = "search"
    LLM = "llm"
    EMBEDDING = "embedding"
    RERANK = "rerank"
    VECTOR_WRITE = "vector_write"


@dataclass(frozen=True, slots=True)
class LimiterSnapshot:
    limit: int
    active: int
    waiting: int
    peak_active: int


class _Limiter:
    def __init__(self, name: RuntimeResource, limit: int, timeout: float) -> None:
        self.name = name
        self.limit = limit
        self.timeout = timeout
        self._semaphore = asyncio.BoundedSemaphore(limit)
        self.active = 0
        self.waiting = 0
        self.peak_active = 0
        self._ownership: ContextVar[tuple[object | None, int] | None] = ContextVar(
            f"zleap_sag_runtime_{name.value}_{id(self)}", default=None
        )

    @asynccontextmanager
    async def slot(self) -> AsyncIterator[None]:
        task = asyncio.current_task()
        ownership = self._ownership.get()
        if ownership is not None and ownership[0] is task:
            token = self._ownership.set((task, ownership[1] + 1))
            try:
                yield
            finally:
                self._ownership.reset(token)
            return

        self.waiting += 1
        try:
            try:
                await asyncio.wait_for(self._semaphore.acquire(), timeout=self.timeout)
            except TimeoutError as exc:
                raise ResourceBusyError(
                    f"等待 {self.name.value} 执行槽超时({self.timeout:g}s)"
                ) from exc
        finally:
            self.waiting -= 1

        self.active += 1
        self.peak_active = max(self.peak_active, self.active)
        token = self._ownership.set((task, 1))
        try:
            yield
        finally:
            self._ownership.reset(token)
            self.active -= 1
            self._semaphore.release()

    def snapshot(self) -> LimiterSnapshot:
        return LimiterSnapshot(
            limit=self.limit,
            active=self.active,
            waiting=self.waiting,
            peak_active=self.peak_active,
        )


class RuntimeGovernor:
    """Own all bounded resources for exactly one engine instance."""

    def __init__(self, limits: RuntimeLimits) -> None:
        timeout = limits.acquire_timeout_seconds
        self._limiters = {
            RuntimeResource.MUTATION: _Limiter(
                RuntimeResource.MUTATION, limits.mutation_concurrency, timeout
            ),
            RuntimeResource.SEARCH: _Limiter(
                RuntimeResource.SEARCH, limits.search_concurrency, timeout
            ),
            RuntimeResource.LLM: _Limiter(RuntimeResource.LLM, limits.llm_concurrency, timeout),
            RuntimeResource.EMBEDDING: _Limiter(
                RuntimeResource.EMBEDDING, limits.embedding_concurrency, timeout
            ),
            RuntimeResource.RERANK: _Limiter(
                RuntimeResource.RERANK, limits.rerank_concurrency, timeout
            ),
            RuntimeResource.VECTOR_WRITE: _Limiter(
                RuntimeResource.VECTOR_WRITE, limits.vector_write_concurrency, timeout
            ),
        }

    def slot(self, resource: RuntimeResource) -> AbstractAsyncContextManager[None]:
        return self._limiters[resource].slot()

    def snapshot(self) -> dict[RuntimeResource, LimiterSnapshot]:
        return {name: limiter.snapshot() for name, limiter in self._limiters.items()}


__all__ = [
    "LimiterSnapshot",
    "RuntimeGovernor",
    "RuntimeResource",
]
