"""SQL-backed target selection and bounded housekeeping for SAG maintenance."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

from sqlalchemy import and_, delete, exists, func, or_, select, update

from zleap.sag.db import SAGFence, SAGOperation, SAGSearchSession, SAGSourceManifest
from zleap.sag.db.clock import database_utcnow


@dataclass(frozen=True, slots=True)
class CleanupTarget:
    data_source_id: str
    source_id: str
    updated_at: datetime


class MaintenanceStore:
    def __init__(self, session_factory: Any) -> None:
        self._session_factory = session_factory

    async def cleanup_targets(self, limit: int) -> tuple[tuple[CleanupTarget, ...], bool]:
        """Select the oldest unique sources with visible cleanup debt."""

        query_limit = limit + 1
        async with self._session_factory() as session:
            manifest_rows = (
                await session.execute(
                    select(
                        SAGSourceManifest.data_source_id,
                        SAGSourceManifest.source_id,
                        SAGSourceManifest.updated_time,
                    )
                    .where(SAGSourceManifest.cleanup_required.is_(True))
                    .order_by(
                        SAGSourceManifest.updated_time,
                        SAGSourceManifest.data_source_id,
                        SAGSourceManifest.source_id,
                    )
                    .limit(query_limit)
                )
            ).all()
            oldest_operation = func.min(SAGOperation.updated_time).label("oldest_operation")
            operation_rows = (
                await session.execute(
                    select(
                        SAGOperation.data_source_id,
                        SAGOperation.source_id,
                        oldest_operation,
                    )
                    .where(
                        SAGOperation.operation_type == "process_source",
                        SAGOperation.status == "failed",
                        SAGOperation.retryable.is_(False),
                        SAGOperation.cleanup_completed_at.is_(None),
                        SAGOperation.source_id.is_not(None),
                    )
                    .group_by(SAGOperation.data_source_id, SAGOperation.source_id)
                    .order_by(
                        oldest_operation,
                        SAGOperation.data_source_id,
                        SAGOperation.source_id,
                    )
                    .limit(query_limit)
                )
            ).all()

        by_source: dict[tuple[str, str], CleanupTarget] = {}
        for data_source_id, source_id, updated_at in (*manifest_rows, *operation_rows):
            if source_id is None:
                continue
            target = CleanupTarget(
                data_source_id=str(data_source_id),
                source_id=str(source_id),
                updated_at=updated_at,
            )
            key = (target.data_source_id, target.source_id)
            current = by_source.get(key)
            if current is None or target.updated_at < current.updated_at:
                by_source[key] = target
        ordered = tuple(
            sorted(
                by_source.values(),
                key=lambda item: (item.updated_at, item.data_source_id, item.source_id),
            )
        )
        return ordered[:limit], len(ordered) > limit

    async def purge_expired_search_sessions(self, limit: int) -> tuple[int, bool]:
        async with self._session_factory() as session:
            now = await database_utcnow(session)
            session_ids = tuple(
                (
                    await session.scalars(
                        select(SAGSearchSession.session_id)
                        .where(SAGSearchSession.expires_at <= now)
                        .order_by(SAGSearchSession.expires_at, SAGSearchSession.session_id)
                        .limit(limit + 1)
                    )
                ).all()
            )
            selected = session_ids[:limit]
            if selected:
                result = await session.execute(
                    delete(SAGSearchSession).where(SAGSearchSession.session_id.in_(selected))
                )
                await session.commit()
                deleted = max(int(result.rowcount or 0), 0)
            else:
                deleted = 0
        return deleted, len(session_ids) > limit

    async def release_stale_operations(self, limit: int) -> tuple[int, bool]:
        """Turn expired RUNNING leases into replayable failures without deleting work."""

        async with self._session_factory() as session:
            now = await database_utcnow(session)
            operation_ids = tuple(
                (
                    await session.scalars(
                        select(SAGOperation.operation_id)
                        .where(
                            SAGOperation.status == "running",
                            SAGOperation.lease_expires_at.is_not(None),
                            SAGOperation.lease_expires_at <= now,
                        )
                        .order_by(SAGOperation.lease_expires_at, SAGOperation.operation_id)
                        .limit(limit + 1)
                    )
                ).all()
            )
            selected = operation_ids[:limit]
            if selected:
                result = await session.execute(
                    update(SAGOperation)
                    .where(
                        SAGOperation.operation_id.in_(selected),
                        SAGOperation.status == "running",
                        SAGOperation.lease_expires_at.is_not(None),
                        SAGOperation.lease_expires_at <= now,
                    )
                    .values(
                        status="failed",
                        error_code="execution_failed",
                        error_message="execution lease expired; exact replay is required",
                        retryable=True,
                        owner_id=None,
                        lease_expires_at=None,
                        updated_time=now,
                    )
                )
                await session.commit()
                released = max(int(result.rowcount or 0), 0)
            else:
                released = 0
        return released, len(operation_ids) > limit

    async def purge_terminal_operations(
        self,
        *,
        retention_days: int,
        limit: int,
    ) -> tuple[int, bool]:
        """Delete only terminal receipts made stale by a newer durable fence.

        The current fence-owned receipt is retained without a time limit.  An
        older deleted receipt cannot execute again because its token is lower
        than the retained fence high-water mark.
        """

        terminal_and_clean = or_(
            SAGOperation.status == "succeeded",
            and_(
                SAGOperation.status == "failed",
                SAGOperation.retryable.is_(False),
                SAGOperation.cleanup_completed_at.is_not(None),
            ),
        )
        not_current_fence = ~exists(
            select(SAGFence.fence_scope).where(SAGFence.operation_id == SAGOperation.operation_id)
        )
        async with self._session_factory() as session:
            cutoff = await database_utcnow(session) - timedelta(days=retention_days)
            operation_ids = tuple(
                (
                    await session.scalars(
                        select(SAGOperation.operation_id)
                        .where(
                            SAGOperation.updated_time <= cutoff,
                            terminal_and_clean,
                            not_current_fence,
                        )
                        .order_by(SAGOperation.updated_time, SAGOperation.operation_id)
                        .limit(limit + 1)
                    )
                ).all()
            )
            selected = operation_ids[:limit]
            if selected:
                result = await session.execute(
                    delete(SAGOperation).where(
                        SAGOperation.operation_id.in_(selected),
                        terminal_and_clean,
                        not_current_fence,
                    )
                )
                await session.commit()
                deleted = max(int(result.rowcount or 0), 0)
            else:
                deleted = 0
        return deleted, len(operation_ids) > limit


__all__ = ["CleanupTarget", "MaintenanceStore"]
