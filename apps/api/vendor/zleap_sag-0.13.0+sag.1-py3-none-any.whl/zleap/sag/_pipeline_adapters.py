"""Built-in adapters connecting public pipeline ports to the existing SAG core.

This module is intentionally outside :mod:`zleap.sag.pipeline`: the public
pipeline package stays free of ORM and provider imports.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import uuid
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import asdict
from datetime import UTC, datetime, timedelta
from typing import Any, Literal, cast
from zoneinfo import ZoneInfo

from sqlalchemy import delete, select, update
from sqlalchemy.orm import selectinload

from zleap.sag._extraction_progress import ChunkCheckpointWriter, ExtractionCheckpointWriteError
from zleap.sag._safe_error import safe_error_summary
from zleap.sag.core.adapters import MissingCapabilityError
from zleap.sag.core.ai.usage import UsageReporter, report_llm_usage
from zleap.sag.core.storage.repositories.compensation import (
    capture_vector_snapshots,
    restore_vector_snapshots,
)
from zleap.sag.db import (
    Article,
    ArticleParseStatus,
    ArticleSection,
    ChatConversation,
    ChatMessage,
    DataSource,
    EventEntity,
    SourceChunk,
    SourceEvent,
)
from zleap.sag.db.clock import database_utcnow
from zleap.sag.exceptions import (
    ConfigError,
    ExtractRollbackError,
    OperationConflictError,
    ResourceBusyError,
    StaleFenceError,
    VectorSyncError,
)
from zleap.sag.pipeline._utils import content_hash
from zleap.sag.pipeline.context import CancellationToken
from zleap.sag.pipeline.contracts import (
    ChunkSet,
    ChunkSetRef,
    EventDetail,
    EventEntityDetail,
    EventSetRef,
    ItemFailure,
    PersistedChunkSelector,
    SearchRequest,
    SearchResult,
    SourceDescriptor,
    SourceType,
    WriteStatus,
)
from zleap.sag.pipeline.errors import (
    ExtractionBatchFailure,
    ExtractionError,
    IndexError,
    StageInputError,
    StalePipelineReferenceError,
    UnsupportedStageOptionError,
)
from zleap.sag.pipeline.options import (
    ExtractionOptions,
    IndexOptions,
    ReplacePolicy,
    VectorPolicy,
)
from zleap.sag.utils import get_logger
from zleap.sag.utils.batch import run_batches, split_batches

logger = get_logger("pipeline.adapters")


def _json_dict(value: dict[str, Any] | None) -> dict[str, Any]:
    """Copy portable metadata and normalize datetime/enum-like extension values."""

    return json.loads(json.dumps(value or {}, default=str, ensure_ascii=False))


def _json_value(value: Any) -> Any:
    if value is None:
        return None
    return json.loads(json.dumps(value, default=str, ensure_ascii=False))


def _image_url(item_type: str | None, metadata: dict[str, Any] | None) -> str | None:
    """仅将图片的规范化引用写入 ArticleSection.image_url。"""
    if (item_type or "").upper() != "IMAGE":
        return None
    value = (metadata or {}).get("image_src")
    return str(value)[:500] if value else None


def _source_type_value(value: SourceType | str) -> str:
    return value.value if isinstance(value, SourceType) else str(value)


def _naive_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is not None:
        value = value.astimezone(UTC).replace(tzinfo=None)
    return value


def _aware_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


def _stored_version(rows: list[Any], key: str) -> str:
    versions = {
        str((row.extra_data or {}).get(key)) for row in rows if (row.extra_data or {}).get(key)
    }
    if len(versions) != 1:
        from zleap.sag.exceptions import StorageSchemaMismatchError

        raise StorageSchemaMismatchError(
            f"持久化 Chunk 缺少唯一 {key}",
            diffs=[f"{key}={sorted(versions)}"],
        )
    return next(iter(versions))


def _physical_source_type(value: SourceType | str) -> str:
    source_type = _source_type_value(value)
    if source_type in {"text", "article"}:
        return "ARTICLE"
    if source_type == "chat":
        return "CHAT"
    if source_type == "recording":
        return "RECORDING"
    raise StageInputError(
        f"不支持的来源类型: {source_type}",
        stage="index",
        code="unsupported_source_type",
    )


class BuiltinIndexAdapter:
    """Current-schema Index implementation with split relational/vector commits."""

    def __init__(
        self,
        *,
        session_factory: Any,
        repositories: Any,
        embedding: Any,
        storage_mode: str = "normal",
        embedding_concurrency: int = 1,
        vector_write_concurrency: int = 1,
    ) -> None:
        if embedding_concurrency < 1 or vector_write_concurrency < 1:
            raise ConfigError("concurrency bounds must be positive")
        self.session_factory = session_factory
        self.repositories = repositories
        self.embedding = embedding
        self.storage_mode = storage_mode
        # Mirrors the Engine governor limits: the batch fan-out below must never
        # admit more callers than the governor, or the surplus queues on the
        # governor semaphore and times out as spurious resource exhaustion.
        self.embedding_concurrency = embedding_concurrency
        self.vector_write_concurrency = vector_write_concurrency

    async def index(
        self,
        chunks: ChunkSet,
        descriptor: SourceDescriptor,
        options: IndexOptions,
    ) -> ChunkSetRef:
        return await self._index(chunks, descriptor, options, generation_id=None)

    async def index_generation(
        self,
        chunks: ChunkSet,
        descriptor: SourceDescriptor,
        options: IndexOptions,
        *,
        generation_id: str,
    ) -> ChunkSetRef:
        """Write one invisible durable generation without replacing the active one."""
        if not generation_id.strip():
            raise StageInputError(
                "generation_id 不能为空",
                stage="index",
                code="generation_id_required",
            )
        return await self._index(
            chunks,
            descriptor,
            options,
            generation_id=generation_id.strip(),
        )

    async def _index(
        self,
        chunks: ChunkSet,
        descriptor: SourceDescriptor,
        options: IndexOptions,
        *,
        generation_id: str | None,
    ) -> ChunkSetRef:
        data_source_id = descriptor.data_source_id
        if not data_source_id:
            raise StageInputError(
                "Index 需要 data_source_id",
                stage="index",
                code="data_source_id_required",
            )
        physical_type = _physical_source_type(descriptor.source_type)
        if options.refresh:
            raise UnsupportedStageOptionError(
                "当前 VectorStore 合同不支持显式 refresh",
                stage="index",
                code="unsupported_index_option",
            )
        source_id = descriptor.source_id or str(uuid.uuid4())
        old_chunk_ids: list[str] = []
        old_event_ids: list[str] = []
        relation_reused = False
        persisted_references: dict[str, list[str]] = {}
        relation_snapshot: dict[str, Any] | None = None

        # The complete relational mutation is committed before any embedding/vector I/O.
        try:
            async with self.session_factory() as session:
                if await session.get(DataSource, data_source_id) is None:
                    raise StageInputError(
                        f"信息源不存在: {data_source_id}",
                        stage="index",
                        code="data_source_not_found",
                    )
                carrier = await self._get_carrier(session, physical_type, source_id)
                if carrier is not None and carrier.data_source_id != data_source_id:
                    raise StageInputError(
                        f"来源 {source_id} 已属于其他信息源",
                        stage="index",
                        code="source_data_source_conflict",
                    )
                existing_rows = await self._load_chunks(
                    session,
                    source_id,
                    physical_type,
                    generation_id=generation_id,
                )
                pipeline_meta = self._pipeline_meta(carrier)
                existing_version = (
                    _stored_version(existing_rows, "chunk_version")
                    if generation_id is not None and existing_rows
                    else pipeline_meta.get("chunk_version")
                )

                exists_for_policy = (
                    bool(existing_rows) if generation_id is not None else carrier is not None
                )
                if exists_for_policy and options.replace_policy == ReplacePolicy.CREATE_ONLY:
                    raise IndexError(
                        f"来源已存在: {source_id}",
                        stage="index",
                        code="source_already_exists",
                    )
                if exists_for_policy and options.replace_policy == ReplacePolicy.REUSE_IF_SAME:
                    if existing_version != chunks.chunk_version:
                        raise StalePipelineReferenceError(
                            "来源已存在且 chunk_version 不同；需要显式 REPLACE_CURRENT",
                            stage="index",
                            code="chunk_version_conflict",
                        )
                    mapping = {
                        str((row.extra_data or {}).get("client_key", f"chunk-{row.rank}")): row.id
                        for row in existing_rows
                    }
                    persisted_references = {
                        str((row.extra_data or {}).get("client_key", f"chunk-{row.rank}")): list(
                            row.references or []
                        )
                        for row in existing_rows
                    }
                    if len(mapping) != len(chunks.chunks):
                        raise StalePipelineReferenceError(
                            "已有关系记录与 ChunkSet 数量不一致",
                            stage="index",
                            code="incomplete_idempotent_state",
                        )
                    relation_reused = True
                    chunk_ids = [mapping[item.client_key] for item in chunks.chunks]
                else:
                    if generation_id is not None:
                        relation_snapshot = {
                            "managed_generation": generation_id,
                            "source_id": source_id,
                            "physical_type": physical_type,
                            "carrier": (
                                self._row_snapshot(carrier) if carrier is not None else None
                            ),
                        }
                        old_chunk_ids = [str(row.id) for row in existing_rows]
                        old_event_ids = await self._delete_generation_relations(
                            session,
                            source_id=source_id,
                            physical_type=physical_type,
                            generation_id=generation_id,
                        )
                    elif carrier is not None:
                        relation_snapshot = await self._capture_relation_snapshot(
                            session,
                            carrier=carrier,
                            source_id=source_id,
                            physical_type=physical_type,
                        )
                        old_rows = await self._load_chunks(session, source_id, physical_type)
                        old_chunk_ids = [row.id for row in old_rows]
                        old_event_ids = await self._delete_current_relations(
                            session, source_id=source_id, physical_type=physical_type
                        )
                    carrier = await self._upsert_carrier(
                        session,
                        carrier=carrier,
                        source_id=source_id,
                        data_source_id=data_source_id,
                        physical_type=physical_type,
                        descriptor=descriptor,
                        chunks=chunks,
                        generation_id=generation_id,
                    )
                    mapping, chunk_ids, persisted_references = await self._insert_chunks(
                        session,
                        source_id=source_id,
                        data_source_id=data_source_id,
                        physical_type=physical_type,
                        chunks=chunks,
                        generation_id=generation_id,
                    )
                    await session.commit()
        except (IndexError, StageInputError, StalePipelineReferenceError):
            raise
        except Exception as exc:
            raise IndexError(
                safe_error_summary(exc, label="关系索引失败"),
                stage="index",
                code="relation_write_failed",
                cause_summary=type(exc).__name__,
            ) from exc

        if relation_reused:
            # No relation mutation was made, but vector upsert still runs so a retry can
            # repair a previous partial vector write without duplicating relation rows.
            chunk_ids = [mapping[item.client_key] for item in chunks.chunks]

        failures: list[ItemFailure] = []
        old_vector_groups = (
            (
                self.repositories.source_chunks,
                old_chunk_ids,
                "old_chunk_vector_delete_failed",
                "删除旧 Chunk 向量失败",
            ),
            (
                self.repositories.events,
                old_event_ids,
                "old_event_vector_delete_failed",
                "删除旧 Event 向量失败",
            ),
        )
        rollback_vector_groups = (
            (
                self.repositories.source_chunks,
                list(dict.fromkeys([*old_chunk_ids, *chunk_ids])),
            ),
            (self.repositories.events, old_event_ids),
        )
        try:
            vector_snapshots = await capture_vector_snapshots(rollback_vector_groups)
        except Exception as exc:
            relation_errors = await self._restore_relation_snapshot(relation_snapshot)
            if relation_errors:
                raise IndexError(
                    "Index 向量快照失败，且关系补偿回滚失败: " + "; ".join(relation_errors),
                    stage="index",
                    code="index_rollback_failed",
                ) from exc
            raise IndexError(
                safe_error_summary(exc, label="Index 向量快照失败，关系变更已回滚"),
                stage="index",
                code="index_rolled_back",
                retryable=True,
            ) from exc
        delete_results = await asyncio.gather(
            *(
                repository.vector_store.delete(repository.INDEX_NAME, old_ids)
                for repository, old_ids, _, _ in old_vector_groups
                if old_ids
            ),
            return_exceptions=True,
        )
        delete_groups = [
            (repository, old_ids, failure_code, failure_message)
            for repository, old_ids, failure_code, failure_message in old_vector_groups
            if old_ids
        ]
        for (_repository, old_ids, failure_code, failure_message), deleted in zip(
            delete_groups, delete_results, strict=True
        ):
            if isinstance(deleted, Exception):
                failures.extend(
                    ItemFailure(
                        item_id=item_id,
                        code=failure_code,
                        message=safe_error_summary(deleted),
                        retryable=True,
                    )
                    for item_id in old_ids
                )
            elif not isinstance(deleted, BaseException):
                failures.extend(
                    ItemFailure(
                        item_id=item.id,
                        code=failure_code,
                        message=failure_message,
                        retryable=True,
                    )
                    for item in deleted.failed_items
                )

        # Disabling new vector writes must not preserve stale vectors from the
        # source version that was just replaced.
        if options.vector_policy == VectorPolicy.DISABLED:
            if failures:
                await self._raise_after_compensation(
                    failures=failures,
                    relation_snapshot=relation_snapshot,
                    vector_groups=rollback_vector_groups,
                    vector_snapshots=vector_snapshots,
                )
            return self._ref(
                chunks,
                descriptor,
                source_id,
                chunk_ids,
                mapping,
                vector_status=WriteStatus.SKIPPED_BY_POLICY,
                relation_reused=relation_reused,
                generation_id=generation_id,
            )

        batch_size = options.embedding_batch_size
        generate_vectors = self.storage_mode == "normal"
        content_vectors: dict[int, list[float] | None] = {}
        heading_vectors: dict[int, list[float]] = {}

        async def _embed_batch(batch_index: int, chunk_batch: Sequence[Any]) -> list[ItemFailure]:
            """Embed one chunk batch; heading vectors stay best-effort."""
            start = batch_index * batch_size
            if not generate_vectors:
                content_vectors.update(
                    {start + offset: None for offset, _item in enumerate(chunk_batch)}
                )
                return []
            heading_positions = [
                start + offset for offset, item in enumerate(chunk_batch) if item.heading
            ]
            if heading_positions:
                try:
                    result = await self.embedding.batch_generate(
                        [chunks.chunks[index].heading for index in heading_positions]
                    )
                    if len(result) == len(heading_positions):
                        heading_vectors.update(dict(zip(heading_positions, result, strict=True)))
                except Exception:
                    # Heading vectors are optional; content vectors remain authoritative.
                    pass

            try:
                result = await self.embedding.batch_generate([item.content for item in chunk_batch])
            except Exception as exc:
                return [
                    ItemFailure(
                        item_id=mapping[item.client_key],
                        code="embedding_failed",
                        message=safe_error_summary(exc),
                        retryable=True,
                    )
                    for item in chunk_batch
                ]
            if len(result) != len(chunk_batch):
                return [
                    ItemFailure(
                        item_id=mapping[item.client_key],
                        code="embedding_failed",
                        message=(
                            f"embedding 数量不匹配: expected={len(chunk_batch)} actual={len(result)}"
                        ),
                        retryable=True,
                    )
                    for item in chunk_batch
                ]
            content_vectors.update({start + offset: vector for offset, vector in enumerate(result)})
            return []

        # Batches embed concurrently within the governor's embedding limit; the
        # result dicts are keyed by absolute chunk index, so completion order
        # cannot change the produced documents.
        for batch_failures in await run_batches(
            split_batches(chunks.chunks, batch_size),
            _embed_batch,
            concurrency=self.embedding_concurrency,
        ):
            failures.extend(batch_failures)

        documents = []
        for index, item in enumerate(chunks.chunks):
            if index not in content_vectors:
                continue
            chunk_id = mapping[item.client_key]
            documents.append(
                {
                    "id": chunk_id,
                    "chunk_id": chunk_id,
                    "source_id": source_id,
                    "data_source_id": data_source_id,
                    "generation_id": generation_id,
                    "rank": item.rank,
                    "heading": item.heading,
                    "content": item.content,
                    "heading_vector": heading_vectors.get(index),
                    "content_vector": content_vectors[index],
                    "references": persisted_references.get(
                        item.client_key, [ref.key for ref in item.references]
                    ),
                    "chunk_type": item.chunk_type,
                    "content_length": len(item.content),
                }
            )

        async def _upsert_batch(
            _batch_index: int, document_batch: Sequence[dict[str, Any]]
        ) -> list[ItemFailure]:
            try:
                result = await self.repositories.source_chunks.upsert_documents(
                    self.repositories.source_chunks.INDEX_NAME, list(document_batch)
                )
                return [
                    ItemFailure(
                        item_id=item.id,
                        code="vector_upsert_failed",
                        message="向量写入失败",
                        retryable=True,
                    )
                    for item in result.failed_items
                ]
            except Exception as exc:
                return [
                    ItemFailure(
                        item_id=str(document["id"]),
                        code="vector_upsert_failed",
                        message=safe_error_summary(exc),
                        retryable=True,
                    )
                    for document in document_batch
                ]

        # Upserts are keyed by chunk id, so concurrent batches cannot interleave
        # into wrong documents; the vector-write governor bounds provider load.
        for batch_failures in await run_batches(
            split_batches(documents, options.vector_batch_size),
            _upsert_batch,
            concurrency=self.vector_write_concurrency,
        ):
            failures.extend(batch_failures)

        if failures:
            await self._raise_after_compensation(
                failures=failures,
                relation_snapshot=relation_snapshot,
                vector_groups=rollback_vector_groups,
                vector_snapshots=vector_snapshots,
            )
        return self._ref(
            chunks,
            descriptor,
            source_id,
            chunk_ids,
            mapping,
            vector_status=WriteStatus.SUCCEEDED,
            relation_reused=relation_reused,
            generation_id=generation_id,
        )

    @staticmethod
    def _row_snapshot(row: Any) -> dict[str, Any]:
        return {column.key: getattr(row, column.key) for column in row.__table__.columns}

    @classmethod
    async def _capture_relation_snapshot(
        cls,
        session: Any,
        *,
        carrier: Any,
        source_id: str,
        physical_type: str,
    ) -> dict[str, Any]:
        chunks = await cls._load_chunks(session, source_id, physical_type)
        if physical_type == "ARTICLE":
            detail_rows = list(
                (
                    await session.execute(
                        select(ArticleSection).where(ArticleSection.article_id == source_id)
                    )
                )
                .scalars()
                .all()
            )
        else:
            detail_rows = list(
                (
                    await session.execute(
                        select(ChatMessage).where(ChatMessage.conversation_id == source_id)
                    )
                )
                .scalars()
                .all()
            )
        event_rows = list(
            (
                await session.execute(
                    select(SourceEvent.id, SourceEvent.status).where(
                        SourceEvent.source_id == source_id,
                        SourceEvent.source_type == physical_type,
                        SourceEvent.not_deleted(),
                    )
                )
            ).all()
        )
        return {
            "source_id": source_id,
            "physical_type": physical_type,
            "carrier": cls._row_snapshot(carrier) if carrier is not None else None,
            "chunks": [cls._row_snapshot(row) for row in chunks],
            "details": [cls._row_snapshot(row) for row in detail_rows],
            "event_statuses": [(str(row.id), row.status) for row in event_rows],
        }

    async def _restore_relation_snapshot(self, snapshot: dict[str, Any] | None) -> list[str]:
        if snapshot is None:
            return []
        source_id = str(snapshot["source_id"])
        physical_type = str(snapshot["physical_type"])
        carrier_model = Article if physical_type == "ARTICLE" else ChatConversation
        detail_model = ArticleSection if physical_type == "ARTICLE" else ChatMessage
        errors: list[str] = []
        try:
            async with self.session_factory() as session:
                managed_generation = snapshot.get("managed_generation")
                if managed_generation is not None:
                    await self._delete_generation_relations(
                        session,
                        source_id=source_id,
                        physical_type=physical_type,
                        generation_id=str(managed_generation),
                    )
                    carrier_values = snapshot.get("carrier")
                    current = await session.get(carrier_model, source_id)
                    if carrier_values is None:
                        if current is not None:
                            await session.delete(current)
                    elif current is None:
                        session.add(carrier_model(**carrier_values))
                    else:
                        for key, value in carrier_values.items():
                            setattr(current, key, value)
                    await session.commit()
                    return []
                await session.execute(
                    delete(SourceChunk).where(
                        SourceChunk.source_id == source_id,
                        SourceChunk.source_type == physical_type,
                    )
                )
                detail_column = (
                    ArticleSection.article_id
                    if physical_type == "ARTICLE"
                    else ChatMessage.conversation_id
                )
                await session.execute(delete(detail_model).where(detail_column == source_id))

                carrier_values = snapshot["carrier"]
                current = await session.get(carrier_model, source_id)
                if carrier_values is None:
                    if current is not None:
                        await session.delete(current)
                elif current is None:
                    session.add(carrier_model(**carrier_values))
                else:
                    for key, value in carrier_values.items():
                        setattr(current, key, value)

                for values in snapshot["details"]:
                    session.add(detail_model(**values))
                for values in snapshot["chunks"]:
                    session.add(SourceChunk(**values))
                for event_id, status in snapshot["event_statuses"]:
                    await session.execute(
                        update(SourceEvent).where(SourceEvent.id == event_id).values(status=status)
                    )
                await session.commit()
        except Exception as exc:
            errors.append(f"relation_restore_exception({type(exc).__name__})")
        return errors

    async def _raise_after_compensation(
        self,
        *,
        failures: list[ItemFailure],
        relation_snapshot: dict[str, Any] | None,
        vector_groups: tuple[tuple[Any, list[str]], ...],
        vector_snapshots: list[list[Any]],
    ) -> None:
        vector_errors = await restore_vector_snapshots(vector_groups, vector_snapshots)
        relation_errors = await self._restore_relation_snapshot(relation_snapshot)
        rollback_errors = [*vector_errors, *relation_errors]
        failed_ids = ", ".join(sorted({failure.item_id for failure in failures}))
        if rollback_errors:
            raise IndexError(
                "Index 失败且补偿回滚不完整: " + "; ".join(rollback_errors),
                stage="index",
                code="index_rollback_failed",
                retryable=False,
            )
        raise IndexError(
            f"Index 向量操作失败，关系与向量变更已全部回滚: {failed_ids}",
            stage="index",
            code="index_rolled_back",
            retryable=True,
        )

    @staticmethod
    async def _get_carrier(session: Any, physical_type: str, source_id: str) -> Any:
        model = Article if physical_type == "ARTICLE" else ChatConversation
        return await session.get(model, source_id)

    @staticmethod
    def _pipeline_meta(carrier: Any) -> dict[str, Any]:
        if carrier is None:
            return {}
        return (carrier.extra_data or {}).get("sag_pipeline") or {}

    @staticmethod
    async def _load_chunks(
        session: Any,
        source_id: str,
        physical_type: str,
        *,
        generation_id: str | None = None,
    ) -> list[Any]:
        statement = select(SourceChunk).where(
            SourceChunk.source_id == source_id,
            SourceChunk.source_type == physical_type,
        )
        if generation_id is not None:
            statement = statement.where(SourceChunk.generation_id == generation_id)
        result = await session.execute(statement.order_by(SourceChunk.rank))
        return list(result.scalars().all())

    @staticmethod
    async def _delete_generation_relations(
        session: Any,
        *,
        source_id: str,
        physical_type: str,
        generation_id: str,
    ) -> list[str]:
        event_filter = (
            SourceEvent.source_id == source_id,
            SourceEvent.source_type == physical_type,
            SourceEvent.generation_id == generation_id,
        )
        event_ids = list(
            (await session.execute(select(SourceEvent.id).where(*event_filter))).scalars().all()
        )
        await session.execute(delete(SourceEvent).where(*event_filter))
        await session.execute(
            delete(SourceChunk).where(
                SourceChunk.source_id == source_id,
                SourceChunk.source_type == physical_type,
                SourceChunk.generation_id == generation_id,
            )
        )
        if physical_type == "ARTICLE":
            await session.execute(
                delete(ArticleSection).where(
                    ArticleSection.article_id == source_id,
                    ArticleSection.generation_id == generation_id,
                )
            )
        else:
            await session.execute(
                delete(ChatMessage).where(
                    ChatMessage.conversation_id == source_id,
                    ChatMessage.generation_id == generation_id,
                )
            )
        return [str(event_id) for event_id in event_ids]

    @staticmethod
    async def _delete_current_relations(
        session: Any, *, source_id: str, physical_type: str
    ) -> list[str]:
        event_filter = (
            SourceEvent.source_id == source_id,
            SourceEvent.source_type == physical_type,
            SourceEvent.not_deleted(),
        )
        old_event_ids = list(
            (await session.execute(select(SourceEvent.id).where(*event_filter))).scalars().all()
        )
        await session.execute(update(SourceEvent).where(*event_filter).values(status="DELETED"))
        await session.execute(
            delete(SourceChunk).where(
                SourceChunk.source_id == source_id,
                SourceChunk.source_type == physical_type,
            )
        )
        if physical_type == "ARTICLE":
            await session.execute(
                delete(ArticleSection).where(ArticleSection.article_id == source_id)
            )
        else:
            await session.execute(
                delete(ChatMessage).where(ChatMessage.conversation_id == source_id)
            )
        return old_event_ids

    @staticmethod
    async def _upsert_carrier(
        session: Any,
        *,
        carrier: Any,
        source_id: str,
        data_source_id: str,
        physical_type: str,
        descriptor: SourceDescriptor,
        chunks: ChunkSet,
        generation_id: str | None,
    ) -> Any:
        previous_extra = _json_dict(carrier.extra_data) if carrier is not None else {}
        previous_source_version = (previous_extra.get("sag_pipeline") or {}).get("source_version")
        pipeline = {
            "source_version": chunks.source_version,
            "chunk_version": chunks.chunk_version,
            "contract_version": chunks.contract_version,
            "source_type": _source_type_value(descriptor.source_type),
            "generation_id": generation_id,
        }
        extra = _json_dict(descriptor.metadata)
        if previous_source_version == chunks.source_version and previous_extra.get("sag_summary"):
            extra["sag_summary"] = previous_extra["sag_summary"]
        else:
            extra.pop("sag_summary", None)
        extra["sag_pipeline"] = pipeline
        if physical_type == "ARTICLE":
            if carrier is None:
                carrier = Article(id=source_id, data_source_id=data_source_id, title="Untitled")
                session.add(carrier)
            carrier.title = descriptor.title or "Untitled"
            carrier.document_id = descriptor.external_id
            carrier.content = "\n\n".join(item.content for item in chunks.chunks)
            if previous_source_version != chunks.source_version:
                carrier.summary = None
            carrier.status = "PENDING"
            carrier.parse_status = ArticleParseStatus.PARSED.value
            carrier.error = None
            carrier.extra_data = extra
        else:
            if carrier is None:
                carrier = ChatConversation(id=source_id, data_source_id=data_source_id)
                session.add(carrier)
            carrier.title = descriptor.title
            carrier.creator_id = descriptor.creator_id
            carrier.source_id = descriptor.external_id
            carrier.messages_count = len(chunks.units)
            carrier.last_message_time = _naive_utc(
                next((unit.timestamp for unit in reversed(chunks.units) if unit.timestamp), None)
            )
            carrier.parse_status = "PARSED"
            carrier.extra_data = extra
        await session.flush()
        return carrier

    @staticmethod
    async def _insert_chunks(
        session: Any,
        *,
        source_id: str,
        data_source_id: str,
        physical_type: str,
        chunks: ChunkSet,
        generation_id: str | None = None,
    ) -> tuple[dict[str, str], list[str], dict[str, list[str]]]:
        unit_to_id: dict[str, str] = {}
        section_ids_by_chunk: dict[str, list[str]] = {}
        # order_index -> {signature: section_id}. A repeated table header (identical
        # content) keeps one global ArticleSection shared by every table chunk that
        # renders it; a large section split into parts keeps the same order_index but
        # different content, so each distinct variant gets its own ArticleSection row.
        section_ids_by_signature: dict[int, dict[str, str]] = {}
        if physical_type == "ARTICLE":
            for item in chunks.chunks:
                section_ids: list[str] = []
                if item.sections:
                    for sec in item.sections:
                        signature = json.dumps(
                            {
                                "render_group_index": sec.render_group_index,
                                "heading": sec.heading,
                                "content": sec.content,
                                "raw_content": sec.raw_content,
                                "section_type": sec.section_type,
                                "metadata": _json_dict(dict(sec.metadata)),
                            },
                            sort_keys=True,
                            ensure_ascii=False,
                        )
                        variants = section_ids_by_signature.setdefault(sec.order_index, {})
                        section_id = variants.get(signature)
                        if section_id is not None:
                            section_ids.append(section_id)
                            continue

                        section_key = f"{source_id}:{sec.order_index}"
                        if variants:
                            section_key = f"{section_key}:{len(variants)}"
                        section_id = BuiltinIndexAdapter._record_id(
                            generation_id,
                            "section",
                            section_key,
                        )
                        variants[signature] = section_id
                        section_ids.append(section_id)
                        session.add(
                            ArticleSection(
                                id=section_id,
                                article_id=source_id,
                                order_index=sec.order_index,
                                render_group_index=sec.render_group_index,
                                type=sec.section_type,
                                rank=sec.order_index,
                                heading=sec.heading,
                                content=sec.content,
                                raw_content=sec.raw_content,
                                image_url=_image_url(sec.section_type, dict(sec.metadata)),
                                length=len(sec.content),
                                generation_id=generation_id,
                                extra_data={
                                    "client_key": item.client_key,
                                    "section_metadata": dict(sec.metadata),
                                },
                            )
                        )
                else:
                    # 回退：1 Chunk = 1 ArticleSection（heading_strict / 旧数据兼容）
                    section_id = BuiltinIndexAdapter._record_id(
                        generation_id,
                        "section",
                        item.client_key,
                    )
                    section_ids.append(section_id)
                    session.add(
                        ArticleSection(
                            id=section_id,
                            article_id=source_id,
                            order_index=item.rank,
                            render_group_index=item.rank,
                            type=item.chunk_type,
                            rank=item.rank,
                            heading=item.heading,
                            content=item.content,
                            raw_content=item.raw_content,
                            image_url=_image_url(item.chunk_type, dict(item.metadata)),
                            length=len(item.content),
                            generation_id=generation_id,
                            extra_data={
                                "client_key": item.client_key,
                                "source_references": [
                                    ref.model_dump(mode="json") for ref in item.references
                                ],
                            },
                        )
                    )
                section_ids_by_chunk[item.client_key] = section_ids
        else:
            epoch = datetime(1970, 1, 1)
            for order, unit in enumerate(chunks.units):
                message_id = (
                    BuiltinIndexAdapter._record_id(generation_id, "message", unit.unit_key)
                    if generation_id is not None
                    else unit.external_id or str(uuid.uuid4())
                )
                # Host IDs may not fit the built-in CHAR(36) schema; preserve them in
                # extra_data while using a SAG identity for the relation key.
                if len(message_id) > 36:
                    message_id = str(uuid.uuid4())
                unit_to_id[unit.unit_key] = message_id
                session.add(
                    ChatMessage(
                        id=message_id,
                        conversation_id=source_id,
                        timestamp=_naive_utc(unit.timestamp)
                        or epoch + timedelta(microseconds=order),
                        content=unit.content,
                        raw_content=unit.raw_content,
                        sender_id=unit.speaker,
                        sender_name=unit.speaker,
                        sender_role=(unit.role or "USER").upper(),
                        type="TEXT",
                        start_time=unit.start_ms,
                        end_time=unit.end_ms,
                        generation_id=generation_id,
                        extra_data={
                            **_json_dict(unit.metadata),
                            "unit_key": unit.unit_key,
                            "external_id": unit.external_id,
                            "timestamp_missing": unit.timestamp is None,
                        },
                    )
                )

        mapping: dict[str, str] = {}
        ids: list[str] = []
        persisted_references: dict[str, list[str]] = {}
        for item in chunks.chunks:
            chunk_id = BuiltinIndexAdapter._record_id(
                generation_id,
                "chunk",
                item.client_key,
            )
            mapping[item.client_key] = chunk_id
            ids.append(chunk_id)
            if physical_type == "ARTICLE":
                references = section_ids_by_chunk[item.client_key]
            else:
                references = [
                    unit_to_id[ref.key] for ref in item.references if ref.key in unit_to_id
                ]
            persisted_references[item.client_key] = list(references)
            session.add(
                SourceChunk(
                    id=chunk_id,
                    data_source_id=data_source_id,
                    source_type=physical_type,
                    source_id=source_id,
                    generation_id=generation_id,
                    article_id=source_id if physical_type == "ARTICLE" else None,
                    conversation_id=source_id if physical_type != "ARTICLE" else None,
                    content=item.content,
                    raw_content=item.raw_content,
                    heading=item.heading,
                    rank=item.rank,
                    chunk_length=len(item.content),
                    references=references,
                    extra_data={
                        **_json_dict(item.metadata),
                        "chunk_type": item.chunk_type,
                        "client_key": item.client_key,
                        "source_version": chunks.source_version,
                        "chunk_version": chunks.chunk_version,
                    },
                )
            )
        await session.flush()
        return mapping, ids, persisted_references

    @staticmethod
    def _record_id(generation_id: str | None, record_type: str, key: str) -> str:
        if generation_id is None:
            return str(uuid.uuid4())
        return str(
            uuid.uuid5(
                uuid.NAMESPACE_URL,
                f"zleap-sag:{generation_id}:{record_type}:{key}",
            )
        )

    @staticmethod
    def _ref(
        chunks: ChunkSet,
        descriptor: SourceDescriptor,
        source_id: str,
        chunk_ids: list[str],
        mapping: dict[str, str],
        *,
        vector_status: WriteStatus,
        failures: tuple[ItemFailure, ...] = (),
        relation_reused: bool,
        generation_id: str | None,
    ) -> ChunkSetRef:
        assert descriptor.data_source_id is not None
        return ChunkSetRef(
            data_source_id=descriptor.data_source_id,
            source_type=descriptor.source_type,
            source_id=source_id,
            source_version=chunks.source_version,
            chunk_version=chunks.chunk_version,
            generation_id=generation_id,
            chunk_ids=tuple(chunk_ids),
            client_key_to_chunk_id=mapping,
            relation_status=WriteStatus.SUCCEEDED,
            vector_status=vector_status,
            failed_items=failures,
            stats={"relation_reused": relation_reused, "chunk_count": len(chunk_ids)},
        )


class BuiltinExtractAdapter:
    def __init__(
        self,
        *,
        session_factory: Any,
        extractor: Any,
        storage_mode: Literal["normal", "lite"],
        embedding_dimensions: int | None = None,
        llm_concurrency: int | None = None,
        embedding_concurrency: int | None = None,
        vector_write_concurrency: int | None = None,
    ) -> None:
        if llm_concurrency is not None and llm_concurrency < 1:
            raise ConfigError("llm_concurrency must be positive")
        if embedding_concurrency is not None and embedding_concurrency < 1:
            raise ConfigError("embedding_concurrency must be positive")
        if vector_write_concurrency is not None and vector_write_concurrency < 1:
            raise ConfigError("vector_write_concurrency must be positive")
        self.session_factory = session_factory
        self.extractor = extractor
        self.storage_mode = storage_mode
        self.embedding_dimensions = embedding_dimensions
        self.llm_concurrency = llm_concurrency
        self.embedding_concurrency = embedding_concurrency
        self.vector_write_concurrency = vector_write_concurrency

    def _build_config(
        self,
        resolved: dict[str, Any],
        options: ExtractionOptions,
    ) -> Any:
        from zleap.sag.modules.extract.config import ExtractConfig, ExtractionWritePlan

        storage_mode = self.storage_mode
        if (
            storage_mode == "lite"
            and self.embedding_dimensions is not None
            and self.embedding_dimensions < 128
        ):
            raise UnsupportedStageOptionError(
                "lite 模式要求 embedding dimensions 至少为 128",
                stage="extract",
                code="embedding_dimensions_too_small",
            )
        requested_concurrency = options.execution.max_concurrency
        effective_concurrency = (
            requested_concurrency
            if self.llm_concurrency is None
            else min(requested_concurrency, self.llm_concurrency)
        )
        return ExtractConfig(
            storage_mode=storage_mode,
            write_plan=ExtractionWritePlan.from_storage_mode(
                storage_mode,
                write_entity_vectors=options.execution.write_entity_vectors,
                write_event_entity_vectors=options.execution.write_event_entity_vectors,
            ),
            data_source_id=resolved["data_source_id"],
            source_type=resolved["physical_type"],
            source_id=resolved["source_id"],
            source_version=resolved["source_version"],
            chunk_ids=tuple(resolved["chunk_ids"]),
            generation_id=resolved["generation_id"],
            # The batch semaphore must never admit more callers than the Engine's
            # LLM limiter. Otherwise valid in-batch work waits behind its siblings
            # and is misclassified as resource exhaustion after the acquire timeout.
            max_concurrency=effective_concurrency,
            request_rejection_retries=options.execution.request_rejection_retries,
            request_recovery_min_chars=options.execution.request_recovery_min_chars,
            embedding_batch_size=options.execution.embedding_batch_size,
            vector_batch_size=options.execution.vector_batch_size,
            # Same rule for the saver's embedding/vector fan-out: mirror the
            # governor limits so concurrent batches never overrun the semaphore.
            embedding_concurrency=self.embedding_concurrency or 1,
            vector_write_concurrency=self.vector_write_concurrency or 1,
            related_events=options.related_events,
            timezone=options.timezone,
            custom_prompt=options.custom_prompt,
            background=options.background,
            guidance_rules=options.guidance_rules,
            verbatim_prompt=options.verbatim_prompt,
            contract=options.contract,
            on_contract_violation=options.on_contract_violation,
            custom_examples=options.custom_examples,
            limits=options.limits,
            max_retries=options.max_retries,
            enable_article_summary=options.enable_article_summary,
            enable_parent_summary=options.enable_parent_summary,
            parent_summary_token_budget=options.parent_summary_token_budget,
        )

    async def prepare_generation(
        self,
        target: ChunkSetRef,
        options: ExtractionOptions,
        *,
        on_progress: Callable[[int, int], Awaitable[None] | None] | None = None,
        checkpoint: ChunkCheckpointWriter | None = None,
        runtime_fingerprint: str = "",
    ) -> dict[str, Any]:
        """Persistable boundary after LLM generation and before derived writes."""
        if target.generation_id is None:
            raise StageInputError(
                "durable extraction requires generation_id",
                stage="extract",
                code="generation_id_required",
            )
        resolved = await self._resolve(target)
        config = self._build_config(resolved, options)
        checkpoint_kwargs: dict[str, Any] = {}
        usage_reporter: UsageReporter | None = None
        usage_calls = 0
        reused_attempts = 0
        if checkpoint is not None:
            from zleap.sag.modules.extract.extractor import ChunkExtractionSuccess
            from zleap.sag.modules.extract.processor import (
                ExtractionGenerationStats,
                entity_type_contract_fingerprint,
            )
            from zleap.sag.modules.extract.prompts import (
                ExtractionPromptRegistry,
                ExtractionPromptRole,
                prompt_role_for_source_type,
            )

            registry = ExtractionPromptRegistry.from_prompt_manager(self.extractor.prompt_manager)
            roles = [prompt_role_for_source_type(config.source_type)]
            if config.enable_parent_summary:
                roles.append(ExtractionPromptRole.PARENT)
            chunks = await self.extractor._load_chunks(config.chunk_ids)
            if {str(chunk.id) for chunk in chunks} != set(config.chunk_ids):
                raise StalePipelineReferenceError(
                    "checkpoint input chunks are missing", stage="extract"
                )
            fingerprint = hashlib.sha256(
                json.dumps(
                    {
                        "version": 1,
                        "runtime": runtime_fingerprint,
                        "config": config.model_dump(mode="json"),
                        "target": target.model_dump(mode="json"),
                        "prompts": [asdict(registry.load(role)) for role in roles],
                        "entities": entity_type_contract_fingerprint(
                            await self.extractor._load_entity_types_for_chunk(config)
                        ),
                        "chunks": [
                            {
                                key: getattr(chunk, key)
                                for key in (
                                    "id",
                                    "content",
                                    "raw_content",
                                    "heading",
                                    "rank",
                                    "references",
                                    "extra_data",
                                )
                            }
                            for chunk in sorted(chunks, key=lambda chunk: str(chunk.id))
                        ],
                    },
                    sort_keys=True,
                    default=str,
                    ensure_ascii=False,
                ).encode()
            ).hexdigest()
            progress = await checkpoint(fingerprint, config.chunk_ids, None, None)
            config = config.model_copy(
                update={
                    "reference_time": datetime.fromisoformat(progress["created_at"])
                    .astimezone(ZoneInfo(config.timezone))
                    .strftime("%Y-%m-%d %H:%M")
                }
            )
            records = progress["chunks"]
            cached = {
                chunk_id: ChunkExtractionSuccess(
                    events=tuple(
                        self._deserialize_prepared_event(event) for event in record["events"]
                    ),
                    stats=ExtractionGenerationStats(**record["stats"]),
                )
                for chunk_id, record in records.items()
                if record["status"] == "succeeded"
            }
            reused_attempts = sum(item.stats.generation_attempts for item in cached.values())

            async def save_usage(usage):
                nonlocal usage_calls
                usage_calls += 1
                await checkpoint(fingerprint, config.chunk_ids, None, {"usage": usage})

            usage_reporter = save_usage

            async def save_chunk(chunk_id, result, failure):
                previous_attempts = int(records.get(chunk_id, {}).get("attempts", 0))
                record: dict[str, Any]
                if result is not None:
                    record = {
                        "status": "succeeded",
                        "events": [
                            self._serialize_prepared_event(event) for event in result.events
                        ],
                        "stats": asdict(result.stats),
                        "attempts": previous_attempts + result.stats.generation_attempts,
                    }
                else:
                    assert failure is not None
                    record = {
                        "status": "failed",
                        "failure": failure,
                        "attempts": previous_attempts + int(failure["attempts"]),
                    }
                await checkpoint(fingerprint, config.chunk_ids, chunk_id, record)

            checkpoint_kwargs = {"cached_chunks": cached, "on_chunk_result": save_chunk}
        try:
            async with report_llm_usage(usage_reporter):
                result = await self.extractor.prepare_batch(
                    config,
                    on_progress=on_progress,
                    **checkpoint_kwargs,
                )
            if (
                checkpoint is not None
                and result.stats.get("generation_attempts", 0) - reused_attempts > usage_calls
            ):
                # Custom adapters may bypass the built-in usage reporter.
                await checkpoint(fingerprint, config.chunk_ids, None, {"usage_incomplete": True})
        except (
            ExtractionCheckpointWriteError,
            OperationConflictError,
            ResourceBusyError,
            StaleFenceError,
        ):
            raise
        except Exception as exc:
            if checkpoint is not None:
                await checkpoint(fingerprint, config.chunk_ids, None, {"usage_incomplete": True})
            core_failures = getattr(exc, "failures", None)
            if core_failures:
                failures = self._item_failures(list(core_failures))
                raise ExtractionBatchFailure(
                    safe_error_summary(exc, label="Chunk 提取失败"),
                    stage="extract",
                    code=str(getattr(exc, "code", "chunk_retry_exhausted")),
                    retryable=all(item.retryable for item in failures),
                    failures=failures,
                    stats=dict(getattr(exc, "stats", {})),
                    cause_summary=type(exc).__name__,
                ) from exc
            raise ExtractionError(
                safe_error_summary(exc, label="提取准备失败"),
                stage="extract",
                code=str(getattr(exc, "code", "extraction_prepare_failed")),
                retryable=bool(getattr(exc, "retryable", True)),
                cause_summary=type(exc).__name__,
            ) from exc
        if result.failures:
            failures = self._item_failures(list(result.failures))
            raise ExtractionBatchFailure(
                f"{len(failures)} 个 Chunk 重试耗尽，批次未提交",
                stage="extract",
                code="chunk_retry_exhausted",
                retryable=True,
                failures=failures,
                stats=dict(result.stats),
            )
        config_payload = config.model_dump(mode="json")
        # ExtractConfig.storage_mode is excluded from normal serialization because
        # it is a runtime routing field.  The durable hand-off must retain it so
        # commit retries can rebuild exactly the same write plan without invoking
        # the LLM again.
        config_payload["storage_mode"] = self.storage_mode
        return {
            "resolved": _json_value(resolved),
            "options": options.model_dump(mode="json"),
            "config": config_payload,
            "events": [self._serialize_prepared_event(event) for event in result.events],
            "stats": _json_value(dict(result.stats)),
        }

    async def commit_prepared_generation(self, prepared: dict[str, Any]) -> EventSetRef:
        """Commit a durable prepared batch; retries never invoke the LLM again."""
        from zleap.sag.modules.extract.config import ExtractConfig

        resolved = dict(prepared["resolved"])
        options = ExtractionOptions.model_validate(prepared["options"])
        config = ExtractConfig.model_validate(prepared["config"])
        events = [self._deserialize_prepared_event(item) for item in prepared.get("events", [])]
        try:
            result = await self.extractor.commit_prepared(
                events,
                config,
                stats=dict(prepared.get("stats") or {}),
            )
        except Exception as exc:
            raise ExtractionError(
                safe_error_summary(exc, label="提取提交失败"),
                stage="extract",
                code=str(getattr(exc, "code", "extraction_commit_failed")),
                retryable=bool(getattr(exc, "retryable", True)),
                cause_summary=type(exc).__name__,
            ) from exc
        committed_events = list(result.events)
        event_ids = [str(event.id) for event in committed_events]
        parent_event_ids = [str(event.id) for event in committed_events if event.chunk_id is None]
        entity_ids = sorted(
            {
                str(association.entity_id)
                for event in committed_events
                for association in getattr(event, "event_associations", ()) or ()
            }
        )
        return self._event_ref(
            resolved,
            options,
            event_ids,
            entity_ids,
            parent_event_ids=parent_event_ids,
            stats=dict(result.stats),
            vector_status=WriteStatus.SUCCEEDED,
        )

    @staticmethod
    def _serialize_prepared_event(event: SourceEvent) -> dict[str, Any]:
        return _json_value(
            {column.name: getattr(event, column.name) for column in SourceEvent.__table__.columns}
        )

    @staticmethod
    def _deserialize_prepared_event(payload: dict[str, Any]) -> SourceEvent:
        values = dict(payload)
        for column in SourceEvent.__table__.columns:
            value = values.get(column.name)
            if not isinstance(value, str):
                continue
            try:
                is_datetime = column.type.python_type is datetime
            except (AttributeError, NotImplementedError):
                is_datetime = False
            if is_datetime:
                values[column.name] = datetime.fromisoformat(value)
        return SourceEvent(**values)

    async def extract(
        self,
        target: ChunkSetRef | PersistedChunkSelector,
        options: ExtractionOptions,
        *,
        cancellation: CancellationToken | None = None,
    ) -> EventSetRef:
        if cancellation is not None and cancellation.is_cancelled:
            raise asyncio.CancelledError
        if options.strategy != "sag_extract":
            raise UnsupportedStageOptionError(
                f"当前提取实现不支持策略 {options.strategy}",
                stage="extract",
                code="unsupported_extraction_strategy",
            )
        resolved = await self._resolve(target)
        if options.source_type is not None and options.source_type != resolved["public_type"]:
            raise StageInputError(
                "ExtractionOptions.source_type 与持久化来源冲突",
                stage="extract",
                code="source_type_conflict",
            )
        if options.enable_article_summary and resolved["public_type"] not in {
            "text",
            "article",
        }:
            raise StageInputError(
                "enable_article_summary 只适用于 text/article",
                stage="extract",
                code="invalid_extraction_options",
            )
        config = self._build_config(resolved, options)
        extraction_stats: dict[str, Any] = {}
        try:
            if cancellation is None:
                raw_result = await self.extractor.extract_batch(config)
            else:
                raw_result = await self.extractor.extract_batch(config, cancellation=cancellation)
            events = list(raw_result.events)
            failed = list(raw_result.failures)
            extraction_stats = dict(raw_result.stats)
            if failed:
                # 批次原子性：任一 Chunk 重试耗尽即拒绝整批，保留上一份 source 快照。
                failures = self._item_failures(failed)
                extraction_stats["chunk_failures"] = [
                    {
                        "chunk_id": item.item_id,
                        "code": item.code,
                        "message": item.message,
                        "retryable": item.retryable,
                        "attempts": item.attempts,
                    }
                    for item in failures
                ]
                raise ExtractionBatchFailure(
                    f"{len(failures)} 个 Chunk 重试耗尽，批次未提交",
                    stage="extract",
                    code="chunk_retry_exhausted",
                    retryable=True,
                    failures=failures,
                    stats=extraction_stats,
                )
        except Exception as exc:
            status_error = (
                None
                if resolved["generation_id"] is not None
                else await self._update_source_status(
                    resolved,
                    succeeded=False,
                )
            )
            if status_error:
                logger.error("Extract 失败状态写入失败: %s", status_error)
            if isinstance(exc, MissingCapabilityError):
                raise UnsupportedStageOptionError(
                    "文章摘要能力不可用",
                    stage="extract",
                    code="article_summary_capability_missing",
                ) from exc
            if isinstance(exc, ExtractionBatchFailure):
                raise
            core_failures = getattr(exc, "failures", None)
            if core_failures:
                failures = self._item_failures(list(core_failures))
                raise ExtractionBatchFailure(
                    safe_error_summary(exc, label="Chunk 提取失败"),
                    stage="extract",
                    code=str(getattr(exc, "code", "chunk_retry_exhausted")),
                    retryable=all(item.retryable for item in failures),
                    failures=failures,
                    stats=dict(getattr(exc, "stats", {})),
                    cause_summary=type(exc).__name__,
                ) from exc
            rolled_back = isinstance(exc, VectorSyncError | ExtractRollbackError) and (
                exc.compensation_complete is True
            )
            if rolled_back:
                raise ExtractionError(
                    "Extract 失败，关系与向量变更已全部回滚",
                    stage="extract",
                    code="extraction_rolled_back",
                    retryable=True,
                    provider=getattr(exc, "provider", None),
                ) from exc
            if isinstance(exc, ExtractRollbackError) and not exc.compensation_complete:
                raise ExtractionError(
                    "Extract 失败且关系/向量补偿回滚不完整",
                    stage="extract",
                    code="extraction_rollback_failed",
                    retryable=False,
                    cause_summary=type(exc).__name__,
                ) from exc
            if getattr(exc, "code", None) == "article_summary_failed":
                raise ExtractionBatchFailure(
                    "文章摘要提取失败",
                    stage="extract",
                    code="article_summary_failed",
                    retryable=False,
                    failures=(),
                    stats=dict(getattr(exc, "stats", {})),
                    cause_summary=type(exc).__name__,
                ) from exc
            raise ExtractionError(
                safe_error_summary(exc, label="现有提取实现失败"),
                stage="extract",
                code="extractor_failed",
                cause_summary=type(exc).__name__,
            ) from exc

        status_error = (
            None
            if resolved["generation_id"] is not None
            else await self._update_source_status(resolved, succeeded=True)
        )
        if status_error:
            extraction_stats["source_status"] = "update_failed"
            extraction_stats["source_status_error"] = status_error
            logger.error("Extract 成功状态写入失败: %s", status_error)
        else:
            extraction_stats["source_status"] = "completed"

        event_ids = [event.id for event in events]
        parent_event_ids = [
            event.id for event in events if getattr(event, "chunk_id", None) is None
        ]
        entity_ids: set[str] = set()
        relation_write_count = 0
        for event in events:
            for association in getattr(event, "event_associations", ()) or ():
                relation_write_count += 1
                entity_id = getattr(association, "entity_id", None)
                if entity_id:
                    entity_ids.add(str(entity_id))
        vector_write_count = len(event_ids) + relation_write_count
        vector_write_count += len(entity_ids)
        extraction_stats.update(
            {
                "relation_write_count": relation_write_count,
                "vector_write_count": vector_write_count,
            }
        )
        return self._event_ref(
            resolved,
            options,
            event_ids,
            sorted(entity_ids),
            parent_event_ids=parent_event_ids,
            stats=extraction_stats,
            vector_status=WriteStatus.SUCCEEDED,
        )

    @staticmethod
    def _item_failures(failed: list[Any]) -> tuple[ItemFailure, ...]:
        return tuple(
            ItemFailure(
                item_id=str(
                    item.get("chunk_id", "unknown")
                    if isinstance(item, dict)
                    else getattr(item, "chunk_id", "unknown")
                ),
                code=str(
                    item.get("code", "chunk_extraction_failed")
                    if isinstance(item, dict)
                    else getattr(item, "code", "chunk_extraction_failed")
                ),
                message="Chunk 提取失败",
                retryable=bool(
                    item.get("retryable", True)
                    if isinstance(item, dict)
                    else getattr(item, "retryable", True)
                ),
                attempts=int(
                    item.get("attempts", 1)
                    if isinstance(item, dict)
                    else getattr(item, "attempts", 1)
                ),
            )
            for item in failed
        )

    async def _update_source_status(
        self,
        resolved: dict[str, Any],
        *,
        succeeded: bool,
    ) -> str | None:
        """Persist the terminal extraction status without masking extraction errors."""
        try:
            async with self.session_factory() as session:
                now = await database_utcnow(session)
                source_id = str(resolved["source_id"])
                if resolved["physical_type"] == "ARTICLE":
                    source = await session.get(Article, source_id)
                    if source is None:
                        return "article_not_found"
                    if succeeded:
                        source.status = "COMPLETED"
                        source.parse_status = ArticleParseStatus.COMPLETED.value
                        source.error = None
                    else:
                        source.status = "FAILED"
                        source.parse_status = ArticleParseStatus.EXTRACTION_FAILED.value
                        source.error = "extract_failed"
                    source.sync_date = now
                else:
                    source = await session.get(ChatConversation, source_id)
                    if source is None:
                        return "conversation_not_found"
                    source.parse_status = "COMPLETED" if succeeded else "FAILED"
                    source.sync_date = now
                await session.commit()
        except Exception as exc:
            return safe_error_summary(exc, label="source status update failed")
        return None

    async def _resolve(self, target: ChunkSetRef | PersistedChunkSelector) -> dict[str, Any]:
        async with self.session_factory() as session:
            stmt = select(SourceChunk).where(SourceChunk.data_source_id == target.data_source_id)
            if isinstance(target, ChunkSetRef):
                stmt = stmt.where(SourceChunk.id.in_(list(target.chunk_ids)))
                if target.generation_id is not None:
                    stmt = stmt.where(SourceChunk.generation_id == target.generation_id)
            else:
                if target.chunk_ids:
                    stmt = stmt.where(SourceChunk.id.in_(list(target.chunk_ids)))
                if target.source_ids:
                    stmt = stmt.where(SourceChunk.source_id.in_(list(target.source_ids)))
            rows = list((await session.execute(stmt.order_by(SourceChunk.rank))).scalars().all())
            if not rows:
                raise StageInputError(
                    "没有匹配的持久化 Chunk",
                    stage="extract",
                    code="chunks_not_found",
                )
            source_keys = {(row.source_type, row.source_id) for row in rows}
            if len(source_keys) != 1:
                raise StageInputError(
                    "一次 Extract 只能处理一个具体来源",
                    stage="extract",
                    code="multiple_sources_not_supported",
                )
            physical_type, source_id = next(iter(source_keys))
            generations = {row.generation_id for row in rows}
            if len(generations) != 1:
                raise StageInputError(
                    "一次 Extract 不能混用多个 generation",
                    stage="extract",
                    code="multiple_generations_not_supported",
                )
            generation_id = next(iter(generations))
            if isinstance(target, ChunkSetRef):
                missing = set(target.chunk_ids) - {row.id for row in rows}
                if missing:
                    raise StalePipelineReferenceError(
                        f"ChunkSetRef 含已不存在的 chunk: {sorted(missing)}",
                        stage="extract",
                        code="stale_chunk_reference",
                    )
                chunk_version = target.chunk_version
                source_version = target.source_version
                for row in rows:
                    stored = (row.extra_data or {}).get("chunk_version")
                    if stored and stored != target.chunk_version:
                        raise StalePipelineReferenceError(
                            "ChunkSetRef.chunk_version 与持久化数据不一致",
                            stage="extract",
                            code="stale_chunk_version",
                        )
                public_type = _source_type_value(target.source_type)
                if target.generation_id != generation_id:
                    raise StalePipelineReferenceError(
                        "ChunkSetRef.generation_id 与持久化数据不一致",
                        stage="extract",
                        code="stale_generation_reference",
                    )
            else:
                chunk_version = _stored_version(rows, "chunk_version")
                expected = target.expected_chunk_version
                if expected and expected != chunk_version:
                    raise StalePipelineReferenceError(
                        "selector.expected_chunk_version 与持久化数据不一致",
                        stage="extract",
                        code="stale_chunk_version",
                    )
                source_version = _stored_version(rows, "source_version")
                public_type = {
                    "ARTICLE": "article",
                    "CHAT": "chat",
                    "RECORDING": "recording",
                }.get(physical_type, physical_type.lower())
            return {
                "data_source_id": target.data_source_id,
                "source_id": source_id,
                "public_type": public_type,
                "physical_type": physical_type,
                "source_version": source_version,
                "chunk_version": chunk_version,
                "chunk_ids": [row.id for row in rows],
                "generation_id": generation_id,
            }

    def _event_ref(
        self,
        resolved: dict[str, Any],
        options: ExtractionOptions,
        event_ids: list[str],
        entity_ids: list[str],
        *,
        parent_event_ids: list[str],
        stats: dict[str, Any],
        vector_status: WriteStatus,
    ) -> EventSetRef:
        extract_version = content_hash(
            {
                "chunk_version": resolved["chunk_version"],
                "options": options.model_dump(mode="json"),
                "schema_version": "extraction-response-v1",
                "prompt_fingerprint": stats.get("prompt_fingerprint", ""),
                "entity_type_fingerprint": stats.get("entity_type_fingerprint", ""),
                "article_summary_fingerprint": stats.get("article_summary_fingerprint", ""),
                "parent_prompt_fingerprint": stats.get("parent_prompt_fingerprint", ""),
                "storage_mode": self.storage_mode,
                "embedding_dimensions": self.embedding_dimensions,
            }
        )
        return EventSetRef(
            data_source_id=resolved["data_source_id"],
            source_type=resolved["public_type"],
            source_id=resolved["source_id"],
            source_version=resolved["source_version"],
            chunk_version=resolved["chunk_version"],
            extract_version=extract_version,
            generation_id=resolved["generation_id"],
            chunk_ids=tuple(resolved["chunk_ids"]),
            event_ids=tuple(event_ids),
            entity_ids=tuple(entity_ids),
            parent_event_ids=tuple(parent_event_ids),
            relation_status=WriteStatus.SUCCEEDED,
            vector_status=vector_status,
            stats={
                "event_count": len(event_ids),
                "entity_count": len(entity_ids),
                **stats,
            },
        )


class BuiltinEventLoader:
    """Reload persisted events as portable DTOs within an EventSetRef scope."""

    def __init__(self, *, session_factory: Any) -> None:
        self.session_factory = session_factory

    async def load_events(self, event_ref: EventSetRef) -> tuple[EventDetail, ...]:
        event_ids = list(dict.fromkeys(event_ref.event_ids))
        if not event_ids:
            return ()

        public_source_type = _source_type_value(event_ref.source_type)
        physical_source_type = {
            "text": "ARTICLE",
            "article": "ARTICLE",
            "chat": "CHAT",
            "recording": "RECORDING",
        }.get(public_source_type)
        if physical_source_type is None:
            raise StageInputError(
                f"不支持的事项来源类型: {public_source_type}",
                stage="load_events",
                code="unsupported_source_type",
            )

        async with self.session_factory() as session:
            rows = list(
                (
                    await session.execute(
                        select(SourceEvent)
                        .where(
                            SourceEvent.id.in_(event_ids),
                            SourceEvent.data_source_id == event_ref.data_source_id,
                            SourceEvent.source_id == event_ref.source_id,
                            SourceEvent.source_type == physical_source_type,
                            SourceEvent.not_deleted(),
                        )
                        .options(
                            selectinload(SourceEvent.event_associations).selectinload(
                                EventEntity.entity
                            )
                        )
                    )
                )
                .scalars()
                .all()
            )

        rows_by_id = {str(row.id): row for row in rows}
        missing = [event_id for event_id in event_ids if event_id not in rows_by_id]
        if missing:
            raise StalePipelineReferenceError(
                f"EventSetRef 含不存在或超出来源范围的 event: {missing}",
                stage="load_events",
                code="stale_event_reference",
            )

        details: list[EventDetail] = []
        for event_id in event_ids:
            row = rows_by_id[event_id]
            entities: list[EventEntityDetail] = []
            for association in getattr(row, "event_associations", ()) or ():
                entity = getattr(association, "entity", None)
                if entity is None:
                    continue
                entities.append(
                    EventEntityDetail(
                        id=str(entity.id),
                        type=str(entity.type),
                        name=str(entity.name),
                        description=str(association.description or entity.description or ""),
                        weight=float(association.weight),
                        metadata=_json_dict(association.extra_data),
                    )
                )
            entities.sort(key=lambda item: (item.type.casefold(), item.name.casefold(), item.id))
            details.append(
                EventDetail(
                    id=str(row.id),
                    data_source_id=str(row.data_source_id),
                    source_type=SourceType(public_source_type),
                    source_id=str(row.source_id),
                    chunk_id=str(row.chunk_id) if row.chunk_id else None,
                    parent_id=str(row.parent_id) if row.parent_id else None,
                    level=int(row.level),
                    rank=int(row.rank),
                    title=str(row.title),
                    summary=str(row.summary),
                    content=str(row.content),
                    category=row.category,
                    event_type=row.type,
                    keywords=_json_value(row.keywords),
                    priority=row.priority,
                    status=row.status,
                    start_time=_aware_utc(row.start_time),
                    end_time=_aware_utc(row.end_time),
                    references=_json_value(row.references),
                    entities=tuple(entities),
                    created_time=cast(datetime, _aware_utc(row.created_time)),
                    updated_time=cast(datetime, _aware_utc(row.updated_time)),
                )
            )
        return tuple(details)


class BuiltinSearchAdapter:
    """Thin pipeline port adapter; composition and dispatch belong to the engine runtime."""

    def __init__(self, *, orchestrator: Any) -> None:
        self.orchestrator = orchestrator

    async def search(self, request: SearchRequest) -> SearchResult:
        # scope 解析、plan 解析、executor 校验和执行均属于编排器。
        return await self.orchestrator.search(request)
