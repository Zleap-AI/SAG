"""引擎启动的本地目录准备。"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from zleap.sag.config import EngineConfig


def ensure_local_dirs(config: EngineConfig) -> None:
    """为本地后端预建 SQLite 父目录和 LanceDB 目录。"""
    from zleap.sag.config import LanceDBVectorConfig

    rel = config.relational
    if rel is not None and rel.provider == "sqlite" and rel.path:
        Path(rel.path).parent.mkdir(parents=True, exist_ok=True)
    if isinstance(config.vector, LanceDBVectorConfig):
        Path(config.vector.path).mkdir(parents=True, exist_ok=True)
