"""SQL-backed stable search snapshots and tamper-evident cursors."""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import uuid
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import select

from zleap.sag.db import SAGDataSourceManifest, SAGSearchSession
from zleap.sag.db.clock import database_utcnow
from zleap.sag.exceptions import (
    CursorExpiredError,
    CursorInvalidError,
    SearchSessionTooLargeError,
)
from zleap.sag.pipeline import SearchRequest, SearchResult
from zleap.sag.queries import SearchPage

_MAX_RESULT_BYTES = 16 * 1024 * 1024


def _aware(value: datetime) -> datetime:
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


def _digest(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


class SearchSessionStore:
    def __init__(self, session_factory: Any) -> None:
        self._session_factory = session_factory

    async def create(
        self,
        request: SearchRequest,
        result: SearchResult,
        *,
        page_size: int,
        ttl_seconds: int,
        visibility: Any,
    ) -> SearchPage:
        payload = result.model_dump(mode="json")
        encoded_size = len(
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        )
        if encoded_size > _MAX_RESULT_BYTES:
            raise SearchSessionTooLargeError(
                f"stable search snapshot exceeds {_MAX_RESULT_BYTES} bytes"
            )
        result_kind = "events" if result.events else "chunks"
        total = len(result.events) if result_kind == "events" else len(result.chunks)
        async with self._session_factory() as session:
            now = await database_utcnow(session)
            row = SAGSearchSession(
                session_id=str(uuid.uuid4()),
                request_digest=_digest(request.model_dump(mode="json")),
                cursor_key=secrets.token_hex(32),
                scope_digest=_digest(request.scope.model_dump(mode="json")),
                data_source_ids=list(request.scope.data_source_ids),
                source_ids=list(request.scope.source_ids),
                revision_payload=dict(visibility.revisions),
                result_payload=payload,
                result_kind=result_kind,
                total=total,
                page_size=page_size,
                expires_at=now + timedelta(seconds=ttl_seconds),
                created_time=now,
                updated_time=now,
            )
            session.add(row)
            await session.commit()
        return self._page(row, result, 0)

    async def resume(self, cursor: str, cursor_request: SearchRequest) -> SearchPage:
        session_id, offset, signature = self._parse_cursor(cursor)
        async with self._session_factory() as session:
            row = await session.get(SAGSearchSession, session_id)
            if row is None:
                raise CursorInvalidError("search cursor does not exist")
            if row.expires_at <= await database_utcnow(session):
                await session.delete(row)
                await session.commit()
                raise CursorExpiredError("search cursor has expired")
            expected = self._signature(row.cursor_key, session_id, offset)
            if not hmac.compare_digest(signature, expected):
                raise CursorInvalidError("search cursor signature is invalid")
            actual_request_digest = _digest(cursor_request.model_dump(mode="json"))
            if not hmac.compare_digest(actual_request_digest, row.request_digest):
                raise CursorInvalidError("search cursor is not valid for this request")
            actual_scope_digest = _digest(cursor_request.scope.model_dump(mode="json"))
            if not hmac.compare_digest(actual_scope_digest, row.scope_digest):
                raise CursorInvalidError("search cursor is not valid for this scope")
            revisions = dict(
                (
                    await session.execute(
                        select(
                            SAGDataSourceManifest.data_source_id,
                            SAGDataSourceManifest.revision,
                        ).where(SAGDataSourceManifest.data_source_id.in_(row.data_source_ids))
                    )
                ).all()
            )
            current_revisions = {
                str(data_source_id): int(revisions.get(data_source_id, 0))
                for data_source_id in row.data_source_ids
            }
            expected_revisions = {
                str(data_source_id): int(revision)
                for data_source_id, revision in row.revision_payload.items()
            }
            if current_revisions != expected_revisions:
                await session.delete(row)
                await session.commit()
                raise CursorExpiredError("search scope changed after the cursor was issued")
            if offset < 0 or offset >= max(row.total, 1):
                raise CursorInvalidError("search cursor offset is invalid")
            result = SearchResult.model_validate(row.result_payload)
        return self._page(row, result, offset)

    @classmethod
    def _page(cls, row: SAGSearchSession, result: SearchResult, offset: int) -> SearchPage:
        stop = min(offset + row.page_size, row.total)
        updates: dict[str, Any]
        if row.result_kind == "events":
            updates = {"events": result.events[offset:stop], "chunks": ()}
        else:
            updates = {"events": (), "chunks": result.chunks[offset:stop]}
        page_result = result.model_copy(update=updates)
        next_cursor = (
            cls._cursor(row.cursor_key, row.session_id, stop) if stop < row.total else None
        )
        return SearchPage(
            session_id=row.session_id,
            result=page_result,
            offset=offset,
            page_size=row.page_size,
            total=row.total,
            next_cursor=next_cursor,
            expires_at=_aware(row.expires_at),
            revision={str(key): int(value) for key, value in row.revision_payload.items()},
        )

    @staticmethod
    def _signature(key: str, session_id: str, offset: int) -> str:
        return hmac.new(
            key.encode("ascii"),
            f"{session_id}:{offset}".encode("ascii"),
            hashlib.sha256,
        ).hexdigest()

    @classmethod
    def _cursor(cls, key: str, session_id: str, offset: int) -> str:
        return f"{session_id}.{offset}.{cls._signature(key, session_id, offset)}"

    @staticmethod
    def _parse_cursor(cursor: str) -> tuple[str, int, str]:
        try:
            session_id, raw_offset, signature = cursor.strip().split(".", 2)
            uuid.UUID(session_id)
            offset = int(raw_offset)
            if len(signature) != 64:
                raise ValueError
        except (AttributeError, TypeError, ValueError) as exc:
            raise CursorInvalidError("search cursor is malformed") from exc
        return session_id, offset, signature


__all__ = ["SearchSessionStore"]
