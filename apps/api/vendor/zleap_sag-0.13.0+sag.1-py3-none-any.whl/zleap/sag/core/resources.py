"""实例级资源容器(DI 单一事实来源)。

`ResourceContainer` 持有一个引擎所需的全部后端适配器(llm/embedding/rerank/
vector/relational),由 `EngineConfig` 经 registry 构建。业务组件只接收显式依赖，
不再通过进程全局或 ContextVar 解析资源。
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from zleap.sag.core.adapters import registry
from zleap.sag.exceptions import SagError

if TYPE_CHECKING:
    from zleap.sag.core.adapters import (
        EmbeddingAdapter,
        LLMAdapter,
        RelationalStore,
        RerankAdapter,
        VectorStore,
    )


@dataclass(frozen=True)
class StorageResources:
    """关系与向量资源的独立所有权边界。"""

    relational: RelationalStore
    vector: VectorStore

    async def aclose(self) -> None:
        """按向量、关系顺序关闭两类实例级资源。"""
        first_error: BaseException | None = None
        try:
            await self.vector.close()
        except BaseException as exc:  # noqa: BLE001 - 仍需关闭关系资源
            first_error = exc
        try:
            await self.relational.close()
        except BaseException as exc:  # noqa: BLE001 - 保留首个关闭错误
            first_error = first_error or exc
        if first_error is not None:
            raise SagError.wrap(first_error, operation="aclose")


@dataclass(frozen=True)
class ResourceContainer:
    """一个引擎/一次执行所需的全部后端适配器。"""

    llm: LLMAdapter
    embedding: EmbeddingAdapter
    rerank: RerankAdapter | None
    vector: VectorStore
    relational: RelationalStore
    vlm: LLMAdapter | None = None
    prompts: Any = None

    async def aclose(self) -> None:
        """关闭当前实例拥有的 AI 客户端与存储资源。"""
        first_error: BaseException | None = None
        for adapter in (self.vlm, self.llm, self.embedding, self.rerank):
            close = getattr(adapter, "close", None)
            if close is None:
                continue
            try:
                result = close()
                if inspect.isawaitable(result):
                    await result
            except BaseException as exc:  # noqa: BLE001 - close all owned resources
                first_error = first_error or exc
        try:
            await self.storage.aclose()
        except BaseException as exc:  # noqa: BLE001 - close all owned resources
            first_error = first_error or exc
        if first_error is not None:
            raise first_error

    def require_vlm(self) -> LLMAdapter:
        """返回多模态适配器；未配置时明确报错，不回退到文本模型。"""
        if self.vlm is None:
            from zleap.sag.exceptions import ConfigError

            raise ConfigError(
                "该功能需要多模态模型，但当前未配置 VLM。"
                "请设置 EngineConfig(vlm=VLMConfig(model=...)) 或环境变量 VLM_MODEL。"
            )
        return self.vlm

    @property
    def storage(self) -> StorageResources:
        """公开关系/向量资源分组；保留平铺属性供现有调用迁移。"""
        return StorageResources(relational=self.relational, vector=self.vector)


def _provider(config: Any, kind: str) -> str | None:
    """读取某存储类别的 provider 名(仅 relational/vector;AI 侧始终用默认适配器)。

    注:``config.llm.provider``(openai/litellm)是**客户端实现**的选择,由 factory 经
    ``LLM_PROVIDER`` 环境变量处理,不是适配器 provider——故此处不读取 AI 侧的 provider。
    """
    if kind not in ("relational", "vector"):
        return None
    if kind == "vector":
        section = getattr(config, "vector", None)
        provider = getattr(section, "provider", None)
        if provider == "elasticsearch":
            return "es"
        if provider:
            return str(provider)
    section = getattr(config, kind, None)
    return getattr(section, "provider", None)


def build_storage(config: Any) -> StorageResources:
    """只构建关系/向量资源；适合宿主应用在组合根中复用。"""
    storage_mode = getattr(config, "storage_mode", "normal")
    embedding = getattr(config, "embedding", None)
    dimensions = getattr(embedding, "schema_dimensions", None)
    vector_config = getattr(config, "vector", None)
    relational_config = getattr(config, "relational", None)
    vector_kwargs: dict[str, Any] = {
        "config": vector_config,
        "storage_mode": storage_mode,
        "embedding_dimensions": dimensions,
    }
    # ParadeDB 按语言选 BM25 分词器(中文 → jieba);其余后端不接受该参数。
    if getattr(vector_config, "provider", None) == "paradedb":
        vector_kwargs["language"] = getattr(config, "language", "en")
    return StorageResources(
        vector=registry.create_vector_store(_provider(config, "vector"), **vector_kwargs),
        relational=registry.create_relational_store(
            _provider(config, "relational"), config=relational_config
        ),
    )


def build_container(config: Any, *, governor: Any = None) -> ResourceContainer:
    """按完整配置构建实例级资源容器；构造阶段不建立网络连接。"""
    storage = build_storage(config)
    from zleap.sag.core.prompt.manager import PromptManager

    prompt_manager = PromptManager(language=getattr(config, "language", "zh"))
    llm = registry.create_llm(_provider(config, "llm"), config=getattr(config, "llm", None))
    embedding = registry.create_embedding(
        _provider(config, "embedding"), config=getattr(config, "embedding", None)
    )
    rerank_config = getattr(config, "rerank", None)
    rerank = (
        registry.create_rerank(
            _provider(config, "rerank"),
            config=rerank_config,
            prompt_manager=prompt_manager,
        )
        if rerank_config is not None
        else None
    )
    vlm_config = getattr(config, "vlm", None)
    vlm = (
        registry.create_vlm(_provider(config, "vlm"), config=vlm_config)
        if vlm_config is not None
        else None
    )
    vector = storage.vector
    if governor is not None:
        from zleap.sag.core.adapters.limited import (
            LimitedEmbeddingAdapter,
            LimitedLLMAdapter,
            LimitedRerankAdapter,
            LimitedVectorStore,
        )

        llm = LimitedLLMAdapter(llm, governor)
        if vlm is not None:
            vlm = LimitedLLMAdapter(vlm, governor)
        embedding = LimitedEmbeddingAdapter(embedding, governor)
        if rerank is not None:
            rerank = LimitedRerankAdapter(rerank, governor)
        vector = LimitedVectorStore(vector, governor)
    return ResourceContainer(
        llm=llm,
        embedding=embedding,
        rerank=rerank,
        vector=vector,
        relational=storage.relational,
        vlm=vlm,
        prompts=prompt_manager,
    )
