"""
LLM客户端工厂

根据配置创建相应的LLM客户端，支持场景化配置
"""

from dataclasses import dataclass, field
from typing import Any

from zleap.sag.core.ai.base import BaseLLMClient, LLMRetryClient
from zleap.sag.core.ai.embedding import EmbeddingClient
from zleap.sag.core.ai.llm import OpenAIClient
from zleap.sag.core.ai.models import LLMProvider, ModelConfig
from zleap.sag.exceptions import ConfigError
from zleap.sag.utils import get_logger

logger = get_logger("ai.factory")


@dataclass(frozen=True)
class _ResolvedEmbeddingConfig:
    model: str
    api_key: str = field(repr=False)
    base_url: str | None = None
    schema_dimensions: int | None = None
    request_dimensions: int | None = None
    max_tokens: int = 512
    timeout: int = 60
    max_retries: int = 3

    def create_client(self) -> EmbeddingClient:
        return EmbeddingClient(
            model=self.model,
            api_key=self.api_key,
            base_url=self.base_url,
            schema_dimensions=self.schema_dimensions,
            request_dimensions=self.request_dimensions,
            max_tokens=self.max_tokens,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )


def _nonempty_string(config: dict[str, Any], key: str, *, scenario: str) -> str:
    value = config.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"Embedding配置错误：{key} 必须是非空字符串；场景: {scenario}")
    return value


def _optional_string(config: dict[str, Any], key: str, *, scenario: str) -> str | None:
    value = config.get(key)
    if value is None or value == "":
        return None
    if not isinstance(value, str):
        raise ConfigError(f"Embedding配置错误：{key} 必须是字符串；场景: {scenario}")
    return value


def _integer(
    config: dict[str, Any],
    key: str,
    *,
    scenario: str,
    default: int | None,
    minimum: int,
) -> int | None:
    value = config.get(key, default)
    if value is None and default is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ConfigError(
            f"Embedding配置错误：{key} 必须是大于等于 {minimum} 的整数；场景: {scenario}"
        )
    return value


def _resolve_embedding_config(config: dict[str, Any], *, scenario: str) -> _ResolvedEmbeddingConfig:
    if "dimensions" in config:
        raise ConfigError(
            "Embedding dimensions 已移除，请使用 schema_dimensions / request_dimensions"
        )
    max_tokens = _integer(config, "max_tokens", scenario=scenario, default=512, minimum=1)
    timeout = _integer(config, "timeout", scenario=scenario, default=60, minimum=1)
    max_retries = _integer(config, "max_retries", scenario=scenario, default=3, minimum=0)
    assert max_tokens is not None and timeout is not None and max_retries is not None
    return _ResolvedEmbeddingConfig(
        model=_nonempty_string(config, "model", scenario=scenario),
        api_key=_nonempty_string(config, "api_key", scenario=scenario),
        base_url=_optional_string(config, "base_url", scenario=scenario),
        schema_dimensions=_integer(
            config, "schema_dimensions", scenario=scenario, default=None, minimum=1
        ),
        request_dimensions=_integer(
            config, "request_dimensions", scenario=scenario, default=None, minimum=1
        ),
        max_tokens=max_tokens,
        timeout=timeout,
        max_retries=max_retries,
    )


async def create_llm_client(
    *,
    scenario: str = "general",
    model_config: dict[str, Any],
) -> BaseLLMClient | LLMRetryClient:
    """
    创建LLM客户端（统一入口，支持场景化配置）

    只接受当前 Engine 显式传入的配置，不读取进程环境。

    Args:
        scenario: 场景标识，默认 'general'
            - 'extract' : 事项提取
            - 'search'  : 搜索
            - 'chat'    : 对话
            - 'summary' : 摘要
            - 'system'  : 系统（Agent创建等）
            - 'general' : 通用（默认）

        model_config: LLM配置字典
            {
                'model': 'gpt-4',
                'api_key': 'sk-xxx',
                'base_url': 'https://api.302.ai',
                'temperature': 0.7,
                'max_tokens': 8000,
                ...
            }

    Returns:
        LLM客户端实例

    Raises:
        ConfigError: 无法获取有效配置时抛出

    Examples:
        # 显式传入配置
        >>> client = await create_llm_client(
        ...     scenario='extract',
        ...     model_config={'model': 'gpt-4', 'api_key': 'sk-...', 'temperature': 0.1}
        ... )

    说明：
    - 统一使用 OpenAIClient（兼容 OpenAI 官方 + 302.AI 中转）
    - 通过 base_url 区分不同服务商
    """
    config = {
        "temperature": 0.7,
        "max_tokens": 30_000,
        "top_p": 1.0,
        "frequency_penalty": 0.0,
        "presence_penalty": 0.0,
        "timeout": 300,
        "max_retries": 5,
        "enable_think": False,
        "structured_output_mode": "json_schema",
        "data_inspection": True,
        **model_config,
    }
    logger.debug(f"使用显式 LLM 配置: scenario={scenario}")

    # ============ 验证必需参数 ============
    if not config.get("api_key"):
        raise ConfigError(f"LLM配置错误：缺少 API Key；场景: {scenario}")

    if not config.get("model"):
        raise ConfigError(f"LLM配置错误：缺少模型名称；场景: {scenario}")

    # ============ 构建配置对象 ============
    model_config_obj = ModelConfig(
        provider=LLMProvider.OPENAI,  # 统一使用 OPENAI（兼容所有中转服务）
        model=config["model"],
        api_key=config["api_key"],
        base_url=config.get("base_url"),
        temperature=config["temperature"],
        max_tokens=config["max_tokens"],
        top_p=config["top_p"],
        frequency_penalty=config["frequency_penalty"],
        presence_penalty=config["presence_penalty"],
        timeout=config["timeout"],
        max_retries=config["max_retries"],
        enable_think=bool(config.get("enable_think", False)),
        structured_output_mode=config["structured_output_mode"],
        data_inspection=bool(config.get("data_inspection", True)),
    )

    # ============ 创建客户端（按 provider 选择实现）============
    # 默认 openai(兼容 OpenAI 官方 + 302.AI 中转);litellm 为可选多 provider 实现。
    provider_name = str(config.get("provider") or "openai").lower()
    if provider_name == "litellm":
        from zleap.sag.core.ai.litellm_client import LiteLLMClient

        base_client: BaseLLMClient = LiteLLMClient(model_config_obj)
    else:
        base_client = OpenAIClient(model_config_obj)

    # 包装重试机制
    with_retry = config.get("with_retry", True)
    if with_retry:
        logger.debug(
            f"✅ 创建LLM客户端（带重试）: scenario={scenario}",
            extra={
                "scenario": scenario,
                "model": config["model"],
                "base_url": config.get("base_url") or "OpenAI官方",
                "max_retries": config["max_retries"],
            },
        )
        return LLMRetryClient(base_client)

    logger.debug(
        f"✅ 创建LLM客户端: scenario={scenario}",
        extra={
            "scenario": scenario,
            "model": config["model"],
        },
    )
    return base_client


async def create_vlm_client(
    *,
    scenario: str = "general",
    model_config: dict[str, Any],
) -> BaseLLMClient | LLMRetryClient:
    """使用当前 Engine 显式配置创建 OpenAI 兼容的多模态客户端。"""
    config = {
        "temperature": 0.3,
        "max_tokens": 8_000,
        "top_p": 1.0,
        "frequency_penalty": 0.0,
        "presence_penalty": 0.0,
        "timeout": 600,
        "max_retries": 3,
        "enable_think": False,
        "structured_output_mode": "json_schema",
        "data_inspection": True,
        **model_config,
    }
    if not config.get("api_key"):
        raise ConfigError(f"VLM配置错误：缺少 API Key；场景: {scenario}")
    if not config.get("model"):
        raise ConfigError(f"VLM配置错误：缺少模型名称；场景: {scenario}")

    resolved = ModelConfig(
        provider=LLMProvider.OPENAI,
        model=config["model"],
        api_key=config["api_key"],
        base_url=config.get("base_url"),
        temperature=config["temperature"],
        max_tokens=config["max_tokens"],
        top_p=config["top_p"],
        frequency_penalty=config["frequency_penalty"],
        presence_penalty=config["presence_penalty"],
        timeout=config["timeout"],
        max_retries=config["max_retries"],
        enable_think=bool(config.get("enable_think", False)),
        structured_output_mode=config["structured_output_mode"],
        data_inspection=bool(config.get("data_inspection", True)),
    )
    client: BaseLLMClient = OpenAIClient(resolved)
    if config.get("with_retry", True):
        logger.debug(
            "创建 VLM 客户端（带重试）",
            extra={
                "scenario": scenario,
                "model": resolved.model,
                "max_retries": resolved.max_retries,
            },
        )
        return LLMRetryClient(client)
    return client


# ============================================================
# 说明：
# - AI 客户端均由单个 Engine 的 ResourceContainer 持有并负责关闭
# - 工厂只消费显式配置，不读取进程全局 Settings
# ============================================================


# ============ Embedding 客户端工厂 ============


async def create_embedding_client(
    *,
    scenario: str = "general",
    embedding_config: dict[str, Any],
) -> EmbeddingClient:
    """使用当前 Engine 显式配置创建 Embedding 客户端。"""
    config = {
        "max_tokens": 512,
        "timeout": 60,
        "max_retries": 3,
        **embedding_config,
    }

    resolved = _resolve_embedding_config(config, scenario=scenario)
    client = resolved.create_client()

    logger.info(
        "✅ 创建Embedding客户端",
        extra={
            "scenario": scenario,
            "model": resolved.model,
            "base_url": resolved.base_url or "OpenAI官方",
            "schema_dimensions": resolved.schema_dimensions,
            "request_dimensions": resolved.request_dimensions,
        },
    )
    return client
