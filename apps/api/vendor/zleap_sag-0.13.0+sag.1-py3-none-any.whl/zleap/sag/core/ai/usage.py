"""Request-local usage reporting for durable extraction, without shared client state."""

from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from contextvars import ContextVar

from zleap.sag.core.ai.models import LLMResponse

UsageReporter = Callable[[dict[str, int] | None], Awaitable[None]]
_reporter: ContextVar[UsageReporter | None] = ContextVar("sag_usage_reporter", default=None)


@asynccontextmanager
async def report_llm_usage(reporter: UsageReporter | None) -> AsyncIterator[None]:
    token = _reporter.set(reporter)
    try:
        yield
    finally:
        _reporter.reset(token)


async def record_llm_usage(response: LLMResponse | None) -> None:
    reporter = _reporter.get()
    if reporter is not None:
        usage = response.usage if response is not None else None
        # Providers currently normalize missing usage to zero. Treat that as
        # unknown, rather than certifying an incomplete bill as zero consumption.
        await reporter(usage.model_dump() if usage is not None and usage.total_tokens > 0 else None)
