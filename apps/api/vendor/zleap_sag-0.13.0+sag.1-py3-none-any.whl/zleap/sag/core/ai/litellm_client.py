"""litellm 多 provider LLM 客户端(可选,对齐 cognee)。

作为 `create_llm_client` 的可选实现:``LLM_PROVIDER=litellm`` 时启用。
- chat / chat_stream 走 **litellm**(OpenAI/Anthropic/本地/各中转,统一入口);
- chat_with_schema 复用 `BaseLLMClient` 的健壮结构化解析(json_repair + jsonschema),
  与默认 OpenAIClient 行为一致。

需安装 extra:``pip install zleap-sag[litellm]``。默认 provider 仍是 openai,不装 litellm 不受影响。
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from zleap.sag.core.ai.base import BaseLLMClient
from zleap.sag.core.ai.models import LLMMessage, LLMResponse, LLMUsage
from zleap.sag.core.ai.request_errors import translate_llm_provider_error
from zleap.sag.core.ai.request_options import chat_completion_request_options
from zleap.sag.exceptions import ConfigError, LLMError
from zleap.sag.utils import get_logger

logger = get_logger("ai.litellm")


def _load_litellm() -> Any:
    try:
        import litellm

        return litellm
    except ImportError as e:  # pragma: no cover - 依赖缺失路径
        raise ConfigError(
            "使用 litellm provider 需安装依赖:pip install 'zleap-sag[litellm]'"
        ) from e


class LiteLLMClient(BaseLLMClient):
    """litellm 后端的 LLM 客户端。"""

    def _model_name(self) -> str:
        # 自定义 OpenAI 兼容端点用 openai/ 前缀路由;已带 provider 前缀或无 base_url 则原样。
        model = self.config.model
        if self.config.base_url and "/" not in model:
            return f"openai/{model}"
        return model

    def _common_kwargs(self, temperature: float | None, max_tokens: int | None) -> dict[str, Any]:
        return {
            "model": self._model_name(),
            "api_key": self.config.api_key,
            "api_base": self.config.base_url,
            "temperature": self.config.temperature if temperature is None else temperature,
            "max_tokens": self.config.max_tokens if max_tokens is None else max_tokens,
            "timeout": self.config.timeout,
            "num_retries": 0,
            **chat_completion_request_options(
                model=self.config.model,
                thinking_enabled=self.config.enable_think,
            ),
        }

    async def chat(
        self,
        messages: list[LLMMessage],
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        litellm = _load_litellm()
        try:
            resp = await litellm.acompletion(
                messages=[m.to_dict() for m in messages],
                **self._common_kwargs(temperature, max_tokens),
                **kwargs,
            )
        except LLMError:
            raise
        except Exception as e:
            raise translate_llm_provider_error(
                e,
                label="litellm调用失败",
                provider="litellm",
                logger=logger,
            ) from e
        choice = resp.choices[0]
        content = getattr(choice.message, "content", None) or ""
        usage_obj = getattr(resp, "usage", None)
        usage = (
            LLMUsage(
                prompt_tokens=getattr(usage_obj, "prompt_tokens", 0) or 0,
                completion_tokens=getattr(usage_obj, "completion_tokens", 0) or 0,
                total_tokens=getattr(usage_obj, "total_tokens", 0) or 0,
            )
            if usage_obj is not None
            else LLMUsage()
        )
        return LLMResponse(
            content=content,
            model=getattr(resp, "model", self.config.model),
            usage=usage,
            finish_reason=getattr(choice, "finish_reason", "stop") or "stop",
        )

    async def chat_stream(
        self,
        messages: list[LLMMessage],
        temperature: float | None = None,
        max_tokens: int | None = None,
        include_reasoning: bool = False,
        **kwargs: Any,
    ) -> AsyncIterator[tuple[str, str | None]]:
        litellm = _load_litellm()
        try:
            stream = await litellm.acompletion(
                messages=[m.to_dict() for m in messages],
                stream=True,
                **self._common_kwargs(temperature, max_tokens),
                **kwargs,
            )
        except LLMError:
            raise
        except Exception as e:
            raise translate_llm_provider_error(
                e,
                label="litellm流式调用失败",
                provider="litellm",
                logger=logger,
            ) from e
        try:
            async for chunk in stream:
                delta = chunk.choices[0].delta
                content = getattr(delta, "content", None) or ""
                reasoning = getattr(delta, "reasoning_content", None) if include_reasoning else None
                if content or reasoning:
                    yield (content, reasoning)
        except LLMError:
            raise
        except Exception as e:
            raise translate_llm_provider_error(
                e,
                label="litellm流式调用失败",
                provider="litellm",
                logger=logger,
            ) from e
