"""OpenAI-compatible image message transport helpers."""

from __future__ import annotations

import asyncio
import base64
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from zleap.sag.core.ai.models import LLMMessage, LLMRole
from zleap.sag.exceptions import ConfigError

SUPPORTED_IMAGE_MIME_TYPES = frozenset({"image/png", "image/jpeg", "image/webp", "image/gif"})
_MIME_BY_SUFFIX = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
}


def image_part_from_bytes(
    data: bytes,
    mime_type: str,
    detail: str | None = None,
) -> dict[str, Any]:
    """Build one image_url part without logging or retaining the Base64 payload."""
    normalized_mime = mime_type.lower().split(";", 1)[0].strip()
    if normalized_mime not in SUPPORTED_IMAGE_MIME_TYPES:
        raise ConfigError(f"不支持的图片 MIME: {normalized_mime or 'unknown'}")
    if detail is not None and detail not in {"low", "high", "auto"}:
        raise ConfigError("图片 detail 必须是 low、high 或 auto")
    encoded = base64.b64encode(data).decode("ascii")
    image_url = {"url": f"data:{normalized_mime};base64,{encoded}"}
    if detail is not None:
        image_url["detail"] = detail
    return {
        "type": "image_url",
        "image_url": image_url,
    }


async def image_part_from_file(
    path: str | Path,
    detail: str | None = None,
    *,
    max_image_bytes: int | None = None,
) -> dict[str, Any]:
    """读取本地图片并构造 image part；限制值由调用方显式注入。"""
    image_path = Path(path)
    mime_type = _MIME_BY_SUFFIX.get(image_path.suffix.lower())
    if mime_type is None:
        raise ConfigError(
            f"不支持的图片格式 '{image_path.suffix}'(文件: {image_path.name});"
            f"可选: {', '.join(sorted(_MIME_BY_SUFFIX))}"
        )
    if not image_path.is_file():
        raise ConfigError(f"图片文件不存在: {image_path}")

    size = image_path.stat().st_size
    if max_image_bytes is not None and max_image_bytes < 1:
        raise ConfigError("max_image_bytes 必须大于 0")
    if max_image_bytes is not None and size > max_image_bytes:
        raise ConfigError(
            f"图片 {image_path.name} 为 {size / 1e6:.1f}MB，"
            f"超过上限 {max_image_bytes / 1e6:.1f}MB；请压缩后重试或调高 VLM_MAX_IMAGE_BYTES。"
        )
    data = await asyncio.to_thread(image_path.read_bytes)
    return image_part_from_bytes(data, mime_type, detail)


def user_message_with_images(
    text: str,
    image_parts: Sequence[dict[str, Any]],
) -> LLMMessage:
    """Build a user message containing text followed by image parts."""
    return LLMMessage(
        role=LLMRole.USER,
        content=[{"type": "text", "text": text}, *image_parts],
    )


__all__ = [
    "SUPPORTED_IMAGE_MIME_TYPES",
    "image_part_from_bytes",
    "image_part_from_file",
    "user_message_with_images",
]
