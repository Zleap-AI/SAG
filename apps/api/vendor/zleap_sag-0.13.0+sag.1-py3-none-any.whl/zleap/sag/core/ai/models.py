"""
LLM基础模型

定义LLM调用的消息、响应等数据模型
"""

from enum import StrEnum
from typing import Any

from pydantic import Field

from zleap.sag.validation import SagBaseModel as BaseModel


class LLMProvider(StrEnum):
    """LLM提供商"""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LOCAL = "local"


class LLMRole(StrEnum):
    """消息角色"""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


class LLMMessage(BaseModel):
    """LLM消息模型

    ``content`` 支持两种形态（OpenAI 兼容）：
    - ``str``：纯文本，历史路径逐字节不变；
    - ``list[dict]``：多模态 part 数组，如
      ``[{"type": "text", ...}, {"type": "image_url", ...}]``，由
      ``core.ai.image_messages`` 构造。
    """

    role: LLMRole = Field(..., description="角色")
    content: str | list[dict[str, Any]] = Field(..., description="消息内容(文本或多模态part数组)")

    def to_dict(self) -> dict[str, Any]:
        """转换为字典"""
        # Pylint 误认为 role 是 FieldInfo，实际上是 LLMRole 枚举
        return {"role": self.role.value, "content": self.content}  # pylint: disable=no-member


class LLMUsage(BaseModel):
    """Token使用统计"""

    prompt_tokens: int = Field(default=0, description="输入token数")
    completion_tokens: int = Field(default=0, description="输出token数")
    total_tokens: int = Field(default=0, description="总token数")


class LLMResponse(BaseModel):
    """LLM响应模型"""

    content: str = Field(..., description="响应内容")
    model: str = Field(..., description="使用的模型")
    usage: LLMUsage = Field(default_factory=LLMUsage, description="Token使用统计")
    finish_reason: str = Field(default="stop", description="结束原因")

    @property
    def total_tokens(self) -> int:
        """总token数"""
        # Pylint 误认为 usage 是 FieldInfo，实际上是 LLMUsage 模型
        return self.usage.total_tokens  # pylint: disable=no-member


class ModelConfig(BaseModel):
    """LLM/VLM 客户端配置，由 Engine 的资源工厂显式注入。"""

    provider: LLMProvider = Field(..., description="提供商")
    model: str = Field(..., description="模型名称")
    api_key: str = Field(..., description="API密钥")
    base_url: str | None = Field(default=None, description="基础URL")

    # 行为参数（必填，由 factory 注入）
    temperature: float = Field(..., ge=0.0, le=2.0, description="温度参数")
    max_tokens: int = Field(..., ge=1, description="最大输出token数")
    top_p: float = Field(..., ge=0.0, le=1.0, description="top_p参数")
    frequency_penalty: float = Field(..., ge=-2.0, le=2.0, description="频率惩罚")
    presence_penalty: float = Field(..., ge=-2.0, le=2.0, description="存在惩罚")

    # 可靠性参数
    timeout: int = Field(default=600, ge=1, description="超时时间（秒）")
    max_retries: int = Field(default=5, ge=0, description="最大重试次数")
    enable_think: bool = Field(default=False, description="是否请求模型输出思考过程")
    # 结构化输出模式（json_schema/json_object/prompt_only 或注册表中的扩展名）
    # 合法性由 core.ai.structured.get_formatter 在调用边界 fail loud 校验，此处仅作载体。
    structured_output_mode: str = Field(
        default="json_schema",
        description="结构化输出模式: json_schema | json_object | prompt_only，或注册表中的扩展名",
    )
    data_inspection: bool = Field(default=True, description="是否启用上游内容检查")
