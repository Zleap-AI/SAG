"""
AI模块

提供LLM调用、Embedding生成等AI功能
"""

from zleap.sag.core.ai.base import BaseLLMClient, LLMRetryClient
from zleap.sag.core.ai.embedding import EmbeddingClient
from zleap.sag.core.ai.factory import (
    create_embedding_client,
    create_llm_client,
    create_vlm_client,
)
from zleap.sag.core.ai.llm import OpenAIClient
from zleap.sag.core.ai.models import (
    LLMMessage,
    LLMProvider,
    LLMResponse,
    LLMRole,
    LLMUsage,
    ModelConfig,
)

__all__ = [
    # Base
    "BaseLLMClient",
    "LLMRetryClient",
    # Models
    "ModelConfig",
    "LLMMessage",
    "LLMResponse",
    "LLMUsage",
    "LLMProvider",
    "LLMRole",
    # OpenAI
    "OpenAIClient",
    # Factory
    "create_llm_client",
    "create_vlm_client",
    "create_embedding_client",
    # Embedding
    "EmbeddingClient",
]
