"""
rerank模型排序服务

提供统一的事项/段落排序能力，支持 302.ai 等兼容的 Rerank API
"""

from typing import Any

import aiohttp

from zleap.sag._safe_error import safe_error_type
from zleap.sag.core.ai.request_errors import translate_ai_provider_error
from zleap.sag.exceptions import AIError
from zleap.sag.utils import get_logger

logger = get_logger("ai.rerank")


def _get_rerank_template_name(model: str):
    """仅按模型能力判断模板；storage_mode 不得改变提示词语义。"""
    model_lower = model.lower()
    if "qwen3" in model_lower and "rerank" in model_lower:
        return "qwen3_rerank"
    return None


def _load_rerank_template(template_name: str, prompt_manager: Any = None):
    """从 PromptManager 加载指定 rerank 模板配置，返回模板字段字典；加载失败返回 None"""
    try:
        if prompt_manager is None:
            return None
        pm = prompt_manager
        config = pm.get_template_config(template_name)
        return {
            "prefix": config.get("prefix", ""),
            "suffix": config.get("suffix", ""),
            "query_template": config.get("query_template", ""),
            "doc_template": config.get("doc_template", ""),
            "default_instruction": config.get("default_instruction", ""),
        }
    except Exception as e:
        logger.warning(
            "加载 Rerank 模板失败，跳过 prompt 组装",
            extra={"error_type": safe_error_type(e)},
        )
        return None


def _format_with_template(query, documents, instruction, tpl):
    """使用 Qwen3-Rerank 模板组装 query 和 documents，返回 (formatted_query, formatted_docs)"""
    formatted_query = tpl["query_template"].format(
        prefix=tpl["prefix"], instruction=instruction, query=query
    )
    formatted_docs = [
        tpl["doc_template"].format(doc=doc, suffix=tpl["suffix"]) for doc in documents
    ]
    return formatted_query, formatted_docs


class RerankClient:
    """
    Rerank客户端

    支持 302.ai Rerank API
    """

    def __init__(
        self,
        model: str,
        base_url: str,
        api_key: str,
        endpoint: str = "/rerank",
        prompt_manager: Any = None,
        timeout: int = 30,
    ):
        """
        初始化 Rerank 客户端

        Args:
            model: 模型名称
            base_url: API 地址
            api_key: API 密钥
            timeout: 单次请求超时秒数
        """
        self.model = model
        self.base_url = base_url.rstrip("/")
        endpoint = endpoint.strip()
        if not endpoint.startswith("/"):
            endpoint = "/" + endpoint
        self.endpoint = endpoint
        self.api_key = api_key
        self.prompt_manager = prompt_manager
        self.timeout = timeout

        logger.info(
            "Rerank客户端初始化完成",
            extra={
                "model": self.model,
                "base_url": self.base_url,
                "timeout": self.timeout,
            },
        )

    async def rerank(
        self,
        query: str,
        documents: list[dict[str, str]],
        top_n: int | None = None,
        return_documents: bool | None = False,
        use_prompt_template: bool = False,
        instruction: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        使用 Rerank 模型对文档重新排序

        Args:
            query: 查询文本
            documents: 文档列表，格式 [{"id": "...", "text": "..."}, ...]
            top_n: 返回前 N 个结果
            return_documents: 是否在响应中返回文档（传递给API，不影响客户端返回结构）
            use_prompt_template: 是否注入 Qwen3-Rerank 提示词模板
            instruction: 重排指令，仅在 use_prompt_template=True 时生效，默认使用模板中的 default_instruction

        Returns:
            排序后的结果列表，格式：
            [
                {
                    "index": 0,           # 原文档索引
                    "id": "doc_id",       # 文档 ID
                    "score": 0.95         # 相关性分数
                },
                ...
            ]
            注意：不返回 text，调用方通过 id 从原始 documents 获取
        """
        if not documents:
            logger.warning("Rerank 调用失败：文档列表为空")
            return []

        top_n = top_n or len(documents)
        logger.warning(f"Rerank排序 返回 top-{top_n} 个事项/段落的排序结果")
        # 提取文档文本
        texts = [doc.get("text", "") for doc in documents]

        # 如果需要，使用 Rerank 模型专用模板组装 query 和 documents
        if use_prompt_template:
            tpl_name = _get_rerank_template_name(self.model)
            if tpl_name:
                tpl = _load_rerank_template(tpl_name, self.prompt_manager)
                if tpl:
                    inst = instruction or tpl["default_instruction"]
                    query, texts = _format_with_template(query, texts, inst, tpl)
                    logger.info(f"已注入 Rerank 提示词模板: {tpl_name}")
                else:
                    logger.warning(
                        f"use_prompt_template=True 但模板 '{tpl_name}' 加载失败，使用原始文本"
                    )
            else:
                logger.info(f"模型 '{self.model}' 无专用模板，使用原始文本")

        # 构建 Rerank 请求 URL：
        # - 若 base_url 已包含 rerank 端点路径（如 /rerank、/reranks），直接使用，避免重复拼接
        # - 否则拼接配置的 self.endpoint（默认 /rerank，可通过 RERANK_ENDPOINT 自定义）
        base_lower = self.base_url.lower()
        if (
            base_lower.endswith("/rerank")
            or base_lower.endswith("/reranks")
            or base_lower.endswith(self.endpoint.lower())
        ):
            url = self.base_url
        else:
            url = f"{self.base_url}{self.endpoint}"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.model,
            "query": query,
            "top_n": top_n,
            "return_documents": return_documents,  # 不返回文档内容，节省带宽
            "documents": texts,
        }

        try:
            client_timeout = aiohttp.ClientTimeout(total=self.timeout)
            async with aiohttp.ClientSession(timeout=client_timeout) as session:
                async with session.post(url, headers=headers, json=payload) as resp:
                    if resp.status != 200:
                        raise translate_ai_provider_error(
                            None,
                            label="Rerank调用失败",
                            provider="rerank",
                            logger=logger,
                            status_code=resp.status,
                        )

                    resp_json = await resp.json()

            # 解析响应（不返回 text，调用方通过 id 从原始 docs 获取）
            results = []
            for item in resp_json.get("results", []):
                idx = item.get("index")
                results.append(
                    {
                        "index": idx,
                        "id": documents[idx].get("id", str(idx)),
                        "score": item.get("relevance_score", item.get("score", 0.0)),
                    }
                )

            logger.info(
                "Rerank 完成: query_chars=%d, 文档数=%d, 返回=%d",
                len(query),
                len(documents),
                len(results),
            )
            return results

        except AIError:
            raise
        except Exception as e:
            raise translate_ai_provider_error(
                e,
                label="Rerank调用失败",
                provider="rerank",
                logger=logger,
            ) from e
