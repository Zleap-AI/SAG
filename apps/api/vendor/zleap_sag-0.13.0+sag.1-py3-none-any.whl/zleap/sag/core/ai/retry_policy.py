"""AI retry policy derived solely from the structured SAG error contract."""

from __future__ import annotations

from zleap.sag.exceptions import SagError


def should_retry_ai_error(error: BaseException) -> bool:
    """Return the retry decision encoded by a normalized ``SagError``."""

    return isinstance(error, SagError) and error.retryable


__all__ = ["should_retry_ai_error"]
