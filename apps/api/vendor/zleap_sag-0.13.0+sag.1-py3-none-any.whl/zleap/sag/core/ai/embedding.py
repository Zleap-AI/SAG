"""
Embedding生成服务

提供统一的文本向量化能力，所有模块共享
"""

import asyncio
from functools import lru_cache
from typing import Any

from zleap.sag._safe_error import safe_error_type
from zleap.sag.core.ai.request_errors import translate_ai_provider_error
from zleap.sag.core.ai.retry_policy import should_retry_ai_error
from zleap.sag.exceptions import AIError, StateError
from zleap.sag.utils import get_logger

logger = get_logger("ai.embedding")


@lru_cache(maxsize=1)
def _token_encoding():
    """cl100k_base 与自建模型分词器不完全一致，仅作保守估算。"""
    try:
        import tiktoken

        return tiktoken.get_encoding("cl100k_base")
    except Exception:  # noqa: BLE001 - tiktoken 缺失时退化为字符估算
        return None


def _safe_token_budget(max_tokens: int) -> int:
    """留出安全余量：cl100k_base 与服务端分词器不一致，中文场景常低估 token 数。

    实测按 cl100k 精确裁到 512 后，服务端仍可能数出 517，因此按 90% 取预算。
    """
    return max(1, min(max_tokens - 1, int(max_tokens * 0.9)))


def truncate_for_embedding(text: str, max_tokens: int) -> str:
    """把单条文本裁剪到 embedding 模型可接受的 token 上限内。"""
    if max_tokens <= 0 or not text:
        return text

    budget = _safe_token_budget(max_tokens)
    # 任一分词器下 token 数都不会超过字符数，短文本可直接跳过编码。
    if len(text) <= budget:
        return text

    encoding = _token_encoding()
    if encoding is not None:
        tokens = encoding.encode(text)
        if len(tokens) <= budget:
            return text
        truncated = encoding.decode(tokens[:budget])
    else:
        # 退化路径：tiktoken 缺失时按最保守的 1 字/token 估算
        truncated = text[:budget]

    logger.warning(
        "embedding输入超长，已截断",
        extra={
            "original_chars": len(text),
            "truncated_chars": len(truncated),
            "max_tokens": max_tokens,
            "token_budget": budget,
        },
    )
    return truncated


class EmbeddingClient:
    """
    Embedding客户端

    统一的文本向量化服务，支持：
    - OpenAI Embedding API
    - 自定义Embedding服务
    - 本地Embedding模型（未来扩展）
    """

    def __init__(
        self,
        model: str,
        api_key: str,
        base_url: str | None = None,
        max_tokens: int = 512,
        timeout: int = 60,
        max_retries: int = 3,
        *,
        schema_dimensions: int | None = None,
        request_dimensions: int | None = None,
    ) -> None:
        """
        初始化Embedding客户端

        Args:
            model: 模型名称
            api_key: API 密钥
            base_url: API 地址
            schema_dimensions: 存储维度及返回向量校验
            request_dimensions: 请求维度；未传或 None 时不发送
            max_tokens: 单条输入的最大 token 数
            timeout: 请求超时秒数
            max_retries: 请求重试次数
        """
        from openai import AsyncOpenAI

        self.model = model
        self.base_url = base_url
        self.api_key = api_key
        self.schema_dimensions = schema_dimensions
        self.request_dimensions = request_dimensions
        self.max_tokens = max_tokens
        self.max_retries = max_retries

        # 初始化OpenAI客户端
        client_kwargs: dict[str, Any] = {"api_key": self.api_key}
        if self.base_url:
            client_kwargs["base_url"] = self.base_url
        # 不设超时会落到 SDK 默认的 600s，网关卡住时单次检索会挂十分钟
        client_kwargs["timeout"] = timeout
        # 重试由 SAG 统一负责，避免 SDK 重试与上层重试相乘。
        client_kwargs["max_retries"] = 0

        self.client = AsyncOpenAI(**client_kwargs)

        logger.info(
            "Embedding客户端初始化完成",
            extra={
                "model": self.model,
                "schema_dimensions": self.schema_dimensions,
                "request_dimensions": self.request_dimensions,
                "max_tokens": self.max_tokens,
            },
        )

    def _read_embeddings(self, data: list[Any], *, expected_count: int) -> list[list[float]]:
        """Validate the provider response before vectors enter persistent storage."""
        if len(data) != expected_count:
            raise AIError(f"Embedding服务返回数量错误: 期望 {expected_count}，实际 {len(data)}")

        indexes = [item.index for item in data]
        if sorted(indexes) != list(range(expected_count)):
            raise AIError("Embedding服务返回了重复或越界的结果索引")

        ordered = sorted(data, key=lambda item: item.index)
        embeddings = [[float(value) for value in item.embedding] for item in ordered]
        if any(not vector for vector in embeddings):
            raise AIError("Embedding服务返回了空向量")
        expected_dimensions = self.schema_dimensions
        if expected_dimensions is not None:
            invalid_dimensions = {
                len(vector) for vector in embeddings if len(vector) != expected_dimensions
            }
            if invalid_dimensions:
                raise AIError(
                    "Embedding服务返回维度错误: "
                    f"期望 {expected_dimensions}，实际 {sorted(invalid_dimensions)}"
                )
        return embeddings

    async def _create_embeddings(self, input_data: str | list[str], *, label: str) -> Any:
        request: dict[str, Any] = {"input": input_data, "model": self.model}
        if self.request_dimensions is not None:
            request["dimensions"] = self.request_dimensions

        for attempt in range(self.max_retries + 1):
            try:
                return await self.client.embeddings.create(**request)
            except Exception as exc:
                error = (
                    exc
                    if isinstance(exc, AIError)
                    else translate_ai_provider_error(
                        exc,
                        label=label,
                        provider="openai",
                        logger=logger,
                    )
                )
                if not should_retry_ai_error(error) or attempt >= self.max_retries:
                    if error is exc:
                        raise
                    raise error from exc
                delay = min(0.5 * (2**attempt), 8.0)
                logger.warning(
                    "Embedding调用失败，%.1fs后重试 (尝试 %d/%d)",
                    delay,
                    attempt + 1,
                    self.max_retries,
                    extra={"error_type": safe_error_type(error)},
                )
                await asyncio.sleep(delay)

        raise StateError("Embedding 重试循环异常退出")  # pragma: no cover

    async def generate(self, text: str) -> list[float]:
        """
        生成文本的embedding向量

        Args:
            text: 文本内容

        Returns:
            embedding向量

        Raises:
            AIError: 生成失败
        """
        try:
            truncated = truncate_for_embedding(text, self.max_tokens)
            response = await self._create_embeddings(truncated, label="生成embedding失败")

            embedding = self._read_embeddings(response.data, expected_count=1)[0]

            logger.debug(
                "生成embedding成功",
                extra={
                    "text_length": len(text),
                    "vector_dim": len(embedding),
                },
            )

            return embedding

        except AIError:
            raise
        except Exception as e:
            logger.error("生成embedding失败\n%s", e, extra={"error_type": safe_error_type(e)})
            raise AIError(f"生成embedding失败：{e}", cause=e) from e

    async def batch_generate(self, texts: list[str]) -> list[list[float]]:
        """
        批量生成embedding向量

        Args:
            texts: 文本列表

        Returns:
            embedding向量列表

        Raises:
            AIError: 生成失败
        """
        if not texts:
            return []
        try:
            truncated = [truncate_for_embedding(text, self.max_tokens) for text in texts]
            response = await self._create_embeddings(truncated, label="批量生成embedding失败")

            embeddings = self._read_embeddings(response.data, expected_count=len(texts))

            logger.debug(
                "批量生成embedding成功",
                extra={
                    "batch_size": len(texts),
                    "vector_dim": len(embeddings[0]) if embeddings else 0,
                },
            )

            return embeddings

        except AIError:
            raise
        except Exception as e:
            logger.error("批量生成embedding失败\n%s", e, extra={"error_type": safe_error_type(e)})
            raise AIError(f"批量生成embedding失败：{e}", cause=e) from e

    async def close(self) -> None:
        """Close the SDK HTTP pool owned by this client."""
        await self.client.close()
