"""Provider-specific chat completion request options."""

from __future__ import annotations

from typing import Any


def chat_completion_request_options(
    *,
    model: str,
    thinking_enabled: bool,
) -> dict[str, Any]:
    """Return the explicit thinking switch accepted by Qwen-compatible APIs.

    Qwen hybrid-thinking models can think by default, so omission is not the
    same as disabling it. Other model families receive no non-standard option
    while thinking is disabled. A gateway must accept the extension during
    connection validation before a thinking-enabled model is used in runtime.
    """

    if thinking_enabled or "qwen" in model.casefold():
        return {"extra_body": {"enable_thinking": thinking_enabled}}
    return {}


__all__ = ["chat_completion_request_options"]
