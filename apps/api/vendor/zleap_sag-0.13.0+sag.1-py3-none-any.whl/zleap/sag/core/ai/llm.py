"""
OpenAI LLM客户端实现

注意:
- 支持标准OpenAI模型 (sophnet/Qwen3-30B-A3B-Thinking-2507, gpt-3.5-turbo等)
- 支持思考模型 (Thinking Models): 某些模型(如Qwen3-30B-A3B-Thinking)会将推理过程
  放在reasoning_content字段中而不是content字段。本实现会自动检测并处理这种情况。
"""

from collections.abc import AsyncIterator, Iterable
from typing import Any, cast

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionMessageParam

from zleap.sag._safe_error import safe_error_type
from zleap.sag.core.ai.base import BaseLLMClient
from zleap.sag.core.ai.models import LLMMessage, LLMResponse, LLMUsage, ModelConfig
from zleap.sag.core.ai.request_errors import translate_llm_provider_error
from zleap.sag.core.ai.request_options import chat_completion_request_options
from zleap.sag.exceptions import LLMError
from zleap.sag.utils import get_logger

logger = get_logger("ai.openai")


def _preview(content: Any, limit: int = 10_000) -> str:
    """生成有界日志预览；多模态内容只显示图片载荷大小，不输出图片数据。"""
    if isinstance(content, str):
        return content[:limit] + ("..." if len(content) > limit else "")
    if not isinstance(content, list):
        return str(content)[:limit]

    parts: list[str] = []
    for part in content:
        if not isinstance(part, dict):
            parts.append(str(part)[:200])
            continue
        if part.get("type") == "text":
            text = str(part.get("text", ""))
            parts.append(text[:200] + ("..." if len(text) > 200 else ""))
        elif part.get("type") == "image_url":
            image_url = part.get("image_url")
            url = (
                str(image_url.get("url", ""))
                if isinstance(image_url, dict)
                else str(image_url or "")
            )
            parts.append(f"<image {len(url) // 1000}KB>")
        else:
            parts.append(f"<{part.get('type', 'unknown')}>")
    preview = " | ".join(parts)
    return preview[:limit] + ("..." if len(preview) > limit else "")


def _content_length(content: Any) -> int:
    """统计可记录的文本字符数，排除 image_url 中可能包含的 base64 数据。"""
    if isinstance(content, str):
        return len(content)
    if not isinstance(content, list):
        return 0
    return sum(
        len(str(part.get("text", "")))
        for part in content
        if isinstance(part, dict) and part.get("type") == "text"
    )


class OpenAIClient(BaseLLMClient):
    """OpenAI客户端实现"""

    def __init__(self, config: ModelConfig) -> None:
        """
        初始化OpenAI客户端

        Args:
            config: LLM配置
        """
        super().__init__(config)

        # 构建默认 headers（用于控制内容过滤等）
        default_headers = self._build_default_headers()

        # 创建AsyncOpenAI客户端
        self.client = AsyncOpenAI(
            api_key=config.api_key,
            base_url=config.base_url,
            timeout=config.timeout,
            max_retries=0,
            default_headers=default_headers if default_headers else None,
        )

    def _build_default_headers(self) -> dict:
        """
        构建默认请求头

        Returns:
            默认请求头字典
        """

        headers = {}

        # 如果禁用内容过滤（绿网），添加 DashScope header
        if not self.config.data_inspection:
            headers["X-DashScope-DataInspection"] = '{"input": "disable", "output": "disable"}'

        return headers

    async def chat(
        self,
        messages: list[LLMMessage],
        temperature: float | None = None,
        max_tokens: int | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """
        OpenAI聊天补全

        Args:
            messages: 消息列表
            temperature: 温度参数
            max_tokens: 最大输出token数
            **kwargs: 其他参数

        Returns:
            LLM响应

        Raises:
            LLMError: 调用失败
            LLMTimeoutError: 调用超时
            LLMRateLimitError: 速率限制
        """
        try:
            # 准备消息
            api_messages = self._prepare_messages(messages)
            # 记录使用的模型信息
            logger.info(
                "🤖 调用 LLM - 模型: %s, temperature: %.2f, max_tokens: %s, "
                "timeout: %s, enable_think: %s, messages: %d, input_chars: %d",
                self.config.model,
                temperature or self.config.temperature,
                max_tokens or self.config.max_tokens or "未设置",
                self.config.timeout,
                self.config.enable_think,
                len(messages),
                sum(_content_length(message.content) for message in messages),
            )

            # 调用API（使用 cast 显式类型转换）
            response = await self.client.chat.completions.create(
                model=self.config.model,
                messages=cast(Iterable[ChatCompletionMessageParam], api_messages),
                temperature=temperature or self.config.temperature,
                max_tokens=max_tokens or self.config.max_tokens,  # 从配置读取，不硬编码
                **chat_completion_request_options(
                    model=self.config.model,
                    thinking_enabled=self.config.enable_think,
                ),
                **kwargs,
            )

            # 解析响应
            choice = response.choices[0]
            usage = response.usage

            # 处理响应内容
            content = choice.message.content
            reasoning = getattr(choice.message, "reasoning_content", None) or getattr(
                choice.message, "reasoning", None
            )

            logger.debug(
                "OpenAI响应: content_chars=%d, reasoning_chars=%d, finish_reason=%s",
                len(content or ""),
                len(reasoning or ""),
                choice.finish_reason,
            )
            #  添加总 token 数
            if usage is not None:
                logger.info(
                    "Token usage | prompt: %d, completion: %d, total: %d",
                    usage.prompt_tokens,
                    usage.completion_tokens,
                    usage.total_tokens,
                )

            return LLMResponse(
                content=content or "",
                model=response.model,
                usage=LLMUsage(
                    prompt_tokens=usage.prompt_tokens if usage else 0,
                    completion_tokens=usage.completion_tokens if usage else 0,
                    total_tokens=usage.total_tokens if usage else 0,
                ),
                finish_reason=choice.finish_reason or "stop",
            )

        except LLMError:
            raise
        except Exception as e:
            raise translate_llm_provider_error(
                e,
                label="OpenAI调用失败",
                provider="openai",
                logger=logger,
            ) from e

    async def chat_stream(
        self,
        messages: list[LLMMessage],
        temperature: float | None = None,
        max_tokens: int | None = None,
        include_reasoning: bool = False,
        **kwargs: Any,
    ) -> AsyncIterator[tuple[str, str | None]]:
        """
        OpenAI流式聊天补全

        Args:
            messages: 消息列表
            temperature: 温度参数
            max_tokens: 最大输出token数
            include_reasoning: 是否返回推理内容（reasoning_content）
            **kwargs: 其他参数

        Yields:
            元组 (content, reasoning) - content为内容片段，reasoning为推理片段（如果有）

        Raises:
            LLMError: 调用失败
        """
        try:
            # 记录使用的模型信息（添加max_tokens）
            logger.info(
                "🤖 调用流式LLM - 模型: %s, temperature: %.2f, max_tokens: %s, "
                "timeout: %s, enable_think: %s, messages: %d, input_chars: %d",
                self.config.model,
                temperature or self.config.temperature,
                max_tokens or self.config.max_tokens or "未设置",
                self.config.timeout,
                self.config.enable_think,
                len(messages),
                sum(_content_length(message.content) for message in messages),
            )

            # 准备消息
            api_messages = self._prepare_messages(messages)

            # 调用流式API（使用 cast 显式类型转换）
            stream = await self.client.chat.completions.create(
                model=self.config.model,
                messages=cast(Iterable[ChatCompletionMessageParam], api_messages),
                temperature=temperature or self.config.temperature,
                max_tokens=max_tokens or self.config.max_tokens,
                stream=True,
                **chat_completion_request_options(
                    model=self.config.model,
                    thinking_enabled=self.config.enable_think,
                ),
                **kwargs,
            )

            # 逐个生成内容片段
            async for chunk in stream:
                if chunk.choices:
                    delta = chunk.choices[0].delta
                    content = delta.content if delta.content else None
                    reasoning = None

                    # 如果需要推理内容，尝试获取reasoning_content
                    if include_reasoning:
                        reasoning = getattr(delta, "reasoning_content", None) or getattr(
                            delta, "reasoning", None
                        )

                    # 只在有内容或推理时yield
                    if content or reasoning:
                        yield (content or "", reasoning)

        except LLMError:
            raise
        except Exception as e:
            raise translate_llm_provider_error(
                e,
                label="OpenAI流式调用失败",
                provider="openai",
                logger=logger,
            ) from e

    async def close(self) -> None:
        """关闭OpenAI客户端，释放HTTP连接"""
        try:
            await self.client.close()
            logger.debug("OpenAI客户端已关闭")
        except Exception as e:
            logger.warning(
                "关闭OpenAI客户端时出错",
                extra={"error_type": safe_error_type(e)},
            )
