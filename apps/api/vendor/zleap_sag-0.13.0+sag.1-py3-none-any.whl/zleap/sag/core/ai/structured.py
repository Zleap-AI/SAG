"""
结构化输出模式注册表

把 (mode, response_schema) 翻译成传给底层 SDK 的 ``response_format`` 载荷。

模式可扩展：内置 ``json_schema`` / ``json_object`` / ``prompt_only``，宿主可用
``@register_formatter`` 注册自定义模式。未知模式 fail loud（抛 ``ConfigError``），
绝不静默降级为"不注入"。模式名大小写不敏感（注册与查询统一归一化为小写）。
"""

from __future__ import annotations

import logging
from abc import ABC
from collections.abc import Callable, Sequence
from enum import StrEnum
from typing import TYPE_CHECKING, Any, TypeVar, overload

from zleap.sag.exceptions import ConfigError, StateError

if TYPE_CHECKING:
    from zleap.sag.core.ai.models import LLMMessage

logger = logging.getLogger("zleap.sag.core.ai.structured")

BUILTIN_MODES = ("json_schema", "json_object", "prompt_only")


class StructuredOutputMode(StrEnum):
    """内置结构化输出模式；注册表仍可扩展其他字符串模式。"""

    JSON_SCHEMA = "json_schema"
    JSON_OBJECT = "json_object"
    PROMPT_ONLY = "prompt_only"


def _normalize_mode(name: str) -> str:
    """模式名归一化：去首尾空白 + 小写。

    注册（``register_formatter``）与查询（``get_formatter``）统一走这里，使模式名
    大小写不敏感——引擎级配置（``LLMConfig``）本就转小写，请求级路径
    （``SearchOptions``/``AtomicConfig``）归一化后与其对齐，避免大写自定义模式无法配置。
    """
    return name.strip().lower()


class StructuredOutputFormatter(ABC):
    """结构化输出格式化器（无状态，注册类而非实例）。

    - ``build``: 返回传给 ``chat(**kwargs)`` 的 ``response_format`` 载荷；
      ``None`` 表示不注入。返回 ``None`` 的路径**只**允许 ``prompt_only`` 与
      「``json_schema`` 且无 schema」，绝不把"模式查不到"当作"关闭注入"。
    - ``validate_messages``: 可选钩子，检查消息是否满足该模式的约束（默认 no-op）。
    """

    mode: str

    def build(self, response_schema: dict[str, Any] | None) -> dict[str, Any] | None:
        """返回 ``response_format`` 载荷；``None`` 表示不注入。"""
        raise StateError(f"{type(self).__name__} 必须实现 build()")

    def validate_messages(self, messages: Sequence[LLMMessage]) -> None:
        """检查消息约束；不满足时只告警不抛错（默认 no-op）。"""
        return None


class JsonSchemaFormatter(StructuredOutputFormatter):
    """OpenAI JSON Schema mode（默认）：服务端按 schema 约束输出。"""

    mode = "json_schema"

    def build(self, response_schema: dict[str, Any] | None) -> dict[str, Any] | None:
        if not response_schema:
            # 无 schema 时不注入，严格保持既有 chat_with_schema 语义。
            return None
        return {
            "type": "json_schema",
            "json_schema": {"name": "structured_output", "schema": response_schema},
        }


class JsonObjectFormatter(StructuredOutputFormatter):
    """DeepSeek 等厂商的 ``json_object`` 模式：仅约束输出为 JSON 对象。

    注意：该模式下 prompt 需包含 "json" 字样（OpenAI/DeepSeek 约束），否则请求
    可能被服务端拒绝。此处只告警不抛错——不同厂商约束不同，硬抛会误伤能正常
    工作的组合。
    """

    mode = "json_object"

    def build(self, response_schema: dict[str, Any] | None) -> dict[str, Any] | None:
        return {"type": "json_object"}

    def validate_messages(self, messages: Sequence[LLMMessage]) -> None:
        texts: list[str] = []
        for message in messages:
            content = getattr(message, "content", "") or ""
            if isinstance(content, str):
                texts.append(content)
                continue
            texts.extend(
                str(part.get("text", ""))
                for part in content
                if isinstance(part, dict) and part.get("type") == "text"
            )
        if not any("json" in text.lower() for text in texts):
            logger.warning(
                "structured_output 模式 json_object 要求 prompt 包含 'json' 字样，"
                "当前消息中未检测到；若服务端拒绝请求，请在 SYSTEM 提示词中显式说明 JSON 输出格式"
            )


class PromptOnlyFormatter(StructuredOutputFormatter):
    """仅靠提示词约束格式：不注入 ``response_format``，本地仍解析 + 校验 JSON。"""

    mode = "prompt_only"

    def build(self, response_schema: dict[str, Any] | None) -> dict[str, Any] | None:
        return None


F = TypeVar("F", bound=type[StructuredOutputFormatter])

_FORMATTERS: dict[str, type[StructuredOutputFormatter]] = {}


@overload
def register_formatter(
    cls: F,
    *,
    mode: str | None = None,
    replace: bool = False,
) -> F: ...


@overload
def register_formatter(
    cls: None = None,
    *,
    mode: str | None = None,
    replace: bool = False,
) -> Callable[[F], F]: ...


def register_formatter(
    cls: F | None = None,
    *,
    mode: str | None = None,
    replace: bool = False,
) -> F | Callable[[F], F]:
    """注册一个结构化输出模式。

    同时支持两种用法::

        @register_formatter
        class MyFormatter(StructuredOutputFormatter):
            mode = "my_mode"
            ...

        @register_formatter(mode="my_mode")
        class MyFormatter(StructuredOutputFormatter):
            ...

    重复注册默认抛 ``ConfigError``；``replace=True`` 可覆盖既有实现。
    """

    def _register(k: F) -> F:
        raw_mode = mode if mode is not None else getattr(k, "mode", "")
        if not isinstance(raw_mode, str):
            raise ConfigError("register_formatter 的 mode 必须是字符串")
        name = _normalize_mode(raw_mode)
        if not name:
            raise ConfigError("register_formatter 需要 mode（类属性或显式传入）")
        if name in _FORMATTERS and not replace:
            raise ConfigError(f"结构化输出模式 {name!r} 已注册；如需覆盖请传 replace=True")
        _FORMATTERS[name] = k
        return k

    if cls is not None:
        return _register(cls)
    return _register


def get_formatter(mode: str) -> StructuredOutputFormatter:
    """按模式名取格式化器实例；未知模式抛 ``ConfigError``（fail loud，不静默降级）。

    模式名大小写不敏感：与注册表键的归一化一致，任意大小写均可解析。
    """
    cls = _FORMATTERS.get(_normalize_mode(mode))
    if cls is None:
        raise ConfigError(f"未知结构化输出模式 {mode!r}；可选: {', '.join(available_modes())}")
    return cls()


def build_response_format(
    mode: str, response_schema: dict[str, Any] | None
) -> dict[str, Any] | None:
    """便捷入口：按模式名生成 ``response_format`` 载荷（未知模式抛 ConfigError）。"""
    return get_formatter(mode).build(response_schema)


def available_modes() -> list[str]:
    """当前已注册的模式名（供配置校验与错误提示）。"""
    return sorted(_FORMATTERS)


# 内置模式：模块导入即注册。
register_formatter(JsonSchemaFormatter)
register_formatter(JsonObjectFormatter)
register_formatter(PromptOnlyFormatter)


def structured_response_format(
    mode: str | StructuredOutputMode,
    response_schema: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """兼容 dev 的固定模式入口，并统一委托给可扩展注册表。"""
    return build_response_format(str(mode), response_schema)


__all__ = [
    "BUILTIN_MODES",
    "StructuredOutputFormatter",
    "StructuredOutputMode",
    "available_modes",
    "build_response_format",
    "get_formatter",
    "register_formatter",
    "structured_response_format",
]
