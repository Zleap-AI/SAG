"""Classification and translation for AI provider failures.

LLM provider failures are logged with their original exception text and response
body for operator diagnosis. Normalized exceptions and durable operation records
continue to use bounded categories. Embedding and rerank failures retain their
bounded logging behavior.
"""

from __future__ import annotations

import json
import logging
import re
from enum import StrEnum
from typing import Any

from zleap.sag._safe_error import safe_error_type
from zleap.sag.exceptions import (
    AIAuthError,
    AIError,
    AIInvalidRequestError,
    AITransientError,
    LLMAuthError,
    LLMConfigurationError,
    LLMContentPolicyError,
    LLMContextLengthError,
    LLMError,
    LLMInvalidRequestError,
    LLMRateLimitError,
    LLMTimeoutError,
    LLMTransientError,
)


class InvalidRequestKind(StrEnum):
    CONTENT_POLICY = "content_policy"
    CONTEXT_LENGTH = "context_length"
    INVALID_PARAMETER = "invalid_parameter"
    MODEL_NOT_FOUND = "model_not_found"
    UNKNOWN = "unknown"


class ProviderFailureKind(StrEnum):
    AUTH = "auth"
    INVALID_REQUEST = "invalid_request"
    TIMEOUT = "timeout"
    RATE_LIMIT = "rate_limit"
    TRANSIENT = "transient"
    UNKNOWN = "unknown"


_CONTENT_POLICY_MARKERS = (
    "content_filter",
    "content_policy",
    "data_inspection_failed",
    "datainspectionfailed",
    "inappropriate content",
    "moderation",
    "policy violation",
    "safety violation",
    "sensitive content",
)
_CONTEXT_LENGTH_MARKERS = (
    "context_length_exceeded",
    "context window",
    "input is too long",
    "input length",
    "maximum context",
    "max context",
    "prompt is too long",
    "request too large",
    "too many tokens",
)
_INVALID_PARAMETER_MARKERS = (
    "invalid_parameter",
    "invalid parameter",
    "parameter_error",
    "unsupported_parameter",
    "unsupported parameter",
    "response_format",
    "json_schema",
)
_MODEL_NOT_FOUND_MARKERS = (
    "model_not_found",
    "model not found",
    "unknown model",
)
_SAFE_TEXT_LIMIT = 16_384
_BINARY_CHAR_RATIO = 0.05
_ESCAPED_CONTROL = re.compile(r"\\u00[01][0-9a-fA-F]|\\x[01][0-9a-fA-F]")
_SAFE_PROVIDER_CODE = re.compile(r"[A-Za-z][A-Za-z0-9._-]{0,79}\Z")


def classify_invalid_request(error: Exception, *, status_code: int | None) -> InvalidRequestKind:
    """Classify one rejection in memory without returning provider-controlled text."""

    text = _bounded_error_text(error).lower()
    if any(marker in text for marker in _CONTENT_POLICY_MARKERS):
        return InvalidRequestKind.CONTENT_POLICY
    if any(marker in text for marker in _CONTEXT_LENGTH_MARKERS):
        return InvalidRequestKind.CONTEXT_LENGTH
    if status_code == 404 or any(marker in text for marker in _MODEL_NOT_FOUND_MARKERS):
        return InvalidRequestKind.MODEL_NOT_FOUND
    if status_code == 422:
        return InvalidRequestKind.INVALID_PARAMETER
    if any(marker in text for marker in _INVALID_PARAMETER_MARKERS):
        return InvalidRequestKind.INVALID_PARAMETER
    return InvalidRequestKind.UNKNOWN


def classify_provider_failure(
    error: Exception | None,
    *,
    status_code: int | None = None,
) -> ProviderFailureKind:
    """Classify OpenAI-compatible and HTTP failures without exposing response text."""

    from aiohttp import ClientConnectionError, ServerTimeoutError
    from openai import (
        APIConnectionError,
        APIError,
        APITimeoutError,
        AuthenticationError,
        BadRequestError,
        NotFoundError,
        PermissionDeniedError,
        RateLimitError,
        UnprocessableEntityError,
    )

    status = _status_code(error, status_code)
    if isinstance(error, (AuthenticationError, PermissionDeniedError)) or status in {401, 403}:
        return ProviderFailureKind.AUTH
    if isinstance(error, (APITimeoutError, ServerTimeoutError, TimeoutError)) or status == 408:
        return ProviderFailureKind.TIMEOUT
    if isinstance(error, RateLimitError) or status == 429:
        return ProviderFailureKind.RATE_LIMIT
    if isinstance(error, (BadRequestError, NotFoundError, UnprocessableEntityError)) or status in {
        400,
        404,
        422,
    }:
        return ProviderFailureKind.INVALID_REQUEST
    if (
        isinstance(error, (APIConnectionError, ClientConnectionError))
        or status in {409, 425}
        or (status is not None and status >= 500)
        or isinstance(error, APIError)
    ):
        return ProviderFailureKind.TRANSIENT
    return ProviderFailureKind.UNKNOWN


def translate_llm_provider_error(
    error: Exception,
    *,
    label: str,
    provider: str,
    logger: logging.Logger,
) -> LLMError:
    """Translate one raw LLM/VLM provider failure to the shared SAG contract."""

    if isinstance(error, LLMError):
        return error
    status = _status_code(error, None)
    kind = classify_provider_failure(error, status_code=status)
    if kind is ProviderFailureKind.INVALID_REQUEST:
        return translate_invalid_request(
            error,
            label=label,
            status_code=status,
            provider=provider,
            logger=logger,
        )

    _log_provider_failure(
        error,
        label=label,
        kind=kind,
        status_code=status,
        logger=logger,
        include_original=True,
    )
    kwargs = _error_context(kind, provider=provider, status_code=status, error=error)
    if kind is ProviderFailureKind.AUTH:
        return LLMAuthError(f"{label}：API凭证无效或无权限", **kwargs)
    if kind is ProviderFailureKind.TIMEOUT:
        return LLMTimeoutError(f"{label}：调用超时", **kwargs)
    if kind is ProviderFailureKind.RATE_LIMIT:
        return LLMRateLimitError(f"{label}：速率限制", **kwargs)
    if kind is ProviderFailureKind.TRANSIENT:
        return LLMTransientError(f"{label}：模型服务暂时不可用", **kwargs)
    return LLMError(f"{label}：{_raw_error_text(error)}", **kwargs)


def translate_ai_provider_error(
    error: Exception | None,
    *,
    label: str,
    provider: str,
    logger: logging.Logger,
    status_code: int | None = None,
) -> AIError:
    """Translate one Embedding/Rerank failure to provider-neutral AI errors."""

    if isinstance(error, AIError):
        return error
    status = _status_code(error, status_code)
    kind = classify_provider_failure(error, status_code=status)
    _log_provider_failure(
        error,
        label=label,
        kind=kind,
        status_code=status,
        logger=logger,
        include_original=False,
    )
    kwargs = _error_context(kind, provider=provider, status_code=status, error=error)
    if kind is ProviderFailureKind.AUTH:
        return AIAuthError(f"{label}：API凭证无效或无权限", **kwargs)
    if kind is ProviderFailureKind.INVALID_REQUEST:
        return AIInvalidRequestError(f"{label}：模型或请求参数不受支持", **kwargs)
    if kind is ProviderFailureKind.TIMEOUT:
        return AITransientError(f"{label}：调用超时", **kwargs)
    if kind is ProviderFailureKind.RATE_LIMIT:
        return AITransientError(f"{label}：速率限制", **kwargs)
    if kind is ProviderFailureKind.TRANSIENT:
        return AITransientError(f"{label}：服务暂时不可用", **kwargs)
    return AIError(f"{label}：{_raw_error_text(error)}", **kwargs)


def safe_provider_error_code(error: Exception) -> str | None:
    """Return one bounded provider code/type token, never an error message."""

    for candidate in _provider_code_candidates(error):
        if isinstance(candidate, str) and _SAFE_PROVIDER_CODE.fullmatch(candidate) is not None:
            return candidate.lower()
    return None


def translate_invalid_request(
    error: Exception,
    *,
    label: str,
    status_code: int | None,
    provider: str | None = None,
    logger: logging.Logger,
) -> LLMInvalidRequestError:
    """Map one OpenAI-compatible rejection to the shared safe SAG contract."""

    kind = classify_invalid_request(error, status_code=status_code)
    logger.error(
        "%s：请求被拒绝\n%s",
        label,
        _original_error_text(error),
        extra={
            "error_type": safe_error_type(error),
            "request_failure_kind": kind.value,
            "status_code": status_code,
            "provider_error_code": safe_provider_error_code(error),
        },
    )
    kwargs = _error_context(
        ProviderFailureKind.INVALID_REQUEST,
        provider=provider,
        status_code=status_code,
        error=error,
    )
    kwargs["details"]["invalid_request_kind"] = kind.value
    if kind is InvalidRequestKind.CONTENT_POLICY:
        return LLMContentPolicyError(f"{label}：内容未通过模型服务安全策略", **kwargs)
    if kind is InvalidRequestKind.CONTEXT_LENGTH:
        return LLMContextLengthError(f"{label}：输入超过模型上下文上限", **kwargs)
    if kind in {InvalidRequestKind.INVALID_PARAMETER, InvalidRequestKind.MODEL_NOT_FOUND}:
        return LLMConfigurationError(f"{label}：模型或请求参数不受支持", **kwargs)
    return LLMInvalidRequestError(f"{label}：模型服务拒绝了当前输入", **kwargs)


def _status_code(error: Exception | None, explicit: int | None) -> int | None:
    if isinstance(explicit, int) and not isinstance(explicit, bool):
        return explicit
    if error is None:
        return None
    candidate = getattr(error, "status_code", None)
    if isinstance(candidate, int) and not isinstance(candidate, bool):
        return candidate
    response = getattr(error, "response", None)
    for attribute in ("status_code", "status"):
        candidate = getattr(response, attribute, None)
        if isinstance(candidate, int) and not isinstance(candidate, bool):
            return candidate
    return None


def _error_context(
    kind: ProviderFailureKind,
    *,
    provider: str | None,
    status_code: int | None,
    error: Exception | None,
) -> dict[str, Any]:
    details: dict[str, Any] = {"failure_kind": kind.value}
    if status_code is not None:
        details["status_code"] = status_code
    del error
    return {"provider": provider, "details": details}


def _log_provider_failure(
    error: Exception | None,
    *,
    label: str,
    kind: ProviderFailureKind,
    status_code: int | None,
    logger: logging.Logger,
    include_original: bool,
) -> None:
    extra: dict[str, Any] = {
        "error_type": safe_error_type(error) if error is not None else "HTTPStatusError",
        "provider_failure_kind": kind.value,
        "status_code": status_code,
        "provider_error_code": safe_provider_error_code(error) if error is not None else None,
    }
    if include_original:
        logger.error(
            "%s：provider 请求失败\n%s",
            label,
            _original_error_text(error),
            extra=extra,
        )
        return
    if kind is ProviderFailureKind.UNKNOWN:
        extra["error_preview"] = _raw_error_text(error)
    logger.error("%s：provider 请求失败", label, extra=extra)


def _original_error_text(error: Exception | None) -> str:
    """Return unredacted LLM provider details for operator-visible logs."""

    if error is None:
        return "未知错误"
    values: list[str] = []
    try:
        values.append(str(error))
    except Exception:
        values.append(type(error).__name__)

    body = getattr(error, "body", None)
    if body is not None:
        try:
            values.append(json.dumps(body, ensure_ascii=False, default=str))
        except (TypeError, ValueError):
            values.append(repr(body))

    response = getattr(error, "response", None)
    if response is not None:
        try:
            payload = response.json()
        except Exception:
            payload = None
        if payload is not None and payload != body:
            try:
                values.append(json.dumps(payload, ensure_ascii=False, default=str))
            except (TypeError, ValueError):
                values.append(repr(payload))
        elif payload is None:
            try:
                response_text = str(response.text)
            except Exception:
                response_text = ""
            if response_text:
                values.append(response_text)

    readable = [text for value in values if (text := _readable_text(value))]
    return "\n".join(dict.fromkeys(readable)) or safe_error_type(error)


def _readable_text(value: str) -> str:
    """Bound one diagnostic fragment and drop undecoded binary payloads.

    Gateways that ignore ``Accept-Encoding`` hand back raw gzip/deflate bytes.
    Rendering those produces pages of mojibake that bury the real message, so a
    fragment that is mostly non-printable is replaced by a short summary.
    """

    if not value:
        return ""
    if len(value) > _SAFE_TEXT_LIMIT:
        value = f"{value[:_SAFE_TEXT_LIMIT]}...[truncated {len(value) - _SAFE_TEXT_LIMIT} chars]"
    # ``json.dumps`` renders control bytes as literal ```` text, so raw
    # characters alone underestimate how much of the fragment is binary.
    unreadable = sum(1 for char in value if _is_unreadable(char))
    unreadable += sum(len(match) for match in _ESCAPED_CONTROL.findall(value))
    if unreadable > len(value) * _BINARY_CHAR_RATIO:
        return f"<{len(value)} 字符的非文本响应体，疑似未解压或非 UTF-8，已省略>"
    return value


def _raw_error_text(error: Exception | None) -> str:
    """UNKNOWN 失败的原文，折叠为单行；取不到时退回异常类名。"""

    if error is None:
        return "未知错误"
    try:
        text = str(error)
    except Exception:
        text = ""
    text = re.sub(r"\s+", " ", text).strip()
    return text or safe_error_type(error)


def _is_unreadable(char: str) -> bool:
    return (char < " " and char not in "\t\n\r") or "\x7f" <= char <= "\x9f" or char == "�"


def _provider_code_candidates(error: Exception) -> tuple[object, ...]:
    candidates: list[object] = []
    for payload in (getattr(error, "body", None), _response_json(error)):
        if not isinstance(payload, dict):
            continue
        nested = payload.get("error")
        if isinstance(nested, dict):
            candidates.extend((nested.get("code"), nested.get("type")))
        candidates.extend((payload.get("code"), payload.get("type")))
    return tuple(candidates)


def _response_json(error: Exception) -> object:
    response = getattr(error, "response", None)
    if response is None:
        return None
    try:
        return response.json()
    except Exception:
        return None


def _bounded_error_text(error: Exception) -> str:
    values: list[str] = []
    body = getattr(error, "body", None)
    if body is not None:
        try:
            values.append(json.dumps(body, ensure_ascii=True, default=_safe_type_name))
        except (TypeError, ValueError):
            values.append(type(body).__name__)

    response = getattr(error, "response", None)
    if response is not None:
        try:
            payload = response.json()
        except Exception:
            payload = None
        if payload is not None:
            try:
                values.append(json.dumps(payload, ensure_ascii=True, default=_safe_type_name))
            except (TypeError, ValueError):
                values.append(type(payload).__name__)

    # Some OpenAI-compatible gateways only embed the structured error in the
    # exception string.  It is inspected locally, bounded, and never returned.
    try:
        values.append(str(error))
    except Exception:
        values.append(type(error).__name__)
    combined = "\n".join(values)[:_SAFE_TEXT_LIMIT]
    # Collapse whitespace so markers split by pretty-printed JSON still match.
    return re.sub(r"\s+", " ", combined)


def _safe_type_name(value: Any) -> str:
    return type(value).__name__


__all__ = [
    "InvalidRequestKind",
    "ProviderFailureKind",
    "classify_invalid_request",
    "classify_provider_failure",
    "safe_provider_error_code",
    "translate_ai_provider_error",
    "translate_invalid_request",
    "translate_llm_provider_error",
]
