"""
Prompt模板管理器

支持从YAML文件加载提示词模板，变量替换
支持多语言，语言由当前 Engine 显式传入。
"""

from importlib import resources
from importlib.resources.abc import Traversable
from pathlib import Path
from typing import Any

import yaml

from zleap.sag._safe_error import safe_error_type
from zleap.sag.exceptions import PromptError
from zleap.sag.utils import get_logger

logger = get_logger("prompt.manager")


class PromptTemplate:
    """提示词模板"""

    def __init__(
        self,
        name: str,
        template: str,
        variables: list[str] | None = None,
        description: str | None = None,
    ) -> None:
        self.name = name
        self.template = template
        self.variables = variables or []
        self.description = description

    def render(self, **kwargs: Any) -> str:
        """
        渲染模板

        Args:
            **kwargs: 变量值

        Returns:
            渲染后的文本

        Raises:
            PromptError: 缺少必需变量
        """
        missing = set(self.variables) - set(kwargs.keys())
        if missing:
            raise PromptError(f"模板'{self.name}'缺少必需变量: {', '.join(missing)}")

        try:
            return self.template.format(**kwargs)
        except KeyError as e:
            raise PromptError(f"模板变量错误: {e}") from e
        except Exception as e:
            raise PromptError(f"模板渲染失败: {e}") from e


class PromptManager:
    """提示词管理器（支持多语言）"""

    def __init__(
        self,
        prompts_dir: Path | None = None,
        *,
        language: str | None = None,
    ) -> None:
        """
        初始化提示词管理器

        Args:
            prompts_dir: 提示词目录路径

        多语言支持：
            - 默认中文(zh)，提示词在 prompts/ 根目录
            - 英文(en)优先从 prompts/en/ 加载，不存在则 fallback 到根目录
            - 通过环境变量 LLM_LANGUAGE 或 Settings.llm_language 配置
        """
        if prompts_dir is None:
            self.prompts_dir: Path | Traversable = resources.files("zleap.sag").joinpath("prompts")
        else:
            self.prompts_dir = Path(prompts_dir)

        self.templates: dict[str, PromptTemplate] = {}
        self.template_data: dict[str, dict[str, Any]] = {}

        self.language = self._normalize_language(language or "zh")

        if self.prompts_dir.is_dir():
            self.load_templates()
            logger.info(
                "提示词管理器初始化完成",
                extra={
                    "prompts_dir": str(self.prompts_dir),
                    "language": self.language,
                    "count": len(self.templates),
                },
            )
        else:
            logger.warning(f"提示词目录不存在: {self.prompts_dir}")

    @staticmethod
    def _normalize_language(language: str) -> str:
        normalized = language.strip().lower()
        if normalized not in ("zh", "en"):
            raise PromptError(f"不支持的提示词语言: {language!r}")
        return normalized

    def load_templates(self) -> None:
        """
        从YAML文件加载所有模板（支持多语言 fallback）

        加载顺序：
        1. 语言目录（如 en/）- 优先
        2. 根目录 - fallback（跳过已加载的同名模板）
        """
        if not self.prompts_dir.is_dir():
            logger.warning("提示词目录不存在")
            return

        # 1. 优先加载语言目录（非中文时）
        if self.language != "zh":
            lang_dir = self.prompts_dir / self.language
            if lang_dir.is_dir():
                for yaml_file in self._yaml_files(lang_dir):
                    try:
                        self._load_yaml_file(yaml_file)
                    except Exception as e:
                        logger.error(
                            "加载提示词文件失败",
                            extra={"error_type": safe_error_type(e)},
                        )

        # 2. 加载根目录（跳过已存在的模板）
        for yaml_file in self._yaml_files(self.prompts_dir):
            try:
                self._load_yaml_file(yaml_file, skip_existing=True)
            except Exception as e:
                logger.error(
                    "加载提示词文件失败",
                    extra={"error_type": safe_error_type(e)},
                )

    def _load_yaml_file(
        self,
        yaml_file: Path | Traversable,
        skip_existing: bool = False,
        template_name: str | None = None,
    ) -> None:
        """从YAML文件加载模板"""
        with yaml_file.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)

        if not isinstance(data, dict):
            logger.warning(f"无效的YAML格式: {yaml_file}")
            return

        for name, config in data.items():
            if not isinstance(config, dict):
                continue

            final_template_name = template_name if template_name else name

            if skip_existing and final_template_name in self.templates:
                continue

            self.template_data[final_template_name] = config.copy()

            template_text = config.get("template", "") or config.get("system", "")
            variables = config.get("variables", [])
            description = config.get("description", "")

            template = PromptTemplate(
                name=final_template_name,
                template=template_text,
                variables=variables,
                description=description,
            )

            self.templates[final_template_name] = template
            logger.debug(f"加载模板: {final_template_name}")

    @staticmethod
    def _yaml_files(directory: Path | Traversable) -> list[Path | Traversable]:
        return sorted(
            (
                entry
                for entry in directory.iterdir()
                if entry.is_file() and entry.name.endswith(".yaml")
            ),
            key=lambda entry: entry.name,
        )

    def get(self, name: str) -> PromptTemplate:
        """获取模板"""
        if name not in self.templates:
            raise PromptError(f"模板不存在: {name}")
        return self.templates[name]

    def render(self, name: str, **kwargs: Any) -> str:
        """渲染模板"""
        template = self.get(name)
        return template.render(**kwargs)

    def has(self, name: str) -> bool:
        """检查模板是否存在"""
        return name in self.templates

    def list_templates(self) -> list[str]:
        """列出所有模板名称"""
        return list(self.templates.keys())

    def get_template_config(self, name: str, *, test_mode: bool = False) -> dict[str, Any]:
        """
        获取模板的完整配置数据（从 YAML 文件，支持测试模式）

        Args:
            name: 模板名称
            test_mode: 是否使用测试版本（读取 test_{name} 配置）

        Returns:
            完整的模板配置字典

        Raises:
            PromptError: 模板配置不存在
        """
        if test_mode:
            test_name = f"test_{name}"
            if test_name in self.template_data:
                logger.info(f"使用测试模板: {test_name}")
                name = test_name
            else:
                logger.warning(f"测试模板不存在: {test_name}，使用默认模板: {name}")

        if name not in self.template_data:
            self.load_templates()
            if name not in self.template_data:
                raise PromptError(f"模板配置不存在: {name}")

        return self.template_data[name]
