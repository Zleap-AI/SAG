"""Provider-neutral source-chunk vector repository."""

from __future__ import annotations

from typing import Any

from zleap.sag.core.adapters import Filter, VectorStore
from zleap.sag.core.storage.index_schemas import StorageMode
from zleap.sag.core.storage.repositories.base import BaseRepository
from zleap.sag.core.storage.repositories.search_scope import (
    append_scope_filters,
    get_search_scope,
    has_search_scope_filters,
)
from zleap.sag.exceptions import StateError


def _combine(filters: list[Filter]) -> Filter | None:
    if not filters:
        return None
    return filters[0] if len(filters) == 1 else Filter.all(*filters)


class SourceChunkRepository(BaseRepository):
    INDEX_NAME = "source_chunks"

    def __init__(
        self,
        vector_store: VectorStore,
        storage_mode: StorageMode = "normal",
        session_factory: Any = None,
    ) -> None:
        super().__init__(vector_store)
        self.storage_mode = storage_mode
        self.session_factory = session_factory

    async def _resolve_scope_chunk_ids(
        self,
        *,
        data_source_id: str | None = None,
        data_source_ids: list[str] | None = None,
        candidate_chunk_ids: list[str] | None = None,
    ) -> list[str] | None:
        """把向量索引未声明的 source_type/time scope 解析成 chunk_id 白名单。"""
        scope = get_search_scope()
        requires_relational_scope = scope is not None and bool(
            scope.source_types or scope.start_time is not None or scope.end_time is not None
        )
        if not requires_relational_scope:
            return None
        if self.session_factory is None:
            raise StateError("SourceChunkRepository 缺少关系会话，无法应用完整搜索范围")

        from sqlalchemy import select

        from zleap.sag.core.storage.repositories.search_scope import (
            source_event_scope_predicate,
        )
        from zleap.sag.db import SourceChunk, SourceEvent

        assert scope is not None
        statement = select(SourceChunk.id)
        if data_source_ids:
            statement = statement.where(SourceChunk.data_source_id.in_(data_source_ids))
        elif data_source_id:
            statement = statement.where(SourceChunk.data_source_id == data_source_id)
        if candidate_chunk_ids:
            statement = statement.where(SourceChunk.id.in_(candidate_chunk_ids))
        if scope.source_ids:
            statement = statement.where(SourceChunk.source_id.in_(list(scope.source_ids)))
        if scope.source_types:
            statement = statement.where(SourceChunk.source_type.in_(list(scope.source_types)))
        if scope.start_time is not None or scope.end_time is not None:
            statement = statement.join(SourceEvent, SourceEvent.chunk_id == SourceChunk.id)
            statement = source_event_scope_predicate(statement, SourceEvent, scope).distinct()

        async with self.session_factory() as session:
            result = await session.execute(statement)
        return [str(chunk_id) for chunk_id in result.scalars().all()]

    async def index_chunk(
        self,
        chunk_id: str,
        source_id: str,
        data_source_id: str,
        rank: int,
        heading: str | None,
        content: str,
        heading_vector: list[float] | None,
        content_vector: list[float] | None,
        references: list[str] | None = None,
        **kwargs: Any,
    ) -> str:
        return await self.index_document(
            self.INDEX_NAME,
            chunk_id,
            {
                "id": chunk_id,
                "chunk_id": chunk_id,
                "source_id": source_id,
                "data_source_id": data_source_id,
                "rank": rank,
                "heading": heading,
                "content": content,
                "heading_vector": heading_vector,
                "content_vector": content_vector,
                "references": references or [],
                **kwargs,
            },
        )

    async def get_by_source(
        self, source_id: str, sort_by_rank: bool = True
    ) -> list[dict[str, Any]]:
        filters = [Filter.eq("source_id", source_id)]
        append_scope_filters(filters, source_types=False, time_range=False)
        return await self._query(
            self.INDEX_NAME,
            filters=_combine(filters),
            limit=100,
            sort=(("rank", "asc"),) if sort_by_rank else (),
        )

    async def search_similar_by_content(
        self,
        query_vector: list[float],
        k: int = 10,
        data_source_id: str | None = None,
        data_source_ids: list[str] | None = None,
        chunk_type: str | None = None,
        chunk_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        filters: list[Filter] = []
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        elif data_source_id:
            filters.append(Filter.eq("data_source_id", data_source_id))
        if chunk_type:
            filters.append(Filter.eq("chunk_type", chunk_type))
        scoped_chunk_ids = await self._resolve_scope_chunk_ids(
            data_source_id=data_source_id,
            data_source_ids=data_source_ids,
            candidate_chunk_ids=chunk_ids,
        )
        if scoped_chunk_ids is not None:
            if not scoped_chunk_ids:
                return []
            filters.append(Filter.one_of("chunk_id", scoped_chunk_ids))
        elif chunk_ids:
            filters.append(Filter.one_of("chunk_id", chunk_ids))
        append_scope_filters(filters, source_types=False, time_range=False)
        return await self._query(
            self.INDEX_NAME,
            vector=query_vector,
            vector_field="content_vector",
            filters=_combine(filters),
            limit=k,
        )

    async def search_by_text(
        self,
        query: str,
        data_source_id: str | None = None,
        data_source_ids: list[str] | None = None,
        size: int = 10,
    ) -> list[dict[str, Any]]:
        filters: list[Filter] = []
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        elif data_source_id:
            filters.append(Filter.eq("data_source_id", data_source_id))
        scoped_chunk_ids = await self._resolve_scope_chunk_ids(
            data_source_id=data_source_id,
            data_source_ids=data_source_ids,
        )
        if scoped_chunk_ids is not None:
            if not scoped_chunk_ids:
                return []
            filters.append(Filter.one_of("chunk_id", scoped_chunk_ids))
        append_scope_filters(filters, source_types=False, time_range=False)
        return await self._query(
            self.INDEX_NAME,
            text=query,
            text_fields=("heading^2", "content"),
            filters=_combine(filters),
            limit=size,
        )

    async def get_chunks_by_ids(
        self, chunk_ids: list[str], include_vectors: bool = True
    ) -> list[dict[str, Any]]:
        if not chunk_ids:
            return []
        if not has_search_scope_filters():
            return await self._get_many(
                self.INDEX_NAME,
                chunk_ids,
                include_vectors=include_vectors,
            )

        filters = [Filter.one_of("chunk_id", chunk_ids)]
        append_scope_filters(filters, source_types=False, time_range=False)
        return await self._query(
            self.INDEX_NAME,
            filters=_combine(filters),
            limit=len(chunk_ids),
            include_vectors=include_vectors,
        )
