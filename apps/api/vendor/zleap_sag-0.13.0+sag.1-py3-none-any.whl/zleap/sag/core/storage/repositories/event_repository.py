"""Provider-neutral event vector repository."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import numpy as np

from zleap.sag.core.adapters import Filter
from zleap.sag.core.storage.repositories.base import BaseRepository
from zleap.sag.core.storage.repositories.search_scope import (
    append_scope_filters,
    build_time_range_filter,
    has_search_scope_filters,
)
from zleap.sag.exceptions import InvalidInputError


def _combine(filters: list[Filter]) -> Filter | None:
    if not filters:
        return None
    return filters[0] if len(filters) == 1 else Filter.all(*filters)


# ExtractionLimits.max_events_per_chunk currently caps the complete recursive
# event set at 200. Association hydration must not silently truncate a valid
# chunk created with a non-default extraction limit.
_MAX_EVENTS_PER_CHUNK = 200


class EventVectorRepository(BaseRepository):
    INDEX_NAME = "event_vectors_wide"

    async def index_event(
        self,
        event_id: str,
        data_source_id: str,
        source_type: str,
        source_id: str,
        title: str,
        summary: str,
        content: str,
        title_vector: list[float],
        content_vector: list[float],
        **kwargs: Any,
    ) -> str:
        return await self.index_document(
            self.INDEX_NAME,
            event_id,
            {
                "id": event_id,
                "event_id": event_id,
                "data_source_id": data_source_id,
                "source_type": source_type,
                "source_id": source_id,
                "title": title,
                "summary": summary,
                "content": content,
                "title_vector": title_vector,
                "content_vector": content_vector,
                **kwargs,
            },
        )

    async def search_by_text(
        self, query: str, data_source_id: str | None = None, size: int = 10
    ) -> list[dict[str, Any]]:
        filters: list[Filter] = []
        if data_source_id:
            filters.append(Filter.eq("data_source_id", data_source_id))
        append_scope_filters(filters)
        return await self._query(
            self.INDEX_NAME,
            text=query,
            text_fields=("title^3", "summary^2", "content"),
            filters=_combine(filters),
            limit=size,
        )

    async def get_event_vector(
        self, event_id: str, vector_type: str = "content_vector"
    ) -> list[float] | None:
        records = await self.vector_store.get_many(self.INDEX_NAME, [event_id])
        return records[0].vectors.get(vector_type) if records else None

    async def get_events_by_ids(
        self,
        event_ids: list[str],
        source_includes: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        if not event_ids:
            return []
        if has_search_scope_filters():
            filters = [Filter.one_of("event_id", event_ids)]
            append_scope_filters(filters)
            events = await self._query(
                self.INDEX_NAME,
                filters=_combine(filters),
                limit=len(event_ids),
            )
        else:
            events = await self._get_many(
                self.INDEX_NAME,
                event_ids,
                include_vectors=False,
            )
        if source_includes:
            wanted = set(source_includes) | {"id", "event_id"}
            return [
                {key: value for key, value in event.items() if key in wanted} for event in events
            ]
        return events

    async def get_events_by_chunk_ids(
        self,
        chunk_ids: list[str],
        source_includes: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        if not chunk_ids:
            return []
        unique_chunk_ids = list(dict.fromkeys(chunk_ids))
        filters = [Filter.one_of("chunk_id", unique_chunk_ids)]
        append_scope_filters(filters)
        events = await self._query(
            self.INDEX_NAME,
            filters=_combine(filters),
            limit=max(len(unique_chunk_ids) * _MAX_EVENTS_PER_CHUNK, _MAX_EVENTS_PER_CHUNK),
        )
        if source_includes:
            wanted = set(source_includes) | {"id", "event_id", "chunk_id"}
            return [
                {key: value for key, value in event.items() if key in wanted} for event in events
            ]
        return events

    async def search_similar_by_title(
        self,
        query_vector: list[float],
        k: int = 10,
        data_source_id: str | None = None,
        data_source_ids: list[str] | None = None,
        category: str | None = None,
        event_ids: list[str] | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        source_ids: list[str] | None = None,
        exclude_event_ids: list[str] | None = None,
        entity_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        return await self._vector_search(
            "title_vector",
            query_vector,
            k,
            data_source_id,
            data_source_ids,
            category,
            event_ids,
            start_time,
            end_time,
            source_ids,
            exclude_event_ids,
            entity_ids,
        )

    async def search_bm25_by_text(
        self,
        query: str,
        event_ids: list[str],
        k: int = 100,
        data_source_ids: list[str] | None = None,
        fields: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        if not query or not event_ids:
            return []
        filters = [Filter.one_of("event_id", event_ids)]
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        append_scope_filters(filters)
        hits = await self._query(
            self.INDEX_NAME,
            text=query,
            text_fields=fields or ("title^2", "content"),
            filters=Filter.all(*filters),
            limit=min(k, len(event_ids)),
        )
        return [
            {"event_id": hit.get("event_id") or hit.get("id"), "score": hit["score"]}
            for hit in hits
            if hit.get("event_id") or hit.get("id")
        ]

    async def search_similar_by_content(
        self,
        query_vector: list[float],
        k: int = 10,
        data_source_id: str | None = None,
        data_source_ids: list[str] | None = None,
        category: str | None = None,
        event_ids: list[str] | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        source_ids: list[str] | None = None,
        exclude_event_ids: list[str] | None = None,
        entity_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        return await self._vector_search(
            "content_vector",
            query_vector,
            k,
            data_source_id,
            data_source_ids,
            category,
            event_ids,
            start_time,
            end_time,
            source_ids,
            exclude_event_ids,
            entity_ids,
        )

    @staticmethod
    def _is_valid_vector(vector: list[float]) -> bool:
        if not vector:
            return False
        try:
            values = np.array(vector, dtype=np.float32)
            return not (np.isnan(values).any() or np.isinf(values).any())
        except (ValueError, TypeError):
            return False

    async def _vector_search(
        self,
        vector_field: str,
        query_vector: list[float],
        k: int,
        data_source_id: str | None = None,
        data_source_ids: list[str] | None = None,
        category: str | None = None,
        event_ids: list[str] | None = None,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        source_ids: list[str] | None = None,
        exclude_event_ids: list[str] | None = None,
        entity_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        if not self._is_valid_vector(query_vector):
            raise InvalidInputError("查询向量包含无效值（NaN或Inf）")
        data_source_ids = data_source_ids or ([data_source_id] if data_source_id else None)
        filters: list[Filter] = []
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        if category:
            filters.append(Filter.eq("category", category))
        if event_ids:
            filters.append(Filter.one_of("event_id", event_ids))
        if exclude_event_ids:
            filters.append(Filter.negate(Filter.one_of("event_id", exclude_event_ids)))
        if entity_ids:
            filters.append(Filter.one_of("entity_ids", entity_ids))
        if source_ids:
            filters.append(Filter.one_of("source_id", source_ids))
        if time_filter := build_time_range_filter(start_time, end_time):
            filters.append(time_filter)
        append_scope_filters(filters)
        return await self._query(
            self.INDEX_NAME,
            vector=query_vector,
            vector_field=vector_field,
            filters=_combine(filters),
            limit=k,
        )

    async def search_by_time_range(
        self,
        start_time: datetime | None = None,
        end_time: datetime | None = None,
        data_source_id: str | None = None,
        size: int = 100,
    ) -> list[dict[str, Any]]:
        filters: list[Filter] = []
        if time_filter := build_time_range_filter(start_time, end_time):
            filters.append(time_filter)
        if data_source_id:
            filters.append(Filter.eq("data_source_id", data_source_id))
        append_scope_filters(filters)
        return await self._query(
            self.INDEX_NAME,
            filters=_combine(filters),
            limit=size,
            sort=(("created_time", "desc"),),
        )

    async def search_by_entities(
        self,
        entity_ids: list[str],
        data_source_id: str | None = None,
        size: int = 100,
    ) -> list[dict[str, Any]]:
        filters = [Filter.one_of("entity_ids", entity_ids)]
        if data_source_id:
            filters.append(Filter.eq("data_source_id", data_source_id))
        append_scope_filters(filters)
        return await self._query(self.INDEX_NAME, filters=Filter.all(*filters), limit=size)
