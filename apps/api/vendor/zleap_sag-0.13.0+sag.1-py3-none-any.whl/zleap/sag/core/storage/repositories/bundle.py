"""Repository bundle created once at the storage composition root."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from zleap.sag.core.adapters import RelationalStore, VectorStore
from zleap.sag.core.storage.repositories.entity_repository import EntityVectorRepository
from zleap.sag.core.storage.repositories.entity_type_repository import (
    EntityTypeRepository,
)
from zleap.sag.core.storage.repositories.event_entity_relational_repository import (
    EventEntityRelationalRepository,
)
from zleap.sag.core.storage.repositories.event_entity_repository import (
    EventEntityRepository,
)
from zleap.sag.core.storage.repositories.event_repository import EventVectorRepository
from zleap.sag.core.storage.repositories.source_chunk_repository import (
    SourceChunkRepository,
)


@dataclass(frozen=True)
class RepositoryBundle:
    entity_types: EntityTypeRepository
    entities: EntityVectorRepository
    events: EventVectorRepository
    event_entities: EventEntityRepository
    event_entity_relations: EventEntityRelationalRepository
    source_chunks: SourceChunkRepository


def build_repository_bundle(
    relational: RelationalStore,
    vector: VectorStore,
    *,
    storage_mode: Literal["normal", "lite"],
) -> RepositoryBundle:
    entity_types = EntityTypeRepository(relational)
    return RepositoryBundle(
        entity_types=entity_types,
        entities=EntityVectorRepository(vector, storage_mode=storage_mode),
        events=EventVectorRepository(vector),
        event_entities=EventEntityRepository(vector, storage_mode=storage_mode),
        event_entity_relations=EventEntityRelationalRepository(relational),
        source_chunks=SourceChunkRepository(
            vector,
            storage_mode=storage_mode,
            session_factory=relational.session_factory(),
        ),
    )
