"""ParadeDB 向量后端(单库 pgvector 向量 + pg_search 真 BM25)。

设计:
- 复用 ``PgVectorStore`` 的建表/写入/kNN 全部逻辑;向量列仍是 pgvector 的
  ``vector(N)`` + HNSW,不切换到 ParadeDB 索引内向量(那条路会动 SQL 构造,
  且收益只在"向量+过滤"组合查询,单独评估)。
- 只重写词法检索:``search`` 的 match/multi_match 子句从 ``ILIKE`` 升级为
  pg_search 的 ``@@@`` 操作符,``_score`` 用 ``paradedb.score(id)`` 取真实
  BM25 分数(多字段按权重合并,行为对齐 LanceDB)。
  这是 RRF 融合能工作的前提——ILIKE 路径给所有命中打死分 1.0,进 RRF 等于无排序信号。
  注意:裸 pgvector 的 ``_extract_match`` 只认单字段 ``match``,而仓库层
  (``BaseVectorStoreAdapter.query``)发的是 ``multi_match``,若不在此解析,
  ``search`` 会落到 ILIKE 兜底路径且连文本条件都被丢弃。
- 建表时按 ``IndexSchema.text_fields`` 额外创建 BM25 索引;中文用 jieba 分词。
"""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import text

from zleap.sag._safe_error import safe_error_type
from zleap.sag.core.storage.pgvector_store import PgVectorStore, _ident, _table_ident
from zleap.sag.utils import get_logger

logger = get_logger("storage.paradedb")

# pg_search 分词器:中文用 jieba(字典+统计模型,处理歧义词边界优于按字切分)。
# 注意 jieba/lindera 是字典型、查询时加载字典,上游有每个并行 worker 重复加载
# 的已知开销(约 50-163ms/查询),压测时需单独计量。
_CJK_TOKENIZER = "jieba"
_LINDERA_TOKENIZER = "lindera"
_DEFAULT_TOKENIZER = "default"


def _tokenizer_for(language: str | None) -> str:
    """按语言选 pg_search 分词器;接受 ``zh-CN`` 这类带地区码的写法。

    默认分词器走 Unicode Annex #29 词边界,对 CJK 基本等于不切分,故必须显式指定。
    """
    if not language:
        return _DEFAULT_TOKENIZER
    primary = language.replace("_", "-").split("-")[0].lower()
    if primary == "zh":
        return _CJK_TOKENIZER
    if primary in ("ja", "ko"):
        return _LINDERA_TOKENIZER
    return _DEFAULT_TOKENIZER


class ParadeDBStore(PgVectorStore):
    """pgvector 向量 + pg_search BM25 的单库实现。"""

    def __init__(
        self,
        *,
        runtime: Any | None = None,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
        language: str = "en",
    ) -> None:
        super().__init__(
            runtime=runtime,
            storage_mode=storage_mode,
            embedding_dimensions=embedding_dimensions,
        )
        self._language = language

    # ── 建表:在 pgvector 表结构之上补 BM25 索引 ──────────────
    async def _ensure_table(self, index: str, document: dict[str, Any]) -> None:
        await super()._ensure_table(index, document)
        await self._ensure_bm25_index(index)

    async def _ensure_bm25_index(self, index: str) -> None:
        """为 ``IndexSchema.text_fields`` 建 pg_search BM25 索引(幂等)。"""
        from zleap.sag.core.storage.index_schemas import INDEX_SCHEMAS

        schema = INDEX_SCHEMAS.get(index)
        if schema is None:
            return
        table = _table_ident(index)
        text_columns = [
            _ident(field) for field in (*schema.text_fields, *schema.text_keyword_fields)
        ]
        if not text_columns:
            return

        available = await self._existing_columns(table)
        columns = [col for col in text_columns if col in available]
        if not columns:
            return

        statement = self._bm25_index_sql(table, columns, tokenizer=_tokenizer_for(self._language))
        if statement is None:
            return
        try:
            async with self._engine().begin() as conn:
                await conn.execute(text("CREATE EXTENSION IF NOT EXISTS pg_search"))
                await conn.execute(text(statement))
        except Exception as exc:  # noqa: BLE001 - 索引缺失只降级词法能力,不该阻断写入
            logger.warning(
                "ParadeDB BM25 索引创建失败;词法检索将不可用",
                extra={"error_type": safe_error_type(exc)},
            )

    @staticmethod
    def _bm25_index_sql(table: str, columns: list[str], *, tokenizer: str) -> str | None:
        """构建 pg_search BM25 索引 DDL;无可索引文本列时返回 ``None``。"""
        if not columns:
            return None
        # pg_search 用 serde_json 解析 text_fields,必须是合法 JSON(双引号 key);
        # 且要作为字符串字面量传入——写成 "..." 会被 PG 当标识符并截断到 63 字节。
        fields = json.dumps(
            {_ident(col): {"tokenizer": {"type": tokenizer}} for col in columns},
            ensure_ascii=False,
        ).replace("'", "''")
        quoted = ", ".join(f'"{_ident(col)}"' for col in columns)
        return (
            f'CREATE INDEX IF NOT EXISTS "{table}_bm25_idx" ON "{table}" '
            f"USING bm25 (id, {quoted}) "
            f"WITH (key_field='id', text_fields='{fields}')"
        )

    @staticmethod
    def _lexical_sql(
        table: str,
        select_columns: list[str],
        *,
        limit: int,
        offset: int = 0,
        where: str = "",
        match_field: str = "",
    ) -> str:
        """构建 ``@@@`` 词法检索 SQL,相关性取 ``paradedb.score(id)``。"""
        bm25_where = f'"{_ident(match_field or select_columns[0])}" @@@ :q'
        where_sql = f"({where}) AND {bm25_where}" if where else bm25_where
        select_cols = ", ".join(f'"{c}"' for c in select_columns)
        return (
            f"SELECT {select_cols}, paradedb.score(id) AS _score "
            f'FROM "{table}" WHERE {where_sql} '
            f"ORDER BY _score DESC LIMIT {int(limit)} OFFSET {int(offset)}"
        )

    @staticmethod
    def _split_lexical(
        query: dict[str, Any] | None,
    ) -> tuple[str, list[tuple[str, float]]] | None:
        """提取词法子句,返回 (查询文本, [(字段, 权重)]);无词法子句返回 ``None``。

        支持 ``multi_match``(含 ``title^2`` 权重)与 ``match``(含嵌套 dict 形式),
        可出现在顶层或 ``bool.must`` 里;其余子句(term/terms/range…)留给
        ``_translate_filter`` 作过滤。参考 LanceDB 的 ``_split_lexical`` 语义。
        """

        def _parse(node: dict[str, Any]) -> tuple[str, list[tuple[str, float]]] | None:
            if "multi_match" in node:
                mm = node["multi_match"]
                fields: list[tuple[str, float]] = []
                for raw in mm.get("fields") or []:
                    name, _, boost = str(raw).partition("^")
                    if name:
                        fields.append((name, float(boost) if boost else 1.0))
                text = mm.get("query")
                return (str(text), fields) if text and fields else None
            if "match" in node:
                ((f, v),) = node["match"].items()
                text = v.get("query") if isinstance(v, dict) else v
                return (str(text), [(f, 1.0)]) if text else None
            return None

        if not query:
            return None
        found = _parse(query)
        if found:
            return found
        if "bool" in query:
            must = query["bool"].get("must", [])
            must = must if isinstance(must, list) else [must]
            for child in must:
                if isinstance(child, dict) and (parsed := _parse(child)):
                    return parsed
        return None

    async def _existing_columns(self, table: str) -> set[str]:
        async with self._engine().connect() as conn:
            rows = (
                await conn.execute(
                    text(
                        "SELECT column_name FROM information_schema.columns "
                        "WHERE table_schema = current_schema() AND table_name = :t"
                    ),
                    {"t": table},
                )
            ).fetchall()
        return {str(row[0]) for row in rows}

    async def ping(self) -> bool:
        try:
            async with self._engine().connect() as conn:
                await conn.execute(text("SELECT 1"))
            return True
        except Exception as exc:  # noqa: BLE001 - 与 pgvector 行为一致
            logger.error(
                "ParadeDB 连接检查失败",
                extra={"error_type": safe_error_type(exc)},
            )
            return False

    # ── 词法检索:ES DSL multi_match/match → pg_search @@@ + 真 BM25 分数 ──
    async def search(
        self,
        index: str,
        query: dict[str, Any],
        size: int = 10,
        from_: int = 0,
        routing: str | None = None,
        return_full_response: bool = False,
        include_vector: bool = False,
        **kwargs: Any,
    ) -> Any:
        lexical = self._split_lexical(query)
        if lexical is None:
            # 无词法子句:纯过滤/排序,交回 pgvector 实现(行为一致)。
            return await super().search(
                index,
                query,
                size=size,
                from_=from_,
                routing=routing,
                return_full_response=return_full_response,
                include_vector=include_vector,
                **kwargs,
            )

        table = _table_ident(index)
        if not await self._table_exists(table):
            return {"total": 0, "max_score": 0, "hits": []} if return_full_response else []

        needle, requested = lexical
        where, params = self._translate_filter(query if "bool" in (query or {}) else None)

        # 只保留已存在的文本列;multi_match 可能引用 schema 外的字段(防御)。
        available = await self._existing_columns(table)
        fields: list[tuple[str, float]] = []
        for raw_field, boost in requested:
            field = _ident(raw_field.removesuffix(".keyword"))
            if field in available:
                fields.append((field, boost))
        if not fields:
            return await super().search(
                index,
                query,
                size=size,
                from_=from_,
                routing=routing,
                return_full_response=return_full_response,
                include_vector=include_vector,
                **kwargs,
            )

        columns = await self._scalar_columns(table, include_vector)
        rows = await self._bm25_rows(
            table,
            list(columns),
            needle,
            fields,
            where,
            params,
            limit=from_ + size,
        )
        rows = rows[from_ : from_ + size]

        if not return_full_response:
            return [{k: v for k, v in row.items() if k != "_score"} for row in rows]
        scores = [float(row.get("_score") or 0.0) for row in rows]
        return {
            "total": len(rows),
            "max_score": max(scores, default=0),
            "hits": [
                {
                    "id": row.get("id"),
                    "score": float(row.get("_score") or 0.0),
                    "source": {k: v for k, v in row.items() if k != "_score"},
                    "index": index,
                }
                for row in rows
            ],
        }

    async def _bm25_rows(
        self,
        table: str,
        columns: list[str],
        needle: str,
        fields: list[tuple[str, float]],
        where: str,
        params: dict[str, Any],
        *,
        limit: int,
    ) -> list[dict[str, Any]]:
        """逐字段 BM25 检索,按 id 合并取 max(权重×score),分数降序返回。

        pg_search 的 ``@@@`` 是单字段操作符,multi_match 需逐字段查询后在
        Python 侧合并;权重乘到 ``paradedb.score`` 上(与 LanceDB 一致)。
        """
        merged: dict[str, tuple[dict[str, Any], float]] = {}
        for field, boost in fields:
            sql = self._lexical_sql(table, columns, limit=limit, where=where, match_field=field)
            qparams = {**params, "q": needle}
            async with self._engine().connect() as conn:
                fetched = [
                    dict(r._mapping) for r in (await conn.execute(text(sql), qparams)).fetchall()
                ]
            for row in fetched:
                rid = row.get("id")
                if rid is None:
                    continue
                score = float(row.get("_score") or 0.0) * boost
                prev = merged.get(rid)
                if prev is not None and prev[1] >= score:
                    continue
                merged[rid] = (row, score)
        ordered = sorted(merged.values(), key=lambda item: item[1], reverse=True)
        return [dict(row, _score=score) for row, score in ordered]
