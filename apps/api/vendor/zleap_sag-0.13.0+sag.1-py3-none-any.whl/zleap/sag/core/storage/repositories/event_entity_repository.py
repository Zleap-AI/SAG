"""Provider-neutral event-entity vector repository."""

from __future__ import annotations

import asyncio
from typing import Any

import numpy as np

from zleap.sag.core.adapters import Filter, VectorStore
from zleap.sag.core.storage.index_schemas import (
    StorageMode,
    prepare_vector_for_index,
)
from zleap.sag.core.storage.repositories.base import BaseRepository
from zleap.sag.core.storage.repositories.search_scope import append_scope_filters
from zleap.sag.exceptions import InvalidInputError

_RELATION_FANOUT_FACTOR = 3
_RELATION_FANOUT_CAP = 10000


def _combine(filters: list[Filter]) -> Filter | None:
    if not filters:
        return None
    return filters[0] if len(filters) == 1 else Filter.all(*filters)


class EventEntityRepository(BaseRepository):
    INDEX_NAME = "event_entity_vectors"

    def __init__(self, vector_store: VectorStore, storage_mode: StorageMode = "normal") -> None:
        super().__init__(vector_store)
        self.storage_mode = storage_mode

    def prepare_vector(self, vector: list[float]) -> list[float]:
        return prepare_vector_for_index(self.storage_mode, self.INDEX_NAME, vector)

    async def index_event_entity(
        self,
        association_id: str,
        event_id: str,
        entity_id: str,
        data_source_id: str,
        description: str,
        vector: list[float],
        **kwargs: Any,
    ) -> str:
        return await self.index_document(
            self.INDEX_NAME,
            association_id,
            {
                "id": association_id,
                "event_id": event_id,
                "entity_id": entity_id,
                "data_source_id": data_source_id,
                "description": description,
                "vector": self.prepare_vector(vector),
                **kwargs,
            },
        )

    @staticmethod
    def _is_valid_vector(vector: list[float]) -> bool:
        if not vector:
            return False
        try:
            values = np.array(vector, dtype=np.float32)
            return not (np.isnan(values).any() or np.isinf(values).any())
        except (ValueError, TypeError):
            return False

    @staticmethod
    def _cosine_rank_relations(
        rows: list[dict[str, Any]], query_vector: list[float], limit: int
    ) -> list[dict[str, Any]]:
        query_array = np.asarray(query_vector, dtype=np.float32)
        query_norm = float(np.linalg.norm(query_array))
        if query_norm == 0.0:
            return []
        vectors, kept = [], []
        for row in rows:
            vector = row.get("vector")
            if isinstance(vector, str):
                # asyncpg 未注册 codec 时,pgvector/OceanBase 返回向量文本如 "[1,2,3]"
                try:
                    vector = [float(x) for x in vector.strip("[]").split(",")]
                except ValueError:
                    continue
            if not isinstance(vector, list) or len(vector) != query_array.shape[0]:
                continue
            vectors.append(vector)
            kept.append(row)
        if not vectors:
            return []
        matrix = np.asarray(vectors, dtype=np.float32)
        norms = np.linalg.norm(matrix, axis=1)
        valid = norms > 0
        scores = np.full(matrix.shape[0], -np.inf, dtype=np.float32)
        scores[valid] = (matrix[valid] @ query_array) / (norms[valid] * query_norm)
        scores = (scores + 1.0) / 2.0
        if limit < scores.shape[0]:
            top = np.argpartition(-scores, limit - 1)[:limit]
            top = top[np.argsort(-scores[top])]
        else:
            top = np.argsort(-scores)
        return [
            {
                "event_id": kept[i]["event_id"],
                "entity_id": kept[i]["entity_id"],
                "score": float(scores[i]),
            }
            for i in top
            if np.isfinite(scores[i])
        ]

    async def score_relations_by_event_ids(
        self,
        query_vector: list[float],
        event_ids: list[str],
        data_source_ids: list[str] | None = None,
        exclude_entity_ids: list[str] | None = None,
        size: int = 100,
    ) -> list[dict[str, Any]]:
        """Score event-to-entity relations through the provider-neutral vector port."""

        if not event_ids or size <= 0:
            return []
        query_vector = self.prepare_vector(query_vector)
        if not self._is_valid_vector(query_vector):
            raise InvalidInputError("查询向量包含无效值（NaN或Inf）")
        filters: list[Filter] = [Filter.one_of("event_id", list(dict.fromkeys(event_ids)))]
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        if exclude_entity_ids:
            filters.append(Filter.negate(Filter.one_of("entity_id", exclude_entity_ids)))
        append_scope_filters(filters, time_range=False)
        fetch = getattr(self.vector_store, "fetch_relation_vectors", None)
        if fetch is not None:
            rows = await fetch(self.INDEX_NAME, filters=_combine(filters))
            return self._cosine_rank_relations(rows, query_vector, size)
        return await self._query(
            self.INDEX_NAME,
            vector=query_vector,
            filters=_combine(filters),
            limit=size,
        )

    def _relation_scope_filters(
        self,
        data_source_ids: list[str] | None,
        exclude_event_ids: list[str] | None,
    ) -> list[Filter]:
        filters: list[Filter] = []
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        if exclude_event_ids:
            filters.append(Filter.negate(Filter.one_of("event_id", exclude_event_ids)))
        append_scope_filters(filters, time_range=False)
        return filters

    async def get_relations_by_entity_ids_limited(
        self,
        entity_ids: list[str],
        per_entity_limit: int,
        data_source_ids: list[str] | None = None,
        exclude_event_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Return a bounded relation projection for every requested entity.

        单次 ``entity_id IN (...)`` 扫描替代逐实体扫描，回表后在内存里按实体分桶截断。
        全局 limit 可能被热门实体吃满而饿死尾部实体，故仅在扫描确实触顶且存在未满桶时，
        对缺口实体并发补查一次，以保住 per-entity 配额语义。
        """

        if not entity_ids or per_entity_limit <= 0:
            return []
        unique_ids = list(dict.fromkeys(str(entity_id) for entity_id in entity_ids))
        scope = self._relation_scope_filters(data_source_ids, exclude_event_ids)

        batch_limit = min(
            len(unique_ids) * per_entity_limit * _RELATION_FANOUT_FACTOR,
            _RELATION_FANOUT_CAP,
        )
        rows = await self._query(
            self.INDEX_NAME,
            filters=_combine([Filter.one_of("entity_id", unique_ids), *scope]),
            limit=batch_limit,
        )
        buckets = self._bucket_relations(rows, unique_ids, per_entity_limit)

        if len(rows) >= batch_limit:
            gaps = [
                entity_id for entity_id in unique_ids if len(buckets[entity_id]) < per_entity_limit
            ]
            if gaps:
                refills = await asyncio.gather(
                    *(
                        self._query(
                            self.INDEX_NAME,
                            filters=_combine([Filter.eq("entity_id", entity_id), *scope]),
                            limit=per_entity_limit,
                        )
                        for entity_id in gaps
                    )
                )
                for entity_id, refill in zip(gaps, refills, strict=True):
                    buckets[entity_id] = self._bucket_relations(
                        refill, [entity_id], per_entity_limit
                    )[entity_id]

        return [row for entity_id in unique_ids for row in buckets[entity_id]]

    @staticmethod
    def _bucket_relations(
        rows: list[dict[str, Any]],
        entity_ids: list[str],
        per_entity_limit: int,
    ) -> dict[str, list[dict[str, Any]]]:
        """按 entity_id 分桶，桶内按 event_id 排序后截断，使无序截断变得可复现。"""

        wanted = set(entity_ids)
        grouped: dict[str, dict[str, dict[str, Any]]] = {entity_id: {} for entity_id in entity_ids}
        for row in rows:
            entity_id = row.get("entity_id")
            event_id = row.get("event_id")
            if not entity_id or not event_id or str(entity_id) not in wanted:
                continue
            grouped[str(entity_id)].setdefault(str(event_id), row)
        return {
            entity_id: [by_event[event_id] for event_id in sorted(by_event)[:per_entity_limit]]
            for entity_id, by_event in grouped.items()
        }

    async def get_by_event(
        self, event_id: str, data_source_id: str | None = None
    ) -> list[dict[str, Any]]:
        filters = [Filter.eq("event_id", event_id)]
        if data_source_id:
            filters.append(Filter.eq("data_source_id", data_source_id))
        append_scope_filters(filters, time_range=False)
        return await self._query(self.INDEX_NAME, filters=Filter.all(*filters), limit=100)

    async def get_by_entity(
        self, entity_id: str, data_source_id: str | None = None
    ) -> list[dict[str, Any]]:
        filters = [Filter.eq("entity_id", entity_id)]
        if data_source_id:
            filters.append(Filter.eq("data_source_id", data_source_id))
        append_scope_filters(filters, time_range=False)
        return await self._query(self.INDEX_NAME, filters=Filter.all(*filters), limit=100)

    async def get_event_ids_by_entity_ids(
        self,
        entity_ids: list[str],
        data_source_ids: list[str] | None = None,
        exclude_event_ids: list[str] | None = None,
        size: int = 10000,
    ) -> list[str]:
        if not entity_ids:
            return []
        filters = [Filter.one_of("entity_id", entity_ids)]
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        if exclude_event_ids:
            filters.append(Filter.negate(Filter.one_of("event_id", exclude_event_ids)))
        append_scope_filters(filters, time_range=False)
        rows = await self._query(
            self.INDEX_NAME,
            filters=Filter.all(*filters),
            limit=size,
            distinct_field="event_id",
        )
        seen: set[str] = set()
        result: list[str] = []
        for row in rows:
            event_id = str(row.get("event_id") or "")
            if event_id and event_id not in seen:
                seen.add(event_id)
                result.append(event_id)
        return result

    async def get_associations_by_ids(self, association_ids: list[str]) -> list[dict[str, Any]]:
        if not association_ids:
            return []
        results: list[dict[str, Any]] = []
        for offset in range(0, len(association_ids), 3000):
            results.extend(
                await self._get_many(self.INDEX_NAME, association_ids[offset : offset + 3000])
            )
        return results

    async def batch_search_similar_by_event_entity_pairs(
        self,
        query_vector: list[float],
        event_entity_pairs: list[tuple[str, str]],
        data_source_ids: list[str] | None = None,
        include_source: bool = False,
    ) -> dict[tuple[str, str], Any]:
        if not event_entity_pairs:
            return {}
        query_vector = self.prepare_vector(query_vector)
        if not self._is_valid_vector(query_vector):
            return {}
        all_results: dict[tuple[str, str], Any] = {}
        for offset in range(0, len(event_entity_pairs), 2500):
            pairs = event_entity_pairs[offset : offset + 2500]
            filters = [
                Filter.one_of("event_id", [pair[0] for pair in pairs]),
                Filter.one_of("entity_id", [pair[1] for pair in pairs]),
            ]
            if data_source_ids:
                filters.append(Filter.one_of("data_source_id", data_source_ids))
            append_scope_filters(filters, time_range=False)
            hits = await self._query(
                self.INDEX_NAME,
                vector=query_vector,
                filters=Filter.all(*filters),
                limit=len(pairs) * 2,
            )
            allowed = set(pairs)
            for hit in hits:
                key = (str(hit.get("event_id") or ""), str(hit.get("entity_id") or ""))
                if key not in allowed:
                    continue
                score = float(hit.get("score", 0.0))
                all_results[key] = (
                    {
                        "score": score,
                        "description": hit.get("description", ""),
                        "data_source_id": hit.get("data_source_id"),
                    }
                    if include_source
                    else score
                )
        return all_results
