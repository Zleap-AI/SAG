"""pgvector 向量后端。

设计:
- 使用向量侧专属 PostgreSQL ``SqlRuntime``；即使物理同库也不复用关系连接池。
- 每个逻辑 collection 映射为一张表,列从写入文档自动推断(向量列 → ``vector(N)`` + HNSW 索引;
  标量 → text/bigint/double/boolean;其它 → jsonb)。
- kNN:``ORDER BY col <=> :q::vector``(cosine),``_score = 1 - 距离``;filter_query(ES bool/term/terms)
  翻译为 SQL WHERE(``_id`` → 主键 ``id`` 列)。
- BM25/词法（``search`` 的 match）退化为 ``ILIKE`` 排序，因此不声明真词法能力。
"""

from __future__ import annotations

import re
from typing import Any, TypeAlias, TypeGuard

from sqlalchemy import text

from zleap.sag._safe_error import safe_error_type
from zleap.sag.exceptions import ConfigError, StorageModeError
from zleap.sag.utils import get_logger

logger = get_logger("storage.pgvector")

_IDENT = re.compile(r"[^a-zA-Z0-9_]")


def _ident(name: str) -> str:
    """把索引/字段名规整为安全的 SQL 标识符。"""
    return _IDENT.sub("_", name)


def _table_ident(index: str) -> str:
    """沿用既有逻辑索引名；storage_mode 不改写物理表名。"""
    return _ident(index)


VectorValue: TypeAlias = list[int | float] | tuple[int | float, ...]


def _is_vector(value: object) -> TypeGuard[VectorValue]:
    return (
        isinstance(value, (list, tuple))
        and len(value) > 8
        and all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in value)
    )


def _vec_literal(vec: VectorValue) -> str:
    return "[" + ",".join(repr(float(x)) for x in vec) + "]"


def _col_type(value: Any) -> str:
    if _is_vector(value):
        return f"vector({len(value)})"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "bigint"
    if isinstance(value, float):
        return "double precision"
    if isinstance(value, str):
        return "text"
    return "jsonb"


class PgVectorStore:
    """pgvector provider implementation owned by ``PgVectorStoreAdapter``."""

    def __init__(
        self,
        *,
        runtime: Any | None = None,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
    ) -> None:
        if storage_mode not in ("normal", "lite"):
            raise StorageModeError("storage_mode 必须是 normal 或 lite")
        self._storage_mode = storage_mode
        self._embedding_dimensions = embedding_dimensions
        self._runtime = runtime
        self._ready_tables: set[str] = set()

    # ── 底层:向量侧专属 PostgreSQL runtime──────────────────
    def _engine(self) -> Any:
        if self._runtime is None:
            raise ConfigError("PgVectorStore 需要显式注入向量侧 SqlRuntime")
        return self._runtime.engine()

    async def schema_table_names(self) -> frozenset[str]:
        """列出当前 schema 中已存在的 SAG 正式向量表。"""
        from zleap.sag.core.storage.index_schemas import INDEX_SCHEMAS

        async with self._engine().connect() as conn:
            rows = (
                await conn.execute(
                    text(
                        "SELECT table_name FROM information_schema.tables "
                        "WHERE table_schema = current_schema()"
                    )
                )
            ).fetchall()
        return frozenset(str(row[0]) for row in rows if str(row[0]) in INDEX_SCHEMAS)

    async def validate_declared_table(self, index: str, dimensions: int | None = None) -> None:
        """只读校验已有 pgvector 表的完整字段、维度与 HNSW 索引。"""
        from zleap.sag.core.storage.index_schemas import (
            INDEX_SCHEMAS,
            declared_schema_document,
        )
        from zleap.sag.exceptions import StorageSchemaMismatchError

        if index not in INDEX_SCHEMAS:
            return
        table = _table_ident(index)
        if not await self._table_exists(table):
            return

        async with self._engine().connect() as conn:
            rows = (
                await conn.execute(
                    text(
                        "SELECT a.attname, pg_catalog.format_type(a.atttypid, a.atttypmod) "
                        "FROM pg_catalog.pg_attribute a "
                        "JOIN pg_catalog.pg_class c ON c.oid = a.attrelid "
                        "JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace "
                        "WHERE n.nspname = current_schema() AND c.relname = :table "
                        "AND a.attnum > 0 AND NOT a.attisdropped"
                    ),
                    {"table": table},
                )
            ).fetchall()
            index_rows = (
                await conn.execute(
                    text(
                        "SELECT indexdef FROM pg_catalog.pg_indexes "
                        "WHERE schemaname = current_schema() AND tablename = :table"
                    ),
                    {"table": table},
                )
            ).fetchall()

        actual = {str(name): str(type_name).lower() for name, type_name in rows}
        vector_dimensions: set[int] = set()
        for field in INDEX_SCHEMAS[index].vector_fields:
            type_name = actual.get(field, "")
            match = re.fullmatch(r"vector\((\d+)\)", type_name)
            if match:
                vector_dimensions.add(int(match.group(1)))
        if dimensions is None:
            if len(vector_dimensions) != 1:
                raise StorageSchemaMismatchError(f"pgvector 表 {table} 的向量维度无法唯一识别")
            dimensions = vector_dimensions.pop()

        expected_document = declared_schema_document(index, dimensions)
        expected = {"id": "text"}
        expected.update(
            {_ident(field): _col_type(value).lower() for field, value in expected_document.items()}
        )
        diffs: list[str] = []
        for field, expected_type in expected.items():
            actual_type = actual.get(field)
            if actual_type is None:
                diffs.append(f"{table}.{field}: 缺少字段")
            elif actual_type != expected_type:
                diffs.append(f"{table}.{field}: 类型 {actual_type!r} != {expected_type!r}")
        # 存量表可能保留旧列（如已下线的 is_delete）；合同只约束当前声明字段，不拒绝列超集。

        index_defs = "\n".join(str(row[0]).lower() for row in index_rows)
        for field in INDEX_SCHEMAS[index].vector_fields:
            has_hnsw = any(
                " using hnsw " in definition
                and "vector_cosine_ops" in definition
                and re.search(rf"[\"(]{re.escape(field)}[\" )]", definition)
                for definition in index_defs.splitlines()
            )
            if not has_hnsw:
                diffs.append(f"{table}.{field}: 缺少 cosine HNSW 索引")
        if diffs:
            raise StorageSchemaMismatchError(
                f"pgvector 表 {table} 不符合向量 schema 合同", diffs=diffs
            )

    async def create_declared_table(self, index: str, dimensions: int) -> None:
        """仅在物理表完全不存在时创建当前模式的完整表。"""
        from zleap.sag.core.storage.index_schemas import declared_schema_document

        table = _table_ident(index)
        if not await self._table_exists(table):
            await self._ensure_table(index, declared_schema_document(index, dimensions))
        await self.validate_declared_table(index, dimensions)

    async def ping(self) -> bool:
        try:
            async with self._engine().connect() as conn:
                await conn.execute(text("SELECT 1"))
            return True
        except Exception as e:
            logger.error("pgvector 连接检查失败", extra={"error_type": safe_error_type(e)})
            return False

    # ── 建表 / 建列(按文档自动推断)─────────────────────────
    async def _ensure_table(self, index: str, document: dict[str, Any]) -> None:
        from zleap.sag.core.storage.index_schemas import (
            INDEX_SCHEMAS,
            MODE_INDEX_NAMES,
            declared_schema_document,
        )
        from zleap.sag.exceptions import StorageError

        mode = self._storage_mode
        if index in INDEX_SCHEMAS and index not in MODE_INDEX_NAMES[mode]:
            raise StorageError(f"storage_mode={mode} 禁止访问向量表 {index}")
        schema_document = document
        if index in INDEX_SCHEMAS:
            dimensions = next(
                (
                    len(value)
                    for field in INDEX_SCHEMAS[index].vector_fields
                    if _is_vector(value := document.get(field))
                ),
                self._embedding_dimensions,
            )
            if dimensions is None:
                raise StorageError(f"无法确定 {index} 的向量维度")
            schema_document = {
                **declared_schema_document(index, dimensions),
                **document,
            }
        table = _table_ident(index)
        import json

        table_existed = await self._table_exists(table)

        async with self._engine().begin() as conn:
            await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
            await conn.execute(text(f'CREATE TABLE IF NOT EXISTS "{table}" (id text PRIMARY KEY)'))
            # 读现有列
            existing = {
                r[0]
                for r in (
                    await conn.execute(
                        text(
                            "SELECT column_name FROM information_schema.columns "
                            "WHERE table_name = :t"
                        ),
                        {"t": table},
                    )
                ).fetchall()
            }
            for field, value in schema_document.items():
                if field in ("_id", "id") or value is None:
                    continue
                col = _ident(field)
                if col in existing:
                    continue
                if table_existed:
                    from zleap.sag.exceptions import StorageSchemaMismatchError

                    raise StorageSchemaMismatchError(
                        f"pgvector 表 {table} 已存在但缺少字段 {col}；包不会执行 ALTER"
                    )
                await conn.execute(
                    text(
                        f'ALTER TABLE "{table}" ADD COLUMN IF NOT EXISTS "{col}" {_col_type(value)}'
                    )
                )
                if _is_vector(value):
                    await conn.execute(
                        text(
                            f'CREATE INDEX IF NOT EXISTS "{table}_{col}_hnsw" ON "{table}" '
                            f'USING hnsw ("{col}" vector_cosine_ops)'
                        )
                    )
        self._ready_tables.add(table)
        _ = json  # 保留(未来 jsonb 序列化用)

    # ── 写入 ────────────────────────────────────────────────
    async def index_document(
        self,
        index: str,
        document: dict[str, Any],
        doc_id: str | None = None,
        routing: str | None = None,
    ) -> str:
        did = doc_id or document.get("_id") or document.get("id") or ""
        await self._write(index, [(str(did), document)])
        return str(did)

    async def bulk_index(
        self,
        index: str,
        documents: list[dict[str, Any]],
        return_details: bool = False,
        routing: str | None = None,
    ) -> Any:
        rows = []
        for d in documents:
            did = (
                d.get("_id")
                or d.get("id")
                or d.get("chunk_id")
                or d.get("entity_id")
                or d.get("event_id")
            )
            if did is None:
                continue
            rows.append((str(did), {k: v for k, v in d.items() if k != "_id"}))
        await self._write(index, rows)
        n = len(rows)
        if return_details:
            return {
                "success": True,
                "total": len(documents),
                "success_count": n,
                "error_count": 0,
                "errors": [],
            }
        return n

    async def _write(self, index: str, rows: list[tuple[str, dict[str, Any]]]) -> None:
        if not rows:
            return
        await self._ensure_table(index, rows[0][1])
        table = _table_ident(index)
        import json

        async with self._engine().begin() as conn:
            for did, doc in rows:
                cols = ["id"]
                placeholders = [":id"]
                params: dict[str, Any] = {"id": did}
                for field, value in doc.items():
                    if field in ("_id", "id") or value is None:
                        continue
                    col = _ident(field)
                    cols.append(f'"{col}"')
                    if _is_vector(value):
                        placeholders.append(f"(:{col})::vector")
                        params[col] = _vec_literal(value)
                    elif isinstance(value, (list, dict)):
                        placeholders.append(f"(:{col})::jsonb")
                        params[col] = json.dumps(value, ensure_ascii=False)
                    else:
                        placeholders.append(f":{col}")
                        params[col] = value
                updates = ", ".join(f"{c} = EXCLUDED.{c}" for c in cols if c != "id")
                sql = (
                    f'INSERT INTO "{table}" ({", ".join(cols)}) VALUES ({", ".join(placeholders)}) '
                    f"ON CONFLICT (id) DO UPDATE SET {updates}"
                    if updates
                    else f'INSERT INTO "{table}" (id) VALUES (:id) ON CONFLICT (id) DO NOTHING'
                )
                await conn.execute(text(sql), params)

    # ── filter_query(ES) → SQL WHERE ──────────────────────
    def _translate_filter(self, fq: dict[str, Any] | None) -> tuple[str, dict[str, Any]]:
        params: dict[str, Any] = {}
        counter = [0]

        def _p(val: Any) -> str:
            counter[0] += 1
            key = f"f{counter[0]}"
            params[key] = val
            return key

        def _clause(node: Any) -> str:
            if not isinstance(node, dict):
                return ""
            if "bool" in node:
                body = node["bool"]
                parts: list[str] = []
                for key in ("must", "filter"):
                    children = body.get(key, [])
                    children = children if isinstance(children, list) else [children]
                    parts.extend(part for child in children if (part := _clause(child)))
                should = body.get("should", [])
                should = should if isinstance(should, list) else [should]
                should_parts = [part for child in should if (part := _clause(child))]
                if should_parts:
                    minimum = body.get("minimum_should_match", 0 if parts else 1)
                    if int(minimum or 0) >= 1:
                        parts.append(" OR ".join(f"({part})" for part in should_parts))
                must_not = body.get("must_not", [])
                must_not = must_not if isinstance(must_not, list) else [must_not]
                parts.extend(f"NOT ({part})" for child in must_not if (part := _clause(child)))
                return " AND ".join(f"({p})" for p in parts) if parts else ""
            if "term" in node:
                ((f, v),) = node["term"].items()
                if isinstance(v, dict):
                    v = v.get("value")
                col = "id" if f == "_id" else _ident(f)
                if v is False:
                    return f'("{col}" = false OR "{col}" IS NULL)'
                return f'"{col}" = :{_p(v)}'
            if "terms" in node:
                ((f, vals),) = node["terms"].items()
                col = "id" if f == "_id" else _ident(f)
                return f'"{col}" = ANY(:{_p(list(vals))})'
            if "range" in node:
                ((f, conditions),) = node["range"].items()
                col = "id" if f == "_id" else _ident(f)
                operators = {"gte": ">=", "gt": ">", "lte": "<=", "lt": "<"}
                return " AND ".join(
                    f'"{col}" {operators[operator]} :{_p(value)}'
                    for operator, value in conditions.items()
                    if operator in operators
                )
            if "exists" in node:
                field = node["exists"]["field"]
                col = "id" if field == "_id" else _ident(field)
                return f'"{col}" IS NOT NULL'
            return ""

        if not fq:
            return "", params
        return _clause(fq), params

    # ── kNN ─────────────────────────────────────────────────
    async def vector_search(
        self,
        index: str,
        field: str,
        vector: list[float],
        size: int = 10,
        filter_query: dict[str, Any] | None = None,
        routing: str | None = None,
        include_vector: bool = False,
    ) -> list[dict[str, Any]]:
        table = _table_ident(index)
        col = _ident(field)
        if table not in self._ready_tables and not await self._table_exists(table):
            return []
        where, params = self._translate_filter(filter_query)
        params["qv"] = _vec_literal(vector)
        cols = await self._scalar_columns(table, include_vector)
        select_cols = ", ".join(f'"{c}"' for c in cols)
        where_sql = f"WHERE {where}" if where else ""
        sql = (
            # _score 对齐 ES ``similarity="cosine"`` 的 (1 + cos) / 2 语义，
            # 见 index_schemas.cosine_distance_to_score。
            f"SELECT {select_cols}, "
            f'1 - (LEAST(2, GREATEST(0, "{col}" <=> (:qv)::vector)) / 2) AS _score '
            f'FROM "{table}" {where_sql} '
            f'ORDER BY "{col}" <=> (:qv)::vector LIMIT {int(size)}'
        )
        async with self._engine().connect() as conn:
            result = await conn.execute(text(sql), params)
            return [dict(r._mapping) for r in result.fetchall()]

    # ── search(ES DSL 子集:match → ILIKE;term/terms 过滤)──
    async def search(
        self,
        index: str,
        query: dict[str, Any],
        size: int = 10,
        from_: int = 0,
        routing: str | None = None,
        return_full_response: bool = False,
        include_vector: bool = False,
        **kwargs: Any,
    ) -> Any:
        table = _table_ident(index)
        if not await self._table_exists(table):
            return {"total": 0, "max_score": 0, "hits": []} if return_full_response else []
        where, params = self._translate_filter(query if "bool" in (query or {}) else None)
        sort = tuple(kwargs.pop("sort", ()))
        order = ""
        # match 子句 → ILIKE 排序
        match = self._extract_match(query)
        if match:
            f, txt = match
            params["m"] = f"%{txt}%"
            like_col = _ident(f)
            match_where = f'"{like_col}" ILIKE :m'
            where = f"({where}) AND {match_where}" if where else match_where
        if sort:
            order = "ORDER BY " + ", ".join(
                f'"{_ident(field)}" {"DESC" if direction == "desc" else "ASC"} NULLS LAST'
                for field, direction in sort
            )
        cols = await self._scalar_columns(table, include_vector)
        select_cols = ", ".join(f'"{c}"' for c in cols)
        where_sql = f"WHERE {where}" if where else ""
        sql = f'SELECT {select_cols} FROM "{table}" {where_sql} {order} LIMIT {int(size)} OFFSET {int(from_)}'
        async with self._engine().connect() as conn:
            rows = [dict(r._mapping) for r in (await conn.execute(text(sql), params)).fetchall()]
        if return_full_response:
            return {
                "total": len(rows),
                "max_score": 1.0 if rows else 0,
                "hits": [
                    {"id": r.get("id"), "score": 1.0, "source": r, "index": index} for r in rows
                ],
            }
        return rows

    @staticmethod
    def _extract_match(query: dict[str, Any] | None) -> tuple[str, str] | None:
        if not query:
            return None
        if "match" in query:
            ((f, v),) = query["match"].items()
            return f, str(v)
        if "bool" in query:
            for c in query["bool"].get("must", []):
                if "match" in c:
                    ((f, v),) = c["match"].items()
                    return f, str(v)
        return None

    # ── 元信息 ──────────────────────────────────────────────
    async def _table_exists(self, table: str) -> bool:
        async with self._engine().connect() as conn:
            r = await conn.execute(text("SELECT to_regclass(:t)"), {"t": f'public."{table}"'})
            return r.scalar() is not None

    async def _scalar_columns(self, table: str, include_vector: bool) -> list[str]:
        async with self._engine().connect() as conn:
            rows = (
                await conn.execute(
                    text(
                        "SELECT column_name, udt_name FROM information_schema.columns "
                        "WHERE table_name = :t"
                    ),
                    {"t": table},
                )
            ).fetchall()
        return [c for c, udt in rows if include_vector or udt != "vector"]

    async def count_documents(self, index: str, query: dict[str, Any] | None = None) -> int:
        table = _table_ident(index)
        if not await self._table_exists(table):
            return 0
        where, params = self._translate_filter(query if query and "bool" in query else None)
        where_sql = f"WHERE {where}" if where else ""
        async with self._engine().connect() as conn:
            r = await conn.execute(text(f'SELECT count(*) FROM "{table}" {where_sql}'), params)
            return int(r.scalar() or 0)

    async def get_document(self, index: str, doc_id: str) -> dict[str, Any] | None:
        table = _table_ident(index)
        if not await self._table_exists(table):
            return None
        cols = await self._scalar_columns(table, include_vector=False)
        select_cols = ", ".join(f'"{c}"' for c in cols)
        async with self._engine().connect() as conn:
            r = await conn.execute(
                text(f'SELECT {select_cols} FROM "{table}" WHERE id = :id'), {"id": doc_id}
            )
            row = r.fetchone()
            return dict(row._mapping) if row else None

    async def delete_document(self, index: str, doc_id: str) -> bool:
        table = _table_ident(index)
        if not await self._table_exists(table):
            return False
        async with self._engine().begin() as conn:
            await conn.execute(text(f'DELETE FROM "{table}" WHERE id = :id'), {"id": doc_id})
        return True

    async def create_index(self, *args: Any, **kwargs: Any) -> bool:
        return True  # 表按需自动创建

    async def index_exists(self, index: str) -> bool:
        return await self._table_exists(_table_ident(index))

    async def delete_index(self, index: str) -> bool:
        async with self._engine().begin() as conn:
            await conn.execute(text(f'DROP TABLE IF EXISTS "{_table_ident(index)}"'))
        return True

    async def close(self) -> None:
        return None
