"""Request-local search filters shared by repository and relational recall paths."""

from __future__ import annotations

from collections.abc import Sequence
from contextvars import ContextVar, Token
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from sqlalchemy import and_, or_

from zleap.sag.core.adapters import Filter


@dataclass(frozen=True, slots=True)
class RepositorySearchScope:
    data_source_ids: tuple[str, ...] = ()
    source_ids: tuple[str, ...] = ()
    source_types: tuple[str, ...] = ()
    start_time: datetime | None = None
    end_time: datetime | None = None


@dataclass(frozen=True, slots=True)
class ActiveGeneration:
    data_source_id: str
    source_id: str
    generation_id: str


@dataclass(frozen=True, slots=True)
class ActiveGenerationScope:
    """Manifest snapshot used consistently by all recall paths in one request."""

    data_source_ids: tuple[str, ...]
    generations: tuple[ActiveGeneration, ...] = ()
    managed_sources: tuple[tuple[str, str], ...] = ()
    inactive_data_source_ids: tuple[str, ...] = ()
    revisions: tuple[tuple[str, int], ...] = ()


_search_scope_var: ContextVar[RepositorySearchScope | None] = ContextVar(
    "zleap_sag_repository_search_scope", default=None
)
_active_generation_scope_var: ContextVar[ActiveGenerationScope | None] = ContextVar(
    "zleap_sag_active_generation_scope", default=None
)


def set_search_scope(scope: RepositorySearchScope) -> Token[RepositorySearchScope | None]:
    return _search_scope_var.set(scope)


def reset_search_scope(token: Token[RepositorySearchScope | None]) -> None:
    _search_scope_var.reset(token)


def get_search_scope() -> RepositorySearchScope | None:
    return _search_scope_var.get()


def set_active_generation_scope(
    scope: ActiveGenerationScope,
) -> Token[ActiveGenerationScope | None]:
    return _active_generation_scope_var.set(scope)


def reset_active_generation_scope(token: Token[ActiveGenerationScope | None]) -> None:
    _active_generation_scope_var.reset(token)


def get_active_generation_scope() -> ActiveGenerationScope | None:
    return _active_generation_scope_var.get()


def _active_generation_vector_filter() -> Filter | None:
    scope = get_active_generation_scope()
    if scope is None:
        return None
    inactive = set(scope.inactive_data_source_ids)
    managed_by_source: dict[str, set[str]] = {}
    for data_source_id, source_id in scope.managed_sources:
        managed_by_source.setdefault(data_source_id, set()).add(source_id)

    branches: list[Filter] = [
        Filter.all(
            Filter.eq("data_source_id", item.data_source_id),
            Filter.eq("source_id", item.source_id),
            Filter.eq("generation_id", item.generation_id),
        )
        for item in scope.generations
        if item.data_source_id not in inactive
    ]
    # Rows created by the explicit stage API have no durable generation. They remain
    # visible only until the same source enters manifest-managed execution.
    for data_source_id in scope.data_source_ids:
        if data_source_id in inactive:
            continue
        unmanaged_parts = [
            Filter.eq("data_source_id", data_source_id),
            Filter.negate(Filter.exists("generation_id")),
        ]
        managed = sorted(managed_by_source.get(data_source_id, ()))
        if managed:
            unmanaged_parts.append(Filter.negate(Filter.one_of("source_id", managed)))
        branches.append(Filter.all(*unmanaged_parts))
    if not branches:
        # An impossible predicate is safer than silently omitting the visibility
        # rule for a deleted namespace.
        return Filter.eq("data_source_id", "__sag_no_visible_generation__")
    return branches[0] if len(branches) == 1 else Filter.any(*branches)


def has_search_scope_filters() -> bool:
    """Return whether the active request scope adds an actual storage filter."""

    scope = get_search_scope()
    return get_active_generation_scope() is not None or (
        scope is not None
        and bool(
            scope.data_source_ids
            or scope.source_ids
            or scope.source_types
            or scope.start_time is not None
            or scope.end_time is not None
        )
    )


def build_time_range_filter(
    start_time: datetime | None,
    end_time: datetime | None,
) -> Filter | None:
    """Build the event/chunk time-overlap predicate used by vector backends."""

    if not start_time and not end_time:
        return None
    point_bounds: dict[str, Any] = {}
    if start_time:
        point_bounds["gte"] = start_time
    if end_time:
        point_bounds["lte"] = end_time

    overlap = [Filter.exists("end_time")]
    if end_time:
        overlap.append(Filter.range("start_time", lte=end_time))
    if start_time:
        overlap.append(Filter.range("end_time", gte=start_time))
    point = Filter.all(
        Filter.negate(Filter.exists("end_time")),
        Filter.range("start_time", **point_bounds),
    )
    return Filter.any(Filter.all(*overlap), point)


def append_scope_filters(
    filters: list[Filter],
    *,
    data_source_ids: bool = True,
    source_ids: bool = True,
    source_types: bool = True,
    time_range: bool = True,
    active_generations: bool = True,
) -> None:
    """只追加目标索引实际声明的作用域字段。"""

    scope = get_search_scope()
    if scope is not None:
        if data_source_ids and scope.data_source_ids:
            filters.append(Filter.one_of("data_source_id", list(scope.data_source_ids)))
        if source_ids and scope.source_ids:
            filters.append(Filter.one_of("source_id", list(scope.source_ids)))
        if source_types and scope.source_types:
            filters.append(Filter.one_of("source_type", list(scope.source_types)))
        if time_range:
            if time_filter := build_time_range_filter(scope.start_time, scope.end_time):
                filters.append(time_filter)
    if active_generations:
        if generation_filter := _active_generation_vector_filter():
            filters.append(generation_filter)


def active_generation_predicate(model: Any) -> Any | None:
    """Return the SQL equivalent of the vector generation visibility predicate."""
    scope = get_active_generation_scope()
    if scope is None:
        return None
    inactive = set(scope.inactive_data_source_ids)
    managed_by_source: dict[str, set[str]] = {}
    for data_source_id, source_id in scope.managed_sources:
        managed_by_source.setdefault(data_source_id, set()).add(source_id)
    branches: list[Any] = [
        and_(
            model.data_source_id == item.data_source_id,
            model.source_id == item.source_id,
            model.generation_id == item.generation_id,
        )
        for item in scope.generations
        if item.data_source_id not in inactive
    ]
    for data_source_id in scope.data_source_ids:
        if data_source_id in inactive:
            continue
        unmanaged_parts: list[Any] = [
            model.data_source_id == data_source_id,
            model.generation_id.is_(None),
        ]
        managed = sorted(managed_by_source.get(data_source_id, ()))
        if managed:
            unmanaged_parts.append(~model.source_id.in_(managed))
        branches.append(and_(*unmanaged_parts))
    if not branches:
        return model.data_source_id == "__sag_no_visible_generation__"
    return or_(*branches)


def apply_active_generation_scope(statement: Any, model: Any) -> Any:
    predicate = active_generation_predicate(model)
    return statement.where(predicate) if predicate is not None else statement


def source_event_scope_predicate(
    statement: Any, event_model: Any, scope: RepositorySearchScope
) -> Any:
    """Apply an explicit request scope to a SourceEvent candidate query."""

    statement = statement.where(event_model.not_deleted())
    statement = apply_active_generation_scope(statement, event_model)
    if scope.data_source_ids:
        statement = statement.where(event_model.data_source_id.in_(list(scope.data_source_ids)))
    if scope.source_ids:
        statement = statement.where(event_model.source_id.in_(list(scope.source_ids)))
    if scope.source_types:
        statement = statement.where(event_model.source_type.in_(list(scope.source_types)))
    if scope.end_time is not None:
        statement = statement.where(event_model.start_time <= scope.end_time)
    if scope.start_time is not None:
        statement = statement.where(
            or_(
                event_model.end_time >= scope.start_time,
                and_(
                    event_model.end_time.is_(None),
                    event_model.start_time >= scope.start_time,
                ),
            )
        )
    return statement


def apply_source_event_scope(statement: Any, event_model: Any) -> Any:
    """Apply the active request scope before relational candidate limiting/ranking."""

    scope = get_search_scope()
    if scope is None:
        return statement
    return source_event_scope_predicate(statement, event_model, scope)


async def fetch_event_ids_for_entities(
    session: Any,
    entity_ids: Sequence[str],
    data_source_ids: Sequence[str] | None = None,
    *,
    distinct: bool = False,
) -> list[Any]:
    """Entity -> event recall channel shared by the search modules."""

    from sqlalchemy import select

    from zleap.sag.db import EventEntity, SourceEvent

    stmt = (
        select(EventEntity.event_id)
        .join(SourceEvent, SourceEvent.id == EventEntity.event_id)
        .where(EventEntity.entity_id.in_(list(entity_ids)))
    )
    if distinct:
        stmt = stmt.distinct()
    if data_source_ids:
        stmt = stmt.where(SourceEvent.data_source_id.in_(list(data_source_ids)))
    stmt = apply_source_event_scope(stmt, SourceEvent)
    result = await session.execute(stmt)
    return [row[0] for row in result.fetchall()]
