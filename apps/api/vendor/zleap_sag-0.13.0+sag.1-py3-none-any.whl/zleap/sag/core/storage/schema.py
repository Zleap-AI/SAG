"""向量结构 manifest 的只读模式识别与合同校验入口。"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Literal

from zleap.sag.core.storage.index_schemas import MODE_INDEX_NAMES, dimensions_for_index
from zleap.sag.exceptions import StorageModeMismatchError

StorageMode = Literal["normal", "lite"]
_ALL = frozenset(MODE_INDEX_NAMES["normal"])


class VectorModeState(StrEnum):
    EMPTY = "EMPTY"
    NORMAL = "NORMAL"
    LITE = "LITE"
    AMBIGUOUS = "AMBIGUOUS"


@dataclass(frozen=True)
class VectorSchemaScan:
    state: VectorModeState
    object_names: frozenset[str]
    missing_objects: tuple[str, ...]


def _is_already_exists_error(exc: Exception) -> bool:
    """只识别向量 provider 的“对象已存在”并发竞态。"""
    original = getattr(exc, "orig", exc)
    args = getattr(original, "args", ())
    codes = {str(value).upper() for value in args[:1]}
    code = getattr(original, "pgcode", None) or getattr(original, "sqlstate", None)
    if code is not None:
        codes.add(str(code).upper())
    if codes.intersection({"1050", "42P07", "42710"}):
        return True
    message = str(original).lower()
    return any(
        marker in message
        for marker in (
            "already exists",
            "duplicate table",
            "resource_already_exists_exception",
        )
    )


def detect_vector_mode(names: frozenset[str]) -> VectorModeState:
    """向量对象名已无法区分模式；模式以 ``sag_schema_meta`` 为准。"""
    relevant = names.intersection(_ALL)
    if not relevant:
        return VectorModeState.EMPTY
    return VectorModeState.AMBIGUOUS


def ensure_vector_mode_matches(state: VectorModeState, storage_mode: StorageMode) -> None:
    # normal/local 与 lite/saas 使用相同的四个对象名，AMBIGUOUS 是正常状态；
    # 模式由关系库 sag_schema_meta 判定，这里只保留对旧显式状态的防御。
    if state in (VectorModeState.NORMAL, VectorModeState.LITE):
        actual = state.value.lower()
        if actual != storage_mode:
            raise StorageModeMismatchError(
                f"storage_mode={storage_mode} 不能访问已识别为 {actual} 的向量存储"
            )


async def prepare_vector_schema(
    vector_adapter: Any,
    *,
    storage_mode: StorageMode,
    dimensions: int | None,
    create_missing: bool,
    enforce_mode: bool = True,
) -> VectorSchemaScan:
    """先校验已有结构，再补建当前可确定向量维度的完整对象。"""
    provider = getattr(vector_adapter, "provider", None)
    if provider not in ("lancedb", "es", "pgvector", "oceanbase"):
        return VectorSchemaScan(VectorModeState.EMPTY, frozenset(), ())

    names = await vector_adapter.schema_object_names()
    state = detect_vector_mode(names)
    if enforce_mode:
        ensure_vector_mode_matches(state, storage_mode)

    required = MODE_INDEX_NAMES[storage_mode]
    existing_required = [name for name in required if name in names]
    for name in existing_required:
        await vector_adapter.validate_schema_object(
            name,
            (dimensions_for_index(storage_mode, name, dimensions) if enforce_mode else None),
        )

    missing = tuple(name for name in required if name not in names)
    if create_missing:
        for name in missing:
            index_dimensions = dimensions_for_index(storage_mode, name, dimensions)
            if index_dimensions is None:
                # 未声明模型维度时，等首次真实向量写入按返回值推断，不能猜成 1024。
                continue
            try:
                await vector_adapter.create_schema_object(name, index_dimensions)
            except Exception as exc:
                if not _is_already_exists_error(exc):
                    raise
                # 另一实例已抢先创建；下面重扫并逐对象校验。
        names = await vector_adapter.schema_object_names()
        for name in required:
            if name not in names:
                continue
            await vector_adapter.validate_schema_object(
                name,
                dimensions_for_index(storage_mode, name, dimensions),
            )
        missing = tuple(name for name in required if name not in names)
        state = detect_vector_mode(names)

    return VectorSchemaScan(state, names, missing)
