"""OceanBase 向量后端。

设计(对齐 pgvector_store 的接入方式,单库部署):
- 使用向量侧专属 OceanBase ``SqlRuntime``；即使物理同库也不复用关系连接池。
- 每个逻辑 collection 映射为一张表,列从写入文档自动推断(向量列 → ``VECTOR(N)`` + HNSW cosine 索引;
  标量 → longtext/bigint/double/tinyint;其它 → json)。维度按首个向量长度确定(与 pgvector 一致)。
- kNN:``cosine_distance(col, '[...]')``,``_score = 1 - 距离``;有向量索引时 ``ORDER BY ... APPROXIMATE``
  (ANN),否则精确暴力(仍正确);filter_query(ES bool/term/terms/range/exists)→ SQL WHERE。
- BM25/词法退化为 ``LIKE``（非真 BM25），故不声明 LEXICAL_SEARCH。

前置:OceanBase **V4.3.3+**,且租户需配 ``ob_vector_memory_limit_percentage>0`` 方可建/用向量索引;
未配置时索引创建失败 → 自动降级为精确检索(带告警),功能仍可用。
"""

from __future__ import annotations

import json
import re
from datetime import date, datetime
from typing import Any, TypeAlias, TypeGuard

from sqlalchemy import text

from zleap.sag._safe_error import safe_error_type
from zleap.sag.exceptions import ConfigError, StorageModeError
from zleap.sag.utils import get_logger

logger = get_logger("storage.oceanbase")

_IDENT = re.compile(r"[^a-zA-Z0-9_]")
_MIN_VECTOR_LEN = 8


def _ident(name: str) -> str:
    """把索引/字段名规整为安全的 SQL 标识符(仅 [a-zA-Z0-9_])。"""
    return _IDENT.sub("_", name)


def _table_ident(index: str) -> str:
    """沿用既有逻辑索引名；storage_mode 不改写物理表名。"""
    return _ident(index)


VectorValue: TypeAlias = list[int | float] | tuple[int | float, ...]


def _is_vector(value: object) -> TypeGuard[VectorValue]:
    return (
        isinstance(value, (list, tuple))
        and len(value) > _MIN_VECTOR_LEN
        and all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in value)
    )


def _vec_literal(vec: VectorValue) -> str:
    """OceanBase 向量字面量:字符串 ``'[f0,f1,...]'``。"""
    return "[" + ",".join(repr(float(x)) for x in vec) + "]"


def _col_type(value: Any) -> str:
    if _is_vector(value):
        return f"VECTOR({len(value)})"
    if isinstance(value, bool):
        return "tinyint(1)"
    if isinstance(value, int):
        return "bigint"
    if isinstance(value, float):
        return "double"
    if isinstance(value, str):
        return "longtext"
    return "json"


def _doc_id(doc: dict[str, Any], explicit: str | None = None) -> str | None:
    did = (
        explicit
        or doc.get("_id")
        or doc.get("id")
        or doc.get("chunk_id")
        or doc.get("entity_id")
        or doc.get("event_id")
    )
    return str(did) if did is not None else None


class OceanBaseVectorStore:
    """OceanBase provider implementation owned by its public adapter."""

    def __init__(
        self,
        *,
        runtime: Any | None = None,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
    ) -> None:
        if storage_mode not in ("normal", "lite"):
            raise StorageModeError("storage_mode 必须是 normal 或 lite")
        self._storage_mode = storage_mode
        self._embedding_dimensions = embedding_dimensions
        self._runtime = runtime
        self._ready_tables: set[str] = set()
        self._approx_cols: set[str] = set()  # "table.col" 已成功建向量索引 → 可用 APPROXIMATE

    # ── 底层:向量侧专属 OceanBase runtime────────────────────
    def _engine(self) -> Any:
        if self._runtime is None:
            raise ConfigError("OceanBaseVectorStore 需要显式注入向量侧 SqlRuntime")
        return self._runtime.engine()

    async def schema_table_names(self) -> frozenset[str]:
        """列出当前 database 中已存在的 SAG 正式向量表。"""
        from zleap.sag.core.storage.index_schemas import INDEX_SCHEMAS

        async with self._engine().connect() as conn:
            rows = (
                await conn.execute(
                    text(
                        "SELECT table_name FROM information_schema.tables "
                        "WHERE table_schema = DATABASE()"
                    )
                )
            ).fetchall()
        return frozenset(str(row[0]) for row in rows if str(row[0]) in INDEX_SCHEMAS)

    async def validate_declared_table(self, index: str, dimensions: int | None = None) -> None:
        """只读校验已有 OceanBase 向量表的完整字段与维度。"""
        from zleap.sag.core.storage.index_schemas import (
            INDEX_SCHEMAS,
            declared_schema_document,
        )
        from zleap.sag.exceptions import StorageSchemaMismatchError

        if index not in INDEX_SCHEMAS:
            return
        table = _table_ident(index)
        if not await self._table_exists(table):
            return
        async with self._engine().connect() as conn:
            rows = (
                await conn.execute(
                    text(
                        "SELECT column_name, column_type, column_key "
                        "FROM information_schema.columns "
                        "WHERE table_schema = DATABASE() AND table_name = :table"
                    ),
                    {"table": table},
                )
            ).fetchall()

        actual = {
            str(name): (str(type_name).lower(), str(column_key).upper())
            for name, type_name, column_key in rows
        }
        vector_dimensions: set[int] = set()
        for field in INDEX_SCHEMAS[index].vector_fields:
            type_name = actual.get(field, ("", ""))[0]
            match = re.fullmatch(r"vector\((\d+)\)", type_name)
            if match:
                vector_dimensions.add(int(match.group(1)))
        if dimensions is None:
            if len(vector_dimensions) != 1:
                raise StorageSchemaMismatchError(f"OceanBase 向量表 {table} 的向量维度无法唯一识别")
            dimensions = vector_dimensions.pop()

        expected_document = declared_schema_document(index, dimensions)
        expected = {"id": "varchar(255)"}
        expected.update(
            {_ident(field): _col_type(value).lower() for field, value in expected_document.items()}
        )
        diffs: list[str] = []
        for field, expected_type in expected.items():
            item = actual.get(field)
            if item is None:
                diffs.append(f"{table}.{field}: 缺少字段")
            elif item[0] != expected_type:
                diffs.append(f"{table}.{field}: 类型 {item[0]!r} != {expected_type!r}")
        if actual.get("id", ("", ""))[1] != "PRI":
            diffs.append(f"{table}.id: 缺少主键")
        # 存量表可能保留旧列（如已下线的 is_delete）；合同只约束当前声明字段，不拒绝列超集。
        if diffs:
            raise StorageSchemaMismatchError(
                f"OceanBase 向量表 {table} 不符合向量 schema 合同",
                diffs=diffs,
            )

    async def create_declared_table(self, index: str, dimensions: int) -> None:
        """仅在物理表完全不存在时创建当前模式的完整表。"""
        from zleap.sag.core.storage.index_schemas import declared_schema_document

        table = _table_ident(index)
        if not await self._table_exists(table):
            await self._ensure_table(index, declared_schema_document(index, dimensions))
        await self.validate_declared_table(index, dimensions)

    # ── 纯 SQL 构建(可单测,不触发 I/O)───────────────────────
    @staticmethod
    def _add_column_sql(table: str, col: str, value: Any) -> str:
        return f"ALTER TABLE `{table}` ADD COLUMN `{col}` {_col_type(value)}"

    @staticmethod
    def _vector_index_sql(table: str, col: str) -> str:
        return (
            f"CREATE VECTOR INDEX `{table}_{col}_vidx` ON `{table}`(`{col}`) "
            f"WITH (distance=cosine, type=hnsw)"
        )

    @staticmethod
    def _upsert_sql(table: str, cols: list[str], placeholders: list[str]) -> str:
        updates = ", ".join(f"`{c}` = VALUES(`{c}`)" for c in cols if c != "id")
        cols_sql = ", ".join(f"`{c}`" for c in cols)
        if updates:
            return (
                f"INSERT INTO `{table}` ({cols_sql}) VALUES ({', '.join(placeholders)}) "
                f"ON DUPLICATE KEY UPDATE {updates}"
            )
        return (
            f"INSERT INTO `{table}` (`id`) VALUES (:id) ON DUPLICATE KEY UPDATE `id` = VALUES(`id`)"
        )

    def _knn_sql(
        self,
        table: str,
        col: str,
        vector: list[float],
        select_cols: list[str],
        where: str,
        size: int,
    ) -> str:
        """kNN SQL。向量字面量内联(满足 OB "与常量向量比较" 的 APPROXIMATE 约束)。"""
        qv = _vec_literal(vector)
        select_sql = ", ".join(f"`{c}`" for c in select_cols)
        where_sql = f"WHERE {where}" if where else ""
        approx = "APPROXIMATE " if f"{table}.{col}" in self._approx_cols else ""
        return (
            # _score 对齐 ES ``similarity="cosine"`` 的 (1 + cos) / 2 语义，
            # 见 index_schemas.cosine_distance_to_score。
            f"SELECT {select_sql}, "
            f"(1 - (LEAST(2, GREATEST(0, cosine_distance(`{col}`, '{qv}'))) / 2)) AS _score "
            f"FROM `{table}` {where_sql} "
            f"ORDER BY cosine_distance(`{col}`, '{qv}') {approx}LIMIT {int(size)}"
        )

    def _translate_filter(self, fq: dict[str, Any] | None) -> tuple[str, dict[str, Any]]:
        params: dict[str, Any] = {}
        counter = [0]

        def _p(val: Any) -> str:
            counter[0] += 1
            key = f"f{counter[0]}"
            params[key] = val
            return key

        def _col(f: str) -> str:
            return "id" if f == "_id" else _ident(f.removesuffix(".keyword"))

        def _clause(node: Any) -> str:
            if not isinstance(node, dict):
                return ""
            if "bool" in node:
                b = node["bool"]
                parts: list[str] = []
                for key in ("must", "filter"):
                    sub = b.get(key, [])
                    sub = sub if isinstance(sub, list) else [sub]
                    parts.extend(p for c in sub if (p := _clause(c)))
                should = b.get("should", [])
                should = should if isinstance(should, list) else [should]
                should_parts = [p for c in should if (p := _clause(c))]
                if should_parts:
                    msm = b.get("minimum_should_match", 0 if parts else 1)
                    if int(msm or 0) >= 1:
                        parts.append(" OR ".join(f"({p})" for p in should_parts))
                must_not = b.get("must_not", [])
                must_not = must_not if isinstance(must_not, list) else [must_not]
                parts.extend(f"NOT ({p})" for c in must_not if (p := _clause(c)))
                return " AND ".join(f"({p})" for p in parts) if parts else ""
            if "term" in node:
                ((f, v),) = node["term"].items()
                if isinstance(v, dict):
                    v = v.get("value")
                col = _col(f)
                if v is False:
                    return f"(`{col}` = 0 OR `{col}` IS NULL)"
                return f"`{col}` = :{_p(v)}"
            if "terms" in node:
                ((f, vals),) = node["terms"].items()
                col = _col(f)
                values = list(vals)
                if not values:
                    return "1 = 0"
                keys = ", ".join(f":{_p(v)}" for v in values)
                return f"`{col}` IN ({keys})"
            if "range" in node:
                ((f, conds),) = node["range"].items()
                col = _col(f)
                ops = {"gte": ">=", "gt": ">", "lte": "<=", "lt": "<"}
                return " AND ".join(
                    f"`{col}` {ops[op]} :{_p(v)}" for op, v in conds.items() if op in ops
                )
            if "exists" in node:
                return f"`{_col(node['exists']['field'])}` IS NOT NULL"
            return ""

        if not fq:
            return "", params
        return _clause(fq), params

    # ── 连通性 ──────────────────────────────────────────────
    async def ping(self) -> bool:
        try:
            async with self._engine().connect() as conn:
                await conn.execute(text("SELECT 1"))
            return True
        except Exception as e:
            logger.error("OceanBase 连接检查失败", extra={"error_type": safe_error_type(e)})
            return False

    async def check_connection(self) -> bool:
        return await self.ping()

    # ── 建表 / 建列(按文档自动推断)─────────────────────────
    async def _ensure_table(self, index: str, document: dict[str, Any]) -> None:
        from zleap.sag.core.storage.index_schemas import (
            INDEX_SCHEMAS,
            MODE_INDEX_NAMES,
            declared_schema_document,
        )
        from zleap.sag.exceptions import StorageError

        mode = self._storage_mode
        if index in INDEX_SCHEMAS and index not in MODE_INDEX_NAMES[mode]:
            raise StorageError(f"storage_mode={mode} 禁止访问向量表 {index}")
        schema_document = document
        if index in INDEX_SCHEMAS:
            dimensions = next(
                (
                    len(value)
                    for field in INDEX_SCHEMAS[index].vector_fields
                    if _is_vector(value := document.get(field))
                ),
                self._embedding_dimensions,
            )
            if dimensions is None:
                raise StorageError(f"无法确定 {index} 的向量维度")
            schema_document = {
                **declared_schema_document(index, dimensions),
                **document,
            }
        table = _table_ident(index)
        table_existed = await self._table_exists(table)
        async with self._engine().begin() as conn:
            await conn.execute(
                text(f"CREATE TABLE IF NOT EXISTS `{table}` (`id` VARCHAR(255) PRIMARY KEY)")
            )
            existing = {
                r[0]
                for r in (
                    await conn.execute(
                        text(
                            "SELECT column_name FROM information_schema.columns "
                            "WHERE table_name = :t AND table_schema = DATABASE()"
                        ),
                        {"t": table},
                    )
                ).fetchall()
            }
            for field, value in schema_document.items():
                if field in ("_id", "id") or value is None:
                    continue
                col = _ident(field)
                if col in existing:
                    continue
                if table_existed:
                    from zleap.sag.exceptions import StorageSchemaMismatchError

                    raise StorageSchemaMismatchError(
                        f"OceanBase 向量表 {table} 已存在但缺少字段 {col}；包不会执行 ALTER"
                    )
                await conn.execute(text(self._add_column_sql(table, col, value)))
                if _is_vector(value):
                    await self._try_create_vector_index(conn, table, col)
        self._ready_tables.add(table)

    async def _try_create_vector_index(self, conn: Any, table: str, col: str) -> None:
        """尝试建 HNSW 向量索引;失败(如租户未配 ob_vector_memory_limit_percentage)则降级精确。"""
        try:
            await conn.execute(text(self._vector_index_sql(table, col)))
            self._approx_cols.add(f"{table}.{col}")
        except Exception as e:
            logger.warning(
                "OceanBase 向量索引创建失败,降级为精确检索;"
                "如需 ANN 请为租户设置 ob_vector_memory_limit_percentage>0",
                extra={"error_type": safe_error_type(e)},
            )

    # ── 写入 ────────────────────────────────────────────────
    async def index_document(
        self,
        index: str,
        document: dict[str, Any],
        doc_id: str | None = None,
        routing: str | None = None,
    ) -> str:
        did = _doc_id(document, doc_id) or ""
        await self._write(index, [(did, document)])
        return did

    async def bulk_index(
        self,
        index: str,
        documents: list[dict[str, Any]],
        return_details: bool = False,
        routing: str | None = None,
    ) -> Any:
        rows: list[tuple[str, dict[str, Any]]] = []
        for d in documents:
            did = _doc_id(d)
            if did is None:
                continue
            rows.append((did, {k: v for k, v in d.items() if k != "_id"}))
        await self._write(index, rows)
        n = len(rows)
        if return_details:
            return {
                "success": True,
                "total": len(documents),
                "success_count": n,
                "error_count": 0,
                "errors": [],
            }
        return n

    async def _write(self, index: str, rows: list[tuple[str, dict[str, Any]]]) -> None:
        if not rows:
            return
        await self._ensure_table(index, rows[0][1])
        table = _table_ident(index)
        async with self._engine().begin() as conn:
            for did, doc in rows:
                cols = ["id"]
                placeholders = [":id"]
                params: dict[str, Any] = {"id": did}
                for field, value in doc.items():
                    if field in ("_id", "id") or value is None:
                        continue
                    col = _ident(field)
                    cols.append(col)
                    if _is_vector(value):
                        placeholders.append(f":{col}")
                        params[col] = _vec_literal(value)  # 字符串 → OB 转 VECTOR
                    elif isinstance(value, (list, dict)):
                        placeholders.append(f":{col}")
                        params[col] = json.dumps(value, ensure_ascii=False)
                    elif isinstance(value, (datetime, date)):
                        placeholders.append(f":{col}")
                        params[col] = value.isoformat()
                    else:
                        placeholders.append(f":{col}")
                        params[col] = value
                await conn.execute(text(self._upsert_sql(table, cols, placeholders)), params)

    # ── kNN ─────────────────────────────────────────────────
    async def vector_search(
        self,
        index: str,
        field: str,
        vector: list[float],
        size: int = 10,
        filter_query: dict[str, Any] | None = None,
        routing: str | None = None,
        include_vector: bool = False,
    ) -> list[dict[str, Any]]:
        table = _table_ident(index)
        col = _ident(field)
        if table not in self._ready_tables and not await self._table_exists(table):
            return []
        where, params = self._translate_filter(filter_query)
        cols = await self._scalar_columns(table, include_vector)
        sql = self._knn_sql(table, col, vector, cols, where, size)
        async with self._engine().connect() as conn:
            result = await conn.execute(text(sql), params)
            return [dict(r._mapping) for r in result.fetchall()]

    # ── search(match → LIKE 降级;term/terms 过滤)───────────
    async def search(
        self,
        index: str,
        query: dict[str, Any],
        size: int = 10,
        from_: int = 0,
        routing: str | None = None,
        return_full_response: bool = False,
        include_vector: bool = False,
        **kwargs: Any,
    ) -> Any:
        table = _table_ident(index)
        if not await self._table_exists(table):
            return {"total": 0, "max_score": 0, "hits": []} if return_full_response else []
        where, params = self._translate_filter(query if "bool" in (query or {}) else None)
        sort = tuple(kwargs.pop("sort", ()))
        match = self._extract_match(query)
        if match:
            f, txt = match
            params["m"] = f"%{txt}%"
            match_where = f"`{_ident(f)}` LIKE :m"
            where = f"({where}) AND {match_where}" if where else match_where
        cols = await self._scalar_columns(table, include_vector)
        select_sql = ", ".join(f"`{c}`" for c in cols)
        where_sql = f"WHERE {where}" if where else ""
        order_sql = ""
        if sort:
            parts: list[str] = []
            for field, direction in sort:
                col = _ident(field)
                parts.extend(
                    [
                        f"(`{col}` IS NULL) ASC",
                        f"`{col}` {'DESC' if direction == 'desc' else 'ASC'}",
                    ]
                )
            order_sql = "ORDER BY " + ", ".join(parts)
        sql = (
            f"SELECT {select_sql} FROM `{table}` {where_sql} "
            f"{order_sql} LIMIT {int(size)} OFFSET {int(from_)}"
        )
        async with self._engine().connect() as conn:
            rows = [dict(r._mapping) for r in (await conn.execute(text(sql), params)).fetchall()]
        if return_full_response:
            return {
                "total": len(rows),
                "max_score": 1.0 if rows else 0,
                "hits": [
                    {"id": r.get("id"), "score": 1.0, "source": r, "index": index} for r in rows
                ],
            }
        return rows

    @staticmethod
    def _extract_match(query: dict[str, Any] | None) -> tuple[str, str] | None:
        def _parse(node: dict[str, Any]) -> tuple[str, str] | None:
            if "multi_match" in node:
                mm = node["multi_match"]
                fields = mm.get("fields", [])
                first = fields[0].split("^")[0] if fields else ""
                return (first, str(mm.get("query", ""))) if first else None
            if "match" in node:
                ((f, v),) = node["match"].items()
                text_val = v.get("query") if isinstance(v, dict) else v
                return f, str(text_val)
            return None

        if not query:
            return None
        found = _parse(query)
        if found:
            return found
        if "bool" in query:
            for c in query["bool"].get("must", []):
                if isinstance(c, dict) and (parsed := _parse(c)):
                    return parsed
        return None

    # ── 元信息 ──────────────────────────────────────────────
    async def _table_exists(self, table: str) -> bool:
        async with self._engine().connect() as conn:
            r = await conn.execute(
                text(
                    "SELECT COUNT(*) FROM information_schema.tables "
                    "WHERE table_name = :t AND table_schema = DATABASE()"
                ),
                {"t": table},
            )
            return bool(r.scalar())

    async def _scalar_columns(self, table: str, include_vector: bool) -> list[str]:
        async with self._engine().connect() as conn:
            rows = (
                await conn.execute(
                    text(
                        "SELECT column_name, data_type FROM information_schema.columns "
                        "WHERE table_name = :t AND table_schema = DATABASE()"
                    ),
                    {"t": table},
                )
            ).fetchall()
        return [c for c, dtype in rows if include_vector or str(dtype).lower() != "vector"]

    async def count_documents(self, index: str, query: dict[str, Any] | None = None) -> int:
        table = _table_ident(index)
        if not await self._table_exists(table):
            return 0
        where, params = self._translate_filter(query if query and "bool" in query else None)
        where_sql = f"WHERE {where}" if where else ""
        async with self._engine().connect() as conn:
            r = await conn.execute(text(f"SELECT count(*) FROM `{table}` {where_sql}"), params)
            return int(r.scalar() or 0)

    async def get_document(self, index: str, doc_id: str) -> dict[str, Any] | None:
        table = _table_ident(index)
        if not await self._table_exists(table):
            return None
        cols = await self._scalar_columns(table, include_vector=False)
        select_sql = ", ".join(f"`{c}`" for c in cols)
        async with self._engine().connect() as conn:
            r = await conn.execute(
                text(f"SELECT {select_sql} FROM `{table}` WHERE `id` = :id"), {"id": doc_id}
            )
            row = r.fetchone()
            return dict(row._mapping) if row else None

    async def delete_document(self, index: str, doc_id: str) -> bool:
        table = _table_ident(index)
        if not await self._table_exists(table):
            return False
        async with self._engine().begin() as conn:
            await conn.execute(text(f"DELETE FROM `{table}` WHERE `id` = :id"), {"id": doc_id})
        return True

    async def update_document(self, index: str, doc_id: str, update_data: dict[str, Any]) -> bool:
        if await self.get_document(index, doc_id) is None:
            return False
        await self._write(index, [(doc_id, {**update_data, "id": doc_id})])
        return True

    async def create_index(self, *args: Any, **kwargs: Any) -> bool:
        return True  # 表按需自动创建

    async def index_exists(self, index: str) -> bool:
        return await self._table_exists(_table_ident(index))

    async def delete_index(self, index: str) -> bool:
        async with self._engine().begin() as conn:
            await conn.execute(text(f"DROP TABLE IF EXISTS `{_table_ident(index)}`"))
        self._ready_tables.discard(_table_ident(index))
        return True

    async def close(self) -> None:
        return None
