"""Provider-neutral vector repository primitives."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from zleap.sag.core.adapters import (
    BulkResult,
    Filter,
    VectorHit,
    VectorQuery,
    VectorRecord,
    VectorStore,
)
from zleap.sag.exceptions import InvalidInputError, VectorSyncError


def _record_from_document(document: dict[str, Any], *, doc_id: str | None = None) -> VectorRecord:
    record_id = str(document.get("id") or document.get("_id") or doc_id or "")
    if not record_id:
        raise InvalidInputError("向量文档缺少 id")
    payload: dict[str, Any] = {}
    vectors: dict[str, list[float]] = {}
    for key, value in document.items():
        if key in {"id", "_id", "score"}:
            continue
        is_vector = key == "vector" or key.endswith("_vector")
        if (
            is_vector
            and isinstance(value, list)
            and all(isinstance(item, (int, float)) for item in value)
        ):
            vectors[key] = [float(item) for item in value]
        else:
            payload[key] = value
    return VectorRecord(id=record_id, payload=payload, vectors=vectors)


def _record_document(record: VectorRecord, *, include_vectors: bool = True) -> dict[str, Any]:
    document = {"id": record.id, **record.payload}
    if include_vectors:
        document.update(record.vectors)
    return document


def _hit_document(hit: VectorHit) -> dict[str, Any]:
    """Map a neutral hit to the repository's domain-facing dictionary."""
    return {"id": hit.id, **hit.payload, **hit.vectors, "score": hit.score}


class BaseRepository:
    """Base class for domain repositories backed only by ``VectorStore``."""

    def __init__(self, vector_store: VectorStore) -> None:
        self.vector_store = vector_store

    async def index_document(
        self,
        collection: str,
        doc_id: str,
        document: dict[str, Any],
        routing: str | None = None,
    ) -> str:
        del routing  # routing is a provider concern and is deliberately not part of the port
        result = await self.vector_store.upsert(
            collection, [_record_from_document(document, doc_id=doc_id)]
        )
        if result.failed_items:
            raise VectorSyncError(
                provider=self.vector_store.provider,
                collection=collection,
                failed_ids=[item.id for item in result.failed_items],
                reason="provider item failure",
            )
        return doc_id

    async def get_document(self, collection: str, doc_id: str) -> dict[str, Any] | None:
        records = await self.vector_store.get_many(collection, [doc_id])
        return _record_document(records[0]) if records else None

    async def delete_document(self, collection: str, doc_id: str) -> bool:
        result = await self.vector_store.delete(collection, [doc_id])
        return result.success_count == 1

    async def upsert_documents(
        self, collection: str, documents: Sequence[dict[str, Any]]
    ) -> BulkResult:
        records = [_record_from_document(document) for document in documents]
        return await self.vector_store.upsert(collection, records)

    async def bulk_index(
        self,
        collection: str,
        documents: list[dict[str, Any]],
        routing: str | None = None,
    ) -> dict[str, int]:
        del routing
        result = await self.upsert_documents(collection, documents)
        return {"success": result.success_count, "failed": result.failure_count}

    async def _query(
        self,
        collection: str,
        *,
        vector: list[float] | None = None,
        vector_field: str = "vector",
        text: str | None = None,
        text_fields: Sequence[str] = (),
        filters: Filter | None = None,
        limit: int = 10,
        include_vectors: bool = False,
        sort: tuple[tuple[str, str], ...] = (),
        distinct_field: str | None = None,
    ) -> list[dict[str, Any]]:
        request = VectorQuery(
            vector=vector,
            vector_field=vector_field,
            text=text,
            text_fields=tuple(text_fields),
            filters=filters,
            limit=limit,
            include_vectors=include_vectors,
            sort=sort,  # type: ignore[arg-type]
            distinct_field=distinct_field,
        )
        return [_hit_document(hit) for hit in await self.vector_store.query(collection, request)]

    async def _get_many(
        self, collection: str, ids: Sequence[str], *, include_vectors: bool = True
    ) -> list[dict[str, Any]]:
        records = await self.vector_store.get_many(collection, ids)
        return [_record_document(record, include_vectors=include_vectors) for record in records]
