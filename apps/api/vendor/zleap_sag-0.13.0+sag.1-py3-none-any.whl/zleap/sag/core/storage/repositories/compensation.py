"""Vector snapshot/restore compensation shared by index and extract write paths."""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from typing import Any

from zleap.sag._safe_error import safe_error_type

VectorGroup = tuple[Any, Sequence[str]]


async def capture_vector_snapshots(
    groups: Sequence[VectorGroup],
) -> list[list[Any]]:
    """Snapshot current vector records for each (repository, ids) group, concurrently."""

    async def snapshot(repository: Any, ids: Sequence[str]) -> list[Any]:
        if not ids:
            return []
        return list(await repository.vector_store.get_many(repository.INDEX_NAME, list(ids)))

    return list(await asyncio.gather(*(snapshot(repository, ids) for repository, ids in groups)))


async def restore_vector_snapshots(
    groups: Sequence[VectorGroup],
    snapshots: Sequence[list[Any]],
) -> list[str]:
    """Best-effort compensation: delete current records, then re-upsert the snapshots."""

    errors: list[str] = []
    for (repository, ids), records in zip(groups, snapshots, strict=True):
        if ids:
            try:
                current = await repository.vector_store.get_many(repository.INDEX_NAME, list(ids))
                current_ids = [record.id for record in current]
                if current_ids:
                    deleted = await repository.vector_store.delete(
                        repository.INDEX_NAME, current_ids
                    )
                    if deleted.failed_items:
                        errors.append(f"{repository.INDEX_NAME}.cleanup_failed_items")
            except Exception as exc:
                errors.append(f"{repository.INDEX_NAME}.cleanup_exception({safe_error_type(exc)})")
        if records:
            try:
                restored = await repository.vector_store.upsert(
                    repository.INDEX_NAME, list(records)
                )
                if restored.failed_items:
                    errors.append(f"{repository.INDEX_NAME}.restore_failed_items")
            except Exception as exc:
                errors.append(f"{repository.INDEX_NAME}.restore_exception({safe_error_type(exc)})")
    return errors
