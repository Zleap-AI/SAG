"""
Elasticsearch 存储客户端

支持向量检索和全文检索
"""

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any

from elasticsearch import AsyncElasticsearch
from elasticsearch.exceptions import NotFoundError

from zleap.sag._safe_error import safe_error_summary, safe_error_type
from zleap.sag.exceptions import StorageError, StorageModeError
from zleap.sag.utils import get_logger

logger = get_logger("storage.elasticsearch")


@dataclass
class ESConfig:
    """ES配置类"""

    hosts: str | list[str]
    username: str | None = None
    password: str | None = None
    scheme: str = "http"
    timeout: int = 120
    max_connections: int = 30
    max_retries: int = 3
    verify_certs: bool = False
    ca_certs: str | None = None
    client_cert: str | None = None
    client_key: str | None = None


class ElasticsearchClient:
    """Elasticsearch异步客户端"""

    def __init__(
        self,
        config: ESConfig,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
        **kwargs: Any,
    ) -> None:
        """
        初始化Elasticsearch客户端

        Args:
            config: 当前 Engine 的 ES 配置对象
            **kwargs: 其他参数
        """
        if storage_mode not in ("normal", "lite"):
            raise StorageModeError("storage_mode 必须是 normal 或 lite")
        self._storage_mode = storage_mode
        self._embedding_dimensions = embedding_dimensions
        self.hosts: list[str]
        client_config: dict[str, Any]

        raw_hosts = config.hosts if isinstance(config.hosts, list) else [config.hosts]

        self.hosts = []
        for host in raw_hosts:
            if not host.startswith("http://") and not host.startswith("https://"):
                self.hosts.append(f"{config.scheme}://{host}")
            else:
                self.hosts.append(host)

        client_config = {**kwargs}

        if config.username and config.password:
            client_config["hosts"] = self.hosts
            client_config["basic_auth"] = (config.username, config.password)
        else:
            client_config["hosts"] = self.hosts

        client_config["request_timeout"] = config.timeout
        client_config["connections_per_node"] = config.max_connections
        client_config["max_retries"] = config.max_retries
        client_config["verify_certs"] = config.verify_certs
        if config.ca_certs is not None:
            client_config["ca_certs"] = config.ca_certs
        if config.client_cert is not None:
            client_config["client_cert"] = config.client_cert
            client_config["client_key"] = config.client_key

        # 创建客户端
        self.client = AsyncElasticsearch(**client_config)
        self._ensured_indices: set[str] = set()  # 已确保建过显式映射的索引

        logger.info("Elasticsearch客户端初始化完成", extra={"hosts": self.hosts})

    @staticmethod
    def _mapping_properties(index: str, dims: int) -> dict[str, Any]:
        from zleap.sag.core.storage.index_schemas import INDEX_SCHEMAS

        decl = INDEX_SCHEMAS[index]
        props: dict[str, Any] = {}
        for field in decl.keyword_fields + decl.array_fields:
            props[field] = {"type": "keyword"}
        for field in decl.text_fields:
            props[field] = {"type": "text"}
        for field in decl.text_keyword_fields:
            props[field] = {
                "type": "text",
                "fields": {"keyword": {"type": "keyword"}},
            }
        for field in decl.stored_text_fields:
            props[field] = {"type": "text", "index": False}
        for field in decl.bool_fields:
            props[field] = {"type": "boolean"}
        for field in decl.datetime_fields:
            props[field] = {"type": "date"}
        for field in decl.int_fields:
            props[field] = {"type": "integer"}
        for field in decl.object_fields:
            props[field] = {"type": "object", "enabled": False}
        for field in decl.vector_fields:
            props[field] = {
                "type": "dense_vector",
                "dims": dims,
                "index": True,
                "similarity": "cosine",
            }
        return props

    async def schema_index_names(self) -> frozenset[str]:
        """列出当前 ES 目标中已存在的 SAG 正式索引。"""
        from zleap.sag.core.storage.index_schemas import INDEX_SCHEMAS

        names: set[str] = set()
        for name in INDEX_SCHEMAS:
            if await self.client.indices.exists(index=name):
                names.add(name)
        return frozenset(names)

    async def validate_declared_index(self, index: str, dimensions: int | None = None) -> None:
        """只读校验现有 mapping；不 put_mapping、不 reindex。"""
        from zleap.sag.core.storage.index_schemas import INDEX_SCHEMAS
        from zleap.sag.exceptions import StorageSchemaMismatchError

        if index not in INDEX_SCHEMAS or not await self.index_exists(index):
            return
        mapping = await self.get_mapping(index)
        actual = mapping.get("properties") or {}
        if dimensions is None:
            dims = {
                actual.get(field, {}).get("dims") for field in INDEX_SCHEMAS[index].vector_fields
            }
            dims.discard(None)
            if len(dims) != 1:
                raise StorageSchemaMismatchError(
                    f"Elasticsearch 索引 {index} 的向量维度无法唯一识别"
                )
            dimensions = dims.pop()
        expected = self._mapping_properties(index, dimensions)
        diffs: list[str] = []
        for field, expected_mapping in expected.items():
            actual_mapping = actual.get(field)
            if actual_mapping is None:
                diffs.append(f"{index}.{field}: 缺少 mapping")
                continue
            for key in ("type", "dims", "index", "similarity", "enabled"):
                if key in expected_mapping and actual_mapping.get(key) != expected_mapping[key]:
                    diffs.append(
                        f"{index}.{field}.{key}: {actual_mapping.get(key)!r} "
                        f"!= {expected_mapping[key]!r}"
                    )
        # 存量 ES 索引可能保留旧字段；合同只约束当前声明字段，不拒绝 mapping 超集。
        if diffs:
            raise StorageSchemaMismatchError(
                f"Elasticsearch 索引 {index} 不符合向量 schema 合同", diffs=diffs
            )

    async def create_declared_index(self, index: str, dimensions: int) -> None:
        """仅创建完全缺失的正式索引。"""
        if not await self.index_exists(index):
            await self.create_index(
                index, mappings={"properties": self._mapping_properties(index, dimensions)}
            )

    async def _ensure_index_mapping(self, index: str, documents: list[dict[str, Any]]) -> None:
        """首次写入某索引前,按 index_schemas 建显式映射(缺失才建)。

        关键:若依赖 ES 动态映射,``data_source_id`` 等会被映射为 ``text``(带分词),导致
        ``term`` 过滤匹配不到 UUID → 检索恒空。显式映射把它们建为 ``keyword``,向量建为
        ``dense_vector``(维度按首个向量推断),使 kNN + 过滤开箱即用。
        """
        if index in self._ensured_indices:
            return
        from zleap.sag.core.storage.index_schemas import INDEX_SCHEMAS, MODE_INDEX_NAMES

        decl = INDEX_SCHEMAS.get(index)
        mode = self._storage_mode
        if decl is not None and index not in MODE_INDEX_NAMES[mode]:
            raise StorageError(f"storage_mode={mode} 禁止访问向量索引 {index}")
        if await self.index_exists(index):
            dims = None
            for doc in documents:
                for f in decl.vector_fields if decl else ():
                    v = doc.get(f)
                    if isinstance(v, (list, tuple)) and len(v) > 8:
                        dims = len(v)
                        break
                if dims:
                    break
            await self.validate_declared_index(index, dims)
            self._ensured_indices.add(index)
            return
        dims = self._embedding_dimensions
        if dims is None:
            for doc in documents:
                for field in decl.vector_fields if decl else ():
                    value = doc.get(field)
                    if isinstance(value, (list, tuple)) and len(value) > 8:
                        dims = len(value)
                        break
                if dims:
                    break
        if decl is not None and dims is not None:
            await self.create_declared_index(index, dims)
        self._ensured_indices.add(index)

    def __getattr__(self, name: str):
        """
        委托未定义的方法给底层的 AsyncElasticsearch 客户端

        这样 ElasticsearchClient 可以同时提供：
        - 自定义方法（如 vector_search, index_document, get_document 等）
        - AsyncElasticsearch 的原生方法（如 search, index, get, delete 等）

        这使得 Repository 可以统一使用 ElasticsearchClient 对象，既能调用自定义方法，
        也能调用原生方法。
        """
        return getattr(self.client, name)

    async def index_document(
        self,
        index: str,
        document: dict[str, Any],
        doc_id: str | None = None,
        routing: str | None = None,
    ) -> str:
        """
        索引文档

        Args:
            index: 索引名称
            document: 文档内容
            doc_id: 文档ID（可选）
            routing: 路由键（可选，用于指定分片）

        Returns:
            文档ID

        Raises:
            StorageError: 索引失败
        """
        try:
            await self._ensure_index_mapping(index, [document])
            source = {key: value for key, value in document.items() if key != "id"}
            response = await self.client.index(
                index=index,
                document=source,
                id=doc_id or document.get("id"),
                routing=routing,
            )
            return response["_id"]
        except Exception as e:
            logger.error("索引文档失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="索引文档失败")) from e

    async def refresh_indexes(self, indexes: Sequence[str]) -> None:
        """Make completed writes searchable without exposing the raw ES client upstream."""
        targets = tuple(dict.fromkeys(indexes))
        if not targets:
            return
        try:
            await self.client.indices.refresh(index=",".join(targets))
        except Exception as exc:
            logger.error(
                "刷新 Elasticsearch 查询视图失败",
                extra={"error_type": safe_error_type(exc)},
            )
            raise StorageError("刷新 Elasticsearch 查询视图失败") from exc

    async def get_document(
        self,
        index: str,
        doc_id: str,
    ) -> dict[str, Any] | None:
        """
        获取文档

        Args:
            index: 索引名称
            doc_id: 文档ID

        Returns:
            文档内容，不存在返回None
        """
        try:
            response = await self.client.get(index=index, id=doc_id)
            return response["_source"]
        except NotFoundError:
            return None
        except Exception as e:
            logger.error("获取文档失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="获取文档失败")) from e

    async def delete_document(
        self,
        index: str,
        doc_id: str,
        routing: str | None = None,
    ) -> bool:
        """
        删除文档

        Args:
            index: 索引名称
            doc_id: 文档ID

        Returns:
            删除成功返回True
        """
        try:
            await self.client.delete(index=index, id=doc_id, routing=routing)
            return True
        except NotFoundError:
            return False
        except Exception as e:
            logger.error("删除文档失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="删除文档失败")) from e

    async def update_document(
        self,
        index: str,
        doc_id: str,
        update_data: dict[str, Any],
    ) -> bool:
        """
        部分更新文档

        Args:
            index: 索引名称
            doc_id: 文档ID
            update_data: 要更新的数据

        Returns:
            更新成功返回True

        Raises:
            StorageError: 更新失败
        """
        try:
            await self.client.update(
                index=index,
                id=doc_id,
                doc=update_data,
            )
            logger.info(f"文档 {doc_id} 更新成功")
            return True
        except NotFoundError:
            logger.warning(f"文档 {doc_id} 不存在")
            return False
        except Exception as e:
            logger.error("更新文档失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="更新文档失败")) from e

    async def count_documents(
        self,
        index: str,
        query: dict[str, Any] | None = None,
    ) -> int:
        """
        统计文档数量

        Args:
            index: 索引名称
            query: 查询条件，默认匹配所有文档

        Returns:
            文档数量

        Raises:
            StorageError: 统计失败
        """
        try:
            if query is None:
                query = {"match_all": {}}

            response = await self.client.count(index=index, query=query)
            return response["count"]
        except Exception as e:
            logger.error("统计文档数量失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="统计文档数量失败")) from e

    async def get_mapping(self, index: str) -> dict[str, Any]:
        """
        获取索引映射

        Args:
            index: 索引名称

        Returns:
            索引映射信息

        Raises:
            StorageError: 获取失败
        """
        try:
            response = await self.client.indices.get_mapping(index=index)
            return response.get(index, {}).get("mappings", {})
        except Exception as e:
            logger.error("获取索引映射失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="获取索引映射失败")) from e

    async def search(
        self,
        index: str,
        query: dict[str, Any],
        size: int = 10,
        from_: int = 0,
        return_full_response: bool = False,
        routing: str | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]] | dict[str, Any]:
        """
        搜索文档

        Args:
            index: 索引名称
            query: 查询DSL
            size: 返回数量
            from_: 起始位置
            return_full_response: 是否返回完整响应（包含total、max_score等）
            routing: 路由键（可选，用于指定分片）
            **kwargs: 其他参数

        Returns:
            return_full_response=False: 文档列表（向下兼容）
            return_full_response=True: 完整响应字典 {total, max_score, hits}
        """
        try:
            search_params = {
                "index": index,
                "query": query,
                "size": size,
                "from_": from_,
                "timeout": "300s",  # 添加查询级别超时，避免高并发时无限等待
                **kwargs,
            }
            if routing:
                search_params["routing"] = routing

            response = await self.client.search(**search_params)

            if return_full_response:
                # 返回完整信息
                hits = response.get("hits", {})
                return {
                    "total": hits.get("total", {}).get("value", 0),
                    "max_score": hits.get("max_score", 0),
                    "hits": [
                        {
                            "id": hit.get("_id"),
                            "score": hit.get("_score"),
                            "source": hit.get("_source"),
                            "index": hit.get("_index"),
                        }
                        for hit in hits.get("hits", [])
                    ],
                }
            else:
                # 向下兼容：只返回文档列表
                return [hit["_source"] for hit in response["hits"]["hits"]]
        except NotFoundError:
            # 索引尚未创建 → 视为无结果,不崩溃(按调用方期望的形状返回空)
            logger.warning(f"搜索:索引 '{index}' 不存在,返回空结果")
            if return_full_response:
                return {"total": 0, "max_score": 0, "hits": []}
            return []
        except Exception as e:
            logger.error("搜索文档失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="搜索文档失败")) from e

    async def vector_search(
        self,
        index: str,
        field: str,
        vector: list[float],
        size: int = 10,
        filter_query: dict[str, Any] | None = None,
        routing: str | None = None,
        include_vector: bool = False,
    ) -> list[dict[str, Any]]:
        """
        向量检索

        Args:
            index: 索引名称
            field: 向量字段名
            vector: 查询向量
            size: 返回数量
            filter_query: 过滤条件
            routing: 路由键（可选，用于指定分片）
            include_vector: 是否返回向量字段（默认 False，减少约4KB/条的数据传输）

        Returns:
            相似文档列表（包含_score字段）
        """
        try:
            knn_query: dict[str, Any] = {
                "field": field,
                "query_vector": vector,
                "k": size,
                # Elasticsearch 8.x rejects num_candidates values above 10,000.
                "num_candidates": min(10_000, max(100, size * 2)),
            }

            if filter_query:
                knn_query["filter"] = filter_query

            response = await self.client.search(
                index=index,
                knn=knn_query,
                size=size,
                timeout="300s",  # 添加查询级别超时，避免无限等待
                source_excludes=None if include_vector else ["vector", "*_vector"],
                routing=routing,
            )

            return [{**hit["_source"], "_score": hit["_score"]} for hit in response["hits"]["hits"]]
        except NotFoundError:
            # 索引尚未创建(如实体/事项向量尚未写入)→ 视为无结果,不崩溃
            logger.warning(f"向量检索:索引 '{index}' 不存在,返回空结果")
            return []
        except Exception as e:
            logger.error("向量检索失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="向量检索失败")) from e

    async def bulk_index(
        self,
        index: str,
        documents: list[dict[str, Any]],
        return_details: bool = False,
        routing: str | None = None,
    ) -> int | dict[str, Any]:
        """
        批量索引文档

        Args:
            index: 索引名称
            documents: 文档列表
            return_details: 是否返回详细信息（包含错误列表）
            routing: 路由键（可选，用于指定分片）

        Returns:
            return_details=False: 成功索引的文档数量（向下兼容）
            return_details=True: 详细结果字典 {success, total, success_count, error_count, errors}
        """
        from elasticsearch.helpers import async_bulk

        try:
            if not documents:
                if return_details:
                    return {
                        "success": True,
                        "total": 0,
                        "success_count": 0,
                        "error_count": 0,
                        "errors": [],
                    }
                return 0

            await self._ensure_index_mapping(index, documents)

            actions = [
                {
                    "_index": index,
                    "_source": {key: value for key, value in doc.items() if key != "id"},
                    "_id": doc.get("id"),
                    **({"_routing": routing} if routing else {}),
                }
                for doc in documents
            ]

            success_count, errors = await async_bulk(
                self.client, actions, raise_on_error=False, stats_only=False
            )

            error_count = len(errors) if isinstance(errors, list) else 0
            logger.info(f"批量索引完成: 成功{success_count}, 失败{error_count}")

            if return_details:
                # 返回详细信息
                error_list = []
                if isinstance(errors, list):
                    for error in errors:
                        if isinstance(error, dict):
                            error_list.append(
                                {
                                    "id": error.get("index", {}).get("_id"),
                                    "error": "provider item failure",
                                }
                            )

                return {
                    "success": error_count == 0,
                    "total": len(documents),
                    "success_count": success_count,
                    "error_count": error_count,
                    "errors": error_list,
                }
            else:
                # 向下兼容：只返回成功数量
                return success_count
        except Exception as e:
            logger.error("批量索引失败", extra={"error_type": safe_error_type(e)})
            if return_details:
                return {
                    "success": False,
                    "total": len(documents),
                    "success_count": 0,
                    "error_count": len(documents),
                    "errors": [{"error": safe_error_summary(e)}],
                }
            raise StorageError(safe_error_summary(e, label="批量索引失败")) from e

    async def create_index(
        self,
        index: str,
        mappings: dict[str, Any],
        settings: dict[str, Any] | None = None,
    ) -> bool:
        """
        创建索引

        Args:
            index: 索引名称
            mappings: 映射定义
            settings: 索引设置

        Returns:
            创建成功返回True
        """
        try:
            # Elasticsearch 8.x 不再使用 body 参数
            await self.client.indices.create(
                index=index, mappings=mappings, settings=settings or {}
            )
            logger.info(f"索引创建成功: {index}")
            return True
        except Exception as e:
            logger.error("创建索引失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="创建索引失败")) from e

    async def delete_index(self, index: str) -> bool:
        """
        删除索引

        Args:
            index: 索引名称

        Returns:
            删除成功返回True
        """
        try:
            await self.client.indices.delete(index=index)
            logger.info(f"索引删除成功: {index}")
            return True
        except NotFoundError:
            return False
        except Exception as e:
            logger.error("删除索引失败", extra={"error_type": safe_error_type(e)})
            raise StorageError(safe_error_summary(e, label="删除索引失败")) from e

    async def index_exists(self, index: str) -> bool:
        """
        检查索引是否存在

        Args:
            index: 索引名称

        Returns:
            存在返回True
        """
        return bool(await self.client.indices.exists(index=index))

    async def index(
        self,
        index: str,
        id: str | None = None,  # noqa: A002
        document: dict[str, Any] | None = None,
        routing: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        await self._ensure_index_mapping(index, [document or {}])
        source = {key: value for key, value in (document or {}).items() if key != "id"}
        response = await self.client.index(
            index=index,
            id=id or (document or {}).get("id"),
            document=source,
            routing=routing,
            **kwargs,
        )
        payload = response.body
        if not isinstance(payload, dict):
            raise StorageError("索引文档失败: Elasticsearch 返回了无效响应")
        return payload

    async def get(self, index: str, id: str, **kwargs: Any) -> dict[str, Any]:  # noqa: A002
        response = await self.client.get(index=index, id=id, **kwargs)
        payload = response.body
        if not isinstance(payload, dict):
            raise StorageError("获取文档失败: Elasticsearch 返回了无效响应")
        return payload

    async def delete(self, index: str, id: str, **kwargs: Any) -> dict[str, Any]:  # noqa: A002
        response = await self.client.delete(index=index, id=id, **kwargs)
        payload = response.body
        if not isinstance(payload, dict):
            raise StorageError("删除文档失败: Elasticsearch 返回了无效响应")
        return payload

    async def close(self) -> None:
        """关闭客户端连接"""
        await self.client.close()
        logger.info("Elasticsearch连接已关闭")

    async def ping(self) -> bool:
        """
        测试连接

        Returns:
            连接成功返回True
        """
        try:
            return await self.client.ping()
        except Exception as e:
            logger.error("ES连接测试失败", extra={"error_type": safe_error_type(e)})
            return False

    async def check_connection(self) -> bool:
        """
        检查ES连接状态并获取版本信息

        Returns:
            连接是否正常
        """
        try:
            info = await self.client.info()
            version = info.get("version", {}).get("number", "unknown")
            logger.info(f"ES连接正常, 版本: {version}")
            return True
        except Exception as e:
            logger.error("ES连接检查失败", extra={"error_type": safe_error_type(e)})
            return False


__all__ = [
    "ESConfig",
    "ElasticsearchClient",
]
