"""Relational event↔entity repository for unscored, untruncated graph expansion."""

from __future__ import annotations

from typing import Any

from zleap.sag.core.adapters import RelationalStore
from zleap.sag.core.storage.repositories.search_scope import (
    apply_source_event_scope,
    fetch_event_ids_for_entities,
)


class EventEntityRelationalRepository:
    """event↔entity 关系表全量直取（不打分、不截断）。

    与 :class:`EventEntityRepository` 并列而非合并：后者走 VectorStore 拿相似度分
    用于剪枝，本类走 RelationalStore 拿全量可达集。两者底层资源都不同，调用方按
    检索变体二选一。
    """

    def __init__(self, relational_store: RelationalStore) -> None:
        self._relational_store = relational_store

    async def fetch_relations_by_event_ids(
        self,
        event_ids: list[str],
        data_source_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Return every ``(event_id, entity_id)`` pair whose event passes the active scope."""

        if not event_ids:
            return []

        from sqlalchemy import select

        from zleap.sag.db import EventEntity, SourceEvent

        statement = (
            select(EventEntity.event_id, EventEntity.entity_id)
            .join(SourceEvent, SourceEvent.id == EventEntity.event_id)
            .where(EventEntity.event_id.in_(list(event_ids)))
        )
        if data_source_ids:
            statement = statement.where(SourceEvent.data_source_id.in_(list(data_source_ids)))
        statement = apply_source_event_scope(statement, SourceEvent)
        async with self._relational_store.session() as session:
            rows = (await session.execute(statement)).fetchall()
        return [{"event_id": str(row[0]), "entity_id": str(row[1])} for row in rows]

    async def fetch_event_ids_for_entities(
        self,
        entity_ids: list[str],
        data_source_ids: list[str] | None = None,
    ) -> list[str]:
        """Return the distinct events reachable from the requested entities."""

        if not entity_ids:
            return []
        async with self._relational_store.session() as session:
            event_ids = await fetch_event_ids_for_entities(
                session,
                list(entity_ids),
                data_source_ids,
                distinct=True,
            )
        return list(dict.fromkeys(str(event_id) for event_id in event_ids))


__all__ = ["EventEntityRelationalRepository"]
