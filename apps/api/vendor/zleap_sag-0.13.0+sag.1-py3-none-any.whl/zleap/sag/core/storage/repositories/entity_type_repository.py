"""Relational repository for entity-type retrieval policy."""

from __future__ import annotations

import time

from zleap.sag.core.adapters import RelationalStore


class EntityTypeRepository:
    """Read entity thresholds from the relational side with an instance-local cache."""

    _CACHE_TTL_SECONDS = 300

    def __init__(self, relational_store: RelationalStore) -> None:
        self._relational_store = relational_store
        self._cache: dict[str, tuple[dict[str, dict[str, float]], float]] = {}

    async def get_type_info(
        self, data_source_ids: list[str] | None = None
    ) -> dict[str, dict[str, float]]:
        cache_key = ",".join(sorted(data_source_ids)) if data_source_ids else "__global__"
        now = time.time()
        cached = self._cache.get(cache_key)
        if cached and now - cached[1] < self._CACHE_TTL_SECONDS:
            return {key: value.copy() for key, value in cached[0].items()}

        from sqlalchemy import select

        from zleap.sag.db import EntityType

        query = select(
            EntityType.type,
            EntityType.similarity_threshold,
            EntityType.weight,
        ).where(EntityType.is_active.is_(True))
        if data_source_ids:
            query = query.where(
                EntityType.data_source_id.in_(data_source_ids) | EntityType.data_source_id.is_(None)
            )
        else:
            query = query.where(EntityType.data_source_id.is_(None))

        type_info: dict[str, dict[str, float]] = {}
        async with self._relational_store.session() as session:
            rows = (await session.execute(query)).all()
        for entity_type, threshold, weight in rows:
            type_info.setdefault(
                entity_type,
                {
                    "threshold": float(threshold),
                    "weight": float(weight) if weight else 1.0,
                },
            )
        self._cache[cache_key] = (type_info, now)
        return {key: value.copy() for key, value in type_info.items()}
