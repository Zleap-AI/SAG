"""Provider-neutral entity vector repository."""

from __future__ import annotations

import asyncio
from typing import Any

from zleap.sag.core.adapters import Filter, VectorStore
from zleap.sag.core.storage.index_schemas import (
    StorageMode,
    prepare_vector_for_index,
)
from zleap.sag.core.storage.repositories.base import BaseRepository


def _combine(filters: list[Filter]) -> Filter | None:
    if not filters:
        return None
    return filters[0] if len(filters) == 1 else Filter.all(*filters)


class EntityVectorRepository(BaseRepository):
    INDEX_NAME = "entity_vectors"

    def __init__(self, vector_store: VectorStore, storage_mode: StorageMode = "normal") -> None:
        super().__init__(vector_store)
        self.storage_mode = storage_mode

    def prepare_vector(self, vector: list[float]) -> list[float]:
        return prepare_vector_for_index(self.storage_mode, self.INDEX_NAME, vector)

    async def index_entity(
        self,
        entity_id: str,
        data_source_id: str,
        entity_type: str,
        name: str,
        vector: list[float],
        **kwargs: Any,
    ) -> str:
        return await self.index_document(
            self.INDEX_NAME,
            entity_id,
            {
                "id": entity_id,
                "entity_id": entity_id,
                "data_source_id": data_source_id,
                "type": entity_type,
                "name": name,
                "vector": self.prepare_vector(vector),
                **kwargs,
            },
        )

    async def search_by_name(
        self, name: str, data_source_id: str | None = None, size: int = 10
    ) -> list[dict[str, Any]]:
        filters: list[Filter] = []
        if data_source_id:
            filters.append(Filter.eq("data_source_id", data_source_id))
        return await self._query(
            self.INDEX_NAME,
            text=name,
            text_fields=("name",),
            filters=_combine(filters),
            limit=size,
        )

    async def search_by_query_bm25(
        self,
        query: str,
        data_source_ids: list[str] | None = None,
        size: int = 20,
    ) -> list[dict[str, Any]]:
        query_text = (query or "").strip()
        if not query_text or size <= 0:
            return []
        filters: list[Filter] = []
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        return await self._query(
            self.INDEX_NAME,
            text=query_text,
            text_fields=("normalized_name^3", "name^2"),
            filters=_combine(filters),
            limit=size,
        )

    async def search_similar(
        self,
        query_vector: list[float],
        k: int = 10,
        data_source_id: str | None = None,
        data_source_ids: list[str] | None = None,
        entity_type: str | None = None,
        type_policies: dict[str, dict[str, float]] | None = None,
    ) -> list[dict[str, Any]]:
        query_vector = self.prepare_vector(query_vector)
        if not data_source_ids and data_source_id:
            data_source_ids = [data_source_id]
        filters: list[Filter] = []
        if data_source_ids:
            filters.append(Filter.one_of("data_source_id", data_source_ids))
        if entity_type:
            filters.append(Filter.eq("type", entity_type))
        results = await self._query(
            self.INDEX_NAME,
            vector=query_vector,
            filters=_combine(filters),
            limit=k,
        )
        if type_policies is None:
            return results

        for entity in results:
            policy = type_policies.get(str(entity.get("type")), {})
            entity["type_threshold"] = policy.get("threshold", 0.8)
            entity["type_weight"] = policy.get("weight", 1.0)
        return results

    async def search_similar_batch(
        self,
        query_vectors: list[list[float]],
        k: int = 5,
        data_source_ids: list[str] | None = None,
        entity_type: str | None = None,
    ) -> list[dict[str, Any]]:
        """Search several rewritten entity vectors and keep the best score per entity."""

        if not query_vectors or k <= 0:
            return []
        batches = await asyncio.gather(
            *(
                self.search_similar(
                    vector,
                    k=k,
                    data_source_ids=data_source_ids,
                    entity_type=entity_type,
                )
                for vector in query_vectors
            )
        )
        merged: dict[str, dict[str, Any]] = {}
        for rows in batches:
            for row in rows:
                entity_id = row.get("entity_id") or row.get("id")
                if not entity_id:
                    continue
                key = str(entity_id)
                if key not in merged or float(row.get("score", 0.0)) > float(
                    merged[key].get("score", 0.0)
                ):
                    merged[key] = row
        return sorted(
            merged.values(),
            key=lambda row: (-float(row.get("score", 0.0)), str(row.get("entity_id") or row["id"])),
        )

    async def search_by_names_exact(
        self,
        names: list[str],
        data_source_ids: list[str],
        entity_types: list[str] | None = None,
        size_per_name: int = 10,
    ) -> list[dict[str, Any]]:
        if not names or not data_source_ids:
            return []
        filters: list[Filter] = [
            Filter.any(*(Filter.eq("name", name, exact=True) for name in names)),
            Filter.one_of("data_source_id", data_source_ids),
        ]
        if entity_types:
            filters.append(Filter.one_of("type", entity_types))
        return await self._query(
            self.INDEX_NAME,
            filters=Filter.all(*filters),
            limit=min(len(names) * size_per_name, 10000),
        )

    async def get_by_source(
        self, data_source_id: str, entity_type: str | None = None, size: int = 100
    ) -> list[dict[str, Any]]:
        filters = [Filter.eq("data_source_id", data_source_id)]
        if entity_type:
            filters.append(Filter.eq("type", entity_type))
        return await self._query(self.INDEX_NAME, filters=_combine(filters), limit=size)

    async def get_entities_by_ids(
        self,
        entity_ids: list[str],
        data_source_ids: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        if not entity_ids:
            return []
        results: list[dict[str, Any]] = []
        for offset in range(0, len(entity_ids), 5000):
            batch_ids = entity_ids[offset : offset + 5000]
            if not data_source_ids:
                entities = await self._get_many(
                    self.INDEX_NAME,
                    batch_ids,
                    include_vectors=False,
                )
                results.extend(entities)
                continue

            filters = [Filter.one_of("entity_id", batch_ids)]
            filters.append(Filter.one_of("data_source_id", data_source_ids))
            results.extend(
                await self._query(
                    self.INDEX_NAME,
                    filters=Filter.all(*filters),
                    limit=len(batch_ids),
                )
            )
        return results

    async def batch_search_similar_by_ids(
        self,
        query_vector: list[float],
        entity_ids: list[str],
        data_source_ids: list[str] | None = None,
    ) -> dict[str, float]:
        query_vector = self.prepare_vector(query_vector)
        all_scores: dict[str, float] = {}
        for offset in range(0, len(entity_ids), 5000):
            batch_ids = entity_ids[offset : offset + 5000]
            filters = [Filter.one_of("entity_id", batch_ids)]
            if data_source_ids:
                filters.append(Filter.one_of("data_source_id", data_source_ids))
            hits = await self._query(
                self.INDEX_NAME,
                vector=query_vector,
                filters=_combine(filters),
                limit=len(batch_ids),
            )
            for hit in hits:
                entity_id = hit.get("entity_id")
                if entity_id:
                    all_scores[str(entity_id)] = float(hit.get("score", 0.0))
        return all_scores
