"""实例级 SQL 运行时。

关系 Store 与 SQL 向量 Store 各自持有一个 ``SqlRuntime``。即使两套配置指向
同一个 PostgreSQL/OceanBase，它们也会建立独立 engine、连接池和 session factory。
"""

from __future__ import annotations

import ssl
from typing import Any
from urllib.parse import quote_plus

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)


class SqlRuntime:
    """惰性创建并拥有一个 SQLAlchemy async engine/连接池。"""

    def __init__(self, config: Any, *, echo: bool = False) -> None:
        self.config = config
        self.provider = str(config.provider).lower()
        self._echo = echo
        self._engine: AsyncEngine | None = None
        self._session_factory: async_sessionmaker[AsyncSession] | None = None

    @property
    def database_url(self) -> str:
        provider = self.provider
        if provider == "sqlite":
            return f"sqlite+aiosqlite:///{self.config.path}"

        user = quote_plus(self.config.user)
        password = quote_plus(self.config.password)
        host = self.config.host
        port = self.config.port
        database = self.config.database
        if provider in ("postgres", "postgresql"):
            return f"postgresql+asyncpg://{user}:{password}@{host}:{port}/{database}"
        return f"mysql+aiomysql://{user}:{password}@{host}:{port}/{database}?charset=utf8mb4"

    def engine(self) -> AsyncEngine:
        if self._engine is not None:
            return self._engine

        if self.provider == "sqlite":
            from sqlalchemy import event

            self._engine = create_async_engine(
                self.database_url,
                echo=self._echo,
                pool_pre_ping=True,
            )

            @event.listens_for(self._engine.sync_engine, "connect")
            def _enable_sqlite_fk(dbapi_conn: Any, _record: Any) -> None:
                cursor = dbapi_conn.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.close()
        else:
            if self.provider in ("postgres", "postgresql"):
                connect_args = {
                    "server_settings": {"timezone": "UTC"},
                    "timeout": float(getattr(self.config, "connect_timeout", 10.0)),
                    "command_timeout": float(getattr(self.config, "command_timeout", 30.0)),
                }
                tls = getattr(self.config, "tls", None)
                if tls is not None:
                    connect_args["ssl"] = _postgres_ssl_context(tls)
            else:
                connect_args = {
                    "init_command": "SET time_zone='+00:00'",
                    "connect_timeout": float(getattr(self.config, "connect_timeout", 10.0)),
                }
            self._engine = create_async_engine(
                self.database_url,
                echo=self._echo,
                pool_size=self.config.pool_size,
                max_overflow=self.config.max_overflow,
                pool_pre_ping=True,
                pool_recycle=self.config.pool_recycle,
                pool_timeout=float(getattr(self.config, "pool_timeout", 30.0)),
                connect_args=connect_args,
            )
        return self._engine

    def session_factory(self) -> async_sessionmaker[AsyncSession]:
        if self._session_factory is None:
            self._session_factory = async_sessionmaker(
                self.engine(),
                class_=AsyncSession,
                expire_on_commit=False,
                autoflush=False,
                autocommit=False,
            )
        return self._session_factory

    def session(self) -> AsyncSession:
        """Create one relation/vector-side session from this runtime's own pool."""
        return self.session_factory()()

    async def close(self) -> None:
        if self._engine is not None:
            await self._engine.dispose()
        self._engine = None
        self._session_factory = None


def _postgres_ssl_context(config: Any) -> ssl.SSLContext:
    """Translate the public PostgreSQL TLS contract to asyncpg safely."""

    if config.mode == "require":
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    else:
        context = ssl.create_default_context(cafile=config.ca_file)
        context.check_hostname = config.mode == "verify-full"
    if config.client_cert_file is not None:
        context.load_cert_chain(
            certfile=config.client_cert_file,
            keyfile=config.client_key_file,
        )
    return context
