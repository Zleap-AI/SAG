"""默认适配器实现。

把现有客户端(OpenAI LLM/Embedding、HTTP Rerank、ES、SQLAlchemy)包装为适配器。
均为**惰性**包装:构造不触发任何 I/O,首次调用时才创建底层客户端,保证 registry
选择过程无副作用、可单测，底层客户端只属于当前 Engine 实例。
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Literal, cast

from zleap.sag._safe_error import safe_error_summary
from zleap.sag.core.adapters.capabilities import Capability
from zleap.sag.core.adapters.models import (
    BulkResult,
    FailedItem,
    Filter,
    VectorHit,
    VectorQuery,
    VectorRecord,
)
from zleap.sag.exceptions import ConfigError, InvalidInputError, StateError


def _backend_filter(expression: Filter | None, *, provider: str) -> dict[str, Any] | None:
    """Translate the neutral filter tree to a backend-native query."""
    if expression is None:
        return None
    op = expression.operator
    if op == "eq":
        field = str(expression.field)
        if expression.exact and provider == "es":
            field = f"{field}.keyword"
        return {"term": {field: expression.value}}
    if op == "in":
        return {"terms": {str(expression.field): list(expression.value)}}
    if op == "range":
        return {"range": {str(expression.field): expression.value}}
    if op == "exists":
        return {"exists": {"field": str(expression.field)}}
    children = [
        item for child in expression.children if (item := _backend_filter(child, provider=provider))
    ]
    if op == "and":
        return {"bool": {"filter": children}}
    if op == "or":
        return {"bool": {"should": children, "minimum_should_match": 1}}
    if op == "not":
        return {"bool": {"must_not": children}}
    raise InvalidInputError(f"未知 Filter operator={op!r}")


def _bulk_result_from_detail(records: Sequence[VectorRecord], detail: dict[str, Any]) -> BulkResult:
    """Normalize backend bulk details without treating unidentified failures as success."""
    record_ids = [record.id for record in records]
    expected_ids = set(record_ids)
    errors = detail.get("errors") or []
    error_by_id: dict[str, str] = {}
    unidentified_count_from_payload = 0
    for item in errors:
        if not isinstance(item, dict):
            unidentified_count_from_payload += 1
            continue
        item_id = item.get("id")
        if item_id is None or str(item_id) not in expected_ids:
            unidentified_count_from_payload += 1
            continue
        error_by_id[str(item_id)] = "provider item failure"

    reported_failures = int(detail.get("error_count", len(errors)) or 0)
    reported_successes = int(detail.get("success_count", len(records) - reported_failures) or 0)
    unidentified_count = max(
        reported_failures - len(error_by_id),
        len(records) - reported_successes - len(error_by_id),
        unidentified_count_from_payload,
    )
    if unidentified_count > 0:
        for record_id in record_ids:
            error_by_id.setdefault(record_id, "provider bulk failure")

    return BulkResult(
        succeeded_ids=tuple(record_id for record_id in record_ids if record_id not in error_by_id),
        failed_items=tuple(
            FailedItem(record_id, error_by_id[record_id])
            for record_id in record_ids
            if record_id in error_by_id
        ),
    )


def _split_document(
    document: dict[str, Any], *, known_id: str | None = None
) -> tuple[str, dict[str, Any], dict[str, list[float]]]:
    payload: dict[str, Any] = {}
    vectors: dict[str, list[float]] = {}
    record_id = str(document.get("id") or known_id or "")
    for key, value in document.items():
        if key in {"id", "_id", "_score"}:
            continue
        is_vector_name = key == "vector" or key.endswith("_vector")
        if (
            is_vector_name
            and isinstance(value, list)
            and all(isinstance(item, int | float) for item in value)
        ):
            vectors[key] = [float(item) for item in value]
        else:
            payload[key] = value
    return record_id, payload, vectors


def _relation_rows(response: dict[str, Any]) -> list[dict[str, Any]]:
    """投影 fetch_relation_vectors 的返回:只保留带 event_id/entity_id 的关系文档。"""
    return [
        hit["source"]
        for hit in response.get("hits", [])
        if hit.get("source") and hit["source"].get("event_id") and hit["source"].get("entity_id")
    ]


class _VectorStoreOperations:
    """Neutral contract implemented on top of the current backend client methods."""

    provider: str
    capabilities: frozenset[Capability]

    def _raw(self) -> Any:
        raise NotImplementedError

    async def upsert(self, collection: str, records: Sequence[VectorRecord]) -> BulkResult:
        documents = [{"id": record.id, **record.payload, **record.vectors} for record in records]
        try:
            detail = await self._raw().bulk_index(collection, documents, return_details=True)
        except Exception as exc:  # noqa: BLE001 - contract returns per-item failures
            return BulkResult(
                failed_items=tuple(
                    FailedItem(record.id, safe_error_summary(exc)) for record in records
                )
            )

        return _bulk_result_from_detail(records, detail)

    async def get_many(self, collection: str, ids: Sequence[str]) -> list[VectorRecord]:
        raw = self._raw()
        batched = getattr(raw, "get_documents", None)
        if batched is not None:
            found: dict[str, VectorRecord] = {}
            for document in await batched(collection, list(ids)):
                normalized_id, payload, vectors = _split_document(document)
                if normalized_id:
                    found[normalized_id] = VectorRecord(normalized_id, payload, vectors)
            return [found[record_id] for record_id in ids if record_id in found]

        records: list[VectorRecord] = []
        for record_id in ids:
            document = await raw.get_document(collection, record_id)
            if document is None:
                continue
            normalized_id, payload, vectors = _split_document(document, known_id=record_id)
            records.append(VectorRecord(normalized_id, payload, vectors))
        return records

    async def query(self, collection: str, request: VectorQuery) -> list[VectorHit]:
        filter_query = _backend_filter(request.filters, provider=self.provider)
        source_kwargs: dict[str, object] = {}
        if self.provider == "es" and not request.include_vectors:
            source_kwargs["source_excludes"] = ["vector", "*_vector"]
        raw_hits: list[dict[str, Any]]
        if request.vector is not None:
            raw_hits = await self._raw().vector_search(
                index=collection,
                field=request.vector_field,
                vector=request.vector,
                size=request.limit,
                filter_query=filter_query,
                include_vector=request.include_vectors,
            )
        elif request.text:
            from zleap.sag.core.adapters.capabilities import require_capability

            require_capability(self, Capability.LEXICAL_SEARCH, context="VectorQuery.text")
            text_fields = list(request.text_fields or ("content",))
            lexical = {"multi_match": {"query": request.text, "fields": text_fields}}
            query: dict[str, Any] = lexical
            if filter_query:
                query = {"bool": {"must": [lexical], "filter": [filter_query]}}
            response = await self._raw().search(
                index=collection,
                query=query,
                size=request.limit,
                return_full_response=True,
                **source_kwargs,
            )
            raw_hits = [
                {
                    **(hit.get("source") or {}),
                    "id": hit.get("id"),
                    "_score": hit.get("score"),
                }
                for hit in response.get("hits", [])
            ]
        else:
            query = {"bool": {"filter": [filter_query]}} if filter_query else {"match_all": {}}
            backend_sort: Any = request.sort
            if request.sort and self.provider == "es":
                backend_sort = [
                    {field: {"order": direction, "missing": "_last"}}
                    for field, direction in request.sort
                ]
            if request.distinct_field and self.provider != "es":
                raw_hits = await self._query_distinct_values(
                    collection,
                    query=query,
                    field=request.distinct_field,
                    limit=request.limit,
                    sort=request.sort,
                )
            else:
                kwargs: dict[str, Any] = {}
                if request.distinct_field:
                    kwargs["collapse"] = {"field": request.distinct_field}
                if request.sort:
                    kwargs["sort"] = backend_sort
                response = await self._raw().search(
                    index=collection,
                    query=query,
                    size=request.limit,
                    return_full_response=True,
                    **kwargs,
                    **source_kwargs,
                )
                raw_hits = self._response_hits(response)

        hits: list[VectorHit] = []
        for raw_hit in raw_hits:
            record_id, payload, vectors = _split_document(raw_hit)
            hits.append(
                VectorHit(
                    id=record_id,
                    score=float(raw_hit.get("_score") or 0.0),
                    payload=payload,
                    vectors=vectors if request.include_vectors else {},
                )
            )
        return hits

    @staticmethod
    def _response_hits(response: dict[str, Any]) -> list[dict[str, Any]]:
        return [
            {
                **(hit.get("source") or {}),
                "id": hit.get("id"),
                "_score": hit.get("score"),
            }
            for hit in response.get("hits", [])
        ]

    async def fetch_relation_vectors(
        self,
        index: str,
        *,
        filters: Filter | None = None,
        size: int = 10000,
    ) -> list[dict[str, Any]]:
        """按过滤条件取回候选关系向量的快速路径,交给上层精算余弦。

        事件侧候选有界时,不再做 filtered-kNN,而是按过滤条件全量取回
        event_id/entity_id/vector。返回行必须带 vector 字段。
        """
        filter_query = _backend_filter(filters, provider=self.provider)
        query = filter_query or {"match_all": {}}
        backend_kwargs: dict[str, Any] = (
            # ES 用 _source 投影 + _doc 文档序扫描;其余后端需要显式带出 vector 列
            {
                "sort": [{"_doc": "asc"}],
                "_source": {"includes": ["event_id", "entity_id", "vector"]},
            }
            if self.provider == "es"
            else {"include_vector": True}
        )
        response = await self._raw().search(
            index=index,
            query=query,
            size=size,
            return_full_response=True,
            **backend_kwargs,
        )
        return _relation_rows(response)

    async def _query_distinct_values(
        self,
        collection: str,
        *,
        query: dict[str, Any],
        field: str,
        limit: int,
        sort: tuple[tuple[str, str], ...] = (),
    ) -> list[dict[str, Any]]:
        """Page non-ES stores until ``limit`` distinct values have been collected."""
        page_size = max(100, min(limit, 1000))
        offset = 0
        seen: set[Any] = set()
        distinct_hits: list[dict[str, Any]] = []
        while len(distinct_hits) < limit:
            response = await self._raw().search(
                index=collection,
                query=query,
                size=page_size,
                from_=offset,
                return_full_response=True,
                sort=sort,
            )
            page = self._response_hits(response)
            if not page:
                break
            for hit in page:
                value = hit.get(field)
                if value is None or value in seen:
                    continue
                seen.add(value)
                distinct_hits.append(hit)
                if len(distinct_hits) == limit:
                    break
            offset += len(page)
            if len(page) < page_size:
                break
        return distinct_hits

    async def delete(self, collection: str, ids: Sequence[str]) -> BulkResult:
        succeeded: list[str] = []
        failed: list[FailedItem] = []
        for record_id in ids:
            try:
                deleted = await self._raw().delete_document(collection, record_id)
            except Exception as exc:  # noqa: BLE001 - normalize provider errors
                failed.append(FailedItem(record_id, safe_error_summary(exc)))
                continue
            if deleted:
                succeeded.append(record_id)
            else:
                succeeded.append(record_id)
        return BulkResult(tuple(succeeded), tuple(failed))

    async def publish(self, collections: Sequence[str]) -> None:
        """Strongly consistent stores already expose completed writes to queries."""
        del collections

    async def schema_object_names(self) -> frozenset[str]:
        if self.provider == "es":
            return await self._raw().schema_index_names()
        return await self._raw().schema_table_names()

    async def validate_schema_object(self, name: str, dimensions: int | None) -> None:
        if self.provider == "es":
            await self._raw().validate_declared_index(name, dimensions)
        else:
            await self._raw().validate_declared_table(name, dimensions)

    async def create_schema_object(self, name: str, dimensions: int) -> None:
        if self.provider == "es":
            await self._raw().create_declared_index(name, dimensions)
        else:
            await self._raw().create_declared_table(name, dimensions)

    async def optimize(self) -> bool:
        """写入完成后压实数据文件并建索引;返回是否全部成功。

        ES/pgvector/OceanBase 在写入时自身维护索引,无需外部触发(no-op → True);
        LanceDB 不会,必须显式调用,否则 kNN 一直是全表 brute-force。
        """
        optimize = getattr(self._raw(), "optimize", None)
        if optimize is None:
            return True
        return bool(await optimize())


class OpenAILLMAdapter:
    """包装 `core.ai.factory.create_llm_client`(OpenAI 兼容)。

    注:M1 先保持现有实现;litellm + instructor 作为后续可替换实现接入同一接口。
    """

    provider = "openai"

    def __init__(
        self,
        scenario: str = "general",
        model_config: dict[str, Any] | None = None,
        config: Any = None,
    ) -> None:
        self._scenario = scenario
        self._model_config = model_config or self._config_dict(config)
        self._client: Any = None

    @staticmethod
    def _config_dict(config: Any) -> dict[str, Any] | None:
        if config is None:
            return None
        return {
            "provider": getattr(config, "provider", "openai"),
            "model": config.model,
            "api_key": config.api_key,
            "base_url": config.base_url,
            "temperature": config.temperature,
            "max_tokens": config.max_tokens,
            "top_p": getattr(config, "top_p", 1.0),
            "frequency_penalty": getattr(config, "frequency_penalty", 0.0),
            "presence_penalty": getattr(config, "presence_penalty", 0.0),
            "timeout": config.timeout,
            "max_retries": config.max_retries,
            "enable_think": getattr(config, "enable_think", False),
            "structured_output_mode": config.structured_output_mode,
            "data_inspection": getattr(config, "data_inspection", True),
        }

    async def _get(self) -> Any:
        if self._client is None:
            from zleap.sag.core.ai.factory import create_llm_client

            if self._model_config is None:
                raise ConfigError("OpenAILLMAdapter 需要显式注入 config")
            self._client = await create_llm_client(
                scenario=self._scenario,
                model_config=self._model_config,
            )
        return self._client

    async def chat(self, messages: Sequence[Any], **kwargs: Any) -> Any:
        return await (await self._get()).chat(messages, **kwargs)

    async def chat_with_schema(
        self, messages: Sequence[Any], response_schema: dict[str, Any], **kwargs: Any
    ) -> Any:
        return await (await self._get()).chat_with_schema(
            messages, response_schema=response_schema, **kwargs
        )

    async def chat_with_schema_once(
        self, messages: Sequence[Any], response_schema: dict[str, Any], **kwargs: Any
    ) -> Any:
        client = await self._get()
        method = getattr(client, "chat_with_schema_once", None)
        if method is None:
            method = client.chat_with_schema
        return await method(messages, response_schema=response_schema, **kwargs)

    async def close(self) -> None:
        client = self._client
        try:
            if client is None:
                return
            close = getattr(client, "close", None)
            if close is not None:
                await close()
        finally:
            self._client = None


class OpenAIVLMAdapter(OpenAILLMAdapter):
    """使用显式 VLM 配置惰性创建 OpenAI 兼容的多模态客户端。"""

    provider = "openai"

    async def _get(self) -> Any:
        if self._client is None:
            from zleap.sag.core.ai.factory import create_vlm_client

            if self._model_config is None:
                raise ConfigError("OpenAIVLMAdapter 需要显式注入 config")
            self._client = await create_vlm_client(
                scenario=self._scenario,
                model_config=self._model_config,
            )
        return self._client


class OpenAIEmbeddingAdapter:
    """包装当前 Engine 显式配置的 Embedding 客户端。"""

    provider = "openai"

    def __init__(self, scenario: str = "general", config: Any = None) -> None:
        self._scenario = scenario
        self._config = config
        self._client: Any = None

    async def _get(self) -> Any:
        if self._client is None:
            from zleap.sag.core.ai.factory import create_embedding_client

            if self._config is None:
                raise ConfigError("OpenAIEmbeddingAdapter 需要显式注入 config")
            explicit = self._config.model_dump()
            self._client = await create_embedding_client(
                scenario=self._scenario,
                embedding_config=explicit,
            )
        return self._client

    async def generate(self, text: str) -> list[float]:
        return await (await self._get()).generate(text)

    async def batch_generate(self, texts: list[str]) -> list[list[float]]:
        return await (await self._get()).batch_generate(texts)

    async def close(self) -> None:
        if self._client is not None:
            client = getattr(self._client, "client", None)
            close = getattr(client, "close", None)
            if close is not None:
                await close()
        self._client = None


class HTTPRerankAdapter:
    """包装当前 Engine 显式配置的 Rerank 客户端。"""

    provider = "openai"

    def __init__(self, config: Any = None, prompt_manager: Any = None) -> None:
        self._config = config
        self._prompt_manager = prompt_manager
        self._client: Any = None

    def _get(self) -> Any:
        if self._client is None:
            from zleap.sag.core.ai.rerank import RerankClient

            if self._config is None:
                raise ConfigError("当前 Engine 未配置 rerank")
            self._client = RerankClient(
                model=self._config.model,
                base_url=self._config.base_url,
                api_key=self._config.api_key,
                endpoint=self._config.endpoint,
                prompt_manager=self._prompt_manager,
                timeout=getattr(self._config, "timeout", 30),
            )
        return self._client

    async def rerank(
        self,
        query: str,
        documents: list[dict[str, str]],
        top_n: int | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        return await self._get().rerank(query, documents, top_n=top_n, **kwargs)

    async def close(self) -> None:
        self._client = None


class ESVectorStore(_VectorStoreOperations):
    """实例级 Elasticsearch 向量 Store。"""

    provider = "es"
    capabilities = frozenset(
        {Capability.VECTOR_KNN, Capability.FILTERED_KNN, Capability.LEXICAL_SEARCH}
    )

    def __init__(
        self,
        config: Any = None,
        *,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
    ) -> None:
        self._config = config
        self._storage_mode = storage_mode
        self._embedding_dimensions = embedding_dimensions
        self._client: Any = None

    def _raw(self) -> Any:
        if self._client is None:
            from zleap.sag.core.storage.elasticsearch import ElasticsearchClient, ESConfig

            if self._config is None:
                raise ConfigError("ESVectorStore 需要显式注入 config")
            config = ESConfig(
                hosts=self._config.hosts,
                username=self._config.username,
                password=self._config.password,
                timeout=self._config.timeout,
                max_connections=self._config.max_connections,
                max_retries=self._config.max_retries,
                verify_certs=self._config.verify_certs,
                ca_certs=self._config.ca_certs,
                client_cert=self._config.client_cert,
                client_key=self._config.client_key,
            )
            self._client = ElasticsearchClient(
                config=config,
                storage_mode=self._storage_mode,
                embedding_dimensions=self._embedding_dimensions,
            )
        return self._client

    async def upsert(self, collection: str, records: Sequence[VectorRecord]) -> BulkResult:
        """Keep ES routing internal while exposing only the neutral port."""
        batches: dict[str | None, list[VectorRecord]] = {}
        for record in records:
            route_value = record.payload.get("data_source_id")
            route = str(route_value) if route_value not in (None, "") else None
            batches.setdefault(route, []).append(record)

        error_by_id: dict[str, str] = {}
        for route, batch in batches.items():
            documents = [{"id": record.id, **record.payload, **record.vectors} for record in batch]
            try:
                detail = await self._raw().bulk_index(
                    collection,
                    documents,
                    return_details=True,
                    routing=route,
                )
            except Exception as exc:  # noqa: BLE001 - normalize provider errors
                error_by_id.update({record.id: safe_error_summary(exc) for record in batch})
                continue
            normalized = _bulk_result_from_detail(batch, detail)
            error_by_id.update({item.id: item.error for item in normalized.failed_items})

        return BulkResult(
            succeeded_ids=tuple(record.id for record in records if record.id not in error_by_id),
            failed_items=tuple(
                FailedItem(record.id, error_by_id[record.id])
                for record in records
                if record.id in error_by_id
            ),
        )

    async def get_many(self, collection: str, ids: Sequence[str]) -> list[VectorRecord]:
        """Search by ID across shards because records use data-source routing."""
        found: dict[str, VectorRecord] = {}
        for offset in range(0, len(ids), 5000):
            batch_ids = list(ids[offset : offset + 5000])
            response = await self._raw().search(
                index=collection,
                query={"ids": {"values": batch_ids}},
                size=len(batch_ids),
                return_full_response=True,
            )
            for hit in response.get("hits", []):
                record_id = str(hit.get("id") or "")
                if not record_id:
                    continue
                _, payload, vectors = _split_document(hit.get("source") or {}, known_id=record_id)
                found[record_id] = VectorRecord(record_id, payload, vectors)
        return [found[record_id] for record_id in ids if record_id in found]

    async def delete(self, collection: str, ids: Sequence[str]) -> BulkResult:
        """Resolve routing internally so historical routed documents remain deletable."""
        records = {record.id: record for record in await self.get_many(collection, ids)}
        succeeded: list[str] = []
        failed: list[FailedItem] = []
        for record_id in ids:
            record = records.get(record_id)
            if record is None:
                succeeded.append(record_id)
                continue
            route_value = record.payload.get("data_source_id")
            route = str(route_value) if route_value not in (None, "") else None
            try:
                deleted = await self._raw().delete_document(collection, record_id, routing=route)
            except Exception as exc:  # noqa: BLE001 - normalize provider errors
                failed.append(FailedItem(record_id, safe_error_summary(exc)))
                continue
            if deleted:
                succeeded.append(record_id)
            else:
                succeeded.append(record_id)
        return BulkResult(tuple(succeeded), tuple(failed))

    async def publish(self, collections: Sequence[str]) -> None:
        """Cross Elasticsearch's near-real-time boundary before manifest activation."""
        from zleap.sag.exceptions import VectorSyncError

        targets = tuple(dict.fromkeys(collections))
        if not targets:
            return
        try:
            await self._raw().refresh_indexes(targets)
        except Exception as exc:
            raise VectorSyncError(
                provider=self.provider,
                collection=",".join(targets),
                failed_ids=["query_visibility"],
                reason=type(exc).__name__,
            ) from exc

    async def close(self) -> None:
        if self._client is not None:
            await self._client.close()
        self._client = None

    async def ping(self, timeout: float = 5.0) -> None:
        """连通性检查:失败抛 StorageError(带清晰提示)。"""
        import asyncio

        from zleap.sag.exceptions import StorageError

        client = self._raw()  # 构造/首次导入不计入超时窗口

        async def _check() -> None:
            ok = await client.ping()
            if not ok:
                raise StateError("ping 返回 False")

        try:
            await asyncio.wait_for(_check(), timeout=timeout)
        except Exception as e:
            raise StorageError(safe_error_summary(e, label="Elasticsearch 连接失败")) from e


class LanceDBVectorStore(_VectorStoreOperations):
    """实例级 LanceDB 本地嵌入式后端。

    自带 tantivy BM25 全文检索，声明 LEXICAL_SEARCH，生产搜索 Profile 本地可用。
    """

    provider = "lancedb"
    capabilities = frozenset(
        {Capability.VECTOR_KNN, Capability.FILTERED_KNN, Capability.LEXICAL_SEARCH}
    )

    def __init__(
        self,
        config: Any = None,
        *,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
    ) -> None:
        self._config = config
        self._storage_mode = storage_mode
        self._embedding_dimensions = embedding_dimensions
        self._client: Any = None

    def _raw(self) -> Any:
        if self._client is None:
            from zleap.sag.config import LanceDBVectorConfig
            from zleap.sag.core.storage.lancedb_store import LanceDBStore

            config = self._config or LanceDBVectorConfig(path="./.zleap/lancedb")
            self._client = LanceDBStore(
                config.path,
                storage_mode=self._storage_mode,
                embedding_dimensions=self._embedding_dimensions,
            )
        return self._client

    async def close(self) -> None:
        if self._client is not None:
            await self._client.close()
        self._client = None

    async def ping(self, timeout: float = 5.0) -> None:
        """连通性检查:失败抛 StorageError(带清晰提示)。"""
        import asyncio

        from zleap.sag.exceptions import StorageError

        client = self._raw()  # 构造/首次导入(lancedb 原生库冷加载)不计入超时窗口

        async def _check() -> None:
            ok = await client.ping()
            if not ok:
                raise StateError("ping 返回 False")

        try:
            await asyncio.wait_for(_check(), timeout=timeout)
        except Exception as e:
            raise StorageError(safe_error_summary(e, label="LanceDB 连接失败")) from e


class PgVectorStoreAdapter(_VectorStoreOperations):
    """使用专属 PostgreSQL runtime 的 pgvector 后端。

    注意:pgvector 的全文检索是 ILIKE 降级,非真 BM25,故不声明 LEXICAL_SEARCH;
    需要真词法检索的生产 Profile 会被 capability 校验显式拒绝。
    """

    provider = "pgvector"
    capabilities = frozenset({Capability.VECTOR_KNN, Capability.FILTERED_KNN})

    def __init__(
        self,
        config: Any = None,
        *,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
    ) -> None:
        self._config = config
        self._storage_mode = storage_mode
        self._embedding_dimensions = embedding_dimensions
        self._runtime: Any = None
        self._client: Any = None

    def _raw(self) -> Any:
        if self._client is None:
            if self._config is None:
                raise ConfigError("PgVectorStoreAdapter 需要独立 PgVectorConfig")
            from zleap.sag.core.storage.pgvector_store import PgVectorStore
            from zleap.sag.core.storage.runtime import SqlRuntime

            self._runtime = SqlRuntime(self._config.connection)
            self._client = PgVectorStore(
                runtime=self._runtime,
                storage_mode=self._storage_mode,
                embedding_dimensions=self._embedding_dimensions,
            )
        return self._client

    @property
    def runtime(self) -> Any:
        """向量侧专属 PostgreSQL runtime。"""
        if self._runtime is None:
            self._raw()
        return self._runtime

    async def close(self) -> None:
        if self._runtime is not None:
            await self._runtime.close()
        self._client = None
        self._runtime = None

    async def ping(self, timeout: float = 5.0) -> None:
        """连通性检查:失败抛 StorageError(带清晰提示)。"""
        import asyncio

        from zleap.sag.exceptions import StorageError

        client = self._raw()  # 构造/首次导入不计入超时窗口

        async def _check() -> None:
            ok = await client.ping()
            if not ok:
                raise StateError("ping 返回 False")

        try:
            await asyncio.wait_for(_check(), timeout=timeout)
        except Exception as e:
            raise StorageError(safe_error_summary(e, label="pgvector 连接失败")) from e


class ParadeDBVectorStoreAdapter(_VectorStoreOperations):
    """ParadeDB 单库后端:pgvector 向量 + pg_search 真 BM25。

    与裸 pgvector 的唯一能力差别是声明 LEXICAL_SEARCH——pg_search 提供 Tantivy
    BM25 与 ``paradedb.score`` 真实分数,故 pruned_expand_llm / pruned_expand_rff
    在该后端可用。裸 pgvector 继续 fail-fast(未装扩展时静默降级到 ILIKE 更糟)。
    """

    provider = "paradedb"
    capabilities = frozenset(
        {Capability.VECTOR_KNN, Capability.FILTERED_KNN, Capability.LEXICAL_SEARCH}
    )

    def __init__(
        self,
        config: Any = None,
        *,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
        language: str = "en",
    ) -> None:
        self._config = config
        self._storage_mode = storage_mode
        self._embedding_dimensions = embedding_dimensions
        self._language = language
        self._runtime: Any = None
        self._client: Any = None

    def _raw(self) -> Any:
        if self._client is None:
            if self._config is None:
                raise ConfigError("ParadeDBVectorStoreAdapter 需要独立 ParadeDBVectorConfig")
            from zleap.sag.core.storage.paradedb_store import ParadeDBStore
            from zleap.sag.core.storage.runtime import SqlRuntime

            self._runtime = SqlRuntime(self._config.connection)
            self._client = ParadeDBStore(
                runtime=self._runtime,
                storage_mode=self._storage_mode,
                embedding_dimensions=self._embedding_dimensions,
                language=self._language,
            )
        return self._client

    @property
    def runtime(self) -> Any:
        """向量侧专属 PostgreSQL runtime。"""
        if self._runtime is None:
            self._raw()
        return self._runtime

    async def close(self) -> None:
        if self._runtime is not None:
            await self._runtime.close()
        self._client = None
        self._runtime = None

    async def ping(self, timeout: float = 5.0) -> None:
        """连通性检查:失败抛 StorageError(带清晰提示)。"""
        import asyncio

        from zleap.sag.exceptions import StorageError

        client = self._raw()  # 构造/首次导入不计入超时窗口

        async def _check() -> None:
            ok = await client.ping()
            if not ok:
                raise StateError("ping 返回 False")

        try:
            await asyncio.wait_for(_check(), timeout=timeout)
        except Exception as e:
            raise StorageError(safe_error_summary(e, label="ParadeDB 连接失败")) from e


class OceanBaseVectorStoreAdapter(_VectorStoreOperations):
    """使用专属 OceanBase runtime 的向量后端。

    OceanBase 向量全文为 LIKE 降级,非真 BM25,故不声明 LEXICAL_SEARCH;
    需要真词法检索的生产 Profile 会被 capability 校验显式拒绝（与 pgvector 一致）。
    """

    provider = "oceanbase"
    capabilities = frozenset({Capability.VECTOR_KNN, Capability.FILTERED_KNN})

    def __init__(
        self,
        config: Any = None,
        *,
        storage_mode: str = "normal",
        embedding_dimensions: int | None = None,
    ) -> None:
        self._config = config
        self._storage_mode = storage_mode
        self._embedding_dimensions = embedding_dimensions
        self._runtime: Any = None
        self._client: Any = None

    def _raw(self) -> Any:
        if self._client is None:
            if self._config is None:
                raise ConfigError("OceanBaseVectorStoreAdapter 需要独立 OceanBaseVectorConfig")
            from zleap.sag.core.storage.oceanbase_store import OceanBaseVectorStore
            from zleap.sag.core.storage.runtime import SqlRuntime

            self._runtime = SqlRuntime(self._config.connection)
            self._client = OceanBaseVectorStore(
                runtime=self._runtime,
                storage_mode=self._storage_mode,
                embedding_dimensions=self._embedding_dimensions,
            )
        return self._client

    @property
    def runtime(self) -> Any:
        """向量侧专属 OceanBase runtime。"""
        if self._runtime is None:
            self._raw()
        return self._runtime

    async def close(self) -> None:
        if self._runtime is not None:
            await self._runtime.close()
        self._client = None
        self._runtime = None

    async def ping(self, timeout: float = 5.0) -> None:
        """连通性检查:失败抛 StorageError(带清晰提示)。"""
        import asyncio

        from zleap.sag.exceptions import StorageError

        client = self._raw()  # 构造/首次导入不计入超时窗口

        async def _check() -> None:
            ok = await client.ping()
            if not ok:
                raise StateError("ping 返回 False")

        try:
            await asyncio.wait_for(_check(), timeout=timeout)
        except Exception as e:
            raise StorageError(safe_error_summary(e, label="OceanBase 连接失败")) from e


class SqlAlchemyRelationalStore:
    """拥有独立 SQL runtime 的关系 Store。"""

    capabilities = frozenset({Capability.UPSERT})

    def __init__(self, provider: str = "mysql", config: Any = None) -> None:
        from zleap.sag.config import RelationalConfig
        from zleap.sag.core.storage.runtime import SqlRuntime

        self._config = config or RelationalConfig(
            provider=cast(Literal["mysql", "postgres", "sqlite", "oceanbase"], provider),
            path="./.zleap/sag.db" if provider == "sqlite" else "",
        )
        self.provider = self._config.provider
        self._runtime = SqlRuntime(self._config)

    def session_factory(self) -> Any:
        return self._runtime.session_factory()

    def session(self) -> Any:
        return self._runtime.session()

    def engine(self) -> Any:
        return self._runtime.engine()

    @property
    def runtime(self) -> Any:
        return self._runtime

    async def close(self) -> None:
        await self._runtime.close()

    async def ping(self, timeout: float = 5.0) -> None:
        """连通性检查(SELECT 1):失败抛 StorageError(带清晰提示)。"""
        import asyncio

        from sqlalchemy import text

        from zleap.sag.exceptions import StorageError

        async def _check() -> None:
            factory = self.session_factory()
            async with factory() as session:
                await session.execute(text("SELECT 1"))

        try:
            await asyncio.wait_for(_check(), timeout=timeout)
        except Exception as e:
            raise StorageError(
                safe_error_summary(e, label=f"关系库连接失败({self.provider})")
            ) from e
