"""Concurrency-limited adapters owned by one engine instance."""

from __future__ import annotations

import inspect
from collections.abc import Sequence
from typing import Any

from zleap.sag.core.adapters.models import BulkResult, VectorHit, VectorQuery, VectorRecord
from zleap.sag.runtime import RuntimeGovernor, RuntimeResource


async def _close(inner: Any) -> None:
    method = getattr(inner, "close", None)
    if method is None:
        return
    result = method()
    if inspect.isawaitable(result):
        await result


class LimitedLLMAdapter:
    provider = "limited"

    def __init__(self, inner: Any, governor: RuntimeGovernor) -> None:
        self.inner = inner
        self._governor = governor

    async def chat(self, messages: Sequence[Any], **kwargs: Any) -> Any:
        async with self._governor.slot(RuntimeResource.LLM):
            return await self.inner.chat(messages, **kwargs)

    async def chat_with_schema(
        self, messages: Sequence[Any], response_schema: dict[str, Any], **kwargs: Any
    ) -> Any:
        async with self._governor.slot(RuntimeResource.LLM):
            return await self.inner.chat_with_schema(
                messages, response_schema=response_schema, **kwargs
            )

    async def chat_with_schema_once(
        self, messages: Sequence[Any], response_schema: dict[str, Any], **kwargs: Any
    ) -> Any:
        method = getattr(self.inner, "chat_with_schema_once", None)
        async with self._governor.slot(RuntimeResource.LLM):
            if method is not None:
                return await method(messages, response_schema=response_schema, **kwargs)
            return await self.inner.chat_with_schema(
                messages, response_schema=response_schema, **kwargs
            )

    async def close(self) -> None:
        await _close(self.inner)


class LimitedEmbeddingAdapter:
    provider = "limited"

    def __init__(self, inner: Any, governor: RuntimeGovernor) -> None:
        self.inner = inner
        self._governor = governor

    async def generate(self, text: str) -> list[float]:
        async with self._governor.slot(RuntimeResource.EMBEDDING):
            return await self.inner.generate(text)

    async def batch_generate(self, texts: list[str]) -> list[list[float]]:
        async with self._governor.slot(RuntimeResource.EMBEDDING):
            return await self.inner.batch_generate(texts)

    async def close(self) -> None:
        await _close(self.inner)


class LimitedRerankAdapter:
    provider = "limited"

    def __init__(self, inner: Any, governor: RuntimeGovernor) -> None:
        self.inner = inner
        self._governor = governor

    async def rerank(
        self,
        query: str,
        documents: list[dict[str, str]],
        top_n: int | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        async with self._governor.slot(RuntimeResource.RERANK):
            return await self.inner.rerank(query, documents, top_n=top_n, **kwargs)

    async def close(self) -> None:
        await _close(self.inner)


class LimitedVectorStore:
    """Limit writes while leaving reads under the engine-level search budget."""

    def __init__(self, inner: Any, governor: RuntimeGovernor) -> None:
        self.inner = inner
        self._governor = governor
        self.provider = inner.provider
        self.capabilities = inner.capabilities

    async def upsert(self, collection: str, records: Sequence[VectorRecord]) -> BulkResult:
        async with self._governor.slot(RuntimeResource.VECTOR_WRITE):
            return await self.inner.upsert(collection, records)

    async def get_many(self, collection: str, ids: Sequence[str]) -> list[VectorRecord]:
        return await self.inner.get_many(collection, ids)

    async def query(self, collection: str, request: VectorQuery) -> list[VectorHit]:
        return await self.inner.query(collection, request)

    async def delete(self, collection: str, ids: Sequence[str]) -> BulkResult:
        async with self._governor.slot(RuntimeResource.VECTOR_WRITE):
            return await self.inner.delete(collection, ids)

    async def publish(self, collections: Sequence[str]) -> None:
        async with self._governor.slot(RuntimeResource.VECTOR_WRITE):
            await self.inner.publish(collections)

    async def schema_object_names(self) -> frozenset[str]:
        return await self.inner.schema_object_names()

    async def validate_schema_object(self, name: str, dimensions: int | None) -> None:
        await self.inner.validate_schema_object(name, dimensions)

    async def create_schema_object(self, name: str, dimensions: int) -> None:
        async with self._governor.slot(RuntimeResource.VECTOR_WRITE):
            await self.inner.create_schema_object(name, dimensions)

    async def optimize(self) -> bool:
        async with self._governor.slot(RuntimeResource.VECTOR_WRITE):
            return bool(await self.inner.optimize())

    async def ping(self, timeout: float = 5.0) -> None:
        await self.inner.ping(timeout)

    async def close(self) -> None:
        await self.inner.close()


__all__ = [
    "LimitedEmbeddingAdapter",
    "LimitedLLMAdapter",
    "LimitedRerankAdapter",
    "LimitedVectorStore",
]
