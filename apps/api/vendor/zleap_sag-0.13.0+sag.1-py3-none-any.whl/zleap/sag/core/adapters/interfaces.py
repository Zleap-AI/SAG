"""后端适配器接口(Protocol)。

结构化接口:现有客户端只要方法匹配即满足,便于把既有实现包装为默认适配器,
也便于测试注入 fake。存储适配器额外声明 `capabilities` 与 `provider`。
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Protocol, runtime_checkable

from zleap.sag.core.adapters.capabilities import Capability
from zleap.sag.core.adapters.models import BulkResult, VectorHit, VectorQuery, VectorRecord


@runtime_checkable
class LLMAdapter(Protocol):
    """LLM 适配器:对话 + 结构化输出。"""

    async def chat(self, messages: Sequence[Any], **kwargs: Any) -> Any: ...

    async def chat_with_schema(
        self, messages: Sequence[Any], response_schema: dict[str, Any], **kwargs: Any
    ) -> Any: ...


@runtime_checkable
class EmbeddingAdapter(Protocol):
    """Embedding 适配器:单条 + 批量。"""

    async def generate(self, text: str) -> list[float]: ...

    async def batch_generate(self, texts: list[str]) -> list[list[float]]: ...


@runtime_checkable
class RerankAdapter(Protocol):
    """Rerank 适配器。"""

    async def rerank(
        self,
        query: str,
        documents: list[dict[str, str]],
        top_n: int | None = None,
        **kwargs: Any,
    ) -> list[dict[str, Any]]: ...


@runtime_checkable
class VectorStore(Protocol):
    """Provider-neutral vector storage contract."""

    provider: str
    capabilities: frozenset[Capability]

    async def upsert(self, collection: str, records: Sequence[VectorRecord]) -> BulkResult: ...

    async def get_many(self, collection: str, ids: Sequence[str]) -> list[VectorRecord]: ...

    async def query(self, collection: str, request: VectorQuery) -> list[VectorHit]: ...

    async def delete(self, collection: str, ids: Sequence[str]) -> BulkResult:
        """Idempotently delete IDs; already-absent IDs count as succeeded."""
        ...

    async def publish(self, collections: Sequence[str]) -> None:
        """Make all prior writes query-visible before an external manifest switch."""
        ...

    async def schema_object_names(self) -> frozenset[str]: ...

    async def validate_schema_object(self, name: str, dimensions: int | None) -> None: ...

    async def create_schema_object(self, name: str, dimensions: int) -> None: ...

    async def optimize(self) -> bool:
        """写入完成后压实并建索引;返回是否全部成功。

        后端自动维护索引时为 no-op 并返回 True。
        """
        ...

    async def ping(self, timeout: float = ...) -> None:
        """连通性检查;失败抛异常。"""
        ...

    async def close(self) -> None:
        """关闭本 Store 自己拥有的客户端/连接池。"""
        ...


@runtime_checkable
class RelationalStore(Protocol):
    """关系库适配器合同；连接、会话与生命周期均由实例独立持有。"""

    provider: str
    capabilities: frozenset[Capability]

    def session(self) -> Any:
        """创建只属于关系 Store 的一次 session。"""
        ...

    def session_factory(self) -> Any:
        """返回 async_sessionmaker,供仓储/引擎取会话。"""
        ...

    def engine(self) -> Any:
        """返回本关系 Store 拥有的 SQLAlchemy engine。"""
        ...

    async def ping(self, timeout: float = ...) -> None:
        """连通性检查;失败抛异常。"""
        ...

    async def close(self) -> None:
        """关闭本 Store 自己拥有的连接池。"""
        ...
