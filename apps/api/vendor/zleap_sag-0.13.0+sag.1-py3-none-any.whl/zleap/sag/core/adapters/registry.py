"""适配器工厂 + provider 注册表(对齐 cognee 的 create_*_engine)。

按 `provider` 名选择实现并实例化;支持运行时 `register` 注入自定义/测试适配器。
默认 provider 为零基础设施本地栈(llm/embedding/rerank=openai、vector=lancedb、
relational=sqlite),不显式配置即可本地零服务运行。
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from zleap.sag.core.adapters import defaults
from zleap.sag.core.adapters.capabilities import Capability
from zleap.sag.exceptions import ConfigError

# kind -> {provider -> factory(**kwargs) -> adapter}
_PROVIDERS: dict[str, dict[str, Callable[..., Any]]] = {
    "llm": {"openai": defaults.OpenAILLMAdapter},
    "vlm": {"openai": defaults.OpenAIVLMAdapter},
    "embedding": {"openai": defaults.OpenAIEmbeddingAdapter},
    "rerank": {"openai": defaults.HTTPRerankAdapter},
    "vector": {
        "es": defaults.ESVectorStore,
        "lancedb": defaults.LanceDBVectorStore,
        "pgvector": defaults.PgVectorStoreAdapter,
        "paradedb": defaults.ParadeDBVectorStoreAdapter,
        "oceanbase": defaults.OceanBaseVectorStoreAdapter,
    },
    "relational": {
        "mysql": lambda **kw: defaults.SqlAlchemyRelationalStore(provider="mysql", **kw),
        "postgres": lambda **kw: defaults.SqlAlchemyRelationalStore(provider="postgres", **kw),
        "sqlite": lambda **kw: defaults.SqlAlchemyRelationalStore(provider="sqlite", **kw),
        "oceanbase": lambda **kw: defaults.SqlAlchemyRelationalStore(provider="oceanbase", **kw),
    },
}

# 不显式配置时的默认 provider(= 零基础设施本地栈)
_DEFAULTS: dict[str, str] = {
    "llm": "openai",
    "vlm": "openai",
    "embedding": "openai",
    "rerank": "openai",
    "vector": "lancedb",
    "relational": "sqlite",
}


def register(kind: str, provider: str, factory: Callable[..., Any]) -> None:
    """注册(或覆盖)一个 provider 实现;用于扩展后端或测试注入。"""
    if kind not in _PROVIDERS:
        raise ConfigError(f"未知适配器类别 '{kind}';可选:{', '.join(_PROVIDERS)}")
    _PROVIDERS[kind][provider] = factory


def create(kind: str, provider: str | None = None, **kwargs: Any) -> Any:
    """按类别 + provider 创建适配器实例。provider 为空则用默认。"""
    if kind not in _PROVIDERS:
        raise ConfigError(f"未知适配器类别 '{kind}';可选:{', '.join(_PROVIDERS)}")
    name = provider or _DEFAULTS[kind]
    impls = _PROVIDERS[kind]
    if name not in impls:
        raise ConfigError(f"适配器 '{kind}' 无 provider '{name}';已注册:{', '.join(impls)}")
    return impls[name](**kwargs)


def create_llm(provider: str | None = None, **kwargs: Any) -> Any:
    return create("llm", provider, **kwargs)


def create_vlm(provider: str | None = None, **kwargs: Any) -> Any:
    return create("vlm", provider, **kwargs)


def create_embedding(provider: str | None = None, **kwargs: Any) -> Any:
    return create("embedding", provider, **kwargs)


def create_rerank(provider: str | None = None, **kwargs: Any) -> Any:
    return create("rerank", provider, **kwargs)


def create_vector_store(provider: str | None = None, **kwargs: Any) -> Any:
    return create("vector", provider, **kwargs)


def create_relational_store(provider: str | None = None, **kwargs: Any) -> Any:
    return create("relational", provider, **kwargs)


def capabilities(kind: str, provider: str | None = None, **kwargs: Any) -> frozenset[Capability]:
    """查询某后端声明的能力集合(存储类适配器)。"""
    inst = create(kind, provider, **kwargs)
    return getattr(inst, "capabilities", frozenset())


def available_providers(kind: str) -> list[str]:
    """列出某类别已注册的 provider 名。"""
    if kind not in _PROVIDERS:
        raise ConfigError(f"未知适配器类别 '{kind}';可选:{', '.join(_PROVIDERS)}")
    return sorted(_PROVIDERS[kind])
