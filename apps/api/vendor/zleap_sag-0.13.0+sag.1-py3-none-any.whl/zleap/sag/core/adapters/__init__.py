"""后端适配器层。

定义 LLM/Embedding/Rerank/VectorStore/RelationalStore 的适配器接口 + 能力模型 +
按 provider 名的工厂/注册表(对齐 cognee)。默认实现包装现有客户端,行为不变。

用法::

    from zleap.sag.core.adapters import registry
    emb = registry.create_embedding()            # 默认 openai
    vec = registry.create_vector_store("es")      # 显式选 provider
    caps = registry.capabilities("vector", "es")  # 查询能力
"""

from zleap.sag.core.adapters.capabilities import (
    Capability,
    MissingCapabilityError,
    has_capability,
    require_capability,
)
from zleap.sag.core.adapters.interfaces import (
    EmbeddingAdapter,
    LLMAdapter,
    RelationalStore,
    RerankAdapter,
    VectorStore,
)
from zleap.sag.core.adapters.models import (
    BulkResult,
    FailedItem,
    Filter,
    VectorHit,
    VectorQuery,
    VectorRecord,
)

__all__ = [
    "Capability",
    "BulkResult",
    "FailedItem",
    "Filter",
    "MissingCapabilityError",
    "has_capability",
    "require_capability",
    "LLMAdapter",
    "EmbeddingAdapter",
    "RerankAdapter",
    "VectorStore",
    "VectorHit",
    "VectorQuery",
    "VectorRecord",
    "RelationalStore",
]
