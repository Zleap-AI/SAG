"""Provider-neutral storage value objects."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from zleap.sag.exceptions import InvalidInputError

FilterOperator = Literal["eq", "in", "range", "exists", "and", "or", "not"]


@dataclass(frozen=True)
class Filter:
    """Backend-independent filter expression tree."""

    operator: FilterOperator
    field: str | None = None
    value: Any = None
    exact: bool = False
    children: tuple[Filter, ...] = ()

    @classmethod
    def eq(cls, field: str, value: Any, *, exact: bool = False) -> Filter:
        return cls("eq", field=field, value=value, exact=exact)

    @classmethod
    def one_of(cls, field: str, values: list[Any] | tuple[Any, ...]) -> Filter:
        return cls("in", field=field, value=tuple(values))

    @classmethod
    def range(cls, field: str, **bounds: Any) -> Filter:
        allowed = {"gt", "gte", "lt", "lte"}
        unknown = set(bounds) - allowed
        if unknown:
            raise InvalidInputError(f"未知 range 边界: {', '.join(sorted(unknown))}")
        return cls("range", field=field, value=dict(bounds))

    @classmethod
    def exists(cls, field: str) -> Filter:
        return cls("exists", field=field)

    @classmethod
    def all(cls, *children: Filter) -> Filter:
        return cls("and", children=tuple(children))

    @classmethod
    def any(cls, *children: Filter) -> Filter:
        return cls("or", children=tuple(children))

    @classmethod
    def negate(cls, child: Filter) -> Filter:
        return cls("not", children=(child,))


@dataclass(frozen=True)
class VectorRecord:
    """One logical record, with scalar payload and one or more named vectors."""

    id: str
    payload: dict[str, Any] = field(default_factory=dict)
    vectors: dict[str, list[float]] = field(default_factory=dict)


@dataclass(frozen=True)
class VectorQuery:
    """Vector, lexical, filter-only, or match-all query without backend DSL."""

    vector: list[float] | None = None
    vector_field: str = "vector"
    text: str | None = None
    text_fields: tuple[str, ...] = ()
    filters: Filter | None = None
    limit: int = 10
    include_vectors: bool = False
    sort: tuple[tuple[str, Literal["asc", "desc"]], ...] = ()
    distinct_field: str | None = None

    def __post_init__(self) -> None:
        if self.limit < 1:
            raise InvalidInputError("VectorQuery.limit 必须大于 0")
        if self.sort and (self.vector is not None or self.text):
            raise InvalidInputError("VectorQuery.sort 仅支持过滤或 match-all 查询")
        if self.distinct_field and (self.vector is not None or self.text):
            raise InvalidInputError("VectorQuery.distinct_field 仅支持过滤或 match-all 查询")


@dataclass(frozen=True)
class VectorHit:
    id: str
    score: float
    payload: dict[str, Any]
    vectors: dict[str, list[float]] = field(default_factory=dict)


@dataclass(frozen=True)
class FailedItem:
    id: str
    error: str


@dataclass(frozen=True)
class BulkResult:
    succeeded_ids: tuple[str, ...] = ()
    failed_items: tuple[FailedItem, ...] = ()

    @property
    def success_count(self) -> int:
        return len(self.succeeded_ids)

    @property
    def failure_count(self) -> int:
        return len(self.failed_items)
