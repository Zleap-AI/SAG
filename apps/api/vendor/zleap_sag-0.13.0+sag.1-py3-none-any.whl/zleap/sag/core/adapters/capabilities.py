"""适配器能力模型。

不同后端能力不齐(如 ES 有原生 BM25、pgvector 需 pg_trgm/tsvector、numpy 兜底无词法)。
每个存储适配器声明自己支持的 `Capability`,引擎在**配置/启动时**据此校验"策略 × 后端"
兼容性并 fail-fast 或选兜底,避免运行时静默出错。
"""

from __future__ import annotations

from enum import StrEnum

from zleap.sag.exceptions import SagError


class Capability(StrEnum):
    """后端能力标志。"""

    VECTOR_KNN = "vector_knn"  # 向量近邻检索
    FILTERED_KNN = "filtered_knn"  # 带过滤条件的向量检索
    LEXICAL_SEARCH = "lexical_search"  # 词法/BM25 检索
    GRAPH_RELATION_LOOKUP = "graph_relation_lookup"  # Event/Entity 双向关系查询
    RERANK = "rerank"  # 模型重排
    LLM_STRUCTURED_OUTPUT = "llm_structured_output"  # 结构化 LLM 输出
    SCOPE_RESOLUTION = "scope_resolution"  # 宿主业务范围解析
    UPSERT = "upsert"  # 幂等写入(ON CONFLICT / ON DUPLICATE KEY)


class MissingCapabilityError(SagError):
    """所需能力在当前后端不可用(由 `require_capability` 抛出)。"""

    _code = "sag.adapter.capability"
    _retryable = False

    def __init__(
        self,
        message: str,
        *,
        capability: str | None = None,
        provider: str | None = None,
    ) -> None:
        super().__init__(
            message,
            provider=provider,
            details={"capability": capability} if capability else None,
        )


def has_capability(obj: object, capability: Capability) -> bool:
    """判断适配器是否声明支持某能力。"""
    caps: frozenset[Capability] = getattr(obj, "capabilities", frozenset())
    return capability in caps


def require_capability(obj: object, capability: Capability, *, context: str = "") -> None:
    """断言适配器支持某能力,否则抛出带清晰提示的错误。"""
    if not has_capability(obj, capability):
        where = f"({context}) " if context else ""
        provider = getattr(obj, "provider", type(obj).__name__)
        raise MissingCapabilityError(
            f"{where}后端 '{provider}' 不支持能力 '{capability.value}';"
            "请更换后端或改用不依赖该能力的策略。",
            capability=capability.value,
            provider=provider,
        )
