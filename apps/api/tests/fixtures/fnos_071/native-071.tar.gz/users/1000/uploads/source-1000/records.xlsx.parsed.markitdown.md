## Sheet
| Record | Owner | Amount |
| --- | --- | --- |
| R001 | 1000 | 100 |
| NaN | NaN | NaN |
| Record | Owner | Amount |
| R002 | 1000 | 200 |
